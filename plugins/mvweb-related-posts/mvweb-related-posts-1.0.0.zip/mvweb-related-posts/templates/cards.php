<?php
/**
 * Related posts template — cards grid.
 *
 * Copy to `wp-content/themes/<theme>/mvweb-related-posts/cards.php` to override.
 *
 * @var array $args {
 *     @type WP_Post[] $posts    Related posts.
 *     @type string    $title    Block title.
 *     @type int       $columns  Grid columns.
 *     @type string    $template Template slug.
 *     @type int       $post_id  Source post ID.
 * }
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $args['posts'] ) || ! is_array( $args['posts'] ) ) {
	return;
}

$mvweb_rp_title   = isset( $args['title'] ) ? (string) $args['title'] : '';
$mvweb_rp_columns = isset( $args['columns'] ) ? (int) $args['columns'] : 3;
$mvweb_rp_thumb   = (bool) MVweb_RP_Settings::get( 'show_thumb', true );
$mvweb_rp_excerpt = (bool) MVweb_RP_Settings::get( 'show_excerpt', true );
?>
<aside class="mvweb-rp mvweb-rp--cards" aria-label="<?php echo esc_attr( '' !== $mvweb_rp_title ? $mvweb_rp_title : __( 'Related posts', 'mvweb-related-posts' ) ); ?>">
	<?php if ( '' !== $mvweb_rp_title ) : ?>
		<div class="mvweb-rp__title"><?php echo esc_html( $mvweb_rp_title ); ?></div>
	<?php endif; ?>

	<div class="mvweb-rp__grid" style="--mvweb-rp-columns:<?php echo esc_attr( (string) $mvweb_rp_columns ); ?>">
		<?php foreach ( $args['posts'] as $mvweb_rp_post ) : ?>
			<article class="mvweb-rp__card">
				<a class="mvweb-rp__link" href="<?php echo esc_url( (string) get_permalink( $mvweb_rp_post ) ); ?>">
					<?php
					if ( $mvweb_rp_thumb ) :
						$mvweb_rp_image = mvweb_rp_thumbnail_html( $mvweb_rp_post );
						if ( '' !== $mvweb_rp_image ) :
							?>
							<span class="mvweb-rp__thumb">
								<?php echo $mvweb_rp_image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- markup from wp_get_attachment_image() or an esc_url()'d placeholder. ?>
							</span>
							<?php
						endif;
					endif;
					?>
					<span class="mvweb-rp__body">
						<span class="mvweb-rp__card-title"><?php echo esc_html( get_the_title( $mvweb_rp_post ) ); ?></span>
						<?php if ( $mvweb_rp_excerpt ) : ?>
							<span class="mvweb-rp__excerpt"><?php echo esc_html( mvweb_rp_card_excerpt( $mvweb_rp_post ) ); ?></span>
						<?php endif; ?>
					</span>
				</a>
			</article>
		<?php endforeach; ?>
	</div>
</aside>
