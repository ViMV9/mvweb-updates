<?php
/**
 * Related posts template — plain link list.
 *
 * Copy to `wp-content/themes/<theme>/mvweb-related-posts/links.php` to override.
 *
 * @var array $args {
 *     @type WP_Post[] $posts    Related posts.
 *     @type string    $title    Block title.
 *     @type int       $columns  Grid columns (unused in this template).
 *     @type string    $template Template slug.
 *     @type int       $post_id  Source post ID.
 * }
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $args['posts'] ) || ! is_array( $args['posts'] ) ) {
	return;
}

$mvweb_rp_title = isset( $args['title'] ) ? (string) $args['title'] : '';
?>
<aside class="mvweb-rp mvweb-rp--links" aria-label="<?php echo esc_attr( '' !== $mvweb_rp_title ? $mvweb_rp_title : __( 'Related posts', 'mvweb-related-posts' ) ); ?>">
	<?php if ( '' !== $mvweb_rp_title ) : ?>
		<div class="mvweb-rp__title"><?php echo esc_html( $mvweb_rp_title ); ?></div>
	<?php endif; ?>

	<ul class="mvweb-rp__links">
		<?php foreach ( $args['posts'] as $mvweb_rp_post ) : ?>
			<li class="mvweb-rp__links-item">
				<a class="mvweb-rp__link" href="<?php echo esc_url( (string) get_permalink( $mvweb_rp_post ) ); ?>">
					<?php echo esc_html( get_the_title( $mvweb_rp_post ) ); ?>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</aside>
