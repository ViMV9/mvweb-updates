<?php
/**
 * Uninstall MVweb Related Posts
 *
 * Fired when the plugin is uninstalled.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

$mvweb_rp_options = array(
	'mvweb_rp_settings',
	'mvweb_rp_db_version',
	'mvweb_rp_full_reindex',
	'mvweb_rp_cache_version',
);

$mvweb_rp_meta_keys = array(
	'_mvweb_rp_dirty',
	'_mvweb_rp_indexed',
	'_mvweb_rp_pinned',
	'_mvweb_rp_excluded',
	'_mvweb_rp_hidden',
	'_mvweb_rp_no_suggest',
);

/**
 * Remove plugin data from the current site.
 *
 * @since 1.0.0
 * @param array $options   Option names.
 * @param array $meta_keys Post meta keys.
 * @return void
 */
function mvweb_rp_uninstall_site( array $options, array $meta_keys ) {
	global $wpdb;

	foreach ( $options as $option ) {
		delete_option( $option );
	}

	foreach ( $meta_keys as $meta_key ) {
		delete_post_meta_by_key( $meta_key );
	}

	$tokens = $wpdb->prefix . 'mvweb_rp_tokens';
	$index  = $wpdb->prefix . 'mvweb_rp_index';

	// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$wpdb->query( "DROP TABLE IF EXISTS {$tokens}" );
	$wpdb->query( "DROP TABLE IF EXISTS {$index}" );
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( '_transient_mvweb_rp_' ) . '%' ) );
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( '_transient_timeout_mvweb_rp_' ) . '%' ) );
	// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

	wp_clear_scheduled_hook( 'mvweb_rp_index_batch' );
}

if ( is_multisite() ) {
	foreach ( get_sites( array( 'fields' => 'ids' ) ) as $mvweb_rp_site_id ) {
		switch_to_blog( (int) $mvweb_rp_site_id );
		mvweb_rp_uninstall_site( $mvweb_rp_options, $mvweb_rp_meta_keys );
		restore_current_blog();
	}
} else {
	mvweb_rp_uninstall_site( $mvweb_rp_options, $mvweb_rp_meta_keys );
}

wp_cache_flush();
