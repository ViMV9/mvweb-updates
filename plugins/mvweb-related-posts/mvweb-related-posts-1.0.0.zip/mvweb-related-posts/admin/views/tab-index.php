<?php
/**
 * Index tab: state of the background indexer.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rp_stats = MVweb_RP_Indexer::stats();
$mvweb_rp_done  = isset( $_GET['mvweb_rp_done'] ) ? sanitize_key( wp_unslash( $_GET['mvweb_rp_done'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only notice flag.
?>

<?php if ( 'reindex' === $mvweb_rp_done ) : ?>
	<div class="mvweb-alert mvweb-alert--success">
		<?php esc_html_e( 'Index cleared. The first batch has been processed, the rest continues in the background.', 'mvweb-related-posts' ); ?>
	</div>
<?php endif; ?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Index state', 'mvweb-related-posts' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Scoring runs in the background: saving a post queues it, WP Cron processes the queue in batches.', 'mvweb-related-posts' ); ?></p>

	<div class="mvweb-table-wrap">
		<table class="mvweb-table">
			<tbody>
				<tr>
					<td><?php esc_html_e( 'Posts indexed', 'mvweb-related-posts' ); ?></td>
					<td><strong><?php echo esc_html( number_format_i18n( $mvweb_rp_stats['indexed'] ) ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Stored relations', 'mvweb-related-posts' ); ?></td>
					<td><strong><?php echo esc_html( number_format_i18n( $mvweb_rp_stats['relations'] ) ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Posts in queue', 'mvweb-related-posts' ); ?></td>
					<td><strong><?php echo esc_html( number_format_i18n( $mvweb_rp_stats['queued'] ) ); ?></strong></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Next scheduled run', 'mvweb-related-posts' ); ?></td>
					<td>
						<strong>
							<?php
							echo $mvweb_rp_stats['next_run']
								? esc_html( wp_date( 'd.m.Y H:i', $mvweb_rp_stats['next_run'] ) )
								: esc_html__( 'not scheduled', 'mvweb-related-posts' );
							?>
						</strong>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Rebuild', 'mvweb-related-posts' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Run this after changing weights, taxonomies or post types — stored relations are recalculated from scratch.', 'mvweb-related-posts' ); ?></p>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="<?php echo esc_attr( MVweb_RP_Admin::REINDEX_ACTION ); ?>">
		<?php wp_nonce_field( MVweb_RP_Admin::REINDEX_ACTION ); ?>
		<button type="submit" class="mvweb-btn"><?php esc_html_e( 'Rebuild the whole index', 'mvweb-related-posts' ); ?></button>
	</form>
</div>
