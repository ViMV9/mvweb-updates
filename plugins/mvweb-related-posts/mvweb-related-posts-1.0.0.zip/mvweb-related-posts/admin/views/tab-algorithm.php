<?php
/**
 * Algorithm tab: preset, weights, taxonomies and exclusions.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rp_presets = array(
	'blog'     => __( 'Blog', 'mvweb-related-posts' ),
	'services' => __( 'Service catalogue', 'mvweb-related-posts' ),
	'strict'   => __( 'Strict topical match', 'mvweb-related-posts' ),
	'custom'   => __( 'Custom weights', 'mvweb-related-posts' ),
);

$mvweb_rp_taxonomies = get_taxonomies(
	array( 'public' => true ),
	'objects'
);
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Relevance profile', 'mvweb-related-posts' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Presets set all weights at once. Pick "Custom weights" to tune each factor by hand.', 'mvweb-related-posts' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-preset"><?php esc_html_e( 'Preset', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<select class="mvweb-select" id="mvweb-rp-preset" name="<?php echo esc_attr( $mvweb_rp_option ); ?>[preset]">
				<?php foreach ( $mvweb_rp_presets as $mvweb_rp_preset_key => $mvweb_rp_preset_label ) : ?>
					<option value="<?php echo esc_attr( $mvweb_rp_preset_key ); ?>" <?php selected( $mvweb_rp_settings['preset'], $mvweb_rp_preset_key ); ?>>
						<?php echo esc_html( $mvweb_rp_preset_label ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>

	<?php foreach ( MVweb_RP_Settings::WEIGHT_KEYS as $mvweb_rp_weight_key ) : ?>
		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-rp-<?php echo esc_attr( $mvweb_rp_weight_key ); ?>">
				<?php echo esc_html( MVweb_RP_Admin::weight_label( $mvweb_rp_weight_key ) ); ?>
			</label>
			<div class="mvweb-form-row__field mvweb-rp-slider">
				<input type="range" min="0" max="10" step="1"
					id="mvweb-rp-<?php echo esc_attr( $mvweb_rp_weight_key ); ?>"
					class="mvweb-rp-range"
					data-output="mvweb-rp-<?php echo esc_attr( $mvweb_rp_weight_key ); ?>-val"
					name="<?php echo esc_attr( $mvweb_rp_option ); ?>[<?php echo esc_attr( $mvweb_rp_weight_key ); ?>]"
					value="<?php echo esc_attr( (string) $mvweb_rp_settings[ $mvweb_rp_weight_key ] ); ?>">
				<input type="number" min="0" max="10" step="1"
					id="mvweb-rp-<?php echo esc_attr( $mvweb_rp_weight_key ); ?>-val"
					class="mvweb-input mvweb-rp-range-num"
					aria-label="<?php echo esc_attr( MVweb_RP_Admin::weight_label( $mvweb_rp_weight_key ) ); ?>"
					value="<?php echo esc_attr( (string) $mvweb_rp_settings[ $mvweb_rp_weight_key ] ); ?>">
			</div>
		</div>
	<?php endforeach; ?>

	<div class="mvweb-alert mvweb-alert--info">
		<?php esc_html_e( 'Weights from a preset overwrite the sliders on save. Switch the preset to "Custom weights" to keep your own values.', 'mvweb-related-posts' ); ?>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Taxonomies', 'mvweb-related-posts' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Categories and tags always participate. Add custom taxonomies that describe the topic.', 'mvweb-related-posts' ); ?></p>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Custom taxonomies', 'mvweb-related-posts' ); ?></span>
		<div class="mvweb-form-row__field">
			<?php foreach ( $mvweb_rp_taxonomies as $mvweb_rp_taxonomy ) : ?>
				<?php if ( in_array( $mvweb_rp_taxonomy->name, array( 'category', 'post_tag', 'post_format' ), true ) ) : ?>
					<?php continue; ?>
				<?php endif; ?>
				<label class="mvweb-check">
					<input type="checkbox"
						name="<?php echo esc_attr( $mvweb_rp_option ); ?>[taxonomies][]"
						value="<?php echo esc_attr( $mvweb_rp_taxonomy->name ); ?>"
						<?php checked( in_array( $mvweb_rp_taxonomy->name, (array) $mvweb_rp_settings['taxonomies'], true ) ); ?>>
					<span><?php echo esc_html( $mvweb_rp_taxonomy->labels->name ); ?></span>
				</label>
			<?php endforeach; ?>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Filters and exclusions', 'mvweb-related-posts' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-max-age"><?php esc_html_e( 'Maximum post age, months', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" min="0" max="240" step="1" class="mvweb-input"
				id="mvweb-rp-max-age"
				name="<?php echo esc_attr( $mvweb_rp_option ); ?>[max_age_months]"
				value="<?php echo esc_attr( (string) $mvweb_rp_settings['max_age_months'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( '0 — no age limit.', 'mvweb-related-posts' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-exclude-terms"><?php esc_html_e( 'Excluded term IDs', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" class="mvweb-input"
				id="mvweb-rp-exclude-terms"
				name="<?php echo esc_attr( $mvweb_rp_option ); ?>[exclude_terms]"
				value="<?php echo esc_attr( implode( ', ', (array) $mvweb_rp_settings['exclude_terms'] ) ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Comma separated category, tag or custom taxonomy term IDs. Posts carrying them never appear in the block.', 'mvweb-related-posts' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-exclude-posts"><?php esc_html_e( 'Excluded post IDs', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" class="mvweb-input"
				id="mvweb-rp-exclude-posts"
				name="<?php echo esc_attr( $mvweb_rp_option ); ?>[exclude_posts]"
				value="<?php echo esc_attr( implode( ', ', (array) $mvweb_rp_settings['exclude_posts'] ) ); ?>">
		</div>
	</div>
</div>

<div class="mvweb-submit">
	<button type="submit" class="mvweb-btn mvweb-btn--primary"><?php esc_html_e( 'Save Changes', 'mvweb-related-posts' ); ?></button>
</div>
