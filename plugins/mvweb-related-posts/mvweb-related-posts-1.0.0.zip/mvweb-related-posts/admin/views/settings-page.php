<?php
/**
 * Admin settings page template.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 * Reference: docs/ui-kit-reference.html
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rp_current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.

$mvweb_rp_settings = MVweb_RP_Settings::all();
$mvweb_rp_option   = MVweb_RP_Settings::OPTION;

$mvweb_rp_tabs = array(
	'general'   => array(
		'label' => __( 'General', 'mvweb-related-posts' ),
		'icon'  => 'grid',
	),
	'algorithm' => array(
		'label' => __( 'Algorithm', 'mvweb-related-posts' ),
		'icon'  => 'gear',
	),
	'design'    => array(
		'label' => __( 'Design', 'mvweb-related-posts' ),
		'icon'  => 'grid',
	),
	'index'     => array(
		'label' => __( 'Index', 'mvweb-related-posts' ),
		'icon'  => 'gear',
	),
	'help'      => array(
		'label' => __( 'Help', 'mvweb-related-posts' ),
		'icon'  => 'help',
	),
);

$mvweb_rp_icons = array(
	'grid' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'gear' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
	'help' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">RP</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Related Posts', 'mvweb-related-posts' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_RP_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $mvweb_rp_tabs as $mvweb_rp_tab_id => $mvweb_rp_tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $mvweb_rp_tab_id ); ?>"
						class="mvweb-nav__link <?php echo $mvweb_rp_current_tab === $mvweb_rp_tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						data-tab="<?php echo esc_attr( $mvweb_rp_tab_id ); ?>">
						<?php echo $mvweb_rp_icons[ $mvweb_rp_tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $mvweb_rp_tab['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors(); ?>

		<form method="post" action="options.php">
			<?php settings_fields( 'mvweb_rp_settings_group' ); ?>

			<div id="general" class="mvweb-tab-content <?php echo 'general' === $mvweb_rp_current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_RP_PATH . 'admin/views/tab-general.php'; ?>
			</div>

			<div id="algorithm" class="mvweb-tab-content <?php echo 'algorithm' === $mvweb_rp_current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_RP_PATH . 'admin/views/tab-algorithm.php'; ?>
			</div>

			<div id="design" class="mvweb-tab-content <?php echo 'design' === $mvweb_rp_current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_RP_PATH . 'admin/views/tab-design.php'; ?>
			</div>
		</form>

		<div id="index" class="mvweb-tab-content <?php echo 'index' === $mvweb_rp_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_RP_PATH . 'admin/views/tab-index.php'; ?>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo 'help' === $mvweb_rp_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_RP_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
