<?php
/**
 * General settings tab.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rp_post_types = get_post_types( array( 'public' => true ), 'objects' );
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Output', 'mvweb-related-posts' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Where and how the related posts block appears.', 'mvweb-related-posts' ); ?></p>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Plugin enabled', 'mvweb-related-posts' ); ?></span>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" name="<?php echo esc_attr( $mvweb_rp_option ); ?>[enabled]" value="1" <?php checked( $mvweb_rp_settings['enabled'] ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Render the block on the frontend', 'mvweb-related-posts' ); ?></span>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Automatic output', 'mvweb-related-posts' ); ?></span>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" name="<?php echo esc_attr( $mvweb_rp_option ); ?>[auto_output]" value="1" <?php checked( $mvweb_rp_settings['auto_output'] ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Append the block after post content', 'mvweb-related-posts' ); ?></span>
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Turn this off to place the block manually with the shortcode, the widget or the PHP function.', 'mvweb-related-posts' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Post types', 'mvweb-related-posts' ); ?></span>
		<div class="mvweb-form-row__field">
			<?php foreach ( $mvweb_rp_post_types as $mvweb_rp_type ) : ?>
				<label class="mvweb-check">
					<input type="checkbox"
						name="<?php echo esc_attr( $mvweb_rp_option ); ?>[post_types][]"
						value="<?php echo esc_attr( $mvweb_rp_type->name ); ?>"
						<?php checked( in_array( $mvweb_rp_type->name, (array) $mvweb_rp_settings['post_types'], true ) ); ?>>
					<span><?php echo esc_html( $mvweb_rp_type->labels->singular_name ); ?></span>
				</label>
			<?php endforeach; ?>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-count"><?php esc_html_e( 'Posts in the block', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" min="1" max="12" step="1" class="mvweb-input"
				id="mvweb-rp-count"
				name="<?php echo esc_attr( $mvweb_rp_option ); ?>[count]"
				value="<?php echo esc_attr( (string) $mvweb_rp_settings['count'] ); ?>">
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-min"><?php esc_html_e( 'Minimum posts to show the block', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" min="1" max="12" step="1" class="mvweb-input"
				id="mvweb-rp-min"
				name="<?php echo esc_attr( $mvweb_rp_option ); ?>[min_results]"
				value="<?php echo esc_attr( (string) $mvweb_rp_settings['min_results'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Below this number the block is not rendered at all.', 'mvweb-related-posts' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Category fallback', 'mvweb-related-posts' ); ?></span>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" name="<?php echo esc_attr( $mvweb_rp_option ); ?>[fallback_parent]" value="1" <?php checked( $mvweb_rp_settings['fallback_parent'] ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Top up short results with recent posts from the same category', 'mvweb-related-posts' ); ?></span>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-title"><?php esc_html_e( 'Block title', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" class="mvweb-input"
				id="mvweb-rp-title"
				name="<?php echo esc_attr( $mvweb_rp_option ); ?>[block_title]"
				value="<?php echo esc_attr( (string) $mvweb_rp_settings['block_title'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Rendered as a div, never as a heading — the block does not touch the article heading structure.', 'mvweb-related-posts' ); ?></p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Structured data', 'mvweb-related-posts' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'ItemList markup', 'mvweb-related-posts' ); ?></span>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" name="<?php echo esc_attr( $mvweb_rp_option ); ?>[schema_enabled]" value="1" <?php checked( $mvweb_rp_settings['schema_enabled'] ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Print JSON-LD ItemList next to the block', 'mvweb-related-posts' ); ?></span>
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Google shows ItemList rich results for courses, movies, recipes and restaurants only — for articles this markup is a machine-readable relation signal, not a search appearance feature.', 'mvweb-related-posts' ); ?></p>
		</div>
	</div>
</div>

<div class="mvweb-submit">
	<button type="submit" class="mvweb-btn mvweb-btn--primary"><?php esc_html_e( 'Save Changes', 'mvweb-related-posts' ); ?></button>
</div>
