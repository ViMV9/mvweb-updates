<?php
/**
 * Design tab: template, card contents and images.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rp_templates = array(
	'cards' => __( 'Cards grid', 'mvweb-related-posts' ),
	'list'  => __( 'List with a thumbnail on the left', 'mvweb-related-posts' ),
	'links' => __( 'Plain link list', 'mvweb-related-posts' ),
);

$mvweb_rp_aspects = array(
	'16-9' => __( '16:9', 'mvweb-related-posts' ),
	'4-3'  => __( '4:3', 'mvweb-related-posts' ),
	'1-1'  => __( '1:1', 'mvweb-related-posts' ),
);

$mvweb_rp_sizes = array_merge( get_intermediate_image_sizes(), array( 'full' ) );
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Layout', 'mvweb-related-posts' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-template"><?php esc_html_e( 'Template', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<select class="mvweb-select" id="mvweb-rp-template" name="<?php echo esc_attr( $mvweb_rp_option ); ?>[template]">
				<?php foreach ( $mvweb_rp_templates as $mvweb_rp_template_key => $mvweb_rp_template_label ) : ?>
					<option value="<?php echo esc_attr( $mvweb_rp_template_key ); ?>" <?php selected( $mvweb_rp_settings['template'], $mvweb_rp_template_key ); ?>>
						<?php echo esc_html( $mvweb_rp_template_label ); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Templates can be overridden by copying them from templates/ into your theme under mvweb-related-posts/.', 'mvweb-related-posts' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-columns"><?php esc_html_e( 'Grid columns', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" min="1" max="6" step="1" class="mvweb-input"
				id="mvweb-rp-columns"
				name="<?php echo esc_attr( $mvweb_rp_option ); ?>[columns]"
				value="<?php echo esc_attr( (string) $mvweb_rp_settings['columns'] ); ?>">
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Card contents', 'mvweb-related-posts' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Thumbnail', 'mvweb-related-posts' ); ?></span>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" name="<?php echo esc_attr( $mvweb_rp_option ); ?>[show_thumb]" value="1" <?php checked( $mvweb_rp_settings['show_thumb'] ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Show the image', 'mvweb-related-posts' ); ?></span>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Excerpt', 'mvweb-related-posts' ); ?></span>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" name="<?php echo esc_attr( $mvweb_rp_option ); ?>[show_excerpt]" value="1" <?php checked( $mvweb_rp_settings['show_excerpt'] ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Show a short excerpt', 'mvweb-related-posts' ); ?></span>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-excerpt-words"><?php esc_html_e( 'Excerpt length, words', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" min="5" max="60" step="1" class="mvweb-input"
				id="mvweb-rp-excerpt-words"
				name="<?php echo esc_attr( $mvweb_rp_option ); ?>[excerpt_words]"
				value="<?php echo esc_attr( (string) $mvweb_rp_settings['excerpt_words'] ); ?>">
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Images', 'mvweb-related-posts' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Source order: featured image, then the first image in the content, then the placeholder.', 'mvweb-related-posts' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-image-size"><?php esc_html_e( 'Image size', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<select class="mvweb-select" id="mvweb-rp-image-size" name="<?php echo esc_attr( $mvweb_rp_option ); ?>[image_size]">
				<?php foreach ( $mvweb_rp_sizes as $mvweb_rp_size ) : ?>
					<option value="<?php echo esc_attr( $mvweb_rp_size ); ?>" <?php selected( $mvweb_rp_settings['image_size'], $mvweb_rp_size ); ?>>
						<?php echo esc_html( $mvweb_rp_size ); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'mvweb_rp_thumb is registered by this plugin. Images uploaded before activation need regeneration to get that size.', 'mvweb-related-posts' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-aspect"><?php esc_html_e( 'Aspect ratio', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<select class="mvweb-select" id="mvweb-rp-aspect" name="<?php echo esc_attr( $mvweb_rp_option ); ?>[aspect]">
				<?php foreach ( $mvweb_rp_aspects as $mvweb_rp_aspect_key => $mvweb_rp_aspect_label ) : ?>
					<option value="<?php echo esc_attr( $mvweb_rp_aspect_key ); ?>" <?php selected( $mvweb_rp_settings['aspect'], $mvweb_rp_aspect_key ); ?>>
						<?php echo esc_html( $mvweb_rp_aspect_label ); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Cropping happens in CSS with object-fit, so changing the ratio needs no image regeneration.', 'mvweb-related-posts' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-placeholder"><?php esc_html_e( 'Placeholder image URL', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="url" class="mvweb-input"
				id="mvweb-rp-placeholder"
				name="<?php echo esc_attr( $mvweb_rp_option ); ?>[placeholder_url]"
				value="<?php echo esc_attr( (string) $mvweb_rp_settings['placeholder_url'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Leave empty to use the neutral placeholder bundled with the plugin. Turn the thumbnail off above to render cards without images at all.', 'mvweb-related-posts' ); ?></p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Custom CSS', 'mvweb-related-posts' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Printed inline after the plugin stylesheet. Block variables: --mvweb-rp-gap, --mvweb-rp-columns, --mvweb-rp-ratio, --mvweb-rp-radius, --mvweb-rp-muted.', 'mvweb-related-posts' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-rp-custom-css"><?php esc_html_e( 'CSS', 'mvweb-related-posts' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea class="mvweb-textarea" rows="8"
				id="mvweb-rp-custom-css"
				name="<?php echo esc_attr( $mvweb_rp_option ); ?>[custom_css]"><?php echo esc_textarea( (string) $mvweb_rp_settings['custom_css'] ); ?></textarea>
		</div>
	</div>
</div>

<div class="mvweb-submit">
	<button type="submit" class="mvweb-btn mvweb-btn--primary"><?php esc_html_e( 'Save Changes', 'mvweb-related-posts' ); ?></button>
</div>
