<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-related-posts' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Pick post types', 'mvweb-related-posts' ); ?></strong>
			<p><?php esc_html_e( 'On the General tab select the post types that take part and save.', 'mvweb-related-posts' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Choose a relevance profile', 'mvweb-related-posts' ); ?></strong>
			<p><?php esc_html_e( 'On the Algorithm tab pick a preset, or switch to custom weights and tune each factor.', 'mvweb-related-posts' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Build the index', 'mvweb-related-posts' ); ?></strong>
			<p><?php esc_html_e( 'Open the Index tab and press "Rebuild the whole index". The rest is processed by WP Cron in batches.', 'mvweb-related-posts' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Check a post', 'mvweb-related-posts' ); ?></strong>
			<p><?php esc_html_e( 'Open any post in the editor: the Related posts metabox shows what was matched and how the score was built.', 'mvweb-related-posts' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Placing the block', 'mvweb-related-posts' ); ?></div>
	</div>

	<p><?php esc_html_e( 'Automatic output appends the block after post content. For manual placement use one of these:', 'mvweb-related-posts' ); ?></p>

	<div class="mvweb-codeblock">
		<code>[mvweb_related_posts count="4" template="cards" columns="3" title="Read also"]</code>
	</div>

	<div class="mvweb-codeblock">
		<code>&lt;?php mvweb_rp_related( array( 'count' =&gt; 4, 'template' =&gt; 'list' ) ); ?&gt;</code>
	</div>

	<div class="mvweb-codeblock">
		<code>&lt;?php $posts = mvweb_rp_get_related( get_the_ID(), 4 ); ?&gt;</code>
	</div>

	<p><?php esc_html_e( 'A sidebar widget named "MVweb Related Posts" is available as well.', 'mvweb-related-posts' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-related-posts' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The block does not appear. Why?', 'mvweb-related-posts' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Three usual reasons: the index is still building, fewer posts were found than the minimum on the General tab, or MVweb Smart Links prints its own related block — in that case automatic output here is paused on purpose.', 'mvweb-related-posts' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How does the matching work?', 'mvweb-related-posts' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Every candidate gets a score from six factors: shared categories, shared tags, shared custom taxonomy terms, title word match, content word match and freshness. Russian words are reduced to stems first, so different word forms match each other.', 'mvweb-related-posts' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Does the ItemList markup give a rich result?', 'mvweb-related-posts' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'No. Google renders ItemList carousels for courses, movies, recipes and restaurants only. For an article block the markup stays a valid, machine-readable relation signal without a search appearance change.', 'mvweb-related-posts' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How do I change the markup?', 'mvweb-related-posts' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Copy a file from the plugin templates/ folder into your theme as mvweb-related-posts/cards.php, list.php or links.php. The theme copy wins.', 'mvweb-related-posts' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'A new post is missing from other blocks', 'mvweb-related-posts' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'On its first indexing run the post queues the posts it matched, so their blocks refresh within the next cron batches. A full rebuild does the same for the whole site.', 'mvweb-related-posts' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-related-posts' ); ?></div>
	</div>
	<p>
		<?php
		printf(
			/* translators: %s: MVweb plugin URL */
			esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-related-posts' ),
			'<a href="https://mvweb.ru/plugins/mvweb-related-posts" target="_blank" rel="noopener noreferrer">mvweb.ru</a>'
		);
		?>
	</p>
	<p><?php echo esc_html( sprintf( /* translators: %s: plugin version. */ __( 'Version %s', 'mvweb-related-posts' ), MVWEB_RP_VERSION ) ); ?></p>
</div>
