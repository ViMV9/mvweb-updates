/**
 * Admin JavaScript for MVweb Related Posts.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
		initSliders();
	});

	/**
	 * Keep each weight slider and its number field in sync.
	 */
	function initSliders() {
		var ranges = document.querySelectorAll('.mvweb-rp-range[data-output]');

		Array.prototype.forEach.call(ranges, function (range) {
			var number = document.getElementById(range.getAttribute('data-output'));

			if (!number) {
				return;
			}

			var min = parseFloat(range.min);
			var max = parseFloat(range.max);

			range.addEventListener('input', function () {
				number.value = range.value;
			});

			number.addEventListener('input', function () {
				var value = parseFloat(number.value);

				if (isNaN(value)) {
					return;
				}

				if (!isNaN(min) && value < min) {
					value = min;
				}

				if (!isNaN(max) && value > max) {
					value = max;
				}

				range.value = value;
			});

			// On blur, snap the field back to the clamped value the form will submit.
			number.addEventListener('blur', function () {
				number.value = range.value;
			});
		});
	}

	/**
	 * Initialize tab navigation on the settings page.
	 */
	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length || !panels.length) {
			return;
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();

				var target = link.getAttribute('data-tab') || link.getAttribute('href').replace('#', '');
				var panel = document.getElementById(target);

				if (!panel) {
					return;
				}

				links.forEach(function (l) { l.classList.remove('mvweb-nav__link--active'); });
				panels.forEach(function (p) { p.classList.remove('active'); });

				link.classList.add('mvweb-nav__link--active');
				panel.classList.add('active');
			});
		});
	}
})();
