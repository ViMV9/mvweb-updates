<?php
/**
 * Editor metabox: pinned posts, exclusions and score debugging.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_RP_Metabox
 *
 * @since 1.0.0
 */
class MVweb_RP_Metabox {

	const META_PINNED = '_mvweb_rp_pinned';

	const META_EXCLUDED = '_mvweb_rp_excluded';

	const META_HIDDEN = '_mvweb_rp_hidden';

	const META_NO_SUGGEST = '_mvweb_rp_no_suggest';

	const NONCE_ACTION = 'mvweb_rp_metabox';

	const NONCE_FIELD = 'mvweb_rp_metabox_nonce';

	/**
	 * Register metabox hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_metabox' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ), 10, 2 );
	}

	/**
	 * Add the metabox to supported post types.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function add_metabox() {
		foreach ( (array) MVweb_RP_Settings::get( 'post_types', array( 'post' ) ) as $post_type ) {
			add_meta_box(
				'mvweb-rp-metabox',
				__( 'Related posts', 'mvweb-related-posts' ),
				array( __CLASS__, 'render' ),
				$post_type,
				'side',
				'default'
			);
		}
	}

	/**
	 * Pinned post ids for a post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return int[]
	 */
	public static function get_pinned( $post_id ) {
		return MVweb_RP_Settings::sanitize_id_list( get_post_meta( (int) $post_id, self::META_PINNED, true ) );
	}

	/**
	 * Post ids excluded from this post's block.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return int[]
	 */
	public static function get_excluded( $post_id ) {
		return MVweb_RP_Settings::sanitize_id_list( get_post_meta( (int) $post_id, self::META_EXCLUDED, true ) );
	}

	/**
	 * Whether the block is disabled on this post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public static function is_hidden( $post_id ) {
		return (bool) get_post_meta( (int) $post_id, self::META_HIDDEN, true );
	}

	/**
	 * Render the metabox.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Current post.
	 * @return void
	 */
	public static function render( $post ) {
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );

		$pinned   = implode( ', ', self::get_pinned( $post->ID ) );
		$excluded = implode( ', ', self::get_excluded( $post->ID ) );
		$rows     = MVweb_RP_Indexer::get_related_rows( (int) $post->ID, 8 );
		?>
		<p>
			<label for="mvweb-rp-pinned"><strong><?php esc_html_e( 'Pinned post IDs', 'mvweb-related-posts' ); ?></strong></label>
			<input type="text" class="widefat" id="mvweb-rp-pinned" name="mvweb_rp_pinned" value="<?php echo esc_attr( $pinned ); ?>">
			<span class="description"><?php esc_html_e( 'Comma separated. Shown first, before scored results.', 'mvweb-related-posts' ); ?></span>
		</p>

		<p>
			<label for="mvweb-rp-excluded"><strong><?php esc_html_e( 'Excluded post IDs', 'mvweb-related-posts' ); ?></strong></label>
			<input type="text" class="widefat" id="mvweb-rp-excluded" name="mvweb_rp_excluded" value="<?php echo esc_attr( $excluded ); ?>">
		</p>

		<p>
			<label>
				<input type="checkbox" name="mvweb_rp_hidden" value="1" <?php checked( self::is_hidden( $post->ID ) ); ?>>
				<?php esc_html_e( 'Do not show the block on this post', 'mvweb-related-posts' ); ?>
			</label>
		</p>

		<p>
			<label>
				<input type="checkbox" name="mvweb_rp_no_suggest" value="1" <?php checked( (bool) get_post_meta( $post->ID, self::META_NO_SUGGEST, true ) ); ?>>
				<?php esc_html_e( 'Never suggest this post to others', 'mvweb-related-posts' ); ?>
			</label>
		</p>

		<?php if ( ! empty( $rows ) ) : ?>
			<p><strong><?php esc_html_e( 'Score debug', 'mvweb-related-posts' ); ?></strong></p>
			<table class="widefat striped">
				<tbody>
					<?php foreach ( $rows as $related_id => $row ) : ?>
						<tr>
							<td>
								<?php echo esc_html( get_the_title( $related_id ) ); ?>
								<br>
								<small>
									<?php echo esc_html( sprintf( /* translators: %s: total relevance score. */ __( 'score %s', 'mvweb-related-posts' ), number_format_i18n( $row['score'], 2 ) ) ); ?>
									<?php
									foreach ( $row['factors'] as $factor => $value ) {
										if ( $value <= 0 ) {
											continue;
										}
										echo ' · ' . esc_html( $factor . ' ' . number_format_i18n( (float) $value, 2 ) );
									}
									?>
								</small>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p class="description"><?php esc_html_e( 'No index rows yet — the post is queued for the next indexing run.', 'mvweb-related-posts' ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Persist metabox values.
	 *
	 * @since 1.0.0
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @return void
	 */
	public static function save( $post_id, $post ) {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST[ self::NONCE_FIELD ] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE_FIELD ] ) ), self::NONCE_ACTION ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( ! in_array( $post->post_type, (array) MVweb_RP_Settings::get( 'post_types', array( 'post' ) ), true ) ) {
			return;
		}

		$pinned   = MVweb_RP_Settings::sanitize_id_list( isset( $_POST['mvweb_rp_pinned'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rp_pinned'] ) ) : '' );
		$excluded = MVweb_RP_Settings::sanitize_id_list( isset( $_POST['mvweb_rp_excluded'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rp_excluded'] ) ) : '' );

		update_post_meta( $post_id, self::META_PINNED, $pinned );
		update_post_meta( $post_id, self::META_EXCLUDED, $excluded );

		self::save_flag( $post_id, self::META_HIDDEN, 'mvweb_rp_hidden' );
		self::save_flag( $post_id, self::META_NO_SUGGEST, 'mvweb_rp_no_suggest' );

		MVweb_RP_Cache::bump();
	}

	/**
	 * Store or delete a boolean meta flag.
	 *
	 * @since 1.0.0
	 * @param int    $post_id   Post ID.
	 * @param string $meta_key  Meta key.
	 * @param string $field     Request field name.
	 * @return void
	 */
	private static function save_flag( $post_id, $meta_key, $field ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in save().
		if ( ! empty( $_POST[ $field ] ) ) {
			update_post_meta( $post_id, $meta_key, 1 );
			return;
		}

		delete_post_meta( $post_id, $meta_key );
	}
}
