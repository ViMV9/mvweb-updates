<?php
/**
 * Admin screen: settings page, assets and maintenance actions.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_RP_Admin
 *
 * @since 1.0.0
 */
class MVweb_RP_Admin {

	const PAGE_SLUG = 'mvweb-related-posts';

	const REINDEX_ACTION = 'mvweb_rp_reindex';

	/**
	 * Register admin hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_page' ), 20 );
		add_action( 'admin_init', array( 'MVweb_RP_Settings', 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_post_' . self::REINDEX_ACTION, array( __CLASS__, 'handle_reindex' ) );
		add_action( 'admin_notices', array( __CLASS__, 'smart_links_notice' ) );
	}

	/**
	 * Add the settings page under the MVweb Hub menu.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_page() {
		$parent = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'options-general.php';

		add_submenu_page(
			$parent,
			__( 'MVweb Related Posts', 'mvweb-related-posts' ),
			__( 'Related Posts', 'mvweb-related-posts' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'mvweb-related-posts' ) );
		}

		require MVWEB_RP_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Load the UI Kit and plugin styles on our screen only.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( ! is_string( $hook ) || false === strpos( $hook, self::PAGE_SLUG ) ) {
			return;
		}

		wp_enqueue_style( 'mvweb-rp-admin', MVWEB_RP_URL . 'admin/css/admin.min.css', array(), mvweb_rp_asset_ver( 'admin/css/admin.min.css' ) );
		wp_enqueue_style( 'mvweb-rp-plugin', MVWEB_RP_URL . 'admin/css/plugin.min.css', array( 'mvweb-rp-admin' ), mvweb_rp_asset_ver( 'admin/css/plugin.min.css' ) );
		wp_enqueue_script( 'mvweb-rp-admin', MVWEB_RP_URL . 'admin/js/admin.min.js', array(), mvweb_rp_asset_ver( 'admin/js/admin.min.js' ), true );
	}

	/**
	 * Warn when Smart Links already renders its own related block.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function smart_links_notice() {
		if ( ! current_user_can( 'manage_options' ) || ! MVweb_RP_Public::smart_links_owns_block() ) {
			return;
		}

		$screen = get_current_screen();
		if ( ! $screen instanceof WP_Screen || false === strpos( (string) $screen->id, self::PAGE_SLUG ) ) {
			return;
		}

		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html__( 'MVweb Smart Links already prints a related posts block after the content. Automatic output of this plugin is paused — turn the Smart Links block off, or use the shortcode and the PHP function instead.', 'mvweb-related-posts' )
		);
	}

	/**
	 * Handle the full reindex request.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function handle_reindex() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to run the indexer.', 'mvweb-related-posts' ) );
		}

		check_admin_referer( self::REINDEX_ACTION );

		MVweb_RP_Indexer::reset();
		MVweb_RP_Indexer::schedule();
		MVweb_RP_Indexer::run_batch();

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'          => self::PAGE_SLUG,
					'tab'           => 'index',
					'mvweb_rp_done' => 'reindex',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Human readable label for a factor key.
	 *
	 * @since 1.0.0
	 * @param string $key Weight key.
	 * @return string
	 */
	public static function weight_label( $key ) {
		$labels = array(
			'weight_category'  => __( 'Shared categories', 'mvweb-related-posts' ),
			'weight_tag'       => __( 'Shared tags', 'mvweb-related-posts' ),
			'weight_taxonomy'  => __( 'Shared custom taxonomy terms', 'mvweb-related-posts' ),
			'weight_title'     => __( 'Title word match', 'mvweb-related-posts' ),
			'weight_content'   => __( 'Content word match', 'mvweb-related-posts' ),
			'weight_freshness' => __( 'Post freshness', 'mvweb-related-posts' ),
		);

		return $labels[ $key ] ?? $key;
	}
}
