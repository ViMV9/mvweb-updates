<?php
/**
 * Importer class — WooCommerce product import.
 *
 * Creates/updates simple products, manages stock,
 * handles images, and detects missing products.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Importer
 *
 * Imports products into WooCommerce from a generator pipeline.
 * Supports batch processing, image handling, gallery import,
 * and detection of missing (removed) products.
 *
 * @since 1.0.0
 */
class MVweb_PI_Importer {

	/**
	 * Import statistics.
	 *
	 * @since 1.0.0
	 * @var array{created: int, updated: int, skipped: int, errors: int, touched_ids: int[]}
	 */
	private array $stats = array(
		'created'     => 0,
		'updated'     => 0,
		'skipped'     => 0,
		'errors'      => 0,
		'touched_ids' => array(),
	);

	/**
	 * Category map: external_id => WooCommerce term_id.
	 *
	 * Loaded once from mvweb_pi_category_map option,
	 * populated by MVweb_PI_Categories during import.
	 *
	 * @since 1.0.0
	 * @var array<string, int>|null
	 */
	private ?array $category_map = null;

	/**
	 * Progress option name for checkpoint/resume.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const PROGRESS_OPTION = 'mvweb_pi_import_progress';

	/**
	 * Maximum age (in seconds) for a progress record to be considered resumable.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const PROGRESS_TTL = 3600;

	/**
	 * Image-import policies (settings.image_mode).
	 *
	 * - `smart`    — download images on create, and on update refresh only
	 *                the items whose source URL changed (relies on
	 *                handle_image/handle_gallery's URL-equality short-circuit).
	 *                Default. Covers the common supplier case: photos change
	 *                occasionally, but for most rows the URL is stable.
	 * - `always`   — download/refresh images on every create AND update
	 *                (the original behaviour; safest but slowest).
	 * - `new_only` — download images only when the product is newly created.
	 *                Updates leave existing images alone, even if the source
	 *                URL changed. Useful for catalogs whose suppliers reissue
	 *                URLs on every export without changing the actual image.
	 * - `never`    — never download images at all (textual catalogs).
	 *
	 * @since 1.0.0
	 */
	private const IMAGE_MODE_SMART    = 'smart';
	private const IMAGE_MODE_ALWAYS   = 'always';
	private const IMAGE_MODE_NEW_ONLY = 'new_only';
	private const IMAGE_MODE_NEVER    = 'never';

	/**
	 * Cached image-import policy for the current run.
	 *
	 * @since 1.0.0
	 * @var string|null
	 */
	private ?string $image_mode = null;

	/**
	 * Run the import process.
	 *
	 * Accepts a generator of normalized product data and processes
	 * them in batches. After all products are processed, zeroes out
	 * stock for products missing from the new price list.
	 *
	 * Supports checkpoint/resume: saves progress after each batch.
	 * On resume, skips already-processed products via $skip_count.
	 *
	 * @since 1.0.0
	 * @since 1.1.0 Added $skip_count and $resume_skus parameters for checkpoint/resume.
	 * @since 1.0.0 Added $deadline_ts for cooperative wall-clock budgeting —
	 *              the cron layer uses it to chop long imports into
	 *              short-lived wp_schedule_single_event chunks on web/AJAX.
	 * @param \Generator $products    Generator yielding normalized product arrays.
	 * @param int        $skip_count  Number of products to skip (for resume after crash).
	 * @param string[]   $resume_skus SKUs already collected before crash (for zero_missing_stock).
	 * @param int        $deadline_ts Unix timestamp at which to stop and persist
	 *                                progress; 0 means "no limit, run to completion".
	 * @return array Import statistics, augmented with `incomplete` => bool when
	 *               the deadline was hit before the generator drained.
	 */
	public function run( \Generator $products, int $skip_count = 0, array $resume_skus = array(), int $deadline_ts = 0 ): array {
		// Raise PHP memory ceiling for the duration of the import. Imagick
		// keeps a large RSS while resizing big supplier photos, and Beget's
		// default 256M cgroup limit was killing long CLI runs with SIGBUS
		// somewhere mid-catalog. The legacy importer (mvweb-price-converter)
		// did the same and ran cleanly on the same host. Filterable so an
		// operator with a stricter host can pin a lower value.
		$memory_limit = apply_filters( 'mvweb_pi_import_memory_limit', '512M' );
		if ( $memory_limit ) {
			@ini_set( 'memory_limit', $memory_limit ); // phpcs:ignore WordPress.PHP.IniSet.Risky,WordPress.PHP.NoSilencedErrors
		}

		/**
		 * Fires before the import process begins.
		 *
		 * @since 1.0.0
		 */
		do_action( 'mvweb_pi_before_import' );

		// Skip non-essential image subsizes during import.
		// A standard WC + theme install registers ~10 subsizes; running each
		// one through Imagick on every photo dominates CPU and wall-clock
		// (≈2.2 s and ~250 MB RSS per photo on Beget's VDS). We keep only
		// the four sizes WooCommerce templates actually require — admin
		// thumbnail, catalog tile, product page, gallery thumb — and let
		// every other size be generated lazily by `image_make_intermediate_size()`
		// on first request (native WP behaviour since 5.3) or in bulk via
		// `wp media regenerate` when a new theme registers its own sizes.
		// Filterable in case a site genuinely needs a different baseline.
		$keep_sizes = apply_filters(
			'mvweb_pi_keep_image_sizes',
			array( 'thumbnail', 'woocommerce_thumbnail', 'woocommerce_single', 'woocommerce_gallery_thumbnail' )
		);
		$size_filter = function ( $sizes ) use ( $keep_sizes ) {
			if ( empty( $keep_sizes ) ) {
				return $sizes;
			}
			return array_intersect_key( $sizes, array_flip( (array) $keep_sizes ) );
		};
		add_filter( 'intermediate_image_sizes_advanced', $size_filter, 999 );

		// One-shot reconciliation when the operator newly excludes a
		// category between imports: remove every SKU we previously
		// imported under that branch and delete the now-orphan term,
		// so the storefront stops showing products the operator
		// explicitly opted out of. Only runs on a fresh start — a
		// resumed checkpoint already passed this point.
		if ( 0 === $skip_count ) {
			$this->reconcile_excluded_categories();
		}

		// Default batch size: settings value if configured, otherwise 100.
		// Filter `mvweb_pi_batch_size` runs last so it can override both
		// the default and the settings value (TZ public hook contract).
		$settings = get_option( 'mvweb_pi_settings', array() );
		$default  = ! empty( $settings['batch_size'] ) ? absint( $settings['batch_size'] ) : 100;
		/** @var int $batch_size Number of products per batch. */
		$batch_size = (int) apply_filters( 'mvweb_pi_batch_size', $default );
		if ( $batch_size < 1 ) {
			$batch_size = 100;
		}

		$batch          = array();
		$new_skus       = $resume_skus;
		$batch_num      = 0;
		$started_at     = gmdate( 'Y-m-d H:i:s' );
		$skipped_so_far = 0;

		// Restore stats from checkpoint if resuming.
		if ( $skip_count > 0 ) {
			$progress = get_option( self::PROGRESS_OPTION );
			if ( is_array( $progress ) ) {
				$this->stats = array(
					'created'     => $progress['created'] ?? 0,
					'updated'     => $progress['updated'] ?? 0,
					'skipped'     => $progress['skipped'] ?? 0,
					'errors'      => $progress['errors'] ?? 0,
					'touched_ids' => is_array( $progress['touched_ids'] ?? null ) ? $progress['touched_ids'] : array(),
				);
				$started_at = $progress['started_at'] ?? $started_at;
				$batch_num  = $progress['batch_num'] ?? 0;
			}
		}

		try {

		foreach ( $products as $product_data ) {
			$new_skus[] = $product_data['sku'];

			// Skip already-processed products on resume.
			if ( $skipped_so_far < $skip_count ) {
				++$skipped_so_far;
				continue;
			}

			$batch[] = $product_data;

			if ( count( $batch ) >= $batch_size ) {
				$this->process_batch( $batch );
				$batch = array();
				++$batch_num;

				// Release the per-request object cache between batches. On a CLI
				// run with no persistent cache, every get_post_meta() /
				// update_object_term_cache() the batch primed stays in a PHP
				// array for the rest of the process — across a 1400-SKU import
				// that is the main driver of RSS growth and the reason the
				// memory_limit had to be raised. Flushing keeps memory flat;
				// the next batch re-primes only the rows it actually touches.
				wp_cache_flush();

				// Checkpoint: save progress after each batch.
				$this->save_progress( $new_skus, $started_at, $batch_num );

				mvweb_pi_log(
					sprintf(
						'Batch %d processed (running totals: %d created, %d updated, %d skipped, %d errors).',
						$batch_num,
						$this->stats['created'],
						$this->stats['updated'],
						$this->stats['skipped'],
						$this->stats['errors']
					),
					'debug'
				);

				// Cooperative wall-clock budget: when the caller (web/AJAX)
				// gave us a deadline and we've crossed it, persist what we
				// have and bail. The cron layer reads `incomplete` and
				// schedules a continuation via wp_schedule_single_event().
				// We never bail mid-batch — finishing the current batch
				// guarantees a consistent checkpoint.
				if ( $deadline_ts > 0 && time() >= $deadline_ts ) {
					return array_merge( $this->stats, array(
						'incomplete' => true,
						'processed'  => count( $new_skus ),
					) );
				}
			}
		}

		// Process remaining products.
		if ( ! empty( $batch ) ) {
			$this->process_batch( $batch );
			++$batch_num;
		}

		// At this point the generator has fully drained — the SKU set is complete.
		// Only now is it safe to diff against known_skus and to overwrite known_skus.
		// If the process died inside the loop, save_progress() recorded a partial
		// new_skus but neither zero_missing_stock() nor the known_skus overwrite
		// have run — preserving stock data for products that simply hadn't been
		// streamed yet.
		$final_skus = array_values( array_unique( $new_skus ) );

		// Zero stock for products missing from the new price list (TZ 6.4, 6.5.1).
		$this->zero_missing_stock( $final_skus );

		// Refresh product_cat/product_tag counts. The import writes _stock_status
		// low-level (update_post_meta) for speed, which never fires the term-count
		// hook WooCommerce relies on, so the category counts shown in wp-admin drift
		// from the real number of visible products after every run.
		$this->recount_product_terms();

		// Persist total + last_run on the per-instance stats so callers
		// (cron wrapper, REST endpoint, AJAX handler) get a complete
		// payload that survives the array_merge in MVweb_PI_Cron::run().
		$this->stats['total']    = count( $final_skus );
		$this->stats['last_run'] = current_time( 'mysql' );

		// Save import statistics.
		update_option( 'mvweb_pi_import_stats', $this->stats, false );

		// Save known SKUs for next diff (autoload=false). Only the complete,
		// drained SKU set is persisted here; partial sets from interrupted
		// runs remain in the progress option and are recovered on resume.
		update_option( 'mvweb_pi_known_skus', $final_skus, false );

		// Clear progress — import completed successfully.
		delete_option( self::PROGRESS_OPTION );

		/**
		 * Fires after the import process completes.
		 *
		 * @since 1.0.0
		 * @param array $stats Import statistics.
		 */
		do_action( 'mvweb_pi_after_import', $this->stats );

		return $this->stats;

		} finally {
			remove_filter( 'intermediate_image_sizes_advanced', $size_filter, 999 );
		}
	}

	/**
	 * Save import progress checkpoint.
	 *
	 * Persists current progress to wp_options so the import can be
	 * resumed if the PHP process is interrupted (timeout, OOM, restart).
	 *
	 * @since 1.1.0
	 * @param string[] $new_skus   Accumulated SKUs processed so far.
	 * @param string   $started_at Import start timestamp (GMT).
	 * @param int      $batch_num  Number of completed batches.
	 * @return void
	 */
	private function save_progress( array $new_skus, string $started_at, int $batch_num ): void {
		$processed = $this->stats['created'] + $this->stats['updated']
			+ $this->stats['skipped'] + $this->stats['errors'];

		update_option(
			self::PROGRESS_OPTION,
			array(
				'processed'   => $processed,
				'created'     => $this->stats['created'],
				'updated'     => $this->stats['updated'],
				'skipped'     => $this->stats['skipped'],
				'errors'      => $this->stats['errors'],
				'touched_ids' => $this->stats['touched_ids'],
				'new_skus'    => $new_skus,
				'started_at'  => $started_at,
				'batch_num'   => $batch_num,
			),
			false
		);
	}

	/**
	 * Process a batch of products.
	 *
	 * For each product, determines whether to create or update
	 * based on existing SKU in WooCommerce.
	 *
	 * @since 1.0.0
	 * @since 1.0.11 Resolves every duplicate copy per SKU and zeroes the extra
	 *               copies so only the canonical (lowest-id) product carries the
	 *               feed's stock.
	 * @param array[] $batch Array of normalized product data.
	 * @return void
	 */
	private function process_batch( array $batch ): void {
		// Resolve every copy of each SKU in one SELECT, then prime the postmeta
		// and term caches so update_product()'s get_post_meta() diff reads hit
		// cache instead of issuing cold SELECTs per row on a CLI runner. A SKU
		// can map to several duplicate products (created by an older plugin
		// build that failed to dedupe); the feed describes one logical SKU, so
		// we update the canonical (lowest-id) copy and force the rest out of
		// stock — otherwise stale duplicates keep showing as in stock.
		$sku_to_ids = $this->resolve_all_ids_by_skus(
			array_column( $batch, 'sku' )
		);
		if ( ! empty( $sku_to_ids ) ) {
			$existing_ids = array_merge( ...array_values( $sku_to_ids ) );
			update_meta_cache( 'post', $existing_ids );
			update_object_term_cache( $existing_ids, 'product' );
		}

		foreach ( $batch as $data ) {
			try {
				$ids        = $sku_to_ids[ $data['sku'] ] ?? array();
				$product_id = $ids[0] ?? 0; // Lowest id is the canonical copy.

				// Zero any extra duplicates regardless of how the canonical copy
				// is handled below — they are stale rows the feed describes once,
				// so only one copy should carry its stock. Unconditional so a
				// duplicate is never left in stock even if update_product() bails
				// on the canonical copy (e.g. the post vanished mid-run). The
				// plugin never deletes products — removing the duplicate rows is
				// left to a manual catalog tidy.
				foreach ( array_slice( $ids, 1 ) as $dup_id ) {
					$this->zero_out_product( $dup_id );
				}

				// update_product() returns false on a stale id (the post was
				// deleted but its _sku row lingered); fall through to the create
				// path in that case.
				if ( $product_id && $this->update_product( $product_id, $data ) ) {
					++$this->stats['updated'];
					continue;
				}

				$result = $this->create_product( $data );
				if ( is_wp_error( $result ) ) {
					mvweb_pi_log(
						/* translators: 1: SKU, 2: error message */
						sprintf( __( 'Error creating product %1$s: %2$s', 'mvweb-price-importer' ), $data['sku'], $result->get_error_message() ),
						'error'
					);
					++$this->stats['errors'];
					continue;
				}
				// create_product() writes the row with a low-level
				// wp_insert_post() that never populates wc_product_meta_lookup.
				// Seed it now so the next import resolves this SKU as existing
				// (otherwise every run re-creates the same SKU as a duplicate)
				// and so catalog price/stock filters and ordering work.
				$this->refresh_product_lookup( (int) $result );
				++$this->stats['created'];
			} catch ( \Exception $e ) {
				mvweb_pi_log(
					/* translators: 1: SKU, 2: error message */
					sprintf( __( 'Exception processing product %1$s: %2$s', 'mvweb-price-importer' ), $data['sku'], $e->getMessage() ),
					'error'
				);
				++$this->stats['errors'];
			}
		}
	}

	/**
	 * Resolve a batch of SKUs to every live product ID carrying each one.
	 *
	 * The feed describes one logical SKU, but the catalog can hold several
	 * products sharing it — duplicates created by an older plugin build that
	 * failed to dedupe. The stock-out and feed-update paths must touch ALL of
	 * them, not just the one wc_get_product_id_by_sku() happens to return (it
	 * reads wc_product_meta_lookup, which holds a single row per SKU). Querying
	 * the _sku postmeta directly returns every copy, survives a missing/empty
	 * lookup row, and resolves the whole batch in one SELECT instead of one per
	 * SKU. Trashed products are excluded — a binned SKU should resurface as a
	 * fresh product, not be silently revived.
	 *
	 * @since 1.0.11
	 * @param string[] $skus SKUs to resolve.
	 * @return array<string,int[]> SKU → product IDs (ascending), only for SKUs that exist.
	 */
	private function resolve_all_ids_by_skus( array $skus ): array {
		$skus = array_values( array_unique( array_filter( array_map( 'strval', $skus ), 'strlen' ) ) );
		if ( empty( $skus ) ) {
			return array();
		}

		global $wpdb;

		$placeholders = implode( ',', array_fill( 0, count( $skus ), '%s' ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.post_id, pm.meta_value AS sku
				FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = '_sku'
				AND pm.meta_value IN ({$placeholders})
				AND p.post_type = 'product'
				AND p.post_status != 'trash'
				ORDER BY pm.post_id ASC",
				$skus
			)
		);

		$map = array();
		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$map[ (string) $row->sku ][] = (int) $row->post_id;
			}
		}

		return $map;
	}

	/**
	 * Refresh the wc_product_meta_lookup row for a product.
	 *
	 * create_product() and update_product() write meta with low-level
	 * update_post_meta() calls that bypass WC_Product->save(), so the
	 * wc_product_meta_lookup row WooCommerce normally maintains is never
	 * written. That breaks two things: the SKU dedup lookup in
	 * resolve_existing_skus() (every run re-creates the same SKUs as
	 * duplicates) and the catalog price/stock filters and ordering, which
	 * all read this table. WC's own column set for the lookup row is
	 * version-dependent (COGS, global_unique_id, rating columns appear
	 * across releases), so rather than hand-build the INSERT we call WC's
	 * native WC_Product_Data_Store_CPT::update_lookup_table(), which derives
	 * the full row from post meta itself. The method is protected, so we
	 * reach it through reflection on the live data-store class — this stays
	 * correct across WC schema upgrades. A direct call would fatal
	 * (the method is protected on the WC_Data_Store_WP base).
	 *
	 * @since 1.0.9
	 * @param int $product_id WooCommerce product ID.
	 * @return void
	 */
	private function refresh_product_lookup( int $product_id ): void {
		if ( $product_id <= 0 || ! class_exists( 'WC_Data_Store' ) ) {
			return;
		}

		try {
			$store = \WC_Data_Store::load( 'product' );
			$class = $store->get_current_class_name();
			if ( ! class_exists( $class ) ) {
				return;
			}
			$instance = new $class();
			$method   = new \ReflectionMethod( $instance, 'update_lookup_table' );
			$method->setAccessible( true );
			$method->invoke( $instance, $product_id, 'wc_product_meta_lookup' );
		} catch ( \Throwable $e ) {
			// Lookup is an optimisation, not correctness-critical for the
			// write itself — log and move on rather than abort the import.
			mvweb_pi_log(
				/* translators: 1: product ID, 2: error message */
				sprintf( __( 'Could not refresh product lookup for #%1$d: %2$s', 'mvweb-price-importer' ), $product_id, $e->getMessage() ),
				'warning'
			);
		}
	}

	/**
	 * Create a new WooCommerce simple product.
	 *
	 * @since 1.0.0
	 * @param array $data Normalized product data.
	 * @return int|\WP_Error Product ID on success, WP_Error on failure.
	 */
	private function create_product( array $data ): int|\WP_Error {
		// Low-level product creation: bypasses WC_Product->save() and the
		// woocommerce_new_product hook chain that runs ~30+ callbacks
		// (lookup-table rewrite, search index, currency normalization,
		// caching). On a Beget VDS save() costs 200-300 ms per product;
		// the legacy importer (mvweb-price-converter) wrote products via
		// wp_insert_post + direct update_post_meta and ran in tens of
		// milliseconds per row. We mirror that here. The product_type
		// term is attached explicitly so wc_get_product() resolves the
		// row as a simple product on later reads.
		$product_id = wp_insert_post(
			array(
				'post_title'   => $data['name'],
				'post_content' => $data['description'],
				'post_status'  => 'publish',
				'post_type'    => 'product',
			)
		);

		if ( ! $product_id || is_wp_error( $product_id ) ) {
			return new \WP_Error(
				'product_save_failed',
				/* translators: %s: product SKU */
				sprintf( __( 'Failed to save product: %s', 'mvweb-price-importer' ), $data['sku'] )
			);
		}

		// Required WC product type marker. Without it wc_get_product()
		// returns false because WC can't resolve the data store.
		wp_set_object_terms( $product_id, 'simple', 'product_type', false );

		// Catalog visibility taxonomy — the modern (WC 3.0+) replacement
		// for the legacy _visibility meta. Empty terms = "visible in
		// shop AND in search", which is the default the WC admin sets
		// for a freshly-created product.
		wp_set_object_terms( $product_id, array(), 'product_visibility', false );

		// Price + stock + WC-default flags through direct meta. Mirrors
		// what WC_Product->save() writes, minus the lookup-table rewrite,
		// hook fan-out and post-cache flush.
		update_post_meta( $product_id, '_sku', $data['sku'] );
		update_post_meta( $product_id, '_regular_price', (string) $data['price'] );

		$effective_price = (string) $data['price'];
		if ( ! empty( $data['sale_price'] ) && $data['sale_price'] > 0 ) {
			update_post_meta( $product_id, '_sale_price', (string) $data['sale_price'] );
			$effective_price = (string) $data['sale_price'];
		}
		update_post_meta( $product_id, '_price', $effective_price );

		update_post_meta( $product_id, '_manage_stock', 'yes' );
		update_post_meta( $product_id, '_stock', (string) $data['stock'] );
		update_post_meta( $product_id, '_stock_status', $data['stock'] > 0 ? 'instock' : 'outofstock' );

		// A product created with zero stock must carry the product_visibility
		// 'outofstock' term when the hide-out-of-stock option is on, exactly as
		// WC_Product->save() would. The empty product_visibility set above only
		// covers the in-stock case; without this a freshly imported out-of-stock
		// SKU would show in the catalogue against the site's setting. Mirrors the
		// same sync in update_product().
		if ( 0 >= (int) $data['stock'] && 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
			wp_set_object_terms( $product_id, 'outofstock', 'product_visibility', true );
		}

		// WC-default product flags. Without these the WC admin renders
		// the row with broken icons and the "Tax status" filter excludes
		// the product. Values match what WC_Product_Simple sets on save.
		update_post_meta( $product_id, '_virtual', 'no' );
		update_post_meta( $product_id, '_downloadable', 'no' );
		update_post_meta( $product_id, '_tax_status', 'taxable' );
		update_post_meta( $product_id, '_tax_class', '' );
		update_post_meta( $product_id, '_visibility', 'visible' );
		update_post_meta( $product_id, '_featured', 'no' );
		update_post_meta( $product_id, '_backorders', 'no' );
		update_post_meta( $product_id, '_sold_individually', 'no' );

		// Category assignment (TZ 6.2). Append mode (`true`) so an
		// existing taxonomy (set by other means) isn't replaced on
		// re-import. We remember the feed term in postmeta so
		// update_product() can recognise a supplier-side category move
		// and swap our term out without touching manual categories.
		if ( ! empty( $data['category_id'] ) ) {
			$term_id = $this->resolve_category( $data['category_id'], $data['parent_cat_id'] ?? '' );
			if ( $term_id ) {
				wp_set_object_terms( $product_id, array( (int) $term_id ), 'product_cat', true );
				update_post_meta( $product_id, '_mvweb_pi_feed_cat_term_id', (int) $term_id );
			}
		}

		// Per-warehouse stock meta (TZ 3.3, 16.3).
		if ( ! empty( $data['stocks'] ) && is_array( $data['stocks'] ) ) {
			update_post_meta( $product_id, '_mvweb_pi_stocks', wp_json_encode( $data['stocks'] ) );
		}

		// Barcode meta (TZ 16.3).
		if ( ! empty( $data['barcode'] ) ) {
			update_post_meta( $product_id, '_mvweb_pi_barcode', sanitize_text_field( $data['barcode'] ) );
		}

		// Images: on create we honour every mode except `never`. The first
		// run is the only place Imagick legitimately needs to fire for a
		// brand-new SKU.
		if ( self::IMAGE_MODE_NEVER !== $this->get_image_mode() ) {
			$this->handle_image( $product_id, $data['image'] ?? '' );
			$this->handle_gallery( $product_id, $data['gallery'] ?? array() );
		}

		// Mark the row touched. The bootstrap's `mvweb_pi_after_import`
		// handler runs `wc_delete_product_transients()` once per touched
		// ID at the end of the run; calling it inline per-product cost
		// ~5600 wp_options DELETEs across a 1400-SKU import (each call
		// is itself 3–5 transient + cache-group operations).
		$this->stats['touched_ids'][] = (int) $product_id;

		/**
		 * Fires after a new product is created during import.
		 *
		 * @since 1.0.0
		 * @param int   $product_id WooCommerce product ID.
		 * @param array $data       Normalized product data.
		 */
		do_action( 'mvweb_pi_product_created', $product_id, $data );

		return $product_id;
	}

	/**
	 * Resolve the image-import policy for this run.
	 *
	 * Reads `mvweb_pi_settings.image_mode` once and caches it. Unknown values
	 * fall back to `smart` — the default that handles changed supplier photos
	 * without paying Imagick cost for unchanged ones.
	 *
	 * @since 1.0.0
	 * @return string One of self::IMAGE_MODE_*.
	 */
	private function get_image_mode(): string {
		if ( null !== $this->image_mode ) {
			return $this->image_mode;
		}

		$settings = get_option( 'mvweb_pi_settings', array() );
		$mode     = $settings['image_mode'] ?? self::IMAGE_MODE_SMART;

		$allowed = array(
			self::IMAGE_MODE_SMART,
			self::IMAGE_MODE_ALWAYS,
			self::IMAGE_MODE_NEW_ONLY,
			self::IMAGE_MODE_NEVER,
		);
		if ( ! in_array( $mode, $allowed, true ) ) {
			$mode = self::IMAGE_MODE_SMART;
		}

		$this->image_mode = $mode;
		return $mode;
	}

	/**
	 * Update an existing WooCommerce product.
	 *
	 * Updates all fields: name, price, stock, description, category,
	 * images, and per-warehouse stock meta.
	 *
	 * @since 1.0.0
	 * @param int   $product_id WooCommerce product ID.
	 * @param array $data       Normalized product data.
	 * @return bool True if the row was updated, false if the post id was
	 *              missing or pointed to something other than a product.
	 */
	private function update_product( int $product_id, array $data ): bool {
		// Low-level update path: read current meta via get_post_meta()
		// (memoized by WP after the first call per request) and compare
		// to the incoming feed row, writing only on real diffs. The old
		// path constructed a WC_Product, called setters, and finished
		// with $product->save() — which on a catalog where 99 % of rows
		// don't change between imports cost 200-300 ms per product
		// purely on hook fan-out and lookup-table rewrites. The legacy
		// importer (mvweb-price-converter) did exactly this kind of
		// surgical update and was an order of magnitude faster.
		//
		// One trade-off: this path doesn't synchronously refresh
		// wc_product_meta_lookup (price filtering, sort-by-price, etc.).
		// The importer fires `mvweb_pi_after_import` at the end of the
		// run, and the bootstrap can hook a lookup rebuild there if a
		// site needs catalog filters in lock-step with imports.
		$post = get_post( $product_id );
		if ( ! $post || 'product' !== $post->post_type ) {
			return false;
		}

		// A trashed product still resolves through wc_product_meta_lookup (the
		// lookup row isn't cleared on trash). Updating it in place would keep
		// the SKU buried in the bin instead of resurfacing a live product — bail
		// so process_batch() falls through to create_product() and the SKU comes
		// back as a published product.
		if ( 'trash' === $post->post_status ) {
			return false;
		}

		$new_sale       = ( ! empty( $data['sale_price'] ) && $data['sale_price'] > 0 ) ? (string) $data['sale_price'] : '';
		$new_status     = ( $data['stock'] > 0 ) ? 'instock' : 'outofstock';
		$effective_price = '' !== $new_sale ? $new_sale : (string) $data['price'];

		// Post fields (title/content) — wp_update_post hits wp_posts once
		// when at least one column changes; skip when both match.
		//
		// A sparse YML feed carries <description>/<name> on only some offers, so
		// an empty value means "not supplied", NOT "clear it". Overwriting a
		// non-empty field with an empty feed value would wipe descriptions the
		// operator wrote by hand for SEO. Only update when the feed actually
		// provides a value.
		$needs_post_update = false;
		$post_update       = array( 'ID' => $product_id );
		if ( '' !== (string) $data['name'] && (string) $post->post_title !== (string) $data['name'] ) {
			$post_update['post_title'] = $data['name'];
			$needs_post_update         = true;
		}
		if ( '' !== (string) $data['description'] && (string) $post->post_content !== (string) $data['description'] ) {
			$post_update['post_content'] = $data['description'];
			$needs_post_update           = true;
		}
		if ( $needs_post_update ) {
			wp_update_post( $post_update );
		}

		// Meta diffs — update_post_meta is a no-op when the value already
		// matches, but we still pay one SELECT per call; reading the full
		// meta row once keeps this to N comparisons + writes only on diff.
		$cur_regular = (string) get_post_meta( $product_id, '_regular_price', true );
		if ( $cur_regular !== (string) $data['price'] ) {
			update_post_meta( $product_id, '_regular_price', (string) $data['price'] );
		}

		$cur_sale = (string) get_post_meta( $product_id, '_sale_price', true );
		if ( $cur_sale !== $new_sale ) {
			if ( '' === $new_sale ) {
				delete_post_meta( $product_id, '_sale_price' );
			} else {
				update_post_meta( $product_id, '_sale_price', $new_sale );
			}
		}

		$cur_price = (string) get_post_meta( $product_id, '_price', true );
		if ( $cur_price !== $effective_price ) {
			update_post_meta( $product_id, '_price', $effective_price );
		}

		$cur_stock = (string) get_post_meta( $product_id, '_stock', true );
		if ( $cur_stock !== (string) $data['stock'] ) {
			update_post_meta( $product_id, '_stock', (string) $data['stock'] );
		}

		$cur_status = (string) get_post_meta( $product_id, '_stock_status', true );
		if ( $cur_status !== $new_status ) {
			update_post_meta( $product_id, '_stock_status', $new_status );

			// Keep the product_visibility 'outofstock' term in sync with the new
			// status. WooCommerce hides products carrying that term from the
			// catalogue and search when woocommerce_hide_out_of_stock_items is on,
			// and it only maintains the term inside WC_Product->save() — which this
			// low-level path skips. Without this, a SKU that drops to zero (term
			// added by zero_out_product()'s save()) and later comes back in stock
			// stays tagged out of stock and invisible on the storefront even though
			// its stock meta says instock. Mirror WC's own rule: the term exists
			// only while the hide option is enabled. append=true / removing a single
			// term leaves other visibility terms (featured, exclude-from-*) intact.
			if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
				if ( 'instock' === $new_status ) {
					wp_remove_object_terms( $product_id, 'outofstock', 'product_visibility' );
				} else {
					wp_set_object_terms( $product_id, 'outofstock', 'product_visibility', true );
				}
			}
		}

		// Ensure manage_stock stays set — legacy products may not have it.
		$cur_manage = (string) get_post_meta( $product_id, '_manage_stock', true );
		if ( 'yes' !== $cur_manage ) {
			update_post_meta( $product_id, '_manage_stock', 'yes' );
		}

		// Category assignment (TZ 6.3). Append mode (`true`) so existing
		// terms attached out-of-band (manual edit in WP Admin, other
		// integrations) survive re-import. Idempotent against the feed
		// term because we skip the call when the term is already there.
		if ( ! empty( $data['category_id'] ) ) {
			$term_id = $this->resolve_category( $data['category_id'], $data['parent_cat_id'] ?? '' );
			if ( $term_id ) {
				$current_terms = wp_get_object_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
				if ( ! is_wp_error( $current_terms ) ) {
					$current_ids = array_map( 'intval', (array) $current_terms );
					$prev_feed_term_id = (int) get_post_meta( $product_id, '_mvweb_pi_feed_cat_term_id', true );

					// Supplier moved the SKU to a different category — drop
					// only the term WE assigned last time, keep any manual
					// ones (admin UI, other integrations).
					if ( $prev_feed_term_id > 0 && $prev_feed_term_id !== (int) $term_id ) {
						$current_ids = array_values( array_diff( $current_ids, array( $prev_feed_term_id ) ) );
					}

					if ( ! in_array( (int) $term_id, $current_ids, true ) ) {
						$current_ids[] = (int) $term_id;
					}

					wp_set_object_terms( $product_id, $current_ids, 'product_cat', false );
				}
				update_post_meta( $product_id, '_mvweb_pi_feed_cat_term_id', (int) $term_id );
			}
		}

		// Per-warehouse stock meta (TZ 3.3, 16.3).
		if ( ! empty( $data['stocks'] ) && is_array( $data['stocks'] ) ) {
			update_post_meta( $product_id, '_mvweb_pi_stocks', wp_json_encode( $data['stocks'] ) );
		}

		// Barcode meta.
		if ( ! empty( $data['barcode'] ) ) {
			update_post_meta( $product_id, '_mvweb_pi_barcode', sanitize_text_field( $data['barcode'] ) );
		}

		// Images on update:
		// - `always`   touches every product unconditionally.
		// - `smart`    delegates the decision to handle_image/handle_gallery,
		//              which short-circuit when the source URL hasn't changed,
		//              so Imagick still runs at most once per *changed* SKU.
		// - `new_only` and `never` skip the whole branch — `new_only` leaves
		//              existing images alone even if the URL changed, which
		//              is what suppliers reissuing URLs every export need.
		$mode = $this->get_image_mode();
		if ( self::IMAGE_MODE_ALWAYS === $mode || self::IMAGE_MODE_SMART === $mode ) {
			$this->handle_image( $product_id, $data['image'] ?? '' );
			$this->handle_gallery( $product_id, $data['gallery'] ?? array() );
		}

		// Mark the row touched. Transient invalidation is batched into
		// the `mvweb_pi_after_import` handler — see create_product().
		$this->stats['touched_ids'][] = (int) $product_id;

		// Keep wc_product_meta_lookup in step with the meta we just wrote so
		// catalog price/stock filters and the SKU dedup lookup stay accurate.
		// Idempotent — a row that didn't actually change re-writes the same
		// values. See refresh_product_lookup() for why this goes through WC's
		// native lookup builder rather than a hand-built query.
		$this->refresh_product_lookup( (int) $product_id );

		/**
		 * Fires after an existing product is updated during import.
		 *
		 * @since 1.0.0
		 * @param int   $product_id WooCommerce product ID.
		 * @param array $data       Normalized product data.
		 */
		do_action( 'mvweb_pi_product_updated', $product_id, $data );

		return true;
	}

	/**
	 * Handle featured image for a product.
	 *
	 * Downloads and sets the featured image. If the URL hasn't changed,
	 * skips downloading. If URL changed, removes old image and sets new one.
	 * Only removes images originally uploaded by this plugin.
	 *
	 * @since 1.0.0
	 * @param int    $product_id Product ID.
	 * @param string $image_url  Image URL from the price list.
	 * @return void
	 */
	private function handle_image( int $product_id, string $image_url ): void {
		if ( empty( $image_url ) ) {
			return;
		}

		// Validate image URL (SSRF protection, TZ 2.4).
		$loader = new MVweb_PI_Loader();
		$valid  = $loader->validate_url( $image_url );
		if ( is_wp_error( $valid ) ) {
			mvweb_pi_log(
				/* translators: 1: product ID, 2: error message */
				sprintf( __( 'Image URL validation failed for product %1$d: %2$s', 'mvweb-price-importer' ), $product_id, $valid->get_error_message() ),
				'warning'
			);
			return;
		}

		// Check if image URL has changed (TZ 6.6).
		$saved_url = get_post_meta( $product_id, '_mvweb_pi_image_source', true );
		if ( $saved_url === $image_url ) {
			// Same source URL as last time — skip the re-download, but only if
			// the attachment it produced still exists and is still the product
			// thumbnail. If someone deleted the image from the media library by
			// hand, the cached URL would otherwise pin the product to a missing
			// picture forever. Fall through to re-import when the thumbnail is
			// gone. (handle_gallery() does the same existence check on its hits.)
			$cached_id = (int) get_post_meta( $product_id, '_mvweb_pi_image_attach_id', true );
			if ( $cached_id > 0
				&& 'attachment' === get_post_type( $cached_id )
				&& (int) get_post_thumbnail_id( $product_id ) === $cached_id ) {
				return;
			}
		}

		// Delete old image if it was uploaded by this plugin (TZ 6.6).
		$old_attach_id = (int) get_post_meta( $product_id, '_mvweb_pi_image_attach_id', true );
		if ( $old_attach_id && get_post_meta( $old_attach_id, '_mvweb_pi_uploaded', true ) ) {
			wp_delete_attachment( $old_attach_id, true );
		}

		// Download and attach new image.
		$attach_id = $this->download_and_attach_image( $image_url, $product_id );
		if ( is_wp_error( $attach_id ) ) {
			// Demoted to debug — broken image URLs are routine in supplier
			// feeds (HTTP 404 on stale photos) and would otherwise flood
			// the log with one warning per missing thumbnail per import.
			mvweb_pi_log(
				/* translators: 1: product ID, 2: error message */
				sprintf( __( 'Image download failed for product %1$d: %2$s', 'mvweb-price-importer' ), $product_id, $attach_id->get_error_message() ),
				'debug'
			);
			return;
		}

		set_post_thumbnail( $product_id, $attach_id );
		update_post_meta( $product_id, '_mvweb_pi_image_source', $image_url );
		update_post_meta( $product_id, '_mvweb_pi_image_attach_id', $attach_id );

		// Mark as uploaded by plugin — private key, hidden from REST API (TZ 6.6, 16.5).
		update_post_meta( $attach_id, '_mvweb_pi_uploaded', 1 );
	}

	/**
	 * Handle gallery images for a product.
	 *
	 * Downloads gallery images, deduplicates against the previously imported
	 * set (stored in meta `_mvweb_pi_gallery_sources`), and assigns the
	 * resulting attachment IDs as the product's gallery. Validates each URL
	 * for SSRF protection.
	 *
	 * @since 1.0.0
	 * @since 1.0.0 Added URL-based dedup to prevent attachment duplication
	 *              on repeated imports.
	 * @param int      $product_id Product ID.
	 * @param string[] $gallery    Array of gallery image URLs.
	 * @return void
	 */
	private function handle_gallery( int $product_id, array $gallery ): void {
		if ( empty( $gallery ) ) {
			return;
		}

		$loader = new MVweb_PI_Loader();

		// Previously stored mapping: url => attach_id.
		$saved_sources = get_post_meta( $product_id, '_mvweb_pi_gallery_sources', true );
		if ( ! is_array( $saved_sources ) ) {
			$saved_sources = array();
		}

		$new_sources    = array();
		$attachment_ids = array();
		$seen_urls      = array();

		foreach ( $gallery as $image_url ) {
			if ( empty( $image_url ) || isset( $seen_urls[ $image_url ] ) ) {
				continue;
			}
			$seen_urls[ $image_url ] = true;

			// Reuse existing attachment if the URL was imported previously
			// and the attachment still exists.
			if ( isset( $saved_sources[ $image_url ] ) ) {
				$existing_id = (int) $saved_sources[ $image_url ];
				if ( $existing_id > 0 && 'attachment' === get_post_type( $existing_id ) ) {
					$attachment_ids[]            = $existing_id;
					$new_sources[ $image_url ]  = $existing_id;
					continue;
				}
			}

			// Validate URL (SSRF protection, TZ 2.4).
			$valid = $loader->validate_url( $image_url );
			if ( is_wp_error( $valid ) ) {
				continue;
			}

			$attach_id = $this->download_and_attach_image( $image_url, $product_id );
			if ( is_wp_error( $attach_id ) ) {
				continue;
			}

			// Mark as uploaded by plugin (TZ 16.5).
			update_post_meta( $attach_id, '_mvweb_pi_uploaded', 1 );

			$attachment_ids[]          = $attach_id;
			$new_sources[ $image_url ] = $attach_id;
		}

		// Short-circuit: if the ordered URL → attachment mapping is identical
		// to the previous import, there's nothing to write. Saves
		// N × $product->save() on large catalogs where galleries rarely
		// change between runs. Ordered comparison so a reshuffled gallery
		// in the source feed still propagates to WooCommerce.
		if ( array_keys( $new_sources ) === array_keys( $saved_sources )
			&& $new_sources === $saved_sources
		) {
			return;
		}

		// Delete attachments that are no longer in the gallery
		// (only ones uploaded by this plugin).
		$stale_urls = array_diff_key( $saved_sources, $new_sources );
		foreach ( $stale_urls as $stale_id ) {
			$stale_id = (int) $stale_id;
			if ( $stale_id > 0 && get_post_meta( $stale_id, '_mvweb_pi_uploaded', true ) ) {
				wp_delete_attachment( $stale_id, true );
			}
		}

		// Persist the new mapping for the next import.
		if ( ! empty( $new_sources ) ) {
			update_post_meta( $product_id, '_mvweb_pi_gallery_sources', $new_sources );
		} else {
			delete_post_meta( $product_id, '_mvweb_pi_gallery_sources' );
		}

		if ( ! empty( $attachment_ids ) ) {
			update_post_meta(
				$product_id,
				'_product_image_gallery',
				implode( ',', array_map( 'intval', $attachment_ids ) )
			);
		} else {
			delete_post_meta( $product_id, '_product_image_gallery' );
		}
	}

	/**
	 * Download an image from URL and attach it to a product.
	 *
	 * Uses the plugin loader (SSRF-protected, no redirect following)
	 * to download to a temp file, then runs the file through the
	 * WordPress sideload pipeline to create the attachment. This is
	 * deliberately not `media_sideload_image()` — that helper performs
	 * its own HTTP request which follows redirects and would bypass
	 * SSRF protection (TZ 16.x security fix).
	 *
	 * @since 1.0.0
	 * @since 1.0.0 Replaced media_sideload_image() with a hardened pipeline.
	 * @param string $url        Image URL to download.
	 * @param int    $product_id Product ID to attach to.
	 * @return int|\WP_Error Attachment ID on success, WP_Error on failure.
	 */
	private function download_and_attach_image( string $url, int $product_id ): int|\WP_Error {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// Download via the SSRF-protected loader to a temp file under uploads/pricelists/.
		$loader   = new MVweb_PI_Loader();
		$path     = wp_parse_url( $url, PHP_URL_PATH ) ?? '';
		$basename = sanitize_file_name( wp_basename( $path ) );
		if ( '' === $basename ) {
			$basename = 'image-' . wp_generate_uuid4() . '.jpg';
		}
		$tmp_name = mvweb_pi_get_upload_dir() . 'img-' . wp_generate_uuid4() . '-' . $basename;

		// Suppress per-image log noise. The loader's debug/info lines are
		// useful for the top-level price-list download (one per source), but
		// firing them 1000+ times per import flooded the log with mechanical
		// noise. Image failures are still reported by handle_image() itself.
		// $log=false (no per-image log noise), $check_rebinding=true (SSRF
		// rebinding guard stays on — see Loader::download()).
		$result = $loader->download( $url, $tmp_name, false, true );
		if ( is_wp_error( $result ) ) {
			if ( file_exists( $tmp_name ) ) {
				wp_delete_file( $tmp_name );
			}
			return $result;
		}

		// Sideload the local file into the media library — no HTTP request,
		// no redirect-following, no second SSRF surface.
		$file_array = array(
			'name'     => $basename,
			'tmp_name' => $tmp_name,
		);

		$overrides = array(
			'test_form' => false,
			'test_size' => true,
		);

		$sideload = wp_handle_sideload( $file_array, $overrides );

		if ( isset( $sideload['error'] ) ) {
			if ( file_exists( $tmp_name ) ) {
				wp_delete_file( $tmp_name );
			}
			return new \WP_Error( 'image_sideload_failed', $sideload['error'] );
		}

		// Remove the temp file if wp_handle_sideload() copied rather than moved
		// it. For files that aren't real $_FILES uploads sideload may leave the
		// source behind; across a 1000-image import those orphans pile up in the
		// pricelists dir. The moved/copied destination is $sideload['file'] — only
		// delete the temp when it's a different path that still exists.
		if ( isset( $sideload['file'] ) && $sideload['file'] !== $tmp_name && file_exists( $tmp_name ) ) {
			wp_delete_file( $tmp_name );
		}

		// Create the attachment post.
		$attachment = array(
			'post_mime_type' => $sideload['type'],
			'post_title'     => preg_replace( '/\.[^.]+$/', '', $basename ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		);

		$attach_id = wp_insert_attachment( $attachment, $sideload['file'], $product_id );
		if ( is_wp_error( $attach_id ) || 0 === $attach_id ) {
			return new \WP_Error( 'attachment_insert_failed', __( 'Failed to insert attachment.', 'mvweb-price-importer' ) );
		}

		$metadata = wp_generate_attachment_metadata( $attach_id, $sideload['file'] );
		wp_update_attachment_metadata( $attach_id, $metadata );

		return $attach_id;
	}

	/**
	 * Zero out stock for products missing from the new price list.
	 *
	 * Compares the new set of SKUs with the previously known set.
	 * Products present in the old set but absent in the new set
	 * get their stock set to 0 and status set to 'outofstock'.
	 * Products are NOT deleted or unpublished (TZ 6.4).
	 *
	 * @since 1.0.0
	 * @param string[] $new_skus Array of SKUs from the current import.
	 * @return void
	 */
	private function zero_missing_stock( array $new_skus ): void {
		$known_skus = get_option( 'mvweb_pi_known_skus', array() );

		// On first import, no known SKUs — nothing to zero out.
		if ( empty( $known_skus ) ) {
			return;
		}

		// Truncated-feed guard. The generator drains to the end even when the
		// supplier returned HTTP 200 with a physically truncated body (CDN
		// hiccup, their export crashing mid-write) or a temporarily near-empty
		// feed (10 offers instead of 1400). In that case array_diff() would
		// zero stock on hundreds of live products and they'd vanish from the
		// outgoing Yandex.Market feed on the next regeneration. Refuse to zero
		// anything when the new feed is suspiciously small versus what we knew
		// last run — a real catalogue doesn't lose half its SKUs in one import.
		$threshold = (float) apply_filters( 'mvweb_pi_zero_stock_min_ratio', 0.5 );
		if ( $threshold > 0 && count( $new_skus ) < count( $known_skus ) * $threshold ) {
			mvweb_pi_log(
				sprintf(
					/* translators: 1: new SKU count, 2: previously known SKU count */
					__( 'Skipped zeroing stock for missing products: the new feed has %1$d SKUs versus %2$d known last run, which looks like a truncated or partial feed. Stock left untouched to avoid wiping the catalogue.', 'mvweb-price-importer' ),
					count( $new_skus ),
					count( $known_skus )
				),
				'warning'
			);
			return;
		}

		$missing      = array_diff( $known_skus, $new_skus );
		$zeroed_count = 0;

		// Resolve EVERY product carrying each missing SKU in one query, not just
		// the one the lookup table returns. A SKU dropped from the feed may exist
		// as several duplicate products (created by an older plugin build);
		// zeroing only the first left the rest showing as in stock.
		$missing_map = $this->resolve_all_ids_by_skus( array_values( $missing ) );

		foreach ( $missing_map as $sku => $product_ids ) {
			foreach ( $product_ids as $product_id ) {
				if ( $this->zero_out_product( $product_id ) ) {
					++$zeroed_count;
				}
			}

			mvweb_pi_log(
				/* translators: %s: product SKU */
				sprintf( __( 'Stock zeroed for missing product: %s', 'mvweb-price-importer' ), $sku ),
				'info'
			);
		}

		if ( $zeroed_count > 0 ) {
			mvweb_pi_log(
				/* translators: %d: number of products */
				sprintf( __( 'Zeroed stock for %d missing products.', 'mvweb-price-importer' ), $zeroed_count ),
				'info'
			);
		}
	}

	/**
	 * Recount product category and tag terms.
	 *
	 * Delegates to WooCommerce's own wc_recount_all_terms(), which recounts
	 * product_cat and product_tag taking visibility (hidden out-of-stock
	 * products) into account. Called once at the end of an import so the term
	 * counts in wp-admin reflect the catalogue after the low-level stock writes,
	 * which never trigger the native term-count hook.
	 *
	 * @since 1.0.15
	 * @return void
	 */
	private function recount_product_terms(): void {
		if ( function_exists( 'wc_recount_all_terms' ) ) {
			wc_recount_all_terms();
		}
	}

	/**
	 * Force a single product out of stock.
	 *
	 * Sets quantity to 0, status to outofstock, syncs the product_visibility
	 * term, zeroes the per-warehouse stock meta, and reseeds the lookup row so
	 * catalog price/stock filters reflect the change. Shared by the "missing
	 * from feed" path (zero_missing_stock) and the duplicate sweep in
	 * process_batch so both apply identical stock-out semantics to every copy
	 * of a SKU.
	 *
	 * Low-level path — mirrors update_product()/create_product() and does NOT
	 * call WC_Product->save(). save() fans out ~30 WooCommerce hooks per call,
	 * so on a feed where hundreds of SKUs disappear at once the old save()-based
	 * sweep cost minutes and timed out mid-import on shared hosting. We write the
	 * stock meta, sync the visibility term, and reseed wc_product_meta_lookup
	 * directly — the same trade-off (skipping the save() hook chain) already made
	 * by create/update. Third-party listeners on woocommerce_product_set_stock*
	 * do not fire here, which is acceptable for a bulk stock-out.
	 *
	 * @since 1.0.11
	 * @since 1.0.19 Low-level path; no WC_Product->save().
	 * @param int $product_id WooCommerce product ID.
	 * @return bool True if the product was zeroed, false if it could not load.
	 */
	private function zero_out_product( int $product_id ): bool {
		if ( $product_id <= 0 ) {
			return false;
		}

		$post = get_post( $product_id );
		if ( ! $post || 'product' !== $post->post_type || 'trash' === $post->post_status ) {
			return false;
		}

		// Stock quantity + status, written only on a real diff (update_post_meta
		// is a no-op on an unchanged value but still costs a SELECT).
		if ( '0' !== (string) get_post_meta( $product_id, '_stock', true ) ) {
			update_post_meta( $product_id, '_stock', '0' );
		}

		if ( 'outofstock' !== (string) get_post_meta( $product_id, '_stock_status', true ) ) {
			update_post_meta( $product_id, '_stock_status', 'outofstock' );

			// Keep the product_visibility 'outofstock' term in sync — WooCommerce
			// hides products carrying it from the catalogue/search when
			// woocommerce_hide_out_of_stock_items is on, and only WC_Product->save()
			// maintains it natively (which this low-level path skips). append=true
			// leaves other visibility terms (featured, exclude-from-*) intact.
			if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
				wp_set_object_terms( $product_id, 'outofstock', 'product_visibility', true );
			}
		}

		// Zero per-warehouse stocks.
		$stocks = get_post_meta( $product_id, '_mvweb_pi_stocks', true );
		if ( $stocks ) {
			$decoded = json_decode( $stocks, true );
			if ( is_array( $decoded ) ) {
				$zeroed = array_map( function () {
					return 0;
				}, $decoded );
				update_post_meta( $product_id, '_mvweb_pi_stocks', wp_json_encode( $zeroed ) );
			}
		}

		// Reseed wc_product_meta_lookup (stock_status column) so catalog stock
		// filters and sort-by reflect the stock-out. WC_Product->save() did this
		// implicitly; the low-level path must do it explicitly.
		$this->refresh_product_lookup( $product_id );

		return true;
	}

	/**
	 * Un-hide products left tagged out of stock while their stock says instock.
	 *
	 * Older builds of update_product() changed _stock_status to 'instock' on a
	 * returning SKU without clearing the product_visibility 'outofstock' term
	 * (only WC_Product->save() maintains that term, and the low-level update
	 * path skips it). With woocommerce_hide_out_of_stock_items enabled those
	 * products stayed invisible in the catalogue and search despite being in
	 * stock. This one-shot reconciliation drops the stale term from every such
	 * product in a single DELETE, then fixes the term's count. Idempotent — a
	 * second run finds nothing to remove. Safe to call regardless of the hide
	 * option: an instock product should never carry the term either way.
	 *
	 * @since 1.0.14
	 * @return int Number of products whose stale term was removed.
	 */
	public static function resync_hidden_instock_visibility(): int {
		global $wpdb;

		$tt_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT tt.term_taxonomy_id
				FROM {$wpdb->term_taxonomy} tt
				INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
				WHERE tt.taxonomy = 'product_visibility' AND t.slug = %s",
				'outofstock'
			)
		);

		if ( $tt_id <= 0 ) {
			return 0;
		}

		// Remove the 'outofstock' visibility term from every published product
		// whose stock meta is 'instock'. One DELETE, indexed joins, no per-row
		// PHP loop — cheap even on a 1400+ product catalogue.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$removed = (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE tr FROM {$wpdb->term_relationships} tr
				INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id
				INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = tr.object_id
				WHERE tr.term_taxonomy_id = %d
				AND p.post_type = 'product'
				AND p.post_status = 'publish'
				AND pm.meta_key = '_stock_status'
				AND pm.meta_value = 'instock'",
				$tt_id
			)
		);

		if ( $removed > 0 ) {
			// Recount the term natively. wp_update_term_count() takes
			// term_taxonomy_ids and delegates to the taxonomy's registered
			// count callback — WooCommerce's own, which counts only the right
			// post statuses — and clears the term cache itself, so this fixes
			// both the count and the cache after the bulk DELETE above.
			wp_update_term_count( array( $tt_id ), 'product_visibility' );
		}

		return $removed;
	}

	/**
	 * Resolve external category ID to WooCommerce term_id.
	 *
	 * Checks the category map option for a cached mapping.
	 * Falls back to searching by name if MVweb_PI_Categories
	 * is not yet implemented (Stage 5).
	 *
	 * @since 1.0.0
	 * @param string $external_id     External category ID from the price list.
	 * @param string $parent_ext_id   External parent category ID (optional).
	 * @return int Term ID or 0 if not found.
	 */
	private function resolve_category( string $external_id, string $parent_ext_id = '' ): int {
		if ( empty( $external_id ) ) {
			return 0;
		}

		// Load category map once (populated by MVweb_PI_Categories).
		if ( null === $this->category_map ) {
			$this->category_map = get_option( 'mvweb_pi_category_map', array() );
			if ( ! is_array( $this->category_map ) ) {
				$this->category_map = array();
			}
		}

		if ( isset( $this->category_map[ $external_id ] ) ) {
			$term_id = absint( $this->category_map[ $external_id ] );
			// Validate that the cached id still refers to a live product_cat
			// term — a manual DB cleanup (or syncing from a fresh dump)
			// can drop the wp_term_taxonomy row while the option survives,
			// and wp_set_object_terms() then silently no-ops on a missing
			// term. The MVweb_PI_Categories::import() pass that runs
			// before each batch already re-creates the term and refreshes
			// the option, so it's enough to re-read on a miss.
			if ( $term_id > 0 && term_exists( $term_id, 'product_cat' ) ) {
				return $term_id;
			}
			$this->category_map = get_option( 'mvweb_pi_category_map', array() );
			if ( ! is_array( $this->category_map ) ) {
				$this->category_map = array();
			}
			if ( isset( $this->category_map[ $external_id ] ) ) {
				$term_id = absint( $this->category_map[ $external_id ] );
				if ( $term_id > 0 && term_exists( $term_id, 'product_cat' ) ) {
					return $term_id;
				}
			}
		}

		return 0;
	}

	/**
	 * Reconcile newly excluded categories with the existing catalog.
	 *
	 * When the operator ticks a category in the "Excluded categories"
	 * UI, the converter starts filtering its SKUs out of the feed
	 * stream — but the products it created on earlier runs are still
	 * in WooCommerce. This pass closes that loop: every excluded
	 * branch (the category itself plus its descendants in the
	 * `mvweb_pi_category_meta` tree) gets its products force-deleted
	 * via `wp_delete_post( $id, true )` (skips trash so the SKU is
	 * free for re-import), and the term itself is removed via
	 * `wp_delete_term()`. We also wipe the corresponding entry from
	 * `mvweb_pi_category_map` so the next run doesn't accidentally
	 * resurrect the term through the cache. `mvweb_pi_known_skus`
	 * gets the removed SKUs subtracted so `zero_missing_stock()`
	 * doesn't try to act on them as "missing from the feed".
	 *
	 * Idempotent — re-running it after everything is clean does
	 * nothing.
	 *
	 * Honours the include/exclude filter mode: in exclude mode the ticked
	 * branches are the ones to drop; in include mode it is the INVERSE — every
	 * category that does NOT sit under a ticked branch is the one to drop, so
	 * the closure is built by negating the per-category branch test. This
	 * mirrors the product filter in the converter; without it, include mode
	 * would delete exactly the categories the operator wants to keep.
	 *
	 * @since 1.0.7
	 * @since 1.0.16 Honours include/exclude filter mode.
	 * @return void
	 */
	private function reconcile_excluded_categories(): void {
		$ticked = get_option( 'mvweb_pi_excluded_categories', array() );
		if ( ! is_array( $ticked ) || empty( $ticked ) ) {
			return;
		}

		$meta = get_option( 'mvweb_pi_category_meta', array() );
		if ( ! is_array( $meta ) ) {
			$meta = array();
		}

		$mode    = get_option( 'mvweb_pi_category_filter_mode', 'exclude' );
		$include = ( 'include' === $mode );

		// For each category, is it under any ticked branch? Walk up the parent
		// chain in $meta. The closure (categories to DROP) is then:
		//   exclude mode → categories under a ticked branch
		//   include mode → categories NOT under a ticked branch (the inverse)
		$ticked_set = array_flip( array_map( 'strval', $ticked ) );
		$closure    = array();
		foreach ( $meta as $ext_id => $row ) {
			$cursor = (string) $ext_id;
			$seen   = array();
			$in_set = false;
			while ( '' !== $cursor && ! isset( $seen[ $cursor ] ) ) {
				$seen[ $cursor ] = true;
				if ( isset( $ticked_set[ $cursor ] ) ) {
					$in_set = true;
					break;
				}
				$cursor = (string) ( $meta[ $cursor ]['parent_id'] ?? '' );
			}

			$drop = $include ? ! $in_set : $in_set;
			if ( $drop ) {
				$closure[ (string) $ext_id ] = true;
			}
		}

		if ( empty( $closure ) ) {
			return;
		}

		$map = get_option( 'mvweb_pi_category_map', array() );
		if ( ! is_array( $map ) ) {
			$map = array();
		}

		$term_ids_to_drop = array();
		foreach ( array_keys( $closure ) as $ext_id ) {
			$tid = (int) ( $map[ (string) $ext_id ] ?? 0 );
			if ( $tid > 0 && term_exists( $tid, 'product_cat' ) ) {
				$term_ids_to_drop[ $tid ] = $ext_id;
			}
		}

		if ( empty( $term_ids_to_drop ) ) {
			return;
		}

		// Delete every product attached to any of these terms, in pages rather
		// than one posts_per_page=-1 query: a wide include-mode exclusion on a
		// large catalogue could otherwise pull thousands of IDs into memory at
		// once. We always read page 1 because each deletion shrinks the result
		// set — the next batch's "page 1" is the previous page 2. Attached via
		// `_mvweb_pi_feed_cat_term_id` is intentional: this also catches
		// manually-categorised products sharing the term, which is what
		// excluding the whole category opts into.
		$removed_skus = array();
		$batch_size   = 200;
		$prev_batch   = array();

		do {
			$product_ids = get_posts(
				array(
					'post_type'      => 'product',
					'post_status'    => 'any',
					'fields'         => 'ids',
					'posts_per_page' => $batch_size,
					'no_found_rows'  => true,
					'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
						array(
							'taxonomy'         => 'product_cat',
							'field'            => 'term_id',
							'terms'            => array_keys( $term_ids_to_drop ),
							'include_children' => false,
						),
					),
				)
			);
			$product_ids = array_map( 'intval', (array) $product_ids );

			// Stall guard: if this page returns the exact same IDs as the last
			// one, nothing got deleted (e.g. a third-party pre_delete_post filter
			// is blocking wp_delete_post on these products). Without this the
			// always-page-1 loop would spin forever on the same rows. Bail and
			// log rather than hang the import.
			if ( ! empty( $product_ids ) && $product_ids === $prev_batch ) {
				mvweb_pi_log(
					sprintf(
						/* translators: %d: number of products that could not be deleted */
						__( 'Reconcile stalled: %d products could not be deleted (deletion blocked). Skipping the rest.', 'mvweb-price-importer' ),
						count( $product_ids )
					),
					'warning'
				);
				break;
			}
			$prev_batch = $product_ids;

			foreach ( $product_ids as $pid ) {
				$sku = (string) get_post_meta( $pid, '_sku', true );
				if ( '' !== $sku ) {
					$removed_skus[] = $sku;
				}
				wp_delete_post( $pid, true );
			}

			// Keep the object cache from growing unbounded across pages.
			wp_cache_flush();
		} while ( count( $product_ids ) === $batch_size );

		foreach ( $term_ids_to_drop as $tid => $ext_id ) {
			wp_delete_term( (int) $tid, 'product_cat' );
			unset( $map[ (string) $ext_id ] );
		}

		update_option( 'mvweb_pi_category_map', $map );

		// Subtract removed SKUs from known_skus so the next pass
		// doesn't treat them as "missing from this import" and try
		// to zero out stock on already-deleted posts.
		if ( ! empty( $removed_skus ) ) {
			$known = get_option( 'mvweb_pi_known_skus', array() );
			if ( is_array( $known ) ) {
				$known = array_values( array_diff( $known, $removed_skus ) );
				update_option( 'mvweb_pi_known_skus', $known, false );
			}
		}

		mvweb_pi_log(
			sprintf(
				/* translators: 1: number of categories removed, 2: number of products removed */
				__( 'Excluded categories reconciled: %1$d categories and %2$d products removed.', 'mvweb-price-importer' ),
				count( $term_ids_to_drop ),
				count( $removed_skus )
			),
			'info'
		);
	}

	/**
	 * Get current import statistics.
	 *
	 * @since 1.0.0
	 * @return array{created: int, updated: int, skipped: int, errors: int}
	 */
	public function get_stats(): array {
		return $this->stats;
	}
}
