<?php
/**
 * CLI runner for the MoySklad stock refresh.
 *
 * Usage: php stock-sync-runner.php
 * Add to crontab: *\/15 * * * * php /path/to/wp-content/plugins/mvweb-price-importer/stock-sync-runner.php
 *
 * Worth preferring over wp-cron for this one: wp-cron only fires when somebody
 * visits the site, so a fifteen-minute schedule is fifteen minutes only while
 * there is traffic. A system cron keeps the interval it was given.
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

// Only allow CLI execution.
if ( 'cli' !== php_sapi_name() ) {
	http_response_code( 403 );
	exit( 'This script can only be run from the command line.' );
}

// Bootstrap WordPress.
$wp_load = dirname( __FILE__, 4 ) . '/wp-load.php';

if ( ! file_exists( $wp_load ) ) {
	$wp_load = dirname( __FILE__, 5 ) . '/wp-load.php';
}

if ( ! file_exists( $wp_load ) ) {
	fwrite( STDERR, "Error: wp-load.php not found. Tried:\n" );
	fwrite( STDERR, '  ' . dirname( __FILE__, 4 ) . "/wp-load.php\n" );
	fwrite( STDERR, '  ' . dirname( __FILE__, 5 ) . "/wp-load.php\n" );
	exit( 1 );
}

if ( ! defined( 'DOING_CRON' ) ) {
	define( 'DOING_CRON', true );
}

require_once $wp_load;

if ( ! defined( 'MVWEB_PI_VERSION' ) ) {
	fwrite( STDERR, "Error: MVweb Price Importer is not active.\n" );
	exit( 1 );
}

$sync   = new MVweb_PI_Stock_Sync();
$result = $sync->run();

$status = $result['status'] ?? 'unknown';

if ( 'success' === $status ) {
	fwrite(
		STDOUT,
		sprintf(
			"Stock sync: %d updated, %d matched, %d rows in the report.\n",
			$result['updated'] ?? 0,
			$result['matched'] ?? 0,
			$result['reported'] ?? 0
		)
	);
	exit( 0 );
}

if ( 'skipped' === $status ) {
	fwrite( STDOUT, "Stock sync skipped: MoySklad is not this site's data source.\n" );
	exit( 0 );
}

if ( 'locked' === $status ) {
	fwrite( STDERR, "Stock sync skipped: an import is running.\n" );
	exit( 2 );
}

fwrite( STDERR, 'Stock sync failed: ' . ( $result['message'] ?? 'unknown error' ) . "\n" );
exit( 1 );
