<?php
/**
 * MoySklad catalogue source.
 *
 * Turns the JSON API into the same normalised product rows the price-list
 * converter produces, so the importer downstream cannot tell the two apart.
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_MoySklad_Source
 *
 * The catalogue is fetched once per run into a local file, and the import then
 * streams that file. Reading the API straight into the importer looks simpler
 * on paper and is worse in practice: a web import runs in 50-second slices, and
 * resuming a slice means starting the stream again — which for an HTTP source
 * is re-downloading every page already processed, on every continuation, purely
 * to throw the results away. Spent against an account that gets blocked for an
 * hour after too many rejected requests, that is the one mistake worth
 * designing out. Fetched into a file, a resume rewinds a local disk, which is
 * exactly what the price-list path already does well.
 *
 * The dump is written under a temporary name and moved into place only once the
 * last page has arrived. A half-written dump must never reach the importer: it
 * would look like a catalogue that had lost most of its products, and the
 * import would take the missing ones off sale.
 *
 * @since 1.1.0
 */
class MVweb_PI_MoySklad_Source {

	/**
	 * Products per assortment page. The API's ceiling.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const PAGE = 1000;

	/**
	 * How many rows are checked against the catalogue in one query.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const LOOKUP_CHUNK = 200;

	/**
	 * Transport.
	 *
	 * @since 1.1.0
	 * @var MVweb_PI_MoySklad_Client
	 */
	private MVweb_PI_MoySklad_Client $client;

	/**
	 * MoySklad settings (`mvweb_pi_moysklad`).
	 *
	 * @since 1.1.0
	 * @var array
	 */
	private array $settings;

	/**
	 * Category filter, borrowed from the converter so both sources filter alike.
	 *
	 * @since 1.1.0
	 * @var MVweb_PI_Converter|null
	 */
	private ?MVweb_PI_Converter $filter = null;

	/**
	 * Assortment rows the last fetch could not use because of their kind.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	private int $skipped = 0;

	/**
	 * Assortment rows the last fetch could not use because they carried no price.
	 *
	 * Counted separately and reported: a product silently missing from the shop
	 * is the kind of absence nobody notices until a customer asks for it.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	private int $unpriced = 0;

	/**
	 * Constructor.
	 *
	 * @since 1.1.0
	 * @param MVweb_PI_MoySklad_Client $client   Transport.
	 * @param array                    $settings MoySklad settings.
	 */
	public function __construct( MVweb_PI_MoySklad_Client $client, array $settings ) {
		$this->client   = $client;
		$this->settings = $settings;
	}

	/**
	 * The newest complete dump on disk, or an empty string when there is none.
	 *
	 * A dump is two files sharing one random name — the products and the group
	 * tree they were fetched with — and it counts as complete only when both are
	 * there. That pairing is what makes the fetch safe to interrupt: a run that
	 * dies between writing the two leaves a name that no longer matches
	 * anything, so the next run fetches again rather than importing a fresh
	 * catalogue against a stale tree.
	 *
	 * The name is random for the same reason every other file this plugin puts
	 * in the uploads folder is: it holds the supplier's whole assortment, with
	 * the wholesale and dealer prices that never appear in a public feed, and
	 * the folder is protected by an .htaccess that Nginx does not read.
	 *
	 * @since 1.1.0
	 * @return string Absolute path of the products file, or ''.
	 */
	public static function dump_path(): string {
		$found = glob( mvweb_pi_get_upload_dir() . 'moysklad-catalog-*.jsonl' );
		if ( empty( $found ) ) {
			return '';
		}

		// Newest first: an older leftover must never win over the dump the last
		// fetch produced.
		usort(
			$found,
			static function ( $a, $b ) {
				return filemtime( $b ) <=> filemtime( $a );
			}
		);

		foreach ( $found as $file ) {
			if ( file_exists( self::tree_path( $file ) ) ) {
				return $file;
			}
		}

		return '';
	}

	/**
	 * Path of the group tree belonging to a given products file.
	 *
	 * @since 1.1.0
	 * @param string $dump Products file, as returned by {@see dump_path()}.
	 * @return string
	 */
	public static function tree_path( string $dump ): string {
		return (string) preg_replace( '/moysklad-catalog-(.+)\.jsonl$/', 'moysklad-folders-$1.json', $dump );
	}

	/**
	 * Is there a complete dump on disk to import from?
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function has_dump(): bool {
		return '' !== self::dump_path();
	}

	/**
	 * Remove every catalogue dump, complete or half-written.
	 *
	 * @since 1.1.0
	 * @param string $keep Dump to spare, by absolute path.
	 * @return void
	 */
	public static function drop_dump( string $keep = '' ): void {
		$dir   = mvweb_pi_get_upload_dir();
		$files = array_merge(
			(array) glob( $dir . 'moysklad-catalog-*' ),
			(array) glob( $dir . 'moysklad-folders-*' )
		);

		foreach ( $files as $file ) {
			if ( $keep === $file || self::tree_path( $keep ) === $file ) {
				continue;
			}
			wp_delete_file( $file );
		}
	}

	/**
	 * Pull the whole catalogue from MoySklad into a local dump.
	 *
	 * Cheap in requests and expensive in nothing else: a ten-thousand product
	 * catalogue is ten pages of assortment plus three small calls. Pictures,
	 * which are what actually make an import take hours, are deliberately left
	 * out of this phase — their download links expire after a minute, so they
	 * can only be resolved at the moment the product is written.
	 *
	 * @since 1.1.0
	 * @return array{products: int, skipped: int, unpriced: int, requests: int} What was fetched.
	 * @throws \RuntimeException When the dump cannot be written or put in place.
	 * @throws \Throwable Whatever the API layer raised, once the half-written dump is cleaned up.
	 */
	public function refresh(): array {
		$final   = mvweb_pi_get_upload_dir() . 'moysklad-catalog-' . wp_generate_uuid4() . '.jsonl';
		$partial = $final . '.part';
		$folders = $this->fetch_folders();
		$stock   = $this->fetch_stock();
		$offset  = 0;
		$written = 0;

		$this->skipped  = 0;
		$this->unpriced = 0;

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streaming a multi-megabyte dump line by line.
		$handle = fopen( $partial, 'w' );
		if ( false === $handle ) {
			throw new \RuntimeException(
				sprintf(
					/* translators: %s: file path */
					__( 'Cannot write the catalogue dump: %s', 'mvweb-price-importer' ),
					$partial
				)
			);
		}

		try {
			do {
				$page = $this->client->get(
					'entity/assortment',
					array(
						'limit'  => self::PAGE,
						'offset' => $offset,
					),
					array(
						// Without this header the request goes to the old
						// endpoint, which computes stock on the fly and is
						// being retired in 2027.
						'X-Lognex-Remap-Beta-Feature' => 'assortmentWithoutStock',
					)
				);

				$rows = isset( $page['rows'] ) && is_array( $page['rows'] ) ? $page['rows'] : array();
				$size = isset( $page['meta']['size'] ) ? (int) $page['meta']['size'] : 0;

				foreach ( $rows as $row ) {
					$product = $this->normalize( $row, $stock );
					if ( null === $product ) {
						continue;
					}
					fwrite( $handle, (string) wp_json_encode( $product ) . "\n" );
					++$written;
				}

				$offset += self::PAGE;
				// A short page is the end of the catalogue. `meta.size` is only
				// a second opinion: when the API omits it, the page length is
				// the one signal left, and treating a missing size as "nothing
				// more to fetch" would silently import the first page alone.
				$page_size = count( $rows );
			} while ( self::PAGE === $page_size && ( 0 === $size || $offset < $size ) );
		} catch ( \Throwable $e ) {
			fclose( $handle );
			wp_delete_file( $partial );
			throw $e;
		}

		fclose( $handle );

		// The tree goes down first, under the new dump's name, and the products
		// file is renamed into place after it. That order is what makes the pair
		// complete in a single step: until the rename, dump_path() still finds
		// the previous dump and its own tree, and a fetch that dies here leaves
		// a tree that belongs to no products file rather than a fresh catalogue
		// paired with a stale tree.
		file_put_contents( self::tree_path( $final ), (string) wp_json_encode( $folders ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

		if ( ! rename( $partial, $final ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
			wp_delete_file( $partial );
			wp_delete_file( self::tree_path( $final ) );
			throw new \RuntimeException(
				__( 'The catalogue was fetched but could not be moved into place.', 'mvweb-price-importer' )
			);
		}

		// Now that the new dump is the one on disk, everything older can go —
		// including any tree left behind by a fetch that never finished.
		self::drop_dump( $final );

		return array(
			'products' => $written,
			'skipped'  => $this->skipped,
			'unpriced' => $this->unpriced,
			'requests' => $this->client->sent(),
		);
	}

	/**
	 * The category tree that belongs to the current dump.
	 *
	 * Shaped for {@see MVweb_PI_Categories::import()}: a flat list of
	 * `id`/`name`/`parent_id`, keyed by MoySklad's own identifiers rather than
	 * by name — so renaming a group in MoySklad renames the WooCommerce
	 * category instead of creating a second one beside it.
	 *
	 * @since 1.1.0
	 * @return array[]
	 */
	public function categories(): array {
		$dump = self::dump_path();
		if ( '' === $dump ) {
			return array();
		}

		$raw = json_decode( (string) file_get_contents( self::tree_path( $dump ) ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

		return is_array( $raw ) ? $raw : array();
	}

	/**
	 * Stream the dump as normalised product rows.
	 *
	 * Two things happen here rather than at fetch time. The category filter,
	 * because it reads the tree the import has only just created, and because a
	 * change of filter should not cost a second trip to the API. And pictures,
	 * because their download links live for one minute — far less than the gap
	 * between fetching a catalogue and writing its last product.
	 *
	 * This generator never ends early. An API error becomes an exception, which
	 * travels out through the importer and leaves the run's checkpoint intact;
	 * returning instead would tell the importer the catalogue had ended, and
	 * every product not yet reached would be taken off sale.
	 *
	 * @since 1.1.0
	 * @return \Generator<int, array>
	 * @throws \RuntimeException When the dump is missing or the API cannot be read.
	 */
	public function products(): \Generator {
		// Resolved once and held: the generator is walked over several
		// continuations, and a fetch finishing in between would otherwise move
		// the stream to a different file mid-read.
		$dump = self::dump_path();
		if ( '' === $dump ) {
			throw new \RuntimeException(
				__( 'The catalogue dump is missing. Run the import again to fetch it.', 'mvweb-price-importer' )
			);
		}

		$with_images = 'never' !== ( $this->settings['images'] ?? 'new_only' );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streaming the dump line by line.
		$handle = fopen( $dump, 'r' );
		if ( false === $handle ) {
			throw new \RuntimeException(
				__( 'The catalogue dump could not be opened.', 'mvweb-price-importer' )
			);
		}

		try {
			$chunk = array();

			while ( false !== ( $line = fgets( $handle ) ) ) {
				$row = json_decode( trim( $line ), true );
				if ( ! is_array( $row ) || empty( $row['sku'] ) ) {
					continue;
				}

				if ( $this->excluded( (string) ( $row['category_id'] ?? '' ) ) ) {
					continue;
				}

				$chunk[] = $row;
				if ( count( $chunk ) < self::LOOKUP_CHUNK ) {
					continue;
				}

				foreach ( $this->with_pictures( $chunk, $with_images ) as $ready ) {
					yield $ready;
				}
				$chunk = array();
			}

			foreach ( $this->with_pictures( $chunk, $with_images ) as $ready ) {
				yield $ready;
			}
		} finally {
			fclose( $handle );
		}
	}

	/**
	 * Attach picture URLs to the rows that are about to become new products.
	 *
	 * Resolving a picture costs two requests and the result is valid for a
	 * minute, so it is done for the rows that will actually use it — the ones
	 * whose article is not in the catalogue yet. Products that already exist
	 * keep the pictures they have: MoySklad hands out a different link every
	 * time, so "has the picture changed?" cannot be answered by comparing URLs,
	 * and re-downloading every photo on every run would turn a three-second
	 * sync into a nine-hour one.
	 *
	 * @since 1.1.0
	 * @param array[] $chunk       Rows to prepare.
	 * @param bool    $with_images Whether pictures are wanted at all.
	 * @return array[] The same rows, ready for the importer.
	 * @throws \RuntimeException When the API cannot be read.
	 */
	private function with_pictures( array $chunk, bool $with_images ): array {
		if ( empty( $chunk ) ) {
			return array();
		}

		// Nothing in this chunk has a photo — and most chunks will not, since
		// only products with one carry an address. Skip the catalogue lookup
		// too: it exists solely to decide which of them to fetch.
		$wanted = $with_images && '' !== implode( '', array_column( $chunk, 'images_href' ) );

		$fresh = $wanted ? $this->unknown_skus( array_column( $chunk, 'sku' ) ) : array();

		foreach ( $chunk as $index => $row ) {
			$href = (string) ( $row['images_href'] ?? '' );
			unset( $chunk[ $index ]['images_href'] );

			if ( '' === $href || ! isset( $fresh[ (string) $row['sku'] ] ) ) {
				continue;
			}

			$pictures = $this->fetch_pictures( $href );
			if ( empty( $pictures ) ) {
				continue;
			}

			$chunk[ $index ]['image']   = array_shift( $pictures );
			$chunk[ $index ]['gallery'] = $pictures;
		}

		return array_values( $chunk );
	}

	/**
	 * Which of these articles the catalogue does not have yet.
	 *
	 * Mirrors how the importer resolves an article to a product: straight from
	 * the `_sku` meta, with binned products left out so a deleted article comes
	 * back as a new product rather than being revived in the bin.
	 *
	 * @since 1.1.0
	 * @param string[] $skus Articles to look up.
	 * @return array<string, true> Articles with no product behind them.
	 */
	private function unknown_skus( array $skus ): array {
		$skus = array_values( array_unique( array_filter( array_map( 'strval', $skus ), 'strlen' ) ) );
		if ( empty( $skus ) ) {
			return array();
		}

		global $wpdb;

		$placeholders = implode( ',', array_fill( 0, count( $skus ), '%s' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$known = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT pm.meta_value
				FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = '_sku'
				AND pm.meta_value IN ({$placeholders})
				AND p.post_type = 'product'
				AND p.post_status != 'trash'",
				$skus
			)
		);
		// phpcs:enable

		$unknown = array_flip( $skus );
		foreach ( (array) $known as $sku ) {
			unset( $unknown[ (string) $sku ] );
		}

		return array_map(
			static function () {
				return true;
			},
			$unknown
		);
	}

	/**
	 * Resolve one product's pictures into URLs the loader can fetch.
	 *
	 * MoySklad's own links may not be used on a public page — the documentation
	 * says so in as many words — so the pictures are downloaded into the media
	 * library like any other supplier photo. Each link is a redirect that needs
	 * the token; what it points at does not, and must not receive it.
	 *
	 * @since 1.1.0
	 * @param string $href Address of the product's image collection.
	 * @return string[] Direct URLs, main picture first.
	 * @throws \RuntimeException When the API cannot be read.
	 */
	private function fetch_pictures( string $href ): array {
		$response = $this->client->get( $href );
		$rows     = isset( $response['rows'] ) && is_array( $response['rows'] ) ? $response['rows'] : array();
		$urls     = array();

		foreach ( $rows as $row ) {
			$download = (string) ( $row['meta']['downloadHref'] ?? '' );
			if ( '' === $download ) {
				continue;
			}

			$url = $this->client->resolve_redirect( $download );
			if ( '' !== $url ) {
				$urls[] = $url;
			}
		}

		return $urls;
	}

	/**
	 * Read the whole group tree.
	 *
	 * @since 1.1.0
	 * @return array[] Flat list of id/name/parent_id.
	 * @throws \RuntimeException When the API cannot be read.
	 */
	private function fetch_folders(): array {
		$folders = array();
		$offset  = 0;

		do {
			$page = $this->client->get(
				'entity/productfolder',
				array(
					'limit'  => self::PAGE,
					'offset' => $offset,
				)
			);

			$rows = isset( $page['rows'] ) && is_array( $page['rows'] ) ? $page['rows'] : array();
			foreach ( $rows as $row ) {
				$id = (string) ( $row['id'] ?? '' );
				if ( '' === $id ) {
					continue;
				}
				$folders[] = array(
					'id'        => $id,
					'name'      => (string) ( $row['name'] ?? $id ),
					'parent_id' => self::id_from_href( (string) ( $row['productFolder']['meta']['href'] ?? '' ) ),
				);
			}

			$offset   += self::PAGE;
			$size      = isset( $page['meta']['size'] ) ? (int) $page['meta']['size'] : 0;
			$page_size = count( $rows );
		} while ( self::PAGE === $page_size && ( 0 === $size || $offset < $size ) );

		return $folders;
	}

	/**
	 * Read stock for the whole warehouse in one request.
	 *
	 * The short report, not the detailed one: the short report costs a single
	 * unit of the rate limit and answers without pagination, the detailed one
	 * costs five and pages. The documentation recommends the short report for
	 * exactly this — frequent, quick stock refreshes.
	 *
	 * `$include_zero` decides what an absent product means. A full import does
	 * not care: a row the report leaves out is read as zero, and the import
	 * knows the whole catalogue anyway. The stock sync does care — it sees only
	 * this report, and without the zero lines it cannot tell "sold out" from
	 * "not in this report", so it would leave a sold-out product on sale.
	 *
	 * @since 1.1.0
	 * @since 1.1.0 Public, and able to ask for the zero lines.
	 * @param bool $include_zero Whether to ask for products whose stock is zero.
	 * @return array<string, int> Assortment id => quantity.
	 * @throws \RuntimeException When the API cannot be read.
	 */
	public function fetch_stock( bool $include_zero = false ): array {
		$type  = (string) ( $this->settings['stock_type'] ?? 'quantity' );
		$query = array( 'stockType' => $type );
		if ( $include_zero ) {
			$query['include'] = 'zeroLines';
		}

		$rows = $this->client->get( 'report/stock/all/current', $query );

		$stock = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) || empty( $row['assortmentId'] ) ) {
				continue;
			}

			// The quantity comes back under a key named after the stock type
			// that was asked for — `quantity`, `freeStock`, `reserve` — and only
			// the plain `stock` request answers with a field called `stock`.
			// Reading `stock` unconditionally is silently wrong for every other
			// type: the field is absent, every product reads as zero, and the
			// whole catalogue lands in the shop out of stock. Verified against a
			// live account, where the documented shape did not match.
			$quantity = $row[ $type ] ?? $row['stock'] ?? 0;

			$stock[ (string) $row['assortmentId'] ] = max( 0, (int) round( (float) $quantity ) );
		}

		return $stock;
	}

	/**
	 * Turn one assortment row into the plugin's normalised product shape.
	 *
	 * Deliberately the same keys the price-list converter produces, with one
	 * difference that matters: there is no `sale_price` key at all. MoySklad
	 * has no notion of "the price before the discount", and passing an empty
	 * value would read as "this product has no sale" — which would strip every
	 * sale price the shop had set by hand.
	 *
	 * @since 1.1.0
	 * @param array              $row   Assortment row.
	 * @param array<string, int> $stock Assortment id => quantity.
	 * @return array|null Normalised row, or null when the row cannot be used.
	 */
	private function normalize( array $row, array $stock ): ?array {
		$type = (string) ( $row['meta']['type'] ?? '' );
		// Services and bundles are not stocked goods and have no article of
		// their own to match on; variants arrive with their own handling in a
		// later stage. Anything else is skipped rather than guessed at.
		if ( 'product' !== $type ) {
			++$this->skipped;
			return null;
		}

		$id  = (string) ( $row['id'] ?? '' );
		$sku = $this->sku_of( $row );
		if ( '' === $id || '' === $sku ) {
			++$this->skipped;
			return null;
		}

		$prices = $this->prices_of( $row );
		if ( null === $prices['retail'] ) {
			++$this->unpriced;
			return null;
		}

		$folder = self::id_from_href( (string) ( $row['productFolder']['meta']['href'] ?? '' ) );

		$product = array(
			'sku'             => sanitize_text_field( $sku ),
			// MoySklad's own identifier for this product, stored on the product
			// so the stock sync can find it again. The stock report answers with
			// identifiers and nothing else — no article, no name — so without
			// this the only way to read it would be to fetch the whole assortment
			// on every sync, which is the cost the sync exists to avoid.
			'ms_id'           => $id,
			'name'            => mvweb_pi_clean_text( (string) ( $row['name'] ?? '' ) ),
			'description'     => mvweb_pi_clean_text( (string) ( $row['description'] ?? '' ), true ),
			'price'           => $prices['retail'],
			'wholesale_price' => $prices['wholesale'],
			'dealer_price'    => $prices['dealer'],
			'stock'           => $stock[ $id ] ?? 0,
			'image'           => '',
			'gallery'         => array(),
			'category_id'     => $folder,
			'category_name'   => '',
			'parent_cat_id'   => '',
			'parent_cat_name' => '',
			'barcode'         => self::barcode_of( $row ),
			'warehouse'       => 'moysklad',
			'stocks'          => array( 'moysklad' => $stock[ $id ] ?? 0 ),
			'tags'            => array(),
			// Kept only inside the dump; stripped before the row reaches the
			// importer, which has no use for an address it cannot fetch.
			//
			// Only for products that actually have a photo. The assortment row
			// already says how many there are, and asking a product with none
			// costs exactly as much as asking one with ten: measured against a
			// live account where one product in a thousand had a picture, that
			// is 999 requests spent to be told "nothing here" — about five
			// minutes of the account's rate limit, every import.
			'images_href'     => ( (int) ( $row['images']['meta']['size'] ?? 0 ) > 0 )
				? (string) ( $row['images']['meta']['href'] ?? '' )
				: '',
		);

		return $product;
	}

	/**
	 * The article this product is matched by.
	 *
	 * MoySklad's own identifier is the last resort: it is stable but meaningless
	 * to a shop assistant, and it would end up printed on the storefront.
	 *
	 * @since 1.1.0
	 * @param array $row Assortment row.
	 * @return string
	 */
	private function sku_of( array $row ): string {
		$preferred = 'code' === ( $this->settings['sku_field'] ?? 'article' ) ? 'code' : 'article';
		$fallback  = 'code' === $preferred ? 'article' : 'code';

		foreach ( array( $preferred, $fallback, 'id' ) as $field ) {
			$value = trim( (string) ( $row[ $field ] ?? '' ) );
			if ( '' !== $value ) {
				return $value;
			}
		}

		return '';
	}

	/**
	 * Pick the three prices out of the row's price list.
	 *
	 * MoySklad keeps money in kopecks. Forgetting to divide is the classic
	 * failure of this integration and it is not subtle: every price on the
	 * storefront comes out a hundred times too high.
	 *
	 * @since 1.1.0
	 * @param array $row Assortment row.
	 * @return array{retail: float|null, wholesale: float|null, dealer: float|null}
	 */
	private function prices_of( array $row ): array {
		$by_type = array();
		$list    = isset( $row['salePrices'] ) && is_array( $row['salePrices'] ) ? $row['salePrices'] : array();

		foreach ( $list as $price ) {
			$type = (string) ( $price['priceType']['id'] ?? '' );
			if ( '' === $type ) {
				continue;
			}
			$by_type[ $type ] = (float) ( $price['value'] ?? 0 ) / 100;
		}

		$pick = function ( string $key ) use ( $by_type ): ?float {
			$type = (string) ( $this->settings[ $key ] ?? '' );
			if ( '' === $type || ! isset( $by_type[ $type ] ) ) {
				return null;
			}
			return $by_type[ $type ] > 0 ? $by_type[ $type ] : null;
		};

		$retail = $pick( 'price_retail' );
		if ( null === $retail && ! empty( $by_type ) && '' === (string) ( $this->settings['price_retail'] ?? '' ) ) {
			// No retail price type chosen yet: take the first one MoySklad
			// lists rather than import the whole catalogue at no price.
			$first  = reset( $by_type );
			$retail = $first > 0 ? $first : null;
		}

		return array(
			'retail'    => $retail,
			'wholesale' => $pick( 'price_wholesale' ),
			'dealer'    => $pick( 'price_dealer' ),
		);
	}

	/**
	 * First barcode of any kind.
	 *
	 * @since 1.1.0
	 * @param array $row Assortment row.
	 * @return string
	 */
	private static function barcode_of( array $row ): string {
		$barcodes = isset( $row['barcodes'] ) && is_array( $row['barcodes'] ) ? $row['barcodes'] : array();

		foreach ( $barcodes as $barcode ) {
			if ( ! is_array( $barcode ) ) {
				continue;
			}
			foreach ( $barcode as $value ) {
				$value = trim( (string) $value );
				if ( '' !== $value ) {
					return sanitize_text_field( $value );
				}
			}
		}

		return '';
	}

	/**
	 * Pull the identifier out of a metadata link.
	 *
	 * MoySklad refers to related entities by URL, and the identifier is its last
	 * segment — with any query string (`?expand=…`) cut off first.
	 *
	 * @since 1.1.0
	 * @param string $href Metadata href.
	 * @return string
	 */
	private static function id_from_href( string $href ): string {
		if ( '' === $href ) {
			return '';
		}

		$path = (string) wp_parse_url( $href, PHP_URL_PATH );

		return (string) substr( strrchr( '/' . $path, '/' ), 1 );
	}

	/**
	 * Does the category filter drop this product?
	 *
	 * Borrowed from the converter rather than reimplemented: the two sources
	 * have to agree on what "excluded" means, and a second copy of the rule
	 * would drift from the first.
	 *
	 * @since 1.1.0
	 * @param string $category_id MoySklad group id.
	 * @return bool
	 */
	private function excluded( string $category_id ): bool {
		if ( null === $this->filter ) {
			$this->filter = new MVweb_PI_Converter();
		}

		return $this->filter->is_category_excluded( $category_id );
	}
}
