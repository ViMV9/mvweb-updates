<?php
/**
 * Cron class — scheduled import management.
 *
 * Manages wp-cron integration, import scheduling,
 * atomic lock mechanism, and the full import cycle.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Cron
 *
 * Handles automatic import scheduling via wp-cron, CLI, and REST triggers.
 * Uses atomic lock mechanism to prevent parallel imports.
 *
 * @since 1.0.0
 */
class MVweb_PI_Cron {

	/**
	 * Cron hook name.
	 *
	 * @var string
	 */
	const HOOK = 'mvweb_pi_cron_import';

	/**
	 * Lock option name.
	 *
	 * @var string
	 */
	const LOCK_OPTION = 'mvweb_pi_cron_lock';

	/**
	 * Lock TTL in seconds (30 minutes).
	 *
	 * @var int
	 */
	const LOCK_TTL = 1800;

	/**
	 * Value this process wrote into the lock row, or null when it holds no lock.
	 *
	 * The lock row stores the timestamp of whoever took it, so the timestamp
	 * doubles as proof of ownership: {@see renew_lock()} only writes when the
	 * row still carries the value this process put there. Without that check a
	 * renewal would happily refresh a lock another runner had already stolen,
	 * and both would believe they own it.
	 *
	 * @since 1.1.0
	 * @var string|null
	 */
	private static ?string $lock_token = null;

	/**
	 * MoySklad transport of the run in progress, when that is the source.
	 *
	 * Held so the end of the run can report how much of the account's request
	 * budget the import spent — the number that decides whether a schedule is
	 * sustainable, and the one nobody can see from the outside.
	 *
	 * @since 1.1.0
	 * @var MVweb_PI_MoySklad_Client|null
	 */
	private ?MVweb_PI_MoySklad_Client $ms_client = null;

	/**
	 * Wall-clock budget (seconds) for a single non-CLI run.
	 *
	 * Web/AJAX/wp-cron invocations honour this budget by stopping after the
	 * current batch and scheduling a continuation via wp_schedule_single_event.
	 * CLI runs (cron-runner.php, real system cron) ignore it — they have no
	 * max_execution_time worth respecting.
	 *
	 * 50 s leaves headroom under the typical 60 s PHP-FPM / FastCGI cap.
	 *
	 * @var int
	 */
	const WALL_CLOCK_BUDGET = 50;

	/**
	 * Hook name for scheduling a continuation batch.
	 *
	 * Separate from {@see HOOK} so wp_clear_scheduled_hook() on the regular
	 * recurring schedule never accidentally cancels an in-flight continuation.
	 *
	 * @var string
	 */
	const CONTINUE_HOOK = 'mvweb_pi_continue_import';

	/**
	 * Hook name for continuing an unfinished feed generation.
	 *
	 * Feed generation resumes without the import lock: it only reads the
	 * catalogue, so a continuation is safe to run alongside anything else.
	 *
	 * @since 1.0.27
	 * @var string
	 */
	const CONTINUE_FEEDS_HOOK = 'mvweb_pi_continue_feeds';

	/**
	 * Run the full import cycle.
	 *
	 * This method is called by wp-cron, CLI runner, and REST endpoint.
	 * It acquires a lock, downloads sources, converts data,
	 * imports categories and products, then releases the lock.
	 *
	 * @since 1.0.0
	 * @return array{status: string, stats?: array, message: string} Import result.
	 */
	public function run(): array {
		// Which source this site imports from. Read once, here, because the
		// answer decides which half of this method does the gathering — and
		// because everything after the gathering is deliberately the same for
		// both: one lock, one deadline, one set of hooks, one set of statistics.
		$mode = mvweb_pi_source_mode();

		mvweb_pi_log(
			sprintf( 'Import started (sapi=%s).', php_sapi_name() ),
			'debug'
		);

		// Self-heal: if invoked from CLI (system cron or cron-runner.php),
		// clear a lock that a previous fatal-aborted run may have left behind.
		// Only clear it when it's actually stale (older than LOCK_TTL) — an
		// unconditional delete here would wipe the lock of a *live* web/AJAX
		// import that's running right now (admin "Run import" button while the
		// system cron fires), letting two imports clobber each other in
		// WooCommerce. A genuinely stale lock is older than LOCK_TTL; a live
		// run keeps its timestamp fresh, so this never steals from a healthy
		// process. acquire_lock() handles the same staleness for non-CLI paths.
		if ( 'cli' === php_sapi_name() ) {
			$existing = (int) get_option( self::LOCK_OPTION, 0 );
			if ( $existing > 0 && ( time() - $existing ) >= self::LOCK_TTL ) {
				delete_option( self::LOCK_OPTION );
				mvweb_pi_log( 'CLI self-heal: stale lock pre-cleared.', 'debug' );
			}
		}

		// 1. Acquire lock (atomic).
		if ( ! $this->acquire_lock() ) {
			return array(
				'status'  => 'locked',
				'message' => __( 'Import is already running.', 'mvweb-price-importer' ),
			);
		}

		self::guard_lock_against_fatals();

		// Lift execution-time cap for the importer. CLI usually runs with
		// max_execution_time=0 already; for web/AJAX/cron contexts where
		// the host enforces a wall clock, we want as much headroom as the
		// hosting will give us. Image processing (Imagick resize) on large
		// catalogs blew through the previous hard limit of 600s.
		if ( function_exists( 'set_time_limit' ) ) {
			set_time_limit( 0 );
		}

		try {
			// Check for interrupted import (checkpoint/resume, v1.1).
			$skip_count  = 0;
			$resume_skus = array();
			$progress    = get_option( MVweb_PI_Importer::PROGRESS_OPTION );

			if ( is_array( $progress ) && ! empty( $progress['started_at'] ) ) {
				$age = time() - strtotime( $progress['started_at'] );
				if ( $age < MVweb_PI_Importer::PROGRESS_TTL ) {
					// Poison-pill guard. A checkpoint resumes by skipping the
					// first $processed products. If the product right after that
					// boundary triggers a real fatal/OOM (not a catchable
					// Exception — those are handled per-row), every resume dies
					// at the exact same spot and the import never advances. Track
					// how many times we resumed at an unchanged $processed; after
					// 3 dead resumes, discard the checkpoint and start fresh so a
					// single bad row can't wedge the importer forever.
					$processed = (int) ( $progress['processed'] ?? 0 );
					$attempts  = (int) ( $progress['resume_attempts'] ?? 0 );
					$last_at   = (int) ( $progress['resume_at_processed'] ?? -1 );
					$attempts  = ( $last_at === $processed ) ? $attempts + 1 : 1;

					if ( $attempts >= 3 ) {
						mvweb_pi_log(
							sprintf(
								/* translators: %d: product offset the import keeps dying at */
								__( 'Import keeps failing at product offset %d after repeated resumes. Discarding the checkpoint and starting fresh — inspect that feed row.', 'mvweb-price-importer' ),
								$processed
							),
							'error'
						);
						delete_option( MVweb_PI_Importer::PROGRESS_OPTION );
					} else {
						$progress['resume_attempts']     = $attempts;
						$progress['resume_at_processed'] = $processed;
						update_option( MVweb_PI_Importer::PROGRESS_OPTION, $progress, false );

						// Recent interrupted import — resume from checkpoint.
						$skip_count  = $processed;
						$resume_skus = $progress['new_skus'] ?? array();
						mvweb_pi_log(
							sprintf(
								/* translators: %d: number of already-processed products */
								__( 'Resuming interrupted import, skipping %d already-processed products.', 'mvweb-price-importer' ),
								$skip_count
							),
							'info'
						);
					}
				} else {
					// Stale progress record — discard and start fresh.
					delete_option( MVweb_PI_Importer::PROGRESS_OPTION );
				}
			}

			// Build the product stream for the configured source. Both branches
			// answer with either a stream to import or a finished result — "all
			// sources unchanged", "nothing is configured" — and a finished result
			// ends the run right here, before anything touches the catalogue.
			$prepared = ( 'moysklad' === $mode )
				? $this->prepare_moysklad( $skip_count )
				: $this->prepare_file();

			if ( ! isset( $prepared['products'] ) ) {
				return $prepared;
			}

			// The source could not honour the checkpoint and starts over. It has
			// already discarded the record; the counters have to follow, or the
			// import would carry statistics from a run it is no longer part of.
			if ( ! empty( $prepared['restart'] ) ) {
				$skip_count  = 0;
				$resume_skus = array();
			}

			$products = $prepared['products'];

			// 6. Import products into WooCommerce (with checkpoint/resume support).
			// CLI gets unlimited wall-clock; web/AJAX/wp-cron get a budget
			// and schedule a continuation when it expires.
			$deadline_ts = 'cli' === php_sapi_name() ? 0 : ( time() + self::WALL_CLOCK_BUDGET );

			$importer = new MVweb_PI_Importer();
			$stats    = $importer->run( $products, $skip_count, $resume_skus, $deadline_ts );

			// Importer bailed early because the wall-clock budget expired.
			// Progress is already persisted in mvweb_pi_import_progress; we
			// schedule a continuation 5 s out so the next PHP worker picks
			// up where we left off. The lock is released by `finally` below
			// — acquire_lock() on the next run will succeed because the
			// option is gone.
			if ( ! empty( $stats['incomplete'] ) ) {
				if ( ! wp_next_scheduled( self::CONTINUE_HOOK ) ) {
					wp_schedule_single_event( time() + 5, self::CONTINUE_HOOK );
				}
				mvweb_pi_log(
					sprintf(
						/* translators: %d: number of products processed in this slice */
						__( 'Import slice complete (%d products this run). Continuation scheduled.', 'mvweb-price-importer' ),
						$stats['processed'] ?? 0
					),
					'info'
				);

				return array(
					'status'  => 'continuing',
					'stats'   => $stats,
					'message' => __( 'Import in progress; next slice scheduled.', 'mvweb-price-importer' ),
				);
			}

			// The catalogue has been written; the dump it came from has served
			// its purpose. Dropping it here is what makes the next run fetch a
			// fresh one — and what keeps a copy of the supplier's whole
			// catalogue from sitting on disk between imports.
			if ( 'moysklad' === $mode ) {
				MVweb_PI_MoySklad_Source::drop_dump();
			}

			// 7. Save stats and log results.
			// Format last_run as a human-readable mysql timestamp (matches
			// class-importer's direct save) so the dashboard does not have
			// to render a unix timestamp.
			$result_stats = array_merge(
				$stats,
				array( 'last_run' => current_time( 'mysql' ) )
			);
			update_option( 'mvweb_pi_import_stats', $result_stats, false );

			mvweb_pi_log(
				sprintf(
					'Import stats persisted: %s.',
					wp_json_encode( array_intersect_key( $result_stats, array_flip( array( 'created', 'updated', 'skipped', 'errors', 'total' ) ) ) )
				),
				'debug'
			);

			mvweb_pi_log(
				sprintf(
					/* translators: 1: created count, 2: updated count, 3: skipped count, 4: error count */
					__( 'Import complete: %1$d created, %2$d updated, %3$d skipped, %4$d errors.', 'mvweb-price-importer' ),
					$stats['created'],
					$stats['updated'],
					$stats['skipped'],
					$stats['errors']
				),
				'info'
			);

			// 8. Generate feeds after import if enabled (TZ 9.4).
			$auto_generate = get_option( MVweb_PI_Feeds::OPTION_AUTO_GENERATE, '1' );
			if ( '1' === $auto_generate ) {
				try {
					$feeds_handler = new MVweb_PI_Feeds();

					// Same wall-clock discipline as the import itself: CLI runs
					// straight through, a web/cron worker builds what it can and
					// hands the rest to a scheduled continuation. Generation lands
					// at the tail of an import, where the request has already spent
					// most of its budget — running it in one go is exactly how a
					// large catalogue used to die half-way.
					$feeds_deadline = 'cli' === php_sapi_name() ? 0 : ( time() + self::WALL_CLOCK_BUDGET );
					$slice          = $feeds_handler->step( $feeds_deadline );

					if ( ! $slice['done'] ) {
						$this->schedule_feed_continuation();
						mvweb_pi_log(
							__( 'Feed generation slice complete; continuation scheduled.', 'mvweb-price-importer' ),
							'info'
						);
					} else {
						mvweb_pi_log(
							sprintf(
								/* translators: %d: number of feeds generated */
								__( 'Auto-generated %d feed(s) after import.', 'mvweb-price-importer' ),
								count( $slice['results'] )
							),
							'info'
						);
					}
				} catch ( \Throwable $e ) {
					mvweb_pi_log(
						sprintf(
							/* translators: %s: error message */
							__( 'Feed generation failed: %s', 'mvweb-price-importer' ),
							$e->getMessage()
						),
						'error'
					);
					$this->send_feed_error_email( $e->getMessage() );
				}
			}

			// 9. Email notification on errors (TZ 10.4).
			if ( $stats['errors'] > 0 ) {
				$this->send_error_email( $stats );
			}

			return array(
				'status'  => 'completed',
				'stats'   => $stats,
				'message' => __( 'Import complete.', 'mvweb-price-importer' ),
			);

		} catch ( \Exception $e ) {
			mvweb_pi_log(
				sprintf(
					/* translators: %s: error message */
					__( 'Import failed: %s', 'mvweb-price-importer' ),
					$e->getMessage()
				),
				'error'
			);

			$this->send_error_email(
				array(
					'errors'  => 1,
					'created' => 0,
					'updated' => 0,
					'message' => $e->getMessage(),
				)
			);

			return array(
				'status'  => 'error',
				'message' => $e->getMessage(),
			);

		} finally {
			// Reported on every exit, including a slice that ran out of clock
			// and one that ended in an error — those are exactly the runs where
			// the request count is worth knowing. MoySklad blocks an account
			// that overspends its budget, and nothing else on the site can see
			// how close a schedule is running to that line.
			if ( $this->ms_client instanceof MVweb_PI_MoySklad_Client ) {
				mvweb_pi_log(
					sprintf(
						/* translators: 1: number of API requests, 2: seconds spent waiting on the rate limit */
						__( 'MoySklad: %1$d API requests this run, %2$s s of them spent waiting on the rate limit.', 'mvweb-price-importer' ),
						$this->ms_client->sent(),
						number_format_i18n( $this->ms_client->throttled(), 1 )
					),
					'info'
				);
			}

			$this->release_lock();
		}
	}

	/**
	 * Gather the price-list catalogue into a stream of products.
	 *
	 * Everything specific to importing from a file lives here: which addresses
	 * to fetch, whether they have changed since last time, which parser suits
	 * the extension, and how the column mapping turns a row into a product.
	 *
	 * The return value says one of two things. `products` is a stream to
	 * import. Anything else is a finished run — nothing was configured, or
	 * nothing had changed — and the caller returns it as the result.
	 *
	 * @since 1.1.0 Split out of run() when a second kind of source appeared.
	 * @return array{products?: \Generator, status?: string, message?: string}
	 */
	private function prepare_file(): array {
		$settings   = get_option( 'mvweb_pi_settings', array() );
		$warehouses = $settings['warehouses'] ?? array();
		$source_url = $settings['source_url'] ?? '';

		// Build sources list.
		$sources = $this->build_sources( $warehouses, $source_url );

		if ( empty( $sources ) ) {
			return array(
				'status'  => 'error',
				'message' => __( 'No source URLs configured.', 'mvweb-price-importer' ),
			);
		}

		// 2–3. Download sources (with ETag check per warehouse).
		$loader      = new MVweb_PI_Loader();
		$upload_dir  = mvweb_pi_get_upload_dir();
		$downloaded  = array();
		$all_skipped = true;

		foreach ( $sources as $source ) {
			$url = $loader->convert_google_sheets_url( $source['url'] );

			// ETag check — skip unchanged files (TZ 2.6).
			$changed = $loader->check_etag( $url, $source['id'] );
			if ( ! $changed ) {
				// Reuse the previously downloaded file. The source files
				// carry a UUID suffix, so glob() (lexicographic order) does
				// not return them newest-last — end() could hand back an
				// older leftover. Pick the most recently modified one.
				$existing = glob( $upload_dir . 'source-' . $source['id'] . '-*' );
				if ( ! empty( $existing ) ) {
					usort(
						$existing,
						static function ( $a, $b ) {
							return filemtime( $a ) <=> filemtime( $b );
						}
					);
					$downloaded[ $source['id'] ] = end( $existing );
				}
				continue;
			}

			$all_skipped = false;

			// Clean up old source files for this warehouse.
			$old_files = glob( $upload_dir . 'source-' . $source['id'] . '-*' );
			if ( $old_files ) {
				foreach ( $old_files as $old_file ) {
					wp_delete_file( $old_file );
				}
			}

			// Download.
			do_action( 'mvweb_pi_before_download', $source['id'], $url );

			$format = $loader->detect_format( $url );
			$ext    = ( 'yml' === $format ) ? 'yml' : $format;
			$uuid   = wp_generate_uuid4();
			$dest   = $upload_dir . "source-{$source['id']}-{$uuid}.{$ext}";

			$download_result = $loader->download( $url, $dest );

			if ( is_wp_error( $download_result ) ) {
				mvweb_pi_log(
					sprintf(
						/* translators: 1: warehouse ID, 2: error message */
						__( 'Download failed for warehouse %1$s: %2$s', 'mvweb-price-importer' ),
						$source['id'],
						$download_result->get_error_message()
					),
					'error'
				);
				continue;
			}

			do_action( 'mvweb_pi_after_download', $source['id'], $dest );
			$downloaded[ $source['id'] ] = $dest;
		}

		// If all files unchanged and no downloaded files exist, skip import.
		if ( $all_skipped && empty( $downloaded ) ) {
			mvweb_pi_log( __( 'All sources unchanged. Import skipped.', 'mvweb-price-importer' ), 'info' );
			return array(
				'status'  => 'skipped',
				'message' => __( 'All sources unchanged. Import skipped.', 'mvweb-price-importer' ),
			);
		}

		if ( empty( $downloaded ) ) {
			return array(
				'status'  => 'error',
				'message' => __( 'No source files available for import.', 'mvweb-price-importer' ),
			);
		}

		// A warehouse that failed to download takes its whole branch of the
		// category tree with it, and the importer would read that absence as
		// "the supplier deleted these categories". Import what did arrive,
		// but keep the deletion pass out of this run.
		if ( count( $downloaded ) < count( $sources ) ) {
			add_filter( 'mvweb_pi_delete_vanished_categories', '__return_false' );
			mvweb_pi_log(
				sprintf(
					/* translators: 1: number of sources downloaded, 2: number of sources configured */
					__( 'Only %1$d of %2$d sources were downloaded. Categories missing from the feed will not be removed on this run.', 'mvweb-price-importer' ),
					count( $downloaded ),
					count( $sources )
				),
				'warning'
			);
		}

		// 4. Check mapping.
		$mapping  = get_option( 'mvweb_pi_mapping', array() );
		$required = array( 'sku', 'name', 'price', 'stock' );
		$missing  = array();
		foreach ( $required as $field ) {
			if ( empty( $mapping[ $field ] ) ) {
				$missing[] = $field;
			}
		}

		if ( ! empty( $missing ) ) {
			return array(
				'status'  => 'error',
				'message' => sprintf(
					/* translators: %s: comma-separated list of field names */
					__( 'Required fields not mapped: %s.', 'mvweb-price-importer' ),
					implode( ', ', $missing )
				),
			);
		}

		// 4. Convert to unified format.
		$converter = new MVweb_PI_Converter();
		$is_multi  = count( $downloaded ) > 1;

		// Pass 1: Extract categories (lightweight, no full normalization).
		$categories_data    = $converter->categories_only( $downloaded, $mapping );
		$categories_handler = new MVweb_PI_Categories();
		$categories_handler->import( $categories_data );

		// Pass 2: Stream products directly into importer (no buffering).
		if ( $is_multi ) {
			$products = $converter->merge_warehouses( $downloaded, $mapping );
		} else {
			$products = $converter->convert( $downloaded, $mapping );
		}

		return array( 'products' => $products );
	}

	/**
	 * Gather the MoySklad catalogue into a stream of products.
	 *
	 * The catalogue is pulled into a local dump first and imported from there.
	 * A resume reuses the dump the interrupted run left behind: re-reading a
	 * local file costs nothing, while re-fetching pages already processed —
	 * on every one of a long import's continuations — spends the account's
	 * request budget on work that is thrown away, and an account that
	 * overspends it is blocked for an hour by MoySklad, not by us.
	 *
	 * @since 1.1.0
	 * @param int $skip_count Products an interrupted run had already written.
	 * @return array{products?: \Generator, status?: string, message?: string}
	 * @throws \RuntimeException When the API cannot be read.
	 */
	private function prepare_moysklad( int $skip_count ): array {
		$settings = get_option( 'mvweb_pi_moysklad', array() );
		$token    = is_array( $settings ) ? (string) ( $settings['token'] ?? '' ) : '';

		if ( '' === $token ) {
			return array(
				'status'  => 'error',
				'message' => __( 'MoySklad is the selected data source, but the connection has not been set up yet. Open the MoySklad tab and connect an account.', 'mvweb-price-importer' ),
			);
		}

		$this->ms_client = new MVweb_PI_MoySklad_Client(
			$token,
			(int) ( $settings['rate_limit'] ?? MVweb_PI_MoySklad_Client::DEFAULT_RATE )
		);
		$source = new MVweb_PI_MoySklad_Source( $this->ms_client, $settings );

		$restart = false;

		if ( $skip_count > 0 && MVweb_PI_MoySklad_Source::has_dump() ) {
			mvweb_pi_log( 'MoySklad: resuming from the catalogue fetched by the interrupted run.', 'debug' );
		} else {
			// A checkpoint counts products, not names: it says "the first N
			// rows are done". That is only true of the very dump those rows
			// came from, and MoySklad does not promise to list its assortment
			// in the same order twice. Resuming against a freshly fetched
			// catalogue would therefore skip N arbitrary products and import
			// nothing for them. Starting over costs one run; getting it wrong
			// costs a catalogue that quietly disagrees with the warehouse.
			if ( $skip_count > 0 ) {
				$restart = true;
				delete_option( MVweb_PI_Importer::PROGRESS_OPTION );
				mvweb_pi_log(
					__( 'The interrupted MoySklad import cannot be resumed — the catalogue it was working from is gone. Starting the import over.', 'mvweb-price-importer' ),
					'warning'
				);
			}

			$fetched = $source->refresh();

			mvweb_pi_log(
				sprintf(
					/* translators: 1: number of products, 2: number of requests */
					__( 'MoySklad catalogue fetched: %1$d products in %2$d requests.', 'mvweb-price-importer' ),
					$fetched['products'],
					$fetched['requests']
				),
				'info'
			);

			// Products the catalogue carries but the shop will never see. Said
			// out loud because the alternative is an assortment that is quietly
			// smaller than the one in MoySklad, with nothing to point at.
			if ( $fetched['unpriced'] > 0 || $fetched['skipped'] > 0 ) {
				mvweb_pi_log(
					sprintf(
						/* translators: 1: products with no price, 2: entries of an unsupported kind */
						__( 'MoySklad: %1$d entries were left out because the chosen price type is not set on them, and %2$d because they are not stocked goods (services, kits, variants).', 'mvweb-price-importer' ),
						$fetched['unpriced'],
						$fetched['skipped']
					),
					'warning'
				);
			}
		}

		$categories = $source->categories();
		if ( ! empty( $categories ) ) {
			$categories_handler = new MVweb_PI_Categories();
			$categories_handler->import( $categories );
		}

		return array(
			'products' => $source->products(),
			'restart'  => $restart,
		);
	}

	/**
	 * Continue an unfinished feed generation.
	 *
	 * Bound to {@see self::CONTINUE_FEEDS_HOOK}: works one more slice and
	 * schedules itself again while the queue still holds work.
	 *
	 * @since 1.0.27
	 * @return void
	 */
	public function continue_feeds(): void {
		$feeds = new MVweb_PI_Feeds();
		if ( ! $feeds->is_running() ) {
			return;
		}

		if ( function_exists( 'set_time_limit' ) ) {
			set_time_limit( 0 );
		}

		try {
			$deadline = 'cli' === php_sapi_name() ? 0 : ( time() + self::WALL_CLOCK_BUDGET );
			$slice    = $feeds->step( $deadline );

			if ( ! $slice['done'] ) {
				$this->schedule_feed_continuation();
				return;
			}

			mvweb_pi_log(
				sprintf(
					/* translators: %d: number of feeds generated */
					__( 'Auto-generated %d feed(s) after import.', 'mvweb-price-importer' ),
					count( $slice['results'] )
				),
				'info'
			);
		} catch ( \Throwable $e ) {
			mvweb_pi_log(
				sprintf(
					/* translators: %s: error message */
					__( 'Feed generation failed: %s', 'mvweb-price-importer' ),
					$e->getMessage()
				),
				'error'
			);
			$this->send_feed_error_email( $e->getMessage() );
		}
	}

	/**
	 * Tell the administrator that an unattended feed generation gave up.
	 *
	 * Only the unattended paths report by mail — the post-import run and its
	 * scheduled continuations. A generation started from the Feeds screen shows
	 * its error on screen, so mailing that one would be noise.
	 *
	 * @since 1.0.27
	 * @param string $message Error the run failed with.
	 * @return void
	 */
	private function send_feed_error_email( string $message ): void {
		$admin_email = get_option( 'admin_email' );
		if ( empty( $admin_email ) ) {
			return;
		}

		$subject = sprintf(
			/* translators: %s: site name */
			__( '[%s] Feed Generation Error', 'mvweb-price-importer' ),
			get_bloginfo( 'name' )
		);

		$body_parts   = array();
		$body_parts[] = __( 'Automatic feed generation stopped with an error. The previously published feed is untouched and stays available, but it no longer reflects the latest import.', 'mvweb-price-importer' );
		$body_parts[] = '';
		$body_parts[] = $message;
		$body_parts[] = '';
		$body_parts[] = sprintf(
			/* translators: %s: admin URL */
			__( 'Generate the feed manually and see the log here: %s', 'mvweb-price-importer' ),
			admin_url( 'admin.php?page=mvweb-price-importer&tab=feeds' )
		);

		wp_mail( $admin_email, $subject, implode( "\n", $body_parts ) );
	}

	/**
	 * Schedule the next feed-generation slice.
	 *
	 * @since 1.0.27
	 * @return void
	 */
	private function schedule_feed_continuation(): void {
		if ( ! wp_next_scheduled( self::CONTINUE_FEEDS_HOOK ) ) {
			wp_schedule_single_event( time() + 5, self::CONTINUE_FEEDS_HOOK );
		}
	}

	/**
	 * Build sources list from settings.
	 *
	 * @since 1.0.0
	 * @param array  $warehouses Array of warehouse settings.
	 * @param string $source_url Single source URL (non-multiwarehouse mode).
	 * @return array Array of source items with 'id' and 'url' keys.
	 */
	private function build_sources( array $warehouses, string $source_url ): array {
		$sources = array();

		if ( ! empty( $warehouses ) ) {
			foreach ( $warehouses as $wh ) {
				if ( ! empty( $wh['url'] ) ) {
					$sources[] = array(
						'id'  => $wh['id'] ?? sanitize_title( $wh['name'] ?? '' ),
						'url' => $wh['url'],
					);
				}
			}
		} elseif ( ! empty( $source_url ) ) {
			$sources[] = array(
				'id'  => 'default',
				'url' => $source_url,
			);
		}

		return $sources;
	}

	/**
	 * Acquire import lock atomically.
	 *
	 * Strategy borrowed from the previous-generation importer (which
	 * survived production use without lock pile-ups): use add_option()
	 * — implemented as `INSERT ... ON DUPLICATE KEY UPDATE` at MySQL
	 * level — to guarantee mutual exclusion on the very first attempt.
	 * If the row already exists, fall back to a TTL check on its value
	 * and forcibly steal the lock once it crosses the staleness window.
	 *
	 * Why not UPDATE-with-WHERE: it requires the row to exist, and the
	 * stale-recovery path needs a separate query, which reopens a race
	 * window. add_option is single-shot atomic and matches what the
	 * legacy plugin used in production.
	 *
	 * @since 1.0.0
	 * @return bool True if lock acquired, false if another import is running.
	 */
	public function acquire_lock(): bool {
		global $wpdb;

		$now = time();

		// Atomic CAS: succeeds only if the option row didn't exist yet.
		// MySQL upholds uniqueness on option_name, so concurrent callers
		// cannot both win this race.
		$acquired = add_option( self::LOCK_OPTION, (string) $now, '', 'no' );
		if ( $acquired ) {
			self::$lock_token = (string) $now;
			mvweb_pi_log( 'Lock acquired (fresh).', 'debug' );
			return true;
		}

		// Row already there — inspect for staleness.
		$current = (int) get_option( self::LOCK_OPTION, 0 );

		// Decide whether the existing lock is steal-able: either a cleanly
		// released run left a 0 value, or a dead run left a timestamp older
		// than LOCK_TTL. An active, fresh lock is left alone.
		$stealable = ( 0 === $current ) || ( ( $now - $current ) >= self::LOCK_TTL );
		if ( ! $stealable ) {
			return false;
		}

		// Steal atomically. A plain get_option()+update_option() is a TOCTOU
		// race: two runners that both saw the same stale value would both
		// update and both believe they own the lock, running in parallel. The
		// conditional UPDATE only mutates the row if option_value is still the
		// exact value we read, so MySQL serialises the two writers and only one
		// gets rows_affected === 1. The loser falls through to "back off".
		$updated = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
				(string) $now,
				self::LOCK_OPTION,
				(string) $current
			)
		);

		if ( 1 === (int) $updated ) {
			self::$lock_token = (string) $now;
			// Drop the option from the alloptions cache so the new value is
			// read back correctly by this and other processes.
			wp_cache_delete( 'alloptions', 'options' );
			wp_cache_delete( self::LOCK_OPTION, 'options' );
			if ( ( $now - $current ) >= self::LOCK_TTL && $current > 0 ) {
				mvweb_pi_log(
					sprintf(
						/* translators: %d: seconds since the stale lock was acquired */
						__( 'Stealing stale import lock (%d seconds old).', 'mvweb-price-importer' ),
						$now - $current
					),
					'warning'
				);
			} else {
				mvweb_pi_log( 'Lock acquired (reused empty row).', 'debug' );
			}
			return true;
		}

		// Another runner won the steal, or the row changed under us — back off.
		return false;
	}

	/**
	 * Release the lock even if a fatal error kills the run.
	 *
	 * Belt-and-braces for whoever holds the lock: a fatal (max_execution_time,
	 * OOM, an Imagick crash) never reaches a `finally`, and PHP's shutdown
	 * handlers are the only thing that still runs afterwards. Without this the
	 * lock sits there until its TTL expires, holding off both the import and the
	 * stock sync for half an hour.
	 *
	 * Called by everything that takes the lock, so the handler is written once.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function guard_lock_against_fatals(): void {
		register_shutdown_function( static function () {
			$err = error_get_last();
			if ( ! $err || ! in_array( $err['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR ), true ) ) {
				return;
			}

			// Only ever release our own lock. A run long enough to have its lock
			// stolen after the TTL must not take the new owner's down with it on
			// the way out — the same ownership test renew_lock() makes, and for
			// the same reason. A null token means this process never held it.
			if ( null === self::$lock_token || (string) get_option( self::LOCK_OPTION, '' ) !== self::$lock_token ) {
				return;
			}

			delete_option( self::LOCK_OPTION );
			if ( function_exists( 'mvweb_pi_log' ) ) {
				mvweb_pi_log(
					sprintf( 'Lock released by shutdown handler after fatal: %s', $err['message'] ?? 'unknown' ),
					'error'
				);
			}
		} );
	}

	/**
	 * Release import lock.
	 *
	 * Deletes the option outright (matches legacy importer behaviour).
	 * acquire_lock() relies on add_option() returning false when the row
	 * exists, so leaving a zero-value row behind would force every future
	 * acquisition through the stale-check branch needlessly.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function release_lock(): void {
		delete_option( self::LOCK_OPTION );
		self::$lock_token = null;
		mvweb_pi_log( 'Lock released.', 'debug' );
	}

	/**
	 * Keep a long-running import's lock from going stale under it.
	 *
	 * The lock is taken once and its timestamp never moved, while a first import
	 * of a large catalogue with images runs for hours. Thirty minutes in, the
	 * lock looks abandoned to {@see acquire_lock()}, and the next tick of the
	 * schedule steals it from a process that is very much alive — two imports
	 * writing the same products. The importer calls this whenever it saves a
	 * checkpoint, which is the cheapest place that is guaranteed to be reached
	 * regularly for as long as the run lasts.
	 *
	 * The write is conditional on the row still holding this process's own
	 * timestamp. If the lock was already stolen, the UPDATE matches nothing and
	 * ownership is dropped rather than faked.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function renew_lock(): void {
		if ( null === self::$lock_token ) {
			return;
		}

		// One write per third of the TTL: often enough that the row can never
		// look stale, rare enough that a fast batch does not pay for it.
		$now = time();
		if ( ( $now - (int) self::$lock_token ) < (int) ( self::LOCK_TTL / 3 ) ) {
			return;
		}

		global $wpdb;

		$updated = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
				(string) $now,
				self::LOCK_OPTION,
				self::$lock_token
			)
		);

		if ( 1 === (int) $updated ) {
			self::$lock_token = (string) $now;
			wp_cache_delete( self::LOCK_OPTION, 'options' );
			return;
		}

		// The row no longer carries our timestamp: another runner took the lock
		// while we were working. Say so — a second importer writing the same
		// products leaves no other trace — and stop renewing someone else's.
		self::$lock_token = null;
		mvweb_pi_log(
			__( 'This import no longer holds the lock — another import took it over. Two imports may be writing at once; check the schedule and the log around this moment.', 'mvweb-price-importer' ),
			'warning'
		);
	}

	/**
	 * Send error notification email to site admin.
	 *
	 * Only sends when import has errors (TZ 10.4).
	 *
	 * @since 1.0.0
	 * @param array $stats Import statistics with 'errors', 'created', 'updated' keys.
	 * @return void
	 */
	private function send_error_email( array $stats ): void {
		$admin_email = get_option( 'admin_email' );
		if ( empty( $admin_email ) ) {
			return;
		}

		$site_name = get_bloginfo( 'name' );

		$subject = sprintf(
			/* translators: %s: site name */
			__( '[%s] Price Import Error', 'mvweb-price-importer' ),
			$site_name
		);

		$body_parts = array();

		if ( ! empty( $stats['message'] ) ) {
			$body_parts[] = $stats['message'];
			$body_parts[] = '';
		}

		$body_parts[] = sprintf(
			/* translators: 1: error count, 2: created count, 3: updated count */
			__( 'Errors: %1$d, Created: %2$d, Updated: %3$d', 'mvweb-price-importer' ),
			$stats['errors'] ?? 0,
			$stats['created'] ?? 0,
			$stats['updated'] ?? 0
		);

		$body_parts[] = '';
		$body_parts[] = sprintf(
			/* translators: %s: admin URL */
			__( 'Check import log: %s', 'mvweb-price-importer' ),
			admin_url( 'admin.php?page=mvweb-price-importer' )
		);

		wp_mail( $admin_email, $subject, implode( "\n", $body_parts ) );
	}

	/**
	 * Register custom cron intervals.
	 *
	 * Adds 'Every 6 hours' and 'Every 12 hours' intervals.
	 * WordPress already provides 'hourly' and 'daily'.
	 *
	 * @since 1.0.0
	 * @param array $schedules Existing cron schedules.
	 * @return array Modified schedules.
	 */
	public static function register_intervals( array $schedules ): array {
		// Minute-scale intervals belong to the stock sync, not to the import:
		// WordPress ships nothing shorter than hourly, and a stock refresh that
		// costs one request has no reason to wait an hour.
		$schedules['mvweb_pi_5min'] = array(
			'interval' => 5 * MINUTE_IN_SECONDS,
			'display'  => esc_html__( 'Every 5 minutes', 'mvweb-price-importer' ),
		);

		$schedules['mvweb_pi_15min'] = array(
			'interval' => 15 * MINUTE_IN_SECONDS,
			'display'  => esc_html__( 'Every 15 minutes', 'mvweb-price-importer' ),
		);

		$schedules['mvweb_pi_30min'] = array(
			'interval' => 30 * MINUTE_IN_SECONDS,
			'display'  => esc_html__( 'Every 30 minutes', 'mvweb-price-importer' ),
		);

		$schedules['mvweb_pi_6hours'] = array(
			'interval' => 6 * HOUR_IN_SECONDS,
			'display'  => esc_html__( 'Every 6 hours', 'mvweb-price-importer' ),
		);

		$schedules['mvweb_pi_12hours'] = array(
			'interval' => 12 * HOUR_IN_SECONDS,
			'display'  => esc_html__( 'Every 12 hours', 'mvweb-price-importer' ),
		);

		return $schedules;
	}

	/**
	 * Schedule or reschedule the cron event.
	 *
	 * Clears existing schedule and sets a new one based on the interval.
	 * Pass 'disabled' to unschedule without rescheduling.
	 *
	 * @since 1.0.0
	 * @param string $interval Cron recurrence key ('hourly', 'mvweb_pi_6hours', 'mvweb_pi_12hours', 'daily', 'disabled').
	 * @return void
	 */
	public static function schedule( string $interval ): void {
		wp_clear_scheduled_hook( self::HOOK );

		if ( 'disabled' !== $interval && ! empty( $interval ) ) {
			wp_schedule_event( time(), $interval, self::HOOK );
		} else {
			// Operator turned scheduling off — also drop any pending
			// continuation batch, otherwise a half-finished import would keep
			// firing CONTINUE_HOOK after the schedule was explicitly disabled.
			wp_clear_scheduled_hook( self::CONTINUE_HOOK );
		}
	}

	/**
	 * Check if cron is currently scheduled.
	 *
	 * @since 1.0.0
	 * @return string|false Recurrence string if scheduled, false otherwise.
	 */
	public static function get_schedule(): string|false {
		$event = wp_get_scheduled_event( self::HOOK );
		if ( ! $event ) {
			return false;
		}
		return $event->schedule;
	}

	/**
	 * Get next scheduled run timestamp.
	 *
	 * @since 1.0.0
	 * @return int|false Unix timestamp of next run, false if not scheduled.
	 */
	public static function get_next_run(): int|false {
		return wp_next_scheduled( self::HOOK );
	}

	/**
	 * Get available interval choices for settings UI.
	 *
	 * @since 1.0.0
	 * @return array Associative array of interval_key => label.
	 */
	public static function get_interval_choices(): array {
		return array(
			'disabled'         => __( 'Disabled', 'mvweb-price-importer' ),
			'hourly'           => __( 'Every hour', 'mvweb-price-importer' ),
			'mvweb_pi_6hours'  => __( 'Every 6 hours', 'mvweb-price-importer' ),
			'mvweb_pi_12hours' => __( 'Every 12 hours', 'mvweb-price-importer' ),
			'daily'            => __( 'Once daily', 'mvweb-price-importer' ),
		);
	}

	/**
	 * Check if import lock is currently active.
	 *
	 * @since 1.0.0
	 * @return bool True if locked, false if free.
	 */
	public static function is_locked(): bool {
		$lock = (int) get_option( self::LOCK_OPTION, 0 );
		if ( $lock <= 0 ) {
			return false;
		}

		// Treat stale locks as not-locked so callers (status endpoints, UI)
		// don't claim an import is running when it has actually died.
		if ( ( time() - $lock ) >= self::LOCK_TTL ) {
			return false;
		}

		return true;
	}
}
