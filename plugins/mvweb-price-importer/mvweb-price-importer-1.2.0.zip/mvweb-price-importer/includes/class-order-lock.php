<?php
/**
 * Holding the order status in the admin while MoySklad owns it.
 *
 * Once statuses are read back from MoySklad, two people are deciding what an
 * order's status is: the manager moving the document there, and whoever has the
 * order screen open here. They disagree quietly — the admin's choice stands for
 * a few minutes and is then overwritten by the next sync, which looks like the
 * site losing the change rather than the site being told what the status is.
 *
 * So the field stops accepting changes, and the way past it is a door with a
 * handle on it: a link, a screen that says what will happen, and only then the
 * status becomes editable — for that order, that person, and a quarter of an
 * hour. An order let through this way is marked as overridden and the sync
 * leaves it alone until the document moves again.
 *
 * @package mvweb_pi
 * @since   1.2.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Order_Lock
 *
 * @since 1.2.0
 */
class MVweb_PI_Order_Lock {

	/**
	 * Capability an emergency override needs.
	 *
	 * WordPress cannot say "may edit this order but not its status" — the whole
	 * screen is registered behind one capability — so the distinction is drawn
	 * here instead, at the one place that matters.
	 *
	 * @since 1.2.0
	 * @var string
	 */
	const CAPABILITY = 'manage_woocommerce';

	/**
	 * How long an unlocked order stays unlocked, in seconds.
	 *
	 * @since 1.2.0
	 * @var int
	 */
	const UNLOCK_TTL = 900;

	/**
	 * Register everything this class does.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function register(): void {
		// 35, and the number is the whole trick. WooCommerce saves the order
		// data — the status among it — at 40; items go at 10 and actions at 50
		// (src/Internal/Admin/Orders/Edit.php). Putting the status back before
		// it is read leaves every other field on the screen saving normally.
		//
		// Disabling the select instead would not work at all: a disabled field
		// is not posted, and WC_Meta_Box_Order_Data::save() throws
		// "Order status is missing." before it saves anything else.
		add_action( 'woocommerce_process_shop_order_meta', array( __CLASS__, 'hold_status' ), 35, 1 );

		// The same hook on the classic screen and on high-performance order
		// storage, so there is one place to say this rather than two.
		add_action( 'woocommerce_admin_order_data_after_order_details', array( __CLASS__, 'explain' ), 10, 1 );

		add_action( 'admin_post_mvweb_pi_status_unlock', array( __CLASS__, 'handle_unlock' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );

		// The order screen is not the only place in the admin where a status can
		// be changed, and a lock with two doors left open is not a lock. Both of
		// the others live in the orders list.
		//
		// The bulk action "Change status to …" never reaches the save hook above
		// — it calls update_status() on each order directly. This filter is
		// where both list tables pass their selection through
		// (src/Internal/Admin/Orders/ListTable.php:1450 and
		// includes/admin/list-tables/class-wc-admin-list-table-orders.php:481),
		// so one hook covers the classic screen and the new one.
		add_filter( 'woocommerce_bulk_action_ids', array( __CLASS__, 'hold_bulk' ), 10, 3 );

		// And the one-click buttons in the order row, which are a nonced link to
		// WC_AJAX::mark_order_status(). WooCommerce registers that handler at the
		// default priority, so this one runs first and can end the request.
		add_action( 'wp_ajax_woocommerce_mark_order_status', array( __CLASS__, 'hold_row_action' ), 1 );

		// Same buttons, hidden rather than merely inert: a control that visibly
		// does nothing reads as a broken shop. The classic list table does not
		// draw that column itself — it hands the order to the same ListTable
		// (includes/admin/list-tables/class-wc-admin-list-table-orders.php:206),
		// so this one filter covers both screens.
		add_filter( 'woocommerce_admin_order_actions', array( __CLASS__, 'hide_row_actions' ), 10, 2 );

		// The preview window behind the "Preview" link builds a second set of
		// the same buttons and passes them through a filter of its own
		// (includes/admin/list-tables/class-wc-admin-list-table-orders.php:403).
		add_filter( 'woocommerce_admin_order_preview_actions', array( __CLASS__, 'hide_preview_actions' ), 10, 2 );

		// The admin is not the only way in. WooCommerce accepts a status over
		// its REST API as well — the mobile app and any shop integration go
		// that way — and none of the hooks above sees those requests. Left
		// alone, such a change would stand for a few minutes and then be put
		// back by the next check, which is the very thing this lock exists to
		// prevent. The caller is told outright instead of being answered 200
		// and quietly overruled.
		add_filter( 'woocommerce_rest_pre_insert_shop_order_object', array( __CLASS__, 'hold_rest' ), 10, 3 );
	}

	/**
	 * Is this shop holding order statuses at all?
	 *
	 * @since 1.2.0
	 * @return bool
	 */
	private static function holding(): bool {
		if ( ! MVweb_PI_Orders::pull_enabled() ) {
			return false;
		}

		$settings = get_option( 'mvweb_pi_moysklad', array() );

		return is_array( $settings ) && ! empty( $settings['lock_status'] );
	}

	/**
	 * Is the status field being held for this order?
	 *
	 * Only orders MoySklad actually knows about. An order typed in by hand here
	 * has no document behind it and nobody else deciding its status.
	 *
	 * @since 1.2.0
	 * @param WC_Order $order Order.
	 * @return bool
	 */
	public static function locked( WC_Order $order ): bool {
		return self::holding() && '' !== (string) $order->get_meta( MVweb_PI_Orders::META_MS_ID );
	}

	/**
	 * Take held orders out of a bulk status change.
	 *
	 * Only the status actions: trashing, deleting and erasing personal data are
	 * none of this feature's business.
	 *
	 * @since 1.2.0
	 * @param int[]  $ids    Orders the bulk action is about to touch.
	 * @param string $action Bulk action name.
	 * @param string $type   Object type, `order` for these two list tables.
	 * @return int[]
	 */
	public static function hold_bulk( $ids, $action, $type ): array {
		$ids = array_map( 'absint', (array) $ids );

		if ( 'order' !== $type || ! str_starts_with( (string) $action, 'mark_' ) || ! self::holding() ) {
			return $ids;
		}

		$allowed = array();
		$held    = array();

		foreach ( $ids as $order_id ) {
			$order = wc_get_order( $order_id );

			if ( $order instanceof WC_Order && self::locked( $order ) ) {
				$held[] = $order->get_order_number();
				continue;
			}

			$allowed[] = $order_id;
		}

		if ( ! empty( $held ) ) {
			self::remember_held( $held );
		}

		return $allowed;
	}

	/**
	 * Stop the one-click status buttons in the orders list.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function hold_row_action(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- WooCommerce checks its own nonce in the handler this one runs ahead of; nothing is written here.
		$order_id = isset( $_GET['order_id'] ) ? absint( wp_unslash( $_GET['order_id'] ) ) : 0;

		$order = $order_id ? wc_get_order( $order_id ) : false;
		if ( ! $order instanceof WC_Order || ! self::locked( $order ) ) {
			return;
		}

		self::remember_held( array( $order->get_order_number() ) );

		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url() );
		exit;
	}

	/**
	 * Hide the one-click status buttons on a held order.
	 *
	 * @since 1.2.0
	 * @param array    $actions Row actions.
	 * @param WC_Order $order   Order the row belongs to.
	 * @return array
	 */
	public static function hide_row_actions( $actions, $order ): array {
		$actions = (array) $actions;

		if ( ! $order instanceof WC_Order || ! self::locked( $order ) ) {
			return $actions;
		}

		unset( $actions['processing'], $actions['complete'], $actions['on-hold'] );

		return $actions;
	}

	/**
	 * Hide the status buttons in the order preview window.
	 *
	 * The preview groups them under one key rather than listing them flat, so
	 * dropping that key takes the whole "Change status:" group with it and
	 * leaves the rest of the window as it was.
	 *
	 * @since 1.2.0
	 * @param array    $actions Preview actions.
	 * @param WC_Order $order   Order being previewed.
	 * @return array
	 */
	public static function hide_preview_actions( $actions, $order ): array {
		$actions = (array) $actions;

		if ( ! $order instanceof WC_Order || ! self::locked( $order ) ) {
			return $actions;
		}

		unset( $actions['status'] );

		return $actions;
	}

	/**
	 * Refuse a status change coming in over the REST API.
	 *
	 * The question "is the status being changed?" is asked of both the request
	 * and the object, because the two REST versions answer it in different
	 * places. Version 3 deliberately leaves the status for later — "Change
	 * should be done later so transitions have new data" in its
	 * prepare_object_for_database(), applied in save_object() just before the
	 * save — so at this point only the request knows. Version 2 applies it
	 * here, and then the object's change set knows. Either way a request that
	 * carries the status the order already has passes through, and one that
	 * merely edits an address is never in question.
	 *
	 * @since 1.2.0
	 * @param WC_Order|mixed  $order    Order about to be saved.
	 * @param WP_REST_Request $request  Request being served.
	 * @param bool            $creating Whether this creates a new order.
	 * @return WC_Order|WP_Error|mixed
	 */
	public static function hold_rest( $order, $request, $creating ) {
		if ( $creating || ! $order instanceof WC_Order ) {
			return $order;
		}

		$wanted = isset( $request['status'] ) ? (string) $request['status'] : '';

		if ( str_starts_with( $wanted, 'wc-' ) ) {
			$wanted = substr( $wanted, 3 );
		}

		$changes = $order->get_changes();
		$moving  = isset( $changes['status'] ) || ( '' !== $wanted && $wanted !== $order->get_status() );

		if ( ! $moving || ! self::locked( $order ) ) {
			return $order;
		}

		return new WP_Error(
			'mvweb_pi_status_held',
			__( 'The status of this order is set from MoySklad. Move the document there instead — the status here follows it on the next check.', 'mvweb-price-importer' ),
			array( 'status' => 409 )
		);
	}

	/**
	 * Put the status back to what it was, unless this order was unlocked.
	 *
	 * @since 1.2.0
	 * @param int $order_id Order being saved.
	 * @return void
	 */
	public static function hold_status( $order_id ): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- WooCommerce verifies its own nonce before this hook fires.
		if ( ! isset( $_POST['order_status'] ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order || ! self::locked( $order ) ) {
			return;
		}

		$current   = 'wc-' . $order->get_status();
		$submitted = sanitize_text_field( wp_unslash( $_POST['order_status'] ) );
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( $submitted === $current ) {
			return;
		}

		if ( self::unlocked( (int) $order_id ) ) {
			delete_transient( self::unlock_key( (int) $order_id ) );

			// Recorded on the order, not just allowed: the sync has to know
			// this status was chosen against MoySklad, or it would put its own
			// back within the interval.
			$order->update_meta_data( MVweb_PI_Orders::META_MANUAL, '1' );
			$order->save_meta_data();

			$order->add_order_note(
				sprintf(
					/* translators: %s: user who changed the status */
					__( 'Status changed by hand against MoySklad by %s. MoySklad will not correct it until the document moves to a state that is matched to a status here.', 'mvweb-price-importer' ),
					wp_get_current_user()->display_name
				)
			);

			return;
		}

		$_POST['order_status'] = $current;

		self::remember_held( array( $order->get_order_number() ) );
	}

	/**
	 * Keep a note of orders whose status was held, for the next page load.
	 *
	 * WooCommerce redirects after every one of these actions, so the message has
	 * to survive one hop. A transient per user does that without adding a row
	 * anybody has to clean up afterwards.
	 *
	 * @since 1.2.0
	 * @param string[] $numbers Order numbers.
	 * @return void
	 */
	private static function remember_held( array $numbers ): void {
		$stored = get_transient( self::held_key() );
		$stored = is_array( $stored ) ? $stored : array();

		set_transient(
			self::held_key(),
			array_slice( array_unique( array_merge( $stored, $numbers ) ), 0, 20 ),
			MINUTE_IN_SECONDS
		);
	}

	/**
	 * Say on the order screen who is deciding this order's status.
	 *
	 * @since 1.2.0
	 * @param WC_Order $order Order being shown.
	 * @return void
	 */
	public static function explain( $order ): void {
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$ms_id = (string) $order->get_meta( MVweb_PI_Orders::META_MS_ID );
		if ( '' === $ms_id || ! MVweb_PI_Orders::pull_enabled() ) {
			return;
		}

		$order_id = $order->get_id();
		$last     = get_option( MVweb_PI_Orders::STATUS_LAST_OPTION, array() );
		$last     = is_array( $last ) ? $last : array();
		$states   = self::state_names();
		$state    = (string) $order->get_meta( MVweb_PI_Orders::META_MS_STATE );
		$manual   = '' !== (string) $order->get_meta( MVweb_PI_Orders::META_MANUAL );

		echo '<p class="form-field form-field-wide mvweb-pi-order-lock">';

		if ( '' !== $state && isset( $states[ $state ] ) ) {
			printf(
				/* translators: %s: name of the MoySklad document state */
				esc_html__( 'In MoySklad: %s.', 'mvweb-price-importer' ),
				'<strong>' . esc_html( $states[ $state ] ) . '</strong>'
			);
			echo ' ';
		}

		if ( ! empty( $last['time'] ) ) {
			printf(
				/* translators: %s: human-readable time since the last check */
				esc_html__( 'Last checked %s ago.', 'mvweb-price-importer' ),
				esc_html( human_time_diff( (int) $last['time'], time() ) )
			);
			echo ' ';
		}

		if ( $manual ) {
			echo '<br>' . esc_html__( 'The status here was set by hand and MoySklad is not correcting it. It takes over again when the document moves to a state that is matched to a status here.', 'mvweb-price-importer' );
			echo '</p>';
			return;
		}

		if ( ! self::locked( $order ) ) {
			echo '</p>';
			return;
		}

		echo '<br>' . esc_html__( 'The status is managed by MoySklad. A change made here is put back when the order is saved.', 'mvweb-price-importer' );

		if ( ! current_user_can( self::CAPABILITY ) ) {
			echo '</p>';
			return;
		}

		if ( self::unlocked( $order_id ) ) {
			echo '<br><strong>' . esc_html__( 'Unlocked for the next quarter of an hour: choose a status and save the order.', 'mvweb-price-importer' ) . '</strong>';
			echo '</p>';
			return;
		}

		// Step one of two. The link only asks the question; nothing is unlocked
		// until the form on the other side of it is submitted.
		if ( ! self::asking( $order_id ) ) {
			printf(
				'<br><a href="%s">%s</a>',
				esc_url(
					wp_nonce_url(
						add_query_arg( 'mvweb_pi_unlock', $order_id, $order->get_edit_order_url() ),
						'mvweb_pi_unlock_' . $order_id
					)
				),
				esc_html__( 'Change the status by hand', 'mvweb-price-importer' )
			);
			echo '</p>';
			return;
		}

		echo '</p>';

		// Step two: what this actually does, and a link that means it.
		//
		// A link and not a form, because this is rendered inside WooCommerce's
		// own order form and a nested <form> is discarded by every browser.
		// Its own nonce, checked again on arrival together with the capability
		// — the same shape as the confirmation screens in wp-admin itself.
		$confirm = wp_nonce_url(
			add_query_arg(
				array(
					'action'   => 'mvweb_pi_status_unlock',
					'order_id' => $order_id,
				),
				admin_url( 'admin-post.php' )
			),
			'mvweb_pi_status_unlock_' . $order_id
		);

		echo '<div class="mvweb-pi-order-unlock notice notice-warning inline"><p>';
		echo esc_html__( 'The status here will stop matching MoySklad until the manager moves the document again. Everything a status change normally does still happens: the customer is emailed, and stock is taken or put back.', 'mvweb-price-importer' );
		echo '</p><p>';
		printf(
			'<a class="button button-primary" href="%s">%s</a> <a class="button" href="%s">%s</a>',
			esc_url( $confirm ),
			esc_html__( 'Yes, let me change it', 'mvweb-price-importer' ),
			esc_url( $order->get_edit_order_url() ),
			esc_html__( 'Leave it to MoySklad', 'mvweb-price-importer' )
		);
		echo '</p></div>';
	}

	/**
	 * Unlock one order for the person who confirmed it.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function handle_unlock(): void {
		$order_id = isset( $_GET['order_id'] ) ? absint( wp_unslash( $_GET['order_id'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- verified immediately below, and the id is what says which nonce to verify.

		check_admin_referer( 'mvweb_pi_status_unlock_' . $order_id );

		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to change the status of an order MoySklad manages.', 'mvweb-price-importer' ), '', array( 'response' => 403 ) );
		}

		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			wp_die( esc_html__( 'That order no longer exists.', 'mvweb-price-importer' ), '', array( 'response' => 404 ) );
		}

		// Per person as well as per order: one manager's decision to override
		// is not a licence for whoever opens the screen next.
		set_transient( self::unlock_key( $order_id ), 1, self::UNLOCK_TTL );

		wp_safe_redirect( $order->get_edit_order_url() );
		exit;
	}

	/**
	 * Tell whoever just tried that the status did not stick.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function notice(): void {
		$numbers = get_transient( self::held_key() );
		if ( ! is_array( $numbers ) || empty( $numbers ) ) {
			return;
		}

		delete_transient( self::held_key() );

		$list = implode( ', ', array_map( 'sanitize_text_field', $numbers ) );

		// Two sentences rather than one with a plural: they say different
		// things, and the plural machinery would only be in the way.
		$message = ( 1 === count( $numbers ) )
			? sprintf(
				/* translators: %s: order number */
				__( 'Order %s kept the status MoySklad gave it. Anything else you changed was saved. To override it, open the order and use "Change the status by hand".', 'mvweb-price-importer' ),
				$list
			)
			: sprintf(
				/* translators: 1: number of orders, 2: comma-separated order numbers */
				__( '%1$d orders kept the statuses MoySklad gave them: %2$s. Anything else you changed was saved. To override one, open it and use "Change the status by hand".', 'mvweb-price-importer' ),
				count( $numbers ),
				$list
			);

		printf(
			'<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
			esc_html( $message )
		);
	}

	/**
	 * Has this order been unlocked for the current user?
	 *
	 * @since 1.2.0
	 * @param int $order_id Order id.
	 * @return bool
	 */
	private static function unlocked( int $order_id ): bool {
		return current_user_can( self::CAPABILITY ) && false !== get_transient( self::unlock_key( $order_id ) );
	}

	/**
	 * Is the confirmation screen being asked for, with a valid nonce?
	 *
	 * @since 1.2.0
	 * @param int $order_id Order id.
	 * @return bool
	 */
	private static function asking( int $order_id ): bool {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- the nonce is verified on the last line of this method.
		if ( ! isset( $_GET['mvweb_pi_unlock'] ) || absint( wp_unslash( $_GET['mvweb_pi_unlock'] ) ) !== $order_id ) {
			return false;
		}

		$nonce = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		// Verified rather than asserted: check_admin_referer() would die here,
		// halfway through rendering an order screen, over a link that had
		// merely gone stale. Nothing is written on this path — the write is
		// behind the form's own nonce and capability check.
		return (bool) wp_verify_nonce( $nonce, 'mvweb_pi_unlock_' . $order_id );
	}

	/**
	 * Where an order's unlock is kept.
	 *
	 * @since 1.2.0
	 * @param int $order_id Order id.
	 * @return string
	 */
	private static function unlock_key( int $order_id ): string {
		return 'mvweb_pi_unlock_' . $order_id . '_' . get_current_user_id();
	}

	/**
	 * Where the "your change was put back" message waits for its page load.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	private static function held_key(): string {
		return 'mvweb_pi_status_held_' . get_current_user_id();
	}

	/**
	 * The state names MoySklad reported when the account was connected.
	 *
	 * @since 1.2.0
	 * @return array<string, string> State id => name.
	 */
	private static function state_names(): array {
		$settings = get_option( 'mvweb_pi_moysklad', array() );
		$states   = is_array( $settings ) && is_array( $settings['order_states'] ?? null )
			? $settings['order_states']
			: array();

		return array_map( 'strval', $states );
	}
}
