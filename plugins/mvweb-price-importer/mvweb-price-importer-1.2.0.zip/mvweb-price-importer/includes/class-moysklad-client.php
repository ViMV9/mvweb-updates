<?php
/**
 * MoySklad JSON API transport.
 *
 * Everything that knows about HTTP, authorisation and the API's rate limits
 * lives here; the source layer above it only asks for resources by path.
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_MoySklad_Client
 *
 * A thin, deliberately strict client for JSON API 1.2.
 *
 * Strict because of one line in the API documentation: an account that sends
 * more than 200 failing requests a minute for an hour is cut off, and access
 * comes back only through MoySklad's own support desk. A retry loop that keeps
 * hammering a broken endpoint would therefore take the shop's supplier data
 * offline until somebody writes an email in a foreign support queue. So a
 * request that has exhausted its retries throws, the import stops with its
 * checkpoint intact, and the next scheduled run tries again from there.
 *
 * @since 1.1.0
 */
class MVweb_PI_MoySklad_Client {

	/**
	 * API root.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const BASE = 'https://api.moysklad.ru/api/remap/1.2/';

	/**
	 * Length of the rate-limit window, in seconds.
	 *
	 * @since 1.1.0
	 * @var float
	 */
	const WINDOW = 3.0;

	/**
	 * Requests allowed per window for a plain user token.
	 *
	 * MoySklad lowers this to 11 on 1 December 2026; an application registered
	 * as a "solution" gets 45. The operator picks the applicable number in the
	 * settings, this is only the safe default.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const DEFAULT_RATE = 11;

	/**
	 * How many times one request is retried before it gives up.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const MAX_ATTEMPTS = 3;

	/**
	 * Access token.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	private string $token;

	/**
	 * Requests allowed per {@see self::WINDOW}.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	private int $rate;

	/**
	 * Timestamps of the requests made inside the current window.
	 *
	 * @since 1.1.0
	 * @var float[]
	 */
	private array $recent = array();

	/**
	 * Requests sent since this object was created.
	 *
	 * Reported at the end of a run: the number that matters when judging
	 * whether the import is anywhere near the account's limits.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	private int $sent = 0;

	/**
	 * Seconds spent waiting on the rate limiter.
	 *
	 * @since 1.1.0
	 * @var float
	 */
	private float $throttled = 0.0;

	/**
	 * Constructor.
	 *
	 * @since 1.1.0
	 * @param string $token Access token.
	 * @param int    $rate  Requests allowed per 3-second window.
	 */
	public function __construct( string $token, int $rate = self::DEFAULT_RATE ) {
		$this->token = $token;
		$this->rate  = max( 1, $rate );
	}

	/**
	 * Exchange a login and password for an access token.
	 *
	 * The only call that uses Basic authorisation. Credentials are never
	 * stored: the settings screen passes them straight into this method and
	 * keeps only what comes back.
	 *
	 * @since 1.1.0
	 * @param string $login    MoySklad login.
	 * @param string $password MoySklad password.
	 * @return string|\WP_Error Access token, or the reason it could not be issued.
	 */
	public static function issue_token( string $login, string $password ) {
		$response = wp_remote_post(
			self::BASE . 'security/token',
			array(
				'timeout' => 30,
				'headers' => array(
					'Authorization'   => 'Basic ' . base64_encode( $login . ':' . $password ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- HTTP Basic requires base64, this is not obfuscation.
					// Without this the API answers 415 with an empty body — the
					// single most common way a first integration fails.
					'Accept-Encoding' => 'gzip',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code && 201 !== $code ) {
			return new \WP_Error(
				'mvweb_pi_moysklad_auth',
				self::describe_error( $code, $body )
			);
		}

		$token = is_array( $body ) && isset( $body['access_token'] ) ? (string) $body['access_token'] : '';
		if ( '' === $token ) {
			return new \WP_Error(
				'mvweb_pi_moysklad_auth',
				__( 'MoySklad accepted the login but returned no access token.', 'mvweb-price-importer' )
			);
		}

		return $token;
	}

	/**
	 * GET a resource and return its decoded body.
	 *
	 * @since 1.1.0
	 * @param string   $path    Path relative to {@see self::BASE}, or a full API URL.
	 * @param array    $query   Query arguments.
	 * @param string[] $headers Extra request headers.
	 * @return array Decoded JSON body.
	 * @throws \RuntimeException When the request cannot be completed.
	 */
	public function get( string $path, array $query = array(), array $headers = array() ): array {
		$url = str_starts_with( $path, 'http' ) ? $path : self::BASE . ltrim( $path, '/' );
		if ( ! empty( $query ) ) {
			$url = add_query_arg( $query, $url );
		}

		$response = $this->request( $url, $headers );
		$body     = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		return is_array( $body ) ? $body : array();
	}

	/**
	 * POST a document and return what the API made of it.
	 *
	 * Retries the same way a read does, and that is safe for exactly one reason:
	 * every document this plugin creates carries a `syncId` derived from the
	 * WooCommerce order it represents. MoySklad answers a repeat of a request it
	 * has already accepted with the entity it created the first time rather than
	 * creating a second one — so a retry after a timeout cannot double an order.
	 * A POST without a `syncId` must not go through here.
	 *
	 * @since 1.1.0
	 * @param string $path Path relative to {@see self::BASE}.
	 * @param array  $body Document to send.
	 * @return array Decoded JSON body.
	 * @throws \RuntimeException When the request cannot be completed.
	 */
	public function post( string $path, array $body ): array {
		$url = str_starts_with( $path, 'http' ) ? $path : self::BASE . ltrim( $path, '/' );

		$response = $this->request(
			$url,
			array( 'Content-Type' => 'application/json' ),
			array(
				'method' => 'POST',
				'body'   => wp_json_encode( $body ),
			)
		);

		$decoded = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * Follow one authorised redirect and return where it points.
	 *
	 * MoySklad hands out file downloads as a 302 to a short-lived storage URL:
	 * the redirect needs the token, the URL behind it does not and must not get
	 * it. Resolving the two hops separately is what lets the file itself be
	 * fetched by the plugin's ordinary loader, with its SSRF checks intact —
	 * and keeps the token from being sent to a host outside the API.
	 *
	 * @since 1.1.0
	 * @param string $url Authorised URL that answers with a redirect.
	 * @return string Target URL, empty when the response carried no location.
	 * @throws \RuntimeException When the request cannot be completed.
	 */
	public function resolve_redirect( string $url ): string {
		$response = $this->request(
			$url,
			array(),
			array(
				'redirection' => 0,
				'timeout'     => 30,
			)
		);

		return (string) wp_remote_retrieve_header( $response, 'location' );
	}

	/**
	 * How many requests this client has sent.
	 *
	 * @since 1.1.0
	 * @return int
	 */
	public function sent(): int {
		return $this->sent;
	}

	/**
	 * How long this client spent waiting on the rate limiter, in seconds.
	 *
	 * @since 1.1.0
	 * @return float
	 */
	public function throttled(): float {
		return $this->throttled;
	}

	/**
	 * Replace the access token wherever it appears in a string.
	 *
	 * Applied to everything this class logs or throws. The token is a bearer
	 * credential — anyone holding it can read and write the whole MoySklad
	 * account — and the plugin's log file sits in wp-content/uploads behind an
	 * .htaccess that Nginx never reads.
	 *
	 * @since 1.1.0
	 * @param string $message Text that may contain the token.
	 * @return string
	 */
	public function redact( string $message ): string {
		if ( '' === $this->token ) {
			return $message;
		}

		return str_replace( $this->token, '***', $message );
	}

	/**
	 * Perform one request, honouring the rate limit and retrying where it is safe.
	 *
	 * Only 429 (rate limit) and 5xx (server-side) are retried; every 4xx is
	 * final, because repeating a request the API has already rejected is
	 * exactly what the account-level block counts.
	 *
	 * @since 1.1.0
	 * @param string   $url     Absolute URL.
	 * @param string[] $headers Extra request headers.
	 * @param array    $args    Extra wp_remote_request() arguments (method, body).
	 * @return array WP HTTP response array.
	 * @throws \RuntimeException When the request cannot be completed.
	 */
	private function request( string $url, array $headers = array(), array $args = array() ): array {
		$attempt = 0;

		while ( true ) {
			++$attempt;
			$this->throttle();

			// wp_remote_request(), not wp_remote_get(): the latter forces
			// `method` to GET and would quietly turn a POST into a read.
			$response = wp_remote_request(
				$url,
				array_merge(
					array(
						'timeout' => 60,
						'headers' => array_merge(
							array(
								'Authorization' => 'Bearer ' . $this->token,
								// Mandatory: without it the API answers 415
								// with an empty body.
								'Accept-Encoding' => 'gzip',
								'Accept'          => 'application/json;charset=utf-8',
							),
							$headers
						),
					),
					$args
				)
			);

			++$this->sent;

			if ( is_wp_error( $response ) ) {
				// A transport failure (DNS, TLS, timeout) never reached the
				// API, so it cannot count towards the account block. Worth one
				// more try before giving up on the run.
				if ( $attempt < self::MAX_ATTEMPTS ) {
					$this->pause( $attempt );
					continue;
				}
				throw new \RuntimeException(
					$this->redact( $response->get_error_message() )
				);
			}

			$code = (int) wp_remote_retrieve_response_code( $response );

			if ( $code >= 200 && $code < 400 ) {
				return $response;
			}

			$retryable = ( 429 === $code || $code >= 500 );
			if ( $retryable && $attempt < self::MAX_ATTEMPTS ) {
				$this->pause( $attempt, (string) wp_remote_retrieve_header( $response, 'x-lognex-retry-after' ) );
				continue;
			}

			$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
			throw new \RuntimeException(
				$this->redact( self::describe_error( $code, $body ) )
			);
		}
	}

	/**
	 * Wait out the rate limit before sending the next request.
	 *
	 * A sliding window rather than a fixed delay: the burst at the start of a
	 * run goes through at full speed, and only once the window is full does the
	 * client wait for the oldest request to age out of it.
	 *
	 * This waits — it never returns early or gives up. A source that stopped
	 * yielding here would look to the importer exactly like a feed that had
	 * ended, and the import would then take every product it had not reached
	 * yet off sale.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	private function throttle(): void {
		$now          = microtime( true );
		$this->recent = array_values(
			array_filter(
				$this->recent,
				static function ( $stamp ) use ( $now ) {
					return ( $now - $stamp ) < self::WINDOW;
				}
			)
		);

		if ( count( $this->recent ) >= $this->rate ) {
			$wait = self::WINDOW - ( $now - $this->recent[0] );
			if ( $wait > 0 ) {
				$this->throttled += $wait;
				usleep( (int) ( $wait * 1000000 ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.prevent_path_disclosure_error_reporting,WordPress.PHP.DiscouragedPHPFunctions
			}
			$now = microtime( true );
		}

		$this->recent[] = $now;
	}

	/**
	 * Back off between attempts.
	 *
	 * @since 1.1.0
	 * @param int    $attempt     Attempt number that has just failed.
	 * @param string $retry_after Value of the X-Lognex-Retry-After header, in milliseconds.
	 * @return void
	 */
	private function pause( int $attempt, string $retry_after = '' ): void {
		$seconds = ( '' !== $retry_after && is_numeric( $retry_after ) )
			? ( (float) $retry_after / 1000 )
			: (float) ( 2 ** $attempt );

		// A server that asks for a very long wait is telling us to come back on
		// another run, not to hold this PHP worker open.
		$seconds = min( 30.0, max( 0.5, $seconds ) );

		$this->throttled += $seconds;
		usleep( (int) ( $seconds * 1000000 ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
	}

	/**
	 * Turn an API error response into something an operator can act on.
	 *
	 * @since 1.1.0
	 * @param int        $code HTTP status.
	 * @param array|null $body Decoded response body.
	 * @return string
	 */
	private static function describe_error( int $code, $body ): string {
		$detail = '';
		if ( is_array( $body ) && ! empty( $body['errors'] ) && is_array( $body['errors'] ) ) {
			$first  = reset( $body['errors'] );
			$detail = is_array( $first ) ? (string) ( $first['error'] ?? '' ) : '';
		}

		if ( 401 === $code || 403 === $code ) {
			return __( 'MoySklad refused the credentials. Check the login and password, or issue a new token.', 'mvweb-price-importer' )
				. ( '' !== $detail ? ' ' . $detail : '' );
		}

		if ( 415 === $code ) {
			return __( 'MoySklad rejected the request format (415). This is what the API answers when a request arrives without gzip support.', 'mvweb-price-importer' );
		}

		if ( 429 === $code ) {
			return __( 'MoySklad is rate-limiting this account. The sync stopped rather than keep retrying: an account that keeps sending rejected requests is blocked for an hour, and only MoySklad support can lift that.', 'mvweb-price-importer' );
		}

		return sprintf(
			/* translators: 1: HTTP status code, 2: error text from the API */
			__( 'MoySklad answered %1$d: %2$s', 'mvweb-price-importer' ),
			$code,
			'' !== $detail ? $detail : __( 'no details given.', 'mvweb-price-importer' )
		);
	}
}
