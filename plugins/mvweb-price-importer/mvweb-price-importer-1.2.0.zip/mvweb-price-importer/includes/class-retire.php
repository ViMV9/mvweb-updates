<?php
/**
 * Taking the previous supplier's catalogue off the shelf.
 *
 * Switching the data source used to leave the old catalogue exactly where it
 * was, on the assumption that the new source would match its products back by
 * article. Two suppliers rarely share articles, so what actually happened was
 * both catalogues on the storefront at once — measured on the test site as 1000
 * products becoming 1699, with the old thousand still on sale at yesterday's
 * stock.
 *
 * The reason nothing swept them up is worth stating, because it decides the
 * whole design: the importer's stock-out pass only considers products in the
 * categories named by `mvweb_pi_category_map`, and switching the source clears
 * that option a moment earlier. After the switch the plugin can no longer tell
 * the old cohort from products somebody added by hand.
 *
 * Hence the snapshot. The list of ids is taken **before** the state is cleared,
 * while the map still stands, and everything afterwards works from that list.
 * No new meta on fifteen thousand products, and installations that predate this
 * feature get it working on their next switch.
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Retire
 *
 * @since 1.1.0
 */
class MVweb_PI_Retire {

	/**
	 * Option holding the pending retirement.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const PENDING_OPTION = 'mvweb_pi_retire_pending';

	/**
	 * Product meta recording that this product was retired, and from what.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const META = '_mvweb_pi_retired';

	/**
	 * Products handled per slice.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const SLICE = 200;

	/**
	 * Order statuses whose products must keep a working URL.
	 *
	 * Wider than the set the stock reservation uses: this asks "is the product
	 * mentioned in an order somebody is still dealing with", not "how many units
	 * are spoken for", so an order on hold that never reduced stock counts too.
	 *
	 * @since 1.1.0
	 * @return string[]
	 */
	public static function open_order_statuses(): array {
		/**
		 * Order statuses that keep a retired product reachable by URL.
		 *
		 * @since 1.1.0
		 * @param string[] $statuses Order statuses, `wc-` prefixed.
		 */
		return (array) apply_filters(
			'mvweb_pi_retire_open_order_statuses',
			array( 'wc-pending', 'wc-on-hold', 'wc-processing' )
		);
	}

	/**
	 * What the current catalogue looks like, before anything is decided.
	 *
	 * Called while the category map is still intact — that is, from the settings
	 * screen before the switch is saved, and from the switch itself.
	 *
	 * @since 1.1.0
	 * @return array{ids: int[], in_orders: int[], manual: int}
	 */
	public static function survey(): array {
		$importer = new MVweb_PI_Importer();
		$catalog  = $importer->collect_managed_catalog_skus();

		$ours   = array();
		$manual = 0;

		foreach ( $catalog as $product_id => $sku ) {
			$product_id = (int) $product_id;

			// A product with no article was never written from a supplier offer,
			// and one without any of the plugin's own marks was not written by
			// the plugin at all. Both are somebody's manual work sitting in a
			// category the plugin happens to manage, and neither is ours to
			// take off the shelf. Erring this way is the safe direction: a
			// missed product stays visible and is spotted by eye, while a
			// wrongly hidden one is somebody's work undone.
			$is_ours = '' !== (string) $sku
				&& (
					'' !== (string) get_post_meta( $product_id, '_mvweb_pi_feed_cat_term_id', true )
					|| '' !== (string) get_post_meta( $product_id, MVweb_PI_Stock_Sync::ID_META, true )
				);

			if ( $is_ours ) {
				$ours[] = $product_id;
			} else {
				++$manual;
			}
		}

		return array(
			'ids'       => $ours,
			'in_orders' => self::in_open_orders( $ours ),
			'manual'    => $manual,
		);
	}

	/**
	 * Which of these products are mentioned in orders still being dealt with.
	 *
	 * One query over WooCommerce's own order-item tables rather than a walk over
	 * every open order in PHP. Those tables are the same with and without
	 * high-performance order storage — the HPOS migration deliberately left them
	 * alone — so this works on both.
	 *
	 * @since 1.1.0
	 * @param int[] $ids Product ids to check.
	 * @return int[] Those of them that appear in an open order.
	 */
	public static function in_open_orders( array $ids ): array {
		if ( empty( $ids ) || ! function_exists( 'wc_get_orders' ) ) {
			return array();
		}

		$order_ids = wc_get_orders(
			array(
				'limit'  => -1,
				'type'   => 'shop_order',
				'status' => self::open_order_statuses(),
				'return' => 'ids',
			)
		);

		if ( empty( $order_ids ) ) {
			return array();
		}

		global $wpdb;

		$ids       = array_map( 'intval', $ids );
		$order_ids = array_map( 'intval', (array) $order_ids );

		$id_slots    = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$order_slots = implode( ',', array_fill( 0, count( $order_ids ), '%d' ) );

		$sql = "SELECT DISTINCT oim.meta_value
			FROM {$wpdb->prefix}woocommerce_order_itemmeta oim
			INNER JOIN {$wpdb->prefix}woocommerce_order_items oi
			        ON oi.order_item_id = oim.order_item_id
			WHERE oim.meta_key IN ( '_product_id', '_variation_id' )
			  AND oim.meta_value IN ( {$id_slots} )
			  AND oi.order_id IN ( {$order_slots} )";

		// The query is assembled above from `%d` placeholders only — the counts
		// of ids decide how many, which is why it cannot be a literal here — and
		// every value goes through prepare() below.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery
		$found = $wpdb->get_col(
			$wpdb->prepare( $sql, array_merge( $ids, $order_ids ) )
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery

		return array_map( 'intval', (array) $found );
	}

	/**
	 * Remember what to retire, and how, before the state is cleared.
	 *
	 * @since 1.1.0
	 * @param string $from   Source being left.
	 * @param string $to     Source being adopted.
	 * @param string $action `retire` or `keep`.
	 * @return array{ids: int[], in_orders: int[], manual: int}
	 */
	public static function capture( string $from, string $to, string $action ): array {
		$survey = self::survey();

		if ( 'retire' !== $action || empty( $survey['ids'] ) ) {
			delete_option( self::PENDING_OPTION );
			return $survey;
		}

		update_option(
			self::PENDING_OPTION,
			array(
				'ids'        => $survey['ids'],
				'in_orders'  => $survey['in_orders'],
				'from'       => $from,
				'to'         => $to,
				'created_at' => time(),
				'done'       => array(),
			),
			false
		);

		return $survey;
	}

	/**
	 * Is a retirement waiting for the first successful import?
	 *
	 * @since 1.1.0
	 * @return array|null
	 */
	public static function pending(): ?array {
		$pending = get_option( self::PENDING_OPTION );

		return ( is_array( $pending ) && ! empty( $pending['ids'] ) ) ? $pending : null;
	}

	/**
	 * Take the old catalogue off the shelf, minus whatever the new source claimed.
	 *
	 * Runs at the tail of a completed import — the point where the new source has
	 * proved it works and its articles are known. A product whose article arrived
	 * in this run is not retired: the two suppliers happen to carry it, and the
	 * import has just updated it.
	 *
	 * @since 1.1.0
	 * @param string[] $imported_skus Articles the finished import carried.
	 * @param int      $deadline      Unix timestamp to stop at, 0 for no limit.
	 * @return array{retired: int, hidden: int, kept: int, left: int}
	 */
	public static function apply( array $imported_skus, int $deadline = 0 ): array {
		$result = array(
			'retired' => 0,
			'hidden'  => 0,
			'kept'    => 0,
			'left'    => 0,
		);

		$pending = self::pending();
		if ( null === $pending ) {
			return $result;
		}

		$survivors = array_flip( array_map( 'strval', $imported_skus ) );
		$in_orders = array_flip( array_map( 'intval', (array) ( $pending['in_orders'] ?? array() ) ) );
		$done      = array_flip( array_map( 'intval', (array) ( $pending['done'] ?? array() ) ) );

		$handled = array();

		foreach ( (array) $pending['ids'] as $product_id ) {
			$product_id = (int) $product_id;

			if ( isset( $done[ $product_id ] ) ) {
				continue;
			}

			// Already carried by the new source under the same article.
			$sku = (string) get_post_meta( $product_id, '_sku', true );
			if ( '' !== $sku && isset( $survivors[ $sku ] ) ) {
				++$result['kept'];
				$handled[] = $product_id;
				continue;
			}

			$mode = isset( $in_orders[ $product_id ] ) ? 'hidden' : 'draft';
			if ( self::retire_one( $product_id, $mode ) ) {
				++$result[ 'hidden' === $mode ? 'hidden' : 'retired' ];
			}

			$handled[] = $product_id;

			// Checked every slice rather than every product: `time()` on each of
			// fifteen thousand iterations buys nothing, and a slice is quick.
			//
			// Without a deadline — a CLI run — this goes to the end. With one,
			// it stops and the rest waits for the next import. The alternative,
			// a fixed number per run, would spread a thousand products over five
			// days of a daily schedule while the storefront shows both
			// catalogues at once.
			if ( $deadline > 0 && 0 === count( $handled ) % self::SLICE && time() >= $deadline ) {
				break;
			}
		}

		$pending['done'] = array_values( array_unique( array_merge( (array) $pending['done'], $handled ) ) );
		$result['left']  = max( 0, count( $pending['ids'] ) - count( $pending['done'] ) );

		if ( 0 === $result['left'] ) {
			delete_option( self::PENDING_OPTION );
		} else {
			update_option( self::PENDING_OPTION, $pending, false );
		}

		mvweb_pi_log(
			sprintf(
				/* translators: 1: products moved to draft, 2: products hidden, 3: products kept, 4: products still to do */
				__( 'Previous catalogue: %1$d taken off the shelf, %2$d hidden but left reachable (they are in open orders), %3$d kept because the new source carries them, %4$d still to process.', 'mvweb-price-importer' ),
				$result['retired'],
				$result['hidden'],
				$result['kept'],
				$result['left']
			),
			'warning'
		);

		return $result;
	}

	/**
	 * Take one product off the shelf.
	 *
	 * Two ways, and the difference matters. A product nobody has ordered becomes
	 * a draft: off the storefront, out of search, out of the sitemap, everything
	 * about it kept. A product sitting in an open order stays published and is
	 * merely hidden from the catalogue and search, because its URL still has to
	 * work — the customer's order page, the confirmation email and "my orders"
	 * all link to it.
	 *
	 * Never the wastebasket. WordPress empties it after `EMPTY_TRASH_DAYS` and
	 * the product is then gone for good, at which point WooCommerce cannot open
	 * *any* past order containing it — not merely the open ones.
	 *
	 * @since 1.1.0
	 * @param int    $product_id Product to retire.
	 * @param string $mode       `draft` or `hidden`.
	 * @return bool Whether anything changed.
	 */
	private static function retire_one( int $product_id, string $mode ): bool {
		$post = get_post( $product_id );
		if ( ! $post || 'product' !== $post->post_type || 'trash' === $post->post_status ) {
			return false;
		}

		// Already retired by an earlier slice.
		if ( '' !== (string) get_post_meta( $product_id, self::META, true ) ) {
			return false;
		}

		// The status it had before, so the undo cannot publish something the
		// operator was deliberately keeping as a draft.
		update_post_meta(
			$product_id,
			self::META,
			wp_json_encode(
				array(
					'status' => $post->post_status,
					'mode'   => $mode,
					'at'     => time(),
				)
			)
		);

		if ( 'hidden' === $mode ) {
			wp_set_object_terms( $product_id, array( 'exclude-from-catalog', 'exclude-from-search' ), 'product_visibility', true );
		} elseif ( 'draft' !== $post->post_status ) {
			wp_update_post(
				array(
					'ID'          => $product_id,
					'post_status' => 'draft',
				)
			);
		}

		// Stock goes to zero either way: whatever the previous supplier had on
		// their shelf, this shop can no longer get it.
		if ( '0' !== (string) get_post_meta( $product_id, '_stock', true ) ) {
			update_post_meta( $product_id, '_stock', '0' );
		}
		if ( 'outofstock' !== (string) get_post_meta( $product_id, '_stock_status', true ) ) {
			update_post_meta( $product_id, '_stock_status', 'outofstock' );
		}

		MVweb_PI_Importer::refresh_product_lookup( $product_id );

		return true;
	}

	/**
	 * Put one product back the way it was before it was taken off the shelf.
	 *
	 * Restores the status the product actually had, recorded in the meta at the
	 * moment of retirement, rather than publishing everything — a product the
	 * operator was deliberately keeping as a draft stays one. Stock is not
	 * touched here: the operator's undo has no figure to write, and the import
	 * that calls this has already written a fresh one.
	 *
	 * @since 1.1.0
	 * @param int $product_id Product to restore.
	 * @return bool Whether the product was retired at all.
	 */
	public static function restore_one( int $product_id ): bool {
		$raw = (string) get_post_meta( $product_id, self::META, true );
		if ( '' === $raw ) {
			return false;
		}

		$state = json_decode( $raw, true );
		$state = is_array( $state ) ? $state : array();

		if ( 'hidden' === ( $state['mode'] ?? '' ) ) {
			wp_remove_object_terms( $product_id, array( 'exclude-from-catalog', 'exclude-from-search' ), 'product_visibility' );
		} else {
			$status = (string) ( $state['status'] ?? 'publish' );
			$post   = get_post( $product_id );
			if ( $post && $post->post_status !== $status ) {
				wp_update_post(
					array(
						'ID'          => $product_id,
						'post_status' => $status,
					)
				);
			}
		}

		delete_post_meta( $product_id, self::META );
		MVweb_PI_Importer::refresh_product_lookup( $product_id );

		return true;
	}

	/**
	 * How many products are currently retired.
	 *
	 * @since 1.1.0
	 * @return int
	 */
	public static function retired_count(): int {
		global $wpdb;

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s",
				self::META
			)
		);
	}

	/**
	 * Put the retired products back the way they were.
	 *
	 * Restores the status each product actually had, not "published" — a product
	 * the operator was keeping as a draft before the switch stays one. Stock is
	 * deliberately left at zero: nobody knows the real figure until the source
	 * that carries it is imported again.
	 *
	 * @since 1.1.0
	 * @param int $limit How many to restore in this pass.
	 * @return array{restored: int, left: int}
	 */
	public static function undo( int $limit = 0 ): array {
		global $wpdb;

		$limit = $limit > 0 ? $limit : self::SLICE;

		$product_ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s LIMIT %d",
				self::META,
				$limit
			)
		);

		$restored = 0;

		foreach ( array_map( 'intval', (array) $product_ids ) as $product_id ) {
			if ( self::restore_one( $product_id ) ) {
				++$restored;
			}
		}

		$left = self::retired_count();

		mvweb_pi_log(
			sprintf(
				/* translators: 1: products restored, 2: products still retired */
				__( 'Previous catalogue: %1$d products put back as they were, %2$d still off the shelf.', 'mvweb-price-importer' ),
				$restored,
				$left
			),
			'info'
		);

		return array(
			'restored' => $restored,
			'left'     => $left,
		);
	}
}
