<?php
/**
 * Uninstall MVweb Price Importer
 *
 * Fired when the plugin is uninstalled.
 * Removes all options, post meta, term meta, attachment meta,
 * cron schedules, and uploaded files.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Delete all plugin options.
$options = array(
	'mvweb_pi_settings',
	'mvweb_pi_mapping',
	'mvweb_pi_output',
	'mvweb_pi_category_map',
	'mvweb_pi_feeds_company',
	'mvweb_pi_feeds_currency',
	'mvweb_pi_feeds_auto_generate',
	'mvweb_pi_cron_lock',
	'mvweb_pi_last_etags',
	'mvweb_pi_import_stats',
	'mvweb_pi_import_progress',
	'mvweb_pi_feed_progress',
	'mvweb_pi_feed_lock',
	'mvweb_pi_known_skus',
	'mvweb_pi_excluded_categories',
	'mvweb_pi_category_filter_mode',
	'mvweb_pi_category_meta',
	'mvweb_pi_flatten_roots',
	'mvweb_pi_tag_rules',
	'mvweb_pi_tag_map',
	'mvweb_pi_feeds_slug',
	'mvweb_pi_feed_excluded_categories',
	'mvweb_pi_feed_category_filter_mode',
	'mvweb_pi_version',
	'mvweb_pi_access_key',
);

// Take the price list rule back out of the site's .htaccess before the options
// go: leaving the rule while the key is already deleted would lock the folder
// behind a secret that no longer exists anywhere.
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/misc.php';
if ( function_exists( 'insert_with_markers' ) && function_exists( 'get_home_path' ) ) {
	$htaccess = get_home_path() . '.htaccess';
	if ( file_exists( $htaccess ) && is_writable( $htaccess ) ) {
		insert_with_markers( $htaccess, 'MVweb Price Importer', array() );
	}
}

foreach ( $options as $option ) {
	delete_option( $option );
}

// Clean up product meta.
global $wpdb;
$meta_keys = array(
	'_mvweb_pi_stocks',
	'_mvweb_pi_image_source',
	'_mvweb_pi_image_attach_id',
	'_mvweb_pi_gallery_sources',
	'_mvweb_pi_barcode',
	'_mvweb_pi_wholesale_price',
	'_mvweb_pi_dealer_price',
	'_mvweb_pi_feed_cat_term_id',
);
foreach ( $meta_keys as $key ) {
	$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => $key ), array( '%s' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
}

// Clean up attachment meta.
$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => '_mvweb_pi_uploaded' ), array( '%s' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key

// Clean up term meta.
$term_meta_keys = array(
	'mvweb_pi_external_id',
	'mvweb_pi_tag_key',
);
foreach ( $term_meta_keys as $key ) {
	$wpdb->delete( $wpdb->termmeta, array( 'meta_key' => $key ), array( '%s' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
}

// Clear cron schedule.
wp_clear_scheduled_hook( 'mvweb_pi_cron_import' );
wp_clear_scheduled_hook( 'mvweb_pi_continue_import' );
wp_clear_scheduled_hook( 'mvweb_pi_continue_feeds' );

// Delete uploaded files (pricelists directory).
$upload_dir     = wp_upload_dir();
$pricelists_dir = $upload_dir['basedir'] . '/pricelists/';

if ( is_dir( $pricelists_dir ) ) {
	// Recursive directory removal.
	$iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $pricelists_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);

	foreach ( $iterator as $item ) {
		if ( $item->isDir() ) {
			rmdir( $item->getPathname() );
		} else {
			unlink( $item->getPathname() );
		}
	}

	rmdir( $pricelists_dir );
}

// For multisite, clean up each site. Each iteration is wrapped in
// try/finally so a failure inside one site's cleanup still restores the
// global blog context and lets the loop continue for the remaining sites.
if ( is_multisite() ) {
	$sites = get_sites();
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );

		try {
			foreach ( $options as $option ) {
				delete_option( $option );
			}

			foreach ( $meta_keys as $key ) {
				$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => $key ), array( '%s' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			}
			$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => '_mvweb_pi_uploaded' ), array( '%s' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key

			foreach ( $term_meta_keys as $key ) {
				$wpdb->delete( $wpdb->termmeta, array( 'meta_key' => $key ), array( '%s' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			}

			wp_clear_scheduled_hook( 'mvweb_pi_cron_import' );

			$ms_upload_dir     = wp_upload_dir();
			$ms_pricelists_dir = $ms_upload_dir['basedir'] . '/pricelists/';
			if ( is_dir( $ms_pricelists_dir ) ) {
				$ms_iterator = new RecursiveIteratorIterator(
					new RecursiveDirectoryIterator( $ms_pricelists_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
					RecursiveIteratorIterator::CHILD_FIRST
				);
				foreach ( $ms_iterator as $item ) {
					if ( $item->isDir() ) {
						rmdir( $item->getPathname() );
					} else {
						unlink( $item->getPathname() );
					}
				}
				rmdir( $ms_pricelists_dir );
			}
		} finally {
			restore_current_blog();
		}
	}
}

// Clear any cached data.
wp_cache_flush();
