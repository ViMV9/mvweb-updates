<?php
/**
 * Mapping tab template.
 *
 * Field mapping between price list columns and WooCommerce product fields.
 * Includes auto-detection button and manual override dropdowns.
 *
 * Uses MVweb Admin UI Kit (slate palette, Yoast-style layout).
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get saved mapping and detected headers.
$saved_mapping     = get_option( 'mvweb_pi_mapping', array() );
$detected_headers  = $saved_mapping['_headers'] ?? array();
$tag_rules         = get_option( 'mvweb_pi_tag_rules', array() );

// Detect a YML feed by looking for the canonical YML element names in the
// header set. YML's <picture> tag is repeatable by spec, so we never expose
// a separate "gallery" column to the operator — the parser splits picture[0]
// into the main image and pushes the rest into the gallery automatically.
$is_yml_source = in_array( 'picture', $detected_headers, true )
	&& in_array( 'categoryId', $detected_headers, true );

// Mapping fields definition: key => [label, required, description].
$mapping_fields = array(
	'sku'         => array(
		'label'       => __( 'SKU', 'mvweb-price-importer' ),
		'required'    => true,
		'description' => __( 'Unique product identifier (article number).', 'mvweb-price-importer' ),
	),
	'name'        => array(
		'label'       => __( 'Name', 'mvweb-price-importer' ),
		'required'    => true,
		'description' => __( 'Product title.', 'mvweb-price-importer' ),
	),
	'description' => array(
		'label'       => __( 'Description', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Product description (HTML allowed).', 'mvweb-price-importer' ),
	),
	'price'       => array(
		'label'       => __( 'Price', 'mvweb-price-importer' ),
		'required'    => true,
		'description' => __( 'Regular price.', 'mvweb-price-importer' ),
	),
	'sale_price'  => array(
		'label'       => __( 'Old Price', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Price before discount (strikethrough price).', 'mvweb-price-importer' ),
	),
	'wholesale_price' => array(
		'label'       => __( 'Wholesale Price', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Wholesale price. Stored in a separate product field and does not affect the retail or old price.', 'mvweb-price-importer' ),
	),
	'dealer_price' => array(
		'label'       => __( 'Dealer Price', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Dealer price — a second B2B tier next to the wholesale one. Suppliers name this column differently, so pick it by hand if auto-detect misses it. Stored in a separate product field and does not affect the retail or old price.', 'mvweb-price-importer' ),
	),
	'stock'       => array(
		'label'       => __( 'Stock', 'mvweb-price-importer' ),
		'required'    => true,
		'description' => __( 'Stock quantity.', 'mvweb-price-importer' ),
	),
	'image'       => array(
		'label'       => __( 'Image', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Main product image URL.', 'mvweb-price-importer' ),
	),
	'gallery'     => array(
		'label'       => __( 'Gallery', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Additional image URLs (comma-separated). For YML feeds, all repeated <picture> tags are split automatically — picture[0] becomes the main image and the rest fill the gallery, so no mapping is needed.', 'mvweb-price-importer' ),
	),
	'category'    => array(
		'label'       => __( 'Category', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Category ID from price list.', 'mvweb-price-importer' ),
	),
	'parent_cat'  => array(
		'label'       => __( 'Parent Category', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Parent category ID.', 'mvweb-price-importer' ),
	),
	'barcode'     => array(
		'label'       => __( 'Barcode', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Barcode (EAN, UPC, GTIN).', 'mvweb-price-importer' ),
	),
);
?>

<div class="mvweb-pi-tab-mapping">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Field Mapping', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Map price list columns to WooCommerce product fields. Use the auto-detect button to scan column headers automatically.', 'mvweb-price-importer' ); ?>
		</p>

		<div class="mvweb-pi-mapping-actions">
			<button type="button"
					class="mvweb-btn mvweb-btn--secondary"
					id="mvweb-pi-detect-columns"
					data-action="mvweb_pi_detect_columns">
				<?php esc_html_e( 'Auto-detect Columns', 'mvweb-price-importer' ); ?>
				<span class="mvweb-spinner" id="mvweb-pi-detect-spinner"></span>
			</button>
			<span class="mvweb-pi-detect-status" id="mvweb-pi-detect-status"></span>
		</div>

		<div class="mvweb-table-wrap">
			<table class="mvweb-table" id="mvweb-pi-mapping-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'WooCommerce Field', 'mvweb-price-importer' ); ?></th>
						<th><?php esc_html_e( 'Source Column', 'mvweb-price-importer' ); ?></th>
						<th><?php esc_html_e( 'Required', 'mvweb-price-importer' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $mapping_fields as $field_key => $field_data ) : ?>
						<tr>
							<td>
								<strong><?php echo esc_html( $field_data['label'] ); ?></strong>
								<div class="mvweb-pi-field-desc"><?php echo esc_html( $field_data['description'] ); ?></div>
							</td>
							<td>
								<?php if ( 'gallery' === $field_key && $is_yml_source ) : ?>
									<select class="mvweb-select" disabled>
										<option><?php esc_html_e( 'Auto — split from <picture>', 'mvweb-price-importer' ); ?></option>
									</select>
									<input type="hidden"
										   name="mvweb_pi_mapping[<?php echo esc_attr( $field_key ); ?>]"
										   value="">
								<?php else : ?>
									<select name="mvweb_pi_mapping[<?php echo esc_attr( $field_key ); ?>]"
											class="mvweb-select mvweb-pi-mapping-select"
											data-field="<?php echo esc_attr( $field_key ); ?>">
										<option value=""><?php esc_html_e( '— Not mapped —', 'mvweb-price-importer' ); ?></option>
										<?php if ( ! empty( $detected_headers ) ) : ?>
											<?php foreach ( $detected_headers as $header ) : ?>
												<option value="<?php echo esc_attr( $header ); ?>"
													<?php selected( $saved_mapping[ $field_key ] ?? '', $header ); ?>>
													<?php echo esc_html( $header ); ?>
												</option>
											<?php endforeach; ?>
										<?php endif; ?>
									</select>
								<?php endif; ?>
							</td>
							<td>
								<?php if ( $field_data['required'] ) : ?>
									<span class="mvweb-badge mvweb-badge--error"><?php esc_html_e( 'Yes', 'mvweb-price-importer' ); ?></span>
								<?php else : ?>
									<span class="mvweb-badge mvweb-badge--plain"><?php esc_html_e( 'No', 'mvweb-price-importer' ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php if ( empty( $detected_headers ) ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'No column headers detected. Configure a source URL in the Main tab, then click "Auto-detect Columns" to scan the file.', 'mvweb-price-importer' ); ?>
				</div>
			</div>
		<?php endif; ?>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Product Tags', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Turn a price list column into a WooCommerce product tag. A rule reads one column and assigns the tag when the value means "yes". Leave the list empty and no tags are touched at all.', 'mvweb-price-importer' ); ?>
		</p>

		<input type="hidden" name="mvweb_pi_tag_rules_submitted" value="1">

		<div class="mvweb-table-wrap">
			<table class="mvweb-table" id="mvweb-pi-tag-rules-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Source Column', 'mvweb-price-importer' ); ?></th>
						<th><?php esc_html_e( 'Values meaning "yes"', 'mvweb-price-importer' ); ?></th>
						<th><?php esc_html_e( 'Tag Name', 'mvweb-price-importer' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'mvweb-price-importer' ); ?></th>
					</tr>
				</thead>
				<tbody id="mvweb-pi-tag-rules-body">
					<?php foreach ( $tag_rules as $index => $rule ) : ?>
						<tr class="mvweb-pi-tag-rule-row" data-index="<?php echo esc_attr( absint( $index ) ); ?>">
							<td>
								<select name="mvweb_pi_tag_rules[<?php echo esc_attr( absint( $index ) ); ?>][source]"
										class="mvweb-select mvweb-pi-tag-source">
									<option value=""><?php esc_html_e( '— Not selected —', 'mvweb-price-importer' ); ?></option>
									<?php
									$sources = $detected_headers;
									if ( '' !== ( $rule['source'] ?? '' ) && ! in_array( $rule['source'], $sources, true ) ) {
										// Keep a saved column that the last scan
										// did not report, so re-saving the form
										// does not silently drop the rule.
										$sources[] = $rule['source'];
									}
									?>
									<?php foreach ( $sources as $header ) : ?>
										<option value="<?php echo esc_attr( $header ); ?>" <?php selected( $rule['source'] ?? '', $header ); ?>>
											<?php echo esc_html( $header ); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<input type="hidden"
									   name="mvweb_pi_tag_rules[<?php echo esc_attr( absint( $index ) ); ?>][key]"
									   value="<?php echo esc_attr( $rule['key'] ?? '' ); ?>">
							</td>
							<td>
								<input type="text"
									   name="mvweb_pi_tag_rules[<?php echo esc_attr( absint( $index ) ); ?>][match]"
									   class="mvweb-input mvweb-pi-tag-match"
									   value="<?php echo esc_attr( $rule['match'] ?? '' ); ?>"
									   placeholder="<?php esc_attr_e( 'true, 1, yes', 'mvweb-price-importer' ); ?>">
							</td>
							<td>
								<input type="text"
									   name="mvweb_pi_tag_rules[<?php echo esc_attr( absint( $index ) ); ?>][label]"
									   class="mvweb-input mvweb-pi-tag-label"
									   value="<?php echo esc_attr( $rule['label'] ?? '' ); ?>"
									   placeholder="<?php esc_attr_e( 'Sale', 'mvweb-price-importer' ); ?>">
							</td>
							<td>
								<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-pi-remove-tag-rule">
									&times;
								</button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<div class="mvweb-pi-tag-rule-actions">
			<button type="button" class="mvweb-btn mvweb-btn--secondary" id="mvweb-pi-add-tag-rule">
				+ <?php esc_html_e( 'Add Rule', 'mvweb-price-importer' ); ?>
			</button>
		</div>

		<div class="mvweb-alert mvweb-alert--info">
			<div class="mvweb-alert__body">
				<?php esc_html_e( 'Leave "Values meaning yes" empty to accept true, 1, yes, y, да or +. The tag is created on the first import that needs it; rename it later in Products → Tags and the rename survives every following import. When the column says no, the tag is removed from that product — including a tag you attached by hand.', 'mvweb-price-importer' ); ?>
			</div>
		</div>
	</div>

</div>
