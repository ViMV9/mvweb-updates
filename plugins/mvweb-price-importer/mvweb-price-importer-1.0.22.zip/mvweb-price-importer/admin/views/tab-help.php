<?php
/**
 * Help tab template.
 *
 * Built-in documentation for administrators. Targets two audiences:
 *   - first-time operators who need a literal click-by-click walkthrough,
 *   - returning admins who only want to look up a specific FAQ.
 *
 * Each Quick Start step names the exact tab and section, the field/button
 * to interact with, and the visible result the operator should expect —
 * so the user can keep their eyes on the screen instead of jumping back
 * here mid-task.
 *
 * Uses MVweb Admin UI Kit (slate palette, Yoast-style layout).
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cron_command       = '0 */6 * * * /usr/local/bin/php ' . WP_CONTENT_DIR . '/plugins/mvweb-price-importer/cron-runner.php';
$feeds_cron_command = '0 * * * * /usr/local/bin/php ' . WP_CONTENT_DIR . '/plugins/mvweb-price-importer/feeds-cron-runner.php';
?>

<div class="mvweb-pi-tab-help">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Quick Start', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'A complete first-import walkthrough. Each step ends with the result you should see on the screen before moving on.', 'mvweb-price-importer' ); ?>
		</p>

		<ol class="mvweb-steps">
			<li>
				<div>
					<strong><?php esc_html_e( 'Step 1. Tell the plugin where the price list lives', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'Open the "Main" tab. In the "Source" section, paste the URL of your price list into the "Source URL" field. CSV, YML (Yandex.Market) and XLSX are supported, and Google Sheets share links are auto-converted to a CSV export.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'If you import from several locations (e.g. Moscow and St. Petersburg warehouses), use the "Warehouses" sub-section instead: click "Add Warehouse", fill in a short ID, name and URL for each one. When warehouses are configured the single "Source URL" above is ignored.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'Click "Save Changes" at the bottom of the page. You will see a green "Settings saved." notice at the top.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 2. Choose how often to import, batch size, and what to do with images', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'Still on the "Main" tab, scroll to "Import Schedule". Pick an "Auto-import Interval" (Hourly / Every 6 hours / Every 12 hours / Daily, or "Disabled" if you only want to import manually).', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( '"Batch Size" controls how many products are processed per chunk. 100–250 is a safe default. Reduce it if your hosting kills long-running PHP processes.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( '"Image Import" decides when product photos are downloaded. For catalogs of more than a few hundred items leave the default "Only for new products" — it is by far the cheapest option because re-importing images is what makes runs slow.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'Save again. The notice "Next scheduled import: …" appears with the exact date and time of the upcoming automatic run.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 3. Map your file columns to WooCommerce fields', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'Switch to the "Mapping" tab. Click "Detect columns" — the plugin downloads a sample of the source, parses the header row and tries to match SKU, Name, Price, Stock, Image, Category and the rest automatically.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'Review the dropdowns. Anything left blank means the field could not be auto-detected — pick the right column manually. The required fields are SKU, Name, Price and Stock; without them the import refuses to run.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'Click "Save Changes". A "Mapping saved." notice confirms.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 4. Run the first import', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'Go back to the "Main" tab. In the "Actions" section press "Import Now" (the purple primary button). The yellow spinner spins until the run finishes.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'For very large catalogs the action splits into chunks: each click processes the next slice and a green notice tells you the chunk is done and the next one is scheduled. Keep pressing "Import Now" — or wait for the WordPress cron to run it automatically — until you see the final "Import complete" notice.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'The "Import Statistics" section right below "Actions" now shows the time of the last run, created/updated/skipped/errors counters, total items in the price list and how many SKUs the plugin already knows.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 5. Exclude categories you do not want in the shop (optional)', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'After the first successful import the "Excluded Categories" section on the "Main" tab fills with a tree of every category from the source. Tick any category whose products must be skipped on future imports — ticking a parent automatically excludes everything nested under it.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'Use the filter field to find categories by name, or the "Select all" / "Clear selection" shortcuts. Save Changes and re-run the import — excluded items will be skipped.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 6. Set up reliable scheduling for production (recommended)', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'WordPress cron only fires while visitors are browsing the site. On a low-traffic B2B shop the daily import may slip by hours. Replace it with a real system cron job through your hosting panel — the command to register is shown in the yellow "Note" box at the bottom of this page.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'When the system cron is active, set the "Auto-import Interval" on the Main tab to "Disabled" so the same import is not triggered twice.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 7. Set up a separate cron for feeds (optional)', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'By default the YML feeds are regenerated at the end of each successful import — that is the "Auto-generate" checkbox on the "Feeds" tab. For most shops this is all you need: feeds always reflect the latest import.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'If the price source updates rarely (say, once a day) but you want the feed timestamp refreshed more often — or you want feeds to be rebuilt even when the import is skipped because the source ETag has not changed — register the second cron line shown in the yellow "Note" box at the bottom of this page. It runs the feed generator directly without going through the import pipeline, reading already-imported products from WooCommerce.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'The two cron lines (import and feeds) are independent — pick the interval that suits each one. Common pattern: import every 6 hours, feeds every hour.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>
		</ol>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Frequently Asked Questions', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Common questions about sources, scheduling, feeds, logs, and the Actions buttons.', 'mvweb-price-importer' ); ?>
		</p>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'Which file formats are supported?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'CSV (with semicolon, comma, or tab delimiters), YML (Yandex.Market XML format), and XLSX (Excel). UTF-8 and Windows-1251 encodings are auto-detected.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'Can I use Google Sheets as a source?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'Yes. Paste your Google Sheets sharing link and it will be automatically converted to a CSV export URL.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'What happens to products missing from the new price list?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'Products not found in the new price list will have their stock set to 0 and status changed to "out of stock". They are not deleted or moved to draft.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How do I use the wholesale price in my theme?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php
					printf(
						/* translators: %s: product meta key in <code> */
						esc_html__( 'Map the "Wholesale Price" column on the Mapping tab (it sits right after "Old Price"). On every import the value is parsed and saved on each product in the %s meta field. You can also see and edit it by hand in the WooCommerce product editor, in the field added under the regular/sale price inputs.', 'mvweb-price-importer' ),
						'<code>_mvweb_pi_wholesale_price</code>'
					);
					?>
				</p>
				<p>
					<?php esc_html_e( 'The wholesale price is stored on its own and is never used as the storefront price — WooCommerce keeps charging the regular or sale price. Deciding where to show it, and whether to charge it under any condition (customer role, quantity, order total), is left entirely to the theme. Read the meta and render it wherever you need:', 'mvweb-price-importer' ); ?>
				</p>
				<pre class="mvweb-codeblock"><code><?php echo esc_html( "\$wholesale = get_post_meta( \$product->get_id(), '_mvweb_pi_wholesale_price', true );\nif ( '' !== \$wholesale ) {\n    echo 'Опт: ' . wc_price( \$wholesale );\n}" ); ?></code></pre>
				<p>
					<?php esc_html_e( 'WooCommerce core has no wholesale-price field, so this is a dedicated meta key of the importer — no third-party wholesale plugin reads or writes it. The same value is also exported to generated YML feeds as a <wholesale> element, so it round-trips: re-importing such a feed reads it back automatically.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How do I set up multiple warehouses?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'In the "Main" tab → "Source" section press "Add Warehouse". Enter a unique ID, a display name and the URL for each warehouse. Stock quantities from all warehouses are summed for the total WooCommerce stock; per-warehouse stock is displayed on the product page if "Visible" is enabled.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'When a warehouse is removed from the settings, its leftover source file is deleted and it stops contributing to stock. On the next import a product that was only in that warehouse drops to zero stock (out of stock, hidden from the shop when "Hide out of stock" is on); a product also stocked in other warehouses keeps just their combined quantity.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How do I show per-warehouse stock in my theme?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'WooCommerce core has no concept of warehouses — it keeps a single stock number per product. This plugin sums every warehouse into that native stock (so the cart, checkout and stock reservation keep working) and stores the per-warehouse breakdown separately.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'The simplest way: tick "Visible" for a warehouse. Its name and quantity are then appended to the standard stock line on the product page automatically, via the native woocommerce_get_stock_html filter — no theme code needed.', 'mvweb-price-importer' ); ?></p>
				<p>
					<?php
					printf(
						/* translators: 1: product meta key in <code>, 2: option name in <code> */
						esc_html__( 'For full control in the theme, read the breakdown yourself. Each product stores it in the %1$s meta as JSON (warehouse id → quantity); the warehouse names live in the %2$s option. Example:', 'mvweb-price-importer' ),
						'<code>_mvweb_pi_stocks</code>',
						'<code>mvweb_pi_settings</code>'
					);
					?>
				</p>
				<pre class="mvweb-codeblock"><code><?php echo esc_html( "\$stocks   = json_decode( (string) get_post_meta( \$product->get_id(), '_mvweb_pi_stocks', true ), true );\n\$settings = get_option( 'mvweb_pi_settings', array() );\n\$names    = wp_list_pluck( \$settings['warehouses'] ?? array(), 'name', 'id' );\n\nif ( is_array( \$stocks ) ) {\n    foreach ( \$stocks as \$wh_id => \$qty ) {\n        printf( '%s: %d pcs', esc_html( \$names[ \$wh_id ] ?? \$wh_id ), (int) \$qty );\n    }\n}" ); ?></code></pre>
				<p><?php esc_html_e( 'The same warehouse quantities are also written to the per-warehouse YML feeds on the Feeds tab, so an aggregator or a downstream shop sees exactly what is available at each location.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'What does the "Download" button do?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'Fetches the source price files from every configured URL (single Source URL or each warehouse) and stores them under wp-content/uploads/pricelists/ as source-{warehouse}-{uuid}.{ext}. No WooCommerce products are touched.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Before downloading, the plugin issues a HEAD request and compares ETag / Last-Modified / Content-Length with the values saved from the previous run. If nothing changed, the source is marked "File unchanged" and the full body is not fetched — exactly the same logic the scheduled import uses to skip work. Use this button when you want to refresh a source file by hand without running a full import, or to verify that the URL is reachable.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'What does the "Convert" button do?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'Parses every source file already saved by "Download" with the column mapping configured on the Mapping tab and reports how many products would be imported, how many rows are invalid, and how many duplicate SKUs were found. This is a dry-run — no products in WooCommerce are created or updated.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Use it after changing the mapping or to debug a problematic source — invalid rows and duplicates show up here long before they corrupt the catalog. If you press "Convert" before "Download", the plugin returns "No downloaded source files found" — press "Download" first.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php
					printf(
						/* translators: %s: setting name */
						esc_html__( 'When the %s setting is enabled, "Convert" also writes a CSV checkpoint of the parsed products and a separate file with all invalid rows into the upload directory, so you can inspect them in Excel.', 'mvweb-price-importer' ),
						'<code>' . esc_html__( 'Debug: save converter checkpoint', 'mvweb-price-importer' ) . '</code>'
					);
					?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'What does the "Reset Hash" button do, and when should I use it?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'Clears the saved ETag / Last-Modified / Content-Length values for every source. The next download (manual or scheduled) will therefore re-fetch each file in full, regardless of whether the supplier updated the change-detection headers.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'The button is named after the header-based fingerprint the plugin stores per source — it is not a content hash of the file itself. Reach for it in these situations:', 'mvweb-price-importer' ); ?>
				</p>
				<ul>
					<li><?php esc_html_e( 'The supplier edited the price list but did not change ETag or Last-Modified — the import keeps saying "All sources unchanged" while you can see fresh data in the file.', 'mvweb-price-importer' ); ?></li>
					<li><?php esc_html_e( 'The source URL changed (different server, new export, switched from Google Sheets to direct download) and you want a clean baseline.', 'mvweb-price-importer' ); ?></li>
					<li><?php esc_html_e( 'You just changed the column mapping and want the next scheduled run to start from a fresh download instead of reusing a possibly-cached old file.', 'mvweb-price-importer' ); ?></li>
				</ul>
				<p>
					<?php esc_html_e( 'The button only resets bookkeeping — it does not delete already-downloaded files or any imported products.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'Why is automatic import not running on time?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'The "Auto-import Interval" setting on the Main tab uses WordPress cron (wp-cron). The timer itself does not run anything — the scheduled job only fires when a visitor opens any page of the site (front-end, admin, or REST). With a steady flow of traffic the import runs within a few minutes of the time shown next to "Next import at …". On a low-traffic B2B catalog there may be no visitor for hours, and the import will be delayed by exactly that gap.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'For predictable runs configure a real system cron on the hosting panel — the exact command is in the yellow Note box at the bottom of this page. When system cron is active, change the "Auto-import Interval" on the Main tab to "Disabled" so the same import is not started twice.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How do feeds get updated, and do I need a separate cron for them?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'By default feeds are regenerated at the end of every successful import — that is the "Auto-generate" checkbox on the Feeds tab. For most shops this is enough: feeds always reflect the latest import.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'A separate cron job for feeds is only needed in two cases:', 'mvweb-price-importer' ); ?>
				</p>
				<ul>
					<li><?php esc_html_e( 'The price source rarely changes (e.g. updated once a day) but you want the feed timestamp refreshed more often so Yandex.Market re-fetches it.', 'mvweb-price-importer' ); ?></li>
					<li><?php esc_html_e( 'You want feeds rebuilt even when the import is skipped because the source ETag has not changed (in that case the auto-generate hook does not fire — the import returns "skipped" before reaching it).', 'mvweb-price-importer' ); ?></li>
				</ul>
				<p>
					<?php esc_html_e( 'When that applies, add the second crontab line from the yellow Note box at the bottom of this page. It calls feeds-cron-runner.php directly: WooCommerce products are read as-is, no source download or product update happens. The feeds cron is fully independent of the import cron — pick the interval that suits each one.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'If you do NOT add the second cron, feeds still update — just on the same cadence as the import.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'My theme registers a custom image size and product images miss it — why?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'During import the plugin generates only the four image sizes WooCommerce templates strictly require: thumbnail (admin), woocommerce_thumbnail (catalog tile), woocommerce_single (product page) and woocommerce_gallery_thumbnail (gallery). Every other size — including theme-registered ones like "card", "hero", responsive WP variants like medium_large / 1536x1536 / 2048x2048, and the WP "large" size — is skipped to cut Imagick CPU and memory roughly in half on shared hosting. A 1400-SKU feed becomes minutes-faster per cron cycle and stops blowing through Beget\'s 256 MB cgroup.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Missing sizes are not lost. WordPress generates them on first request to wp_get_attachment_image() / wp_get_attachment_image_src() and caches the result in the attachment metadata — native behaviour since WP 5.3. The first visitor to a product page pays a one-off ~200 ms for that size; everyone after sees it instantly.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php
					printf(
						/* translators: %s: command name in <code> */
						esc_html__( 'If you want every size pre-generated for an existing catalog (for example, you just switched to a new theme that registers its own sizes), run %s once. WordPress will fill in every missing size in batches.', 'mvweb-price-importer' ),
						'<code>wp media regenerate</code>'
					);
					?>
				</p>
				<p>
					<?php
					printf(
						/* translators: %s: filter name in <code> */
						esc_html__( 'To change which sizes are generated during import — for example, add a theme size that you know will be used on every product page — use the %s filter:', 'mvweb-price-importer' ),
						'<code>mvweb_pi_keep_image_sizes</code>'
					);
					?>
				</p>
				<pre class="mvweb-codeblock"><code><?php echo esc_html( "add_filter( 'mvweb_pi_keep_image_sizes', function ( \$sizes ) {\n    \$sizes[] = 'my_theme_card';\n    return \$sizes;\n} );" ); ?></code></pre>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'Where are logs stored and how often are they cleaned?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php
					printf(
						/* translators: %s: log file path */
						esc_html__( 'Logs are stored in JSONL format at %s and read in the "Log" tab.', 'mvweb-price-importer' ),
						'<code>wp-content/uploads/pricelists/mvweb_pi.log</code>'
					);
					?>
				</p>
				<p>
					<?php esc_html_e( 'Rotation is automatic and triggered lazily on the next log write — there is no separate cron job. Two thresholds:', 'mvweb-price-importer' ); ?>
				</p>
				<ul>
					<li><?php esc_html_e( 'When the file passes 10 MB, it is renamed to a dated .bak archive next to it and a fresh log starts.', 'mvweb-price-importer' ); ?></li>
					<li><?php esc_html_e( 'When the file is older than 30 days, the same archive-and-restart happens regardless of size.', 'mvweb-price-importer' ); ?></li>
					<li><?php esc_html_e( 'Archive files (.bak) older than 30 days are deleted on the same write.', 'mvweb-price-importer' ); ?></li>
				</ul>
				<p>
					<?php esc_html_e( 'In practice the log file never grows unboundedly — a busy import that produces hundreds of warnings per run still rolls over within a single day at 10 MB. The "Clear Log" button on the Log tab erases the current file and all archives immediately.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How do I see verbose / developer-level details?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'The log has two layers. Without any extra configuration you only see operator-grade events — downloads completed, conversion summary, import results, errors. That keeps the screen readable when everything is fine.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'When you need to chase a slow or broken import, enable the "Verbose logging" checkbox in Main → Import Schedule. From the next write onward the plugin also records per-batch progress, per-source download details, and individual image-404 misses. Switch the Level filter on the Log tab to "Debug (verbose)" to focus on those entries.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Turn the checkbox back off once you are done — debug mode produces orders of magnitude more lines and is what causes log rotation to kick in early.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'System cron commands', 'mvweb-price-importer' ); ?></div>
		</div>

		<div class="mvweb-alert mvweb-alert--warning">
			<div class="mvweb-alert__body">
				<p class="mvweb-alert__title"><?php esc_html_e( 'Import cron', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'WordPress cron (wp-cron) fires only while visitors are on the site. For B2B shops with low traffic, use system cron for reliable scheduling:', 'mvweb-price-importer' ); ?></p>
				<pre class="mvweb-codeblock"><code><?php echo esc_html( $cron_command ); ?></code></pre>
			</div>
		</div>

		<div class="mvweb-alert mvweb-alert--warning">
			<div class="mvweb-alert__body">
				<p class="mvweb-alert__title"><?php esc_html_e( 'Feeds cron (optional)', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'Add a second crontab line if you need feeds refreshed on a different cadence than the import itself — for example, import once a day but regenerate feeds every hour from already-imported products:', 'mvweb-price-importer' ); ?></p>
				<pre class="mvweb-codeblock"><code><?php echo esc_html( $feeds_cron_command ); ?></code></pre>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-price-importer' ); ?></div>
		</div>
		<p>
			<?php
			printf(
				/* translators: %s: MVweb plugin URL */
				esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-price-importer' ),
				'<a href="https://mvweb.ru/plugins/mvweb-price-importer" target="_blank" rel="noopener noreferrer">mvweb.ru</a>'
			);
			?>
		</p>
	</div>

</div>
