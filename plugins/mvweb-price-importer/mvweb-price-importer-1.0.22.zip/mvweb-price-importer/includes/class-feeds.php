<?php
/**
 * Feeds class — YML feed generation for Yandex.Market.
 *
 * Generates YML feeds using XMLWriter (streaming, no DOM).
 * Supports general feed and per-warehouse feeds.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Feeds
 *
 * Generates YML feeds for Yandex.Market using XMLWriter for
 * memory-efficient streaming output. Supports a general feed
 * (all products in stock) and per-warehouse feeds.
 *
 * Feed files are stored in wp-content/uploads/pricelists/feeds/
 * which is intentionally public (no .htaccess restriction).
 *
 * @since 1.0.0
 */
class MVweb_PI_Feeds {

	/**
	 * Option key for company name.
	 *
	 * @var string
	 */
	const OPTION_COMPANY = 'mvweb_pi_feeds_company';

	/**
	 * Option key for currency.
	 *
	 * @var string
	 */
	const OPTION_CURRENCY = 'mvweb_pi_feeds_currency';

	/**
	 * Option key for auto-generate after import setting.
	 *
	 * @var string
	 */
	const OPTION_AUTO_GENERATE = 'mvweb_pi_feeds_auto_generate';

	/**
	 * Option key for the feed filename slug (e.g. "poisk123" →
	 * products-feed-poisk123.yml). Empty value falls back to "all"
	 * to preserve legacy file URLs.
	 *
	 * @var string
	 */
	const OPTION_SLUG = 'mvweb_pi_feeds_slug';

	/**
	 * Default slug used when no per-instance slug is set. Matches the
	 * filename the plugin shipped with before slugs became configurable.
	 *
	 * @var string
	 */
	const DEFAULT_SLUG = 'all';

	/**
	 * Get company name for feed.
	 *
	 * @since 1.0.0
	 * @return string Company name.
	 */
	public function get_company(): string {
		return get_option( self::OPTION_COMPANY, get_bloginfo( 'name' ) );
	}

	/**
	 * Get currency for feed.
	 *
	 * @since 1.0.0
	 * @return string Currency code (RUR, USD, EUR).
	 */
	public function get_currency(): string {
		return get_option( self::OPTION_CURRENCY, 'RUR' );
	}

	/**
	 * Get the configured feed slug, falling back to DEFAULT_SLUG.
	 *
	 * Slugs are validated on save to match /^[a-z0-9-]+$/, so the value
	 * stored in the option is always safe for direct filename use.
	 *
	 * @since 1.0.3
	 * @return string Slug, never empty.
	 */
	public function get_slug(): string {
		$slug = (string) get_option( self::OPTION_SLUG, '' );
		return self::sanitize_slug( $slug );
	}

	/**
	 * Normalise a user-supplied slug down to the safe charset and
	 * fall back to DEFAULT_SLUG if nothing usable remains.
	 *
	 * @since 1.0.3
	 * @param string $raw Raw input.
	 * @return string Safe slug — non-empty, matches /^[a-z0-9-]+$/.
	 */
	public static function sanitize_slug( string $raw ): string {
		$slug = strtolower( $raw );
		$slug = preg_replace( '/[^a-z0-9-]+/', '', $slug ) ?? '';
		$slug = trim( $slug, '-' );
		return '' === $slug ? self::DEFAULT_SLUG : $slug;
	}

	/**
	 * Generate all feeds: general + per-warehouse.
	 *
	 * @since 1.0.0
	 * @return array<string, array{file: string, url: string, products: int}> Results keyed by feed slug.
	 */
	public function generate_all(): array {
		$results    = array();
		$settings   = get_option( 'mvweb_pi_settings', array() );
		$warehouses = $settings['warehouses'] ?? array();
		$base_slug  = $this->get_slug();

		// General feed (all products with stock > 0).
		$results[ $base_slug ] = $this->generate( $base_slug );

		// Per-warehouse feeds — keep the warehouse id as part of the
		// filename so each warehouse stays addressable even when the
		// operator changes the base slug.
		foreach ( $warehouses as $wh ) {
			$wh_id = $wh['id'] ?? '';
			if ( empty( $wh_id ) ) {
				continue;
			}
			$wh_slug = sanitize_title( $wh['feed_name'] ?? $wh['name'] ?? $wh_id );
			$slug    = $base_slug . '-' . $wh_slug;
			$results[ $wh_id ] = $this->generate( $slug, $wh_id );
		}

		return $results;
	}

	/**
	 * Generate a single YML feed.
	 *
	 * Uses XMLWriter for streaming output directly to file,
	 * avoiding DOM accumulation in memory (TZ 9.3).
	 *
	 * @since 1.0.0
	 * @param string $slug  Feed slug for filename (e.g. 'all', 'moscow').
	 * @param string $wh_id Warehouse ID. Empty string for general feed.
	 * @return array{file: string, url: string, products: int} Generation result.
	 */
	public function generate( string $slug = 'all', string $wh_id = '' ): array {
		$feeds_dir = mvweb_pi_get_feeds_dir();
		$feeds_url = mvweb_pi_get_feeds_url();
		$filename  = "products-feed-{$slug}.yml";
		$file_path = $feeds_dir . $filename;

		$company  = $this->get_company();
		$currency = $this->get_currency();

		// Ensure feeds directory exists and is world-readable so that the
		// generated YML feed can actually be served by the web server.
		// Hosts with restrictive umasks (e.g. Beget VDS with extended ACLs)
		// otherwise create 0700/0600 entries that nginx returns 403 for.
		wp_mkdir_p( $feeds_dir );
		@chmod( $feeds_dir, 0755 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		// Write to a unique temp file, then atomically rename onto the public
		// path. openUri() truncates its target to zero bytes the instant it
		// opens, so writing straight to $file_path means any failure mid-run
		// (OOM, timeout, fatal — and feed generation runs at the tail of an
		// import when memory is already near the limit) leaves a half-written,
		// invalid feed served live by the web server until the next success.
		// The PID in the temp name also keeps two concurrent generators (the
		// auto-run after import vs. the admin "Generate" button or the
		// feeds-cron-runner) from clobbering each other's file — each writes
		// its own temp and the last rename wins with a complete document.
		$tmp_path = $file_path . '.' . getmypid() . '.tmp';

		$writer = new XMLWriter();
		$writer->openUri( $tmp_path );
		$writer->setIndent( true );
		$writer->setIndentString( '  ' );
		$writer->startDocument( '1.0', 'UTF-8' );

		// yml_catalog.
		$writer->startElement( 'yml_catalog' );
		$writer->writeAttribute( 'date', wp_date( 'Y-m-d H:i' ) );

		// shop.
		$writer->startElement( 'shop' );
		$writer->writeElement( 'name', $company );
		$writer->writeElement( 'company', $company );
		$writer->writeElement( 'url', home_url( '/' ) );

		// currencies.
		$writer->startElement( 'currencies' );
		$writer->startElement( 'currency' );
		$writer->writeAttribute( 'id', $currency );
		$writer->writeAttribute( 'rate', '1' );
		$writer->endElement(); // currency.
		$writer->endElement(); // currencies.

		// categories.
		$this->write_categories( $writer, $wh_id );

		// offers.
		$writer->startElement( 'offers' );
		$product_count = $this->write_offers( $writer, $wh_id, $currency );
		$writer->endElement(); // offers.

		$writer->endElement(); // shop.
		$writer->endElement(); // yml_catalog.
		$writer->endDocument();
		$writer->flush();

		// Release the writer so its handle on the temp file is closed before
		// the rename — XMLWriter keeps the stream open until the object is
		// destroyed, and renaming a still-open file is unreliable on some FS.
		unset( $writer );

		// Make the temp file world-readable BEFORE the rename so the public
		// path is correct the instant it appears. XMLWriter::openUri honours
		// umask, which on some hosts produces 0600 and locks nginx out.
		@chmod( $tmp_path, 0644 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		// Atomic publish: rename() on the same filesystem is atomic, so readers
		// only ever see the previous complete feed or the new complete feed,
		// never a half-written one. If the rename fails, drop the temp and
		// surface the error rather than leaving the live feed truncated.
		if ( ! @rename( $tmp_path, $file_path ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( file_exists( $tmp_path ) ) {
				wp_delete_file( $tmp_path );
			}
			mvweb_pi_log(
				sprintf(
					/* translators: %s: feed slug */
					__( 'Feed "%s" generation failed: could not publish the temp file.', 'mvweb-price-importer' ),
					$slug
				),
				'error'
			);
			return array(
				'file'     => $file_path,
				'url'      => $feeds_url . $filename,
				'products' => 0,
			);
		}

		mvweb_pi_log(
			sprintf(
				/* translators: 1: feed slug, 2: product count */
				__( 'Feed "%1$s" generated: %2$d products.', 'mvweb-price-importer' ),
				$slug,
				$product_count
			),
			'info'
		);

		return array(
			'file'     => $file_path,
			'url'      => $feeds_url . $filename,
			'products' => $product_count,
		);
	}

	/**
	 * Write WooCommerce product categories to YML.
	 *
	 * Outputs only the categories that actually carry products in this feed,
	 * plus every parent on the way up to the root, so the tree stays connected
	 * (a child category can't reference a parentId that isn't in the feed).
	 * Empty branches are dropped entirely — the feed exposes only non-empty
	 * parent → child chains.
	 *
	 * @since 1.0.0
	 * @param XMLWriter $writer XMLWriter instance.
	 * @param string    $wh_id  Warehouse ID. Empty for the general feed.
	 * @return void
	 */
	private function write_categories( XMLWriter $writer, string $wh_id = '' ): void {
		$writer->startElement( 'categories' );

		$keep = $this->collect_feed_category_ids( $wh_id );

		if ( empty( $keep ) ) {
			$writer->endElement(); // categories.
			return;
		}

		// Pull the kept terms in one go and write them in the same order WP
		// returns them; ids missing from the DB (shouldn't happen, but stale
		// term cache could) are skipped via the get_term guard.
		foreach ( array_keys( $keep ) as $term_id ) {
			$term = get_term( (int) $term_id, 'product_cat' );
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}

			$writer->startElement( 'category' );
			$writer->writeAttribute( 'id', (string) $term->term_id );

			// Only emit parentId when the parent is itself in the feed, so we
			// never point at a category we dropped as empty.
			if ( $term->parent > 0 && isset( $keep[ $term->parent ] ) ) {
				$writer->writeAttribute( 'parentId', (string) $term->parent );
			}

			$writer->text( $this->xml_text( $term->name ) );
			$writer->endElement(); // category.
		}

		$writer->endElement(); // categories.
	}

	/**
	 * Collect the category ids that must appear in this feed.
	 *
	 * Walks every product that qualifies for the feed (published, in stock for
	 * this warehouse context, with a usable price), takes its assigned
	 * categories, then adds each category's parent chain up to the root. The
	 * result is the minimal connected set of non-empty branches — empty
	 * categories and dead-end empty parents are excluded.
	 *
	 * @since 1.0.9
	 * @param string $wh_id Warehouse ID. Empty for the general feed.
	 * @return array<int, true> Set of term ids to keep, keyed by id.
	 */
	private function collect_feed_category_ids( string $wh_id ): array {
		$keep   = array();
		$parent = $this->build_parent_lookup();
		$page   = 1;

		do {
			$query = new WP_Query(
				array(
					'post_type'      => 'product',
					'post_status'    => 'publish',
					'posts_per_page' => 100,
					'paged'          => $page,
					'fields'         => 'ids',
					'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
						array(
							'key'     => '_stock',
							'value'   => '0',
							'compare' => '>',
							'type'    => 'NUMERIC',
						),
					),
				)
			);

			if ( ! $query->have_posts() ) {
				break;
			}

			foreach ( $query->posts as $product_id ) {
				$product = wc_get_product( $product_id );
				if ( ! $product || 'simple' !== $product->get_type() ) {
					continue;
				}

				// Mirror write_offers()/write_single_offer() exactly: a product
				// only contributes its categories if it actually ships in this
				// feed — warehouse stock and a usable price both apply.
				if ( '' !== $wh_id ) {
					$stocks_json = get_post_meta( $product_id, '_mvweb_pi_stocks', true );
					$stocks      = ! empty( $stocks_json ) ? json_decode( $stocks_json, true ) : array();
					if ( (int) ( $stocks[ $wh_id ] ?? 0 ) <= 0 ) {
						continue;
					}
				}

				if ( ! $this->product_has_price( $product ) ) {
					continue;
				}

				$terms = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
				if ( is_wp_error( $terms ) ) {
					continue;
				}

				foreach ( $terms as $term_id ) {
					$term_id = (int) $term_id;
					// Add the category and walk up its parent chain so the tree
					// stays connected. Stop at the first id already kept — its
					// ancestors are guaranteed present from a previous walk.
					$depth = 0;
					while ( $term_id > 0 && ! isset( $keep[ $term_id ] ) && $depth < 64 ) {
						$keep[ $term_id ] = true;
						$term_id          = (int) ( $parent[ $term_id ] ?? 0 );
						++$depth;
					}
				}
			}

			wp_reset_postdata();
			++$page;

		} while ( $page <= $query->max_num_pages );

		return $keep;
	}

	/**
	 * Build a term_id => parent_id lookup for product_cat in one query.
	 *
	 * @since 1.0.9
	 * @return array<int, int> Map of term id to its parent id.
	 */
	private function build_parent_lookup(): array {
		$lookup = array();
		$terms  = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) ) {
			return $lookup;
		}

		foreach ( $terms as $term ) {
			$lookup[ (int) $term->term_id ] = (int) $term->parent;
		}

		return $lookup;
	}

	/**
	 * Whether a product has a usable price for the feed.
	 *
	 * Matches the price gate in write_single_offer(): a regular or sale price
	 * greater than zero. Keeps the category set in lock-step with the offers
	 * actually written.
	 *
	 * @since 1.0.9
	 * @param WC_Product $product Product to check.
	 * @return bool True if the product would be written to the feed.
	 */
	private function product_has_price( WC_Product $product ): bool {
		$regular = (float) $product->get_regular_price();
		$sale    = (float) $product->get_sale_price();

		return $sale > 0 || $regular > 0;
	}

	/**
	 * Write product offers to YML.
	 *
	 * For general feed: all products with stock > 0.
	 * For warehouse feed: products with stock > 0 on that specific warehouse.
	 *
	 * @since 1.0.0
	 * @param XMLWriter $writer  XMLWriter instance.
	 * @param string    $wh_id   Warehouse ID. Empty for general feed.
	 * @param string    $currency Currency code.
	 * @return int Number of products written.
	 */
	private function write_offers( XMLWriter $writer, string $wh_id, string $currency ): int {
		$count = 0;
		$page  = 1;

		do {
			$args = array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'paged'          => $page,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => '_stock',
						'value'   => '0',
						'compare' => '>',
						'type'    => 'NUMERIC',
					),
				),
			);

			$query = new WP_Query( $args );

			if ( ! $query->have_posts() ) {
				break;
			}

			while ( $query->have_posts() ) {
				$query->the_post();
				$product = wc_get_product( get_the_ID() );

				if ( ! $product || 'simple' !== $product->get_type() ) {
					continue;
				}

				if ( '' !== $wh_id ) {
					$stocks_json = get_post_meta( $product->get_id(), '_mvweb_pi_stocks', true );
					$stocks      = ! empty( $stocks_json ) ? json_decode( $stocks_json, true ) : array();
					$stock_count = (int) ( $stocks[ $wh_id ] ?? 0 );

					if ( $stock_count <= 0 ) {
						continue;
					}
				} else {
					$stock_count = (int) $product->get_stock_quantity();
				}

				if ( $this->write_single_offer( $writer, $product, $currency, $stock_count ) ) {
					++$count;
				}
			}

			wp_reset_postdata();
			++$page;

		} while ( $page <= $query->max_num_pages );

		return $count;
	}

	/**
	 * Write a single offer element.
	 *
	 * XMLWriter automatically escapes special characters (&, <, >, ")
	 * in text content (TZ 9.3).
	 *
	 * @since 1.0.0
	 * @param XMLWriter   $writer      XMLWriter instance.
	 * @param WC_Product  $product     WooCommerce product.
	 * @param string      $currency    Currency code.
	 * @param int         $stock_count Stock quantity for this feed context
	 *                                 (total for general feed, warehouse-specific otherwise).
	 * @return bool True if the offer was written, false if it was skipped
	 *              (e.g. no usable price).
	 */
	private function write_single_offer( XMLWriter $writer, WC_Product $product, string $currency, int $stock_count = 0 ): bool {
		$regular_price = $product->get_regular_price();
		$sale_price    = $product->get_sale_price();
		$has_sale      = ( '' !== $sale_price && (float) $sale_price > 0 );
		$effective     = $has_sale ? (float) $sale_price : (float) $regular_price;

		// A price-less offer is invalid in YML — Yandex.Market rejects an
		// empty/zero <price>, and a single bad offer can get the whole feed
		// bounced. Skip the offer entirely rather than emit <price></price>.
		if ( $effective <= 0 ) {
			return false;
		}

		$writer->startElement( 'offer' );
		$writer->writeAttribute( 'id', (string) $product->get_id() );
		// Reflect the real WooCommerce stock status instead of hard-coding
		// "true": a product kept in catalogue but manually set out of stock
		// must not advertise availability to aggregators.
		$writer->writeAttribute( 'available', $product->is_in_stock() ? 'true' : 'false' );

		// URL.
		$writer->writeElement( 'url', get_permalink( $product->get_id() ) );

		// Price.
		if ( $has_sale ) {
			$writer->writeElement( 'price', $sale_price );
			if ( '' !== $regular_price && (float) $regular_price > 0 ) {
				$writer->writeElement( 'oldprice', $regular_price );
			}
		} else {
			$writer->writeElement( 'price', $regular_price );
		}

		// Wholesale price — custom element mirroring how <barcode> carries the
		// plugin's own `_mvweb_pi_*` meta into the feed. Emitted only when set,
		// and kept out of <price>/<oldprice> so it never changes the price an
		// aggregator or storefront shows. Re-importing this feed reads it back
		// via the generic tag capture in the YML parser, so the field round-trips.
		$wholesale = get_post_meta( $product->get_id(), '_mvweb_pi_wholesale_price', true );
		if ( '' !== (string) $wholesale && (float) $wholesale > 0 ) {
			$writer->writeElement( 'wholesale', (string) $wholesale );
		}

		// Currency.
		$writer->writeElement( 'currencyId', $currency );

		if ( $stock_count > 0 ) {
			$writer->writeElement( 'count', (string) $stock_count );
		}

		// Category.
		$terms = wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'ids' ) );
		if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
			$writer->writeElement( 'categoryId', (string) $terms[0] );
		}

		// Picture.
		$image_id = $product->get_image_id();
		if ( $image_id ) {
			$image_url = wp_get_attachment_url( $image_id );
			if ( $image_url ) {
				$writer->writeElement( 'picture', $image_url );
			}
		}

		// Gallery images.
		$gallery_ids = $product->get_gallery_image_ids();
		foreach ( $gallery_ids as $gallery_id ) {
			$gallery_url = wp_get_attachment_url( $gallery_id );
			if ( $gallery_url ) {
				$writer->writeElement( 'picture', $gallery_url );
			}
		}

		// Name.
		$writer->writeElement( 'name', $this->xml_text( $product->get_name() ) );

		// Description.
		$description = $product->get_description();
		if ( ! empty( $description ) ) {
			// Strip HTML tags for YML compatibility.
			$writer->writeElement( 'description', $this->xml_text( wp_strip_all_tags( $description ) ) );
		}

		// Barcode.
		$barcode = get_post_meta( $product->get_id(), '_mvweb_pi_barcode', true );
		if ( ! empty( $barcode ) ) {
			$writer->writeElement( 'barcode', $barcode );
		}

		$writer->endElement(); // offer.

		return true;
	}

	/**
	 * Decode stored HTML entities before handing text to XMLWriter.
	 *
	 * WordPress stores term names and post titles with entity-encoded
	 * specials (an ampersand is saved as &amp; in wp_terms / wp_posts). If we
	 * passed that raw string to XMLWriter it would escape the ampersand a
	 * second time and emit &amp;amp;, so an aggregator shows "Phones &amp;
	 * Tablets". Decode the entities back to real characters first; XMLWriter
	 * then escapes them exactly once and the feed reads correctly.
	 *
	 * @since 1.0.9
	 * @param string $text Raw text from the DB (possibly entity-encoded).
	 * @return string Decoded text safe to pass to XMLWriter.
	 */
	private function xml_text( string $text ): string {
		return html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	}

	/**
	 * Get list of existing feed files with metadata.
	 *
	 * Scans the feeds directory for YML files and returns
	 * info about each: slug, URL, last modified, product count.
	 *
	 * @since 1.0.0
	 * @return array<int, array{slug: string, url: string, file: string, modified: int, size: string}> Feed list.
	 */
	public function get_feed_list(): array {
		$feeds_dir = mvweb_pi_get_feeds_dir();
		$feeds_url = mvweb_pi_get_feeds_url();
		$feeds     = array();

		$files = glob( $feeds_dir . 'products-feed-*.yml' );
		if ( empty( $files ) ) {
			return $feeds;
		}

		foreach ( $files as $file ) {
			$basename = basename( $file );

			// Extract slug from filename: products-feed-{slug}.yml
			if ( ! preg_match( '/^products-feed-(.+)\.yml$/', $basename, $matches ) ) {
				continue;
			}

			$slug     = $matches[1];
			$modified = filemtime( $file );
			$size     = filesize( $file );

			// Count offers in the feed (quick scan).
			$product_count = $this->count_offers_in_file( $file );

			$feeds[] = array(
				'slug'     => $slug,
				'url'      => $feeds_url . $basename,
				'file'     => $file,
				'modified' => $modified,
				'size'     => size_format( $size ),
				'products' => $product_count,
			);
		}

		return $feeds;
	}

	/**
	 * Count <offer> elements in a YML file.
	 *
	 * Uses a lightweight regex scan instead of full XML parsing
	 * for performance on large files.
	 *
	 * @since 1.0.0
	 * @param string $file_path Absolute path to YML file.
	 * @return int Number of offers found.
	 */
	private function count_offers_in_file( string $file_path ): int {
		if ( ! file_exists( $file_path ) ) {
			return 0;
		}

		$count  = 0;
		$handle = fopen( $file_path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( ! $handle ) {
			return 0;
		}

		while ( ( $line = fgets( $handle ) ) !== false ) {
			if ( str_contains( $line, '<offer ' ) ) {
				++$count;
			}
		}

		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		return $count;
	}

	/**
	 * Delete a single generated feed file by its slug.
	 *
	 * The slug comes from user input via AJAX, so we re-validate it
	 * against the same charset the save flow enforces — guarding the
	 * filesystem against path traversal even if a future caller skips
	 * an earlier sanitization step.
	 *
	 * @since 1.0.3
	 * @param string $slug Feed slug (e.g. "all", "poisk123-moscow").
	 * @return bool True if the file existed and was deleted.
	 */
	public function delete( string $slug ): bool {
		if ( ! preg_match( '/^[a-z0-9-]+$/', $slug ) ) {
			return false;
		}

		$file = mvweb_pi_get_feeds_dir() . 'products-feed-' . $slug . '.yml';
		if ( ! file_exists( $file ) ) {
			return false;
		}

		wp_delete_file( $file );
		return ! file_exists( $file );
	}

	/**
	 * Delete all generated feed files.
	 *
	 * @since 1.0.0
	 * @return int Number of files deleted.
	 */
	public function delete_all(): int {
		$feeds_dir = mvweb_pi_get_feeds_dir();
		$files     = glob( $feeds_dir . 'products-feed-*.yml' );
		$count     = 0;

		if ( ! empty( $files ) ) {
			foreach ( $files as $file ) {
				if ( wp_delete_file( $file ) !== false ) {
					++$count;
				}
			}
		}

		return $count;
	}
}
