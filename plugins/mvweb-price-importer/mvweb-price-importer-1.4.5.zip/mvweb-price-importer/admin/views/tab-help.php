<?php
/**
 * Help tab template.
 *
 * Built-in documentation for administrators. Targets two audiences:
 *   - first-time operators who need a literal click-by-click walkthrough,
 *   - returning admins who only want to look up a specific FAQ.
 *
 * Each Quick Start step names the exact tab and section, the field/button
 * to interact with, and the visible result the operator should expect —
 * so the user can keep their eyes on the screen instead of jumping back
 * here mid-task.
 *
 * Uses MVweb Admin UI Kit (slate palette, Yoast-style layout).
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cron_command       = '0 */6 * * * /usr/local/bin/php ' . WP_CONTENT_DIR . '/plugins/mvweb-price-importer/cron-runner.php';
$feeds_cron_command = '0 * * * * /usr/local/bin/php ' . WP_CONTENT_DIR . '/plugins/mvweb-price-importer/feeds-cron-runner.php';
?>

<div class="mvweb-pi-tab-help">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Quick Start', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'A complete first-import walkthrough. Each step ends with the result you should see on the screen before moving on.', 'mvweb-price-importer' ); ?>
		</p>

		<ol class="mvweb-steps">
			<li>
				<div>
					<strong><?php esc_html_e( 'Step 1. Tell the plugin where the price list lives', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'Open the "Main" tab. In the "Source" section, paste the URL of your price list into the "Source URL" field. CSV, YML (Yandex.Market), XLSX and legacy binary XLS are supported, and Google Sheets share links are auto-converted to a CSV export.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'If you import from several locations (e.g. Moscow and St. Petersburg warehouses), use the "Warehouses" sub-section instead: click "Add Warehouse", fill in a short ID, name and URL for each one. When warehouses are configured the single "Source URL" above is ignored.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'Click "Save Changes" at the bottom of the page. You will see a green "Settings saved." notice at the top.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 2. Choose how often to import, batch size, and what to do with images', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'Still on the "Main" tab, scroll to "Import Schedule". Pick an "Auto-import Interval" (Hourly / Every 6 hours / Every 12 hours / Daily, or "Disabled" if you only want to import manually).', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( '"Batch Size" controls how many products are processed per chunk. 100–250 is a safe default. Reduce it if your hosting kills long-running PHP processes.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( '"Image Import" decides when product photos are downloaded. For catalogs of more than a few hundred items leave the default "Only for new products" — it is by far the cheapest option because re-importing images is what makes runs slow.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'Save again. The notice "Next scheduled import: …" appears with the exact date and time of the upcoming automatic run.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 3. Map your file columns to WooCommerce fields', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'Switch to the "Mapping" tab. Click "Detect columns" — the plugin downloads a sample of the source, parses the header row and tries to match SKU, Name, Price, Stock, Image, Category and the rest automatically.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'Review the dropdowns. Anything left blank means the field could not be auto-detected — pick the right column manually. The required fields are SKU, Name, Price and Stock; without them the import refuses to run.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'Click "Save Changes". A "Mapping saved." notice confirms.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'Below the mapping table is "Product Tags" — optional. Add a rule when your price list marks products as new, on sale or bestsellers: pick the column carrying the mark, list the values that mean "yes" (leave empty to accept true, 1, yes, y, да, +) and type the tag name. Leave the list empty and no tags are touched at all.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 4. Run the first import', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'Go back to the "Main" tab. In the "Actions" section press "Import Now" (the purple primary button). The yellow spinner spins until the run finishes.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'For very large catalogs the action splits into chunks: each click processes the next slice and a green notice tells you the chunk is done and the next one is scheduled. Keep pressing "Import Now" — or wait for the WordPress cron to run it automatically — until you see the final "Import complete" notice.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'The "Import Statistics" section right below "Actions" now shows the time of the last run, created/updated/skipped/errors counters, total items in the price list and how many SKUs the plugin already knows.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 5. Exclude categories you do not want in the shop (optional)', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'Click "Fetch category tree" in the "Category Filter" section on the "Main" tab: it reads the categories of the price list, or the product groups of MoySklad, without importing anything. Every import refreshes the tree as well. Choose whether the ticked branches are excluded or the only ones imported, then tick them — ticking a parent covers everything nested under it.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'Use the filter field to find categories by name, or the "Select all" / "Clear selection" shortcuts. Save Changes and re-run the import — excluded items will be skipped.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 6. Set up reliable scheduling for production (recommended)', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'WordPress cron only fires while visitors are browsing the site. On a low-traffic B2B shop the daily import may slip by hours. Replace it with a real system cron job through your hosting panel — the command to register is shown in the yellow "Note" box at the bottom of this page.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'When the system cron is active, set the "Auto-import Interval" on the Main tab to "Disabled" so the same import is not triggered twice.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 7. Set up a separate cron for feeds (optional)', 'mvweb-price-importer' ); ?></strong>
					<p><?php esc_html_e( 'By default the YML feeds are regenerated at the end of each successful import — that is the "Auto-generate" checkbox on the "Feeds" tab. For most shops this is all you need: feeds always reflect the latest import.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'If the price source updates rarely (say, once a day) but you want the feed timestamp refreshed more often — or you want feeds to be rebuilt even when the import is skipped because the source ETag has not changed — register the second cron line shown in the yellow "Note" box at the bottom of this page. It runs the feed generator directly without going through the import pipeline, reading already-imported products from WooCommerce.', 'mvweb-price-importer' ); ?></p>
					<p><?php esc_html_e( 'The two cron lines (import and feeds) are independent — pick the interval that suits each one. Common pattern: import every 6 hours, feeds every hour.', 'mvweb-price-importer' ); ?></p>
				</div>
			</li>
		</ol>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Frequently Asked Questions', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Common questions about sources, scheduling, feeds, logs, and the Actions buttons.', 'mvweb-price-importer' ); ?>
		</p>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'Which file formats are supported?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'CSV (with semicolon, comma, or tab delimiters), YML (Yandex.Market XML format), XLSX (Excel) and legacy binary XLS (Excel 97-2003). UTF-8 and Windows-1251 encodings are auto-detected.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'Can I use Google Sheets as a source?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'Yes. Paste your Google Sheets sharing link and it will be automatically converted to a CSV export URL.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'Where do I get the MoySklad access token?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'In MoySklad itself, not here. Open the user menu in the top right corner, go to Settings, find the Tokens section and press the button that adds one. Copy the token from the window that appears and paste it on the MoySklad tab, then press Connect.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'The token is shown once. If it is lost, it is not looked up — a new one is issued and the old one is deleted.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'Create the token under a separate MoySklad user with read access rather than under the owner account. A token can do everything the account it belongs to can, and this one only ever needs to read the catalogue. If it ever leaks, a separate user is revoked in MoySklad in one click and nothing else on the account is affected.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'The login and password fields next to it are the other way in: MoySklad issues a token in exchange for them, and only that token is stored. The password itself is never saved.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How often does the catalogue come in from MoySklad, and does anything go back?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'The full catalogue comes in on the schedule set on the Main tab — the same schedule the price-list import uses, hourly at its shortest. Stock has a schedule of its own on the MoySklad tab, down to every five minutes: it asks one question, writes nothing but the quantity, and leaves everything else to the full import.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'The catalogue side reads only: products, prices and stock are never written back. Orders are the one exception, and only once they are switched on — the shop sends its orders across, and the order status here follows the state of the document in MoySklad. With both switches off, MoySklad learns nothing about this shop at all.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'Either way, stock in MoySklad does not go down when something is sold on the site: a document created from here does not reserve goods. The figures are whatever the last refresh brought in, and the plugin subtracts what open WooCommerce orders hold on top of them.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'Which stock figure should I choose on the MoySklad tab?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( '"Free" for almost every shop: what is on the shelf, less what MoySklad has already reserved. "Available" adds goods still on their way from a supplier — a purchase order with five on the shelf and six ordered reads as eleven for sale — so the shop takes orders for goods it does not have yet. Choose it only if selling to order is intended. "Physical" ignores reservations and sells what MoySklad has promised to somebody else.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'The account has several warehouses. Which one does the shop sell from?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'From the sum of the warehouses switched on under "Warehouses" on the MoySklad tab — all of them unless some are switched off. A warehouse opened in MoySklad later is counted from the first import that sees it; to leave it out, press Reconnect with the fields empty, reload the page and switch it off. A reservation MoySklad holds without a warehouse is always taken off the sum.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'Switch on "Show on the product page" for a warehouse and its own figure appears under the stock line, as "Moscow: 8 pcs". The same figures are in the order screen next to each item.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How do "Hit", "New", brand or material from MoySklad get to the shop?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'Through the extra fields table on the MoySklad tab. A flag field becomes a product tag under the name you give it. A string, a number or a list field becomes a WooCommerce attribute: it appears in the product\'s Details tab and can be used in the storefront attribute filters. The attribute is created when you save — or, if the shop already has one with the same name, that one is filled, and on imported products its values then come from MoySklad only.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'MoySklad is the master for what it fills: untick "Hit" there and the next import takes the tag off; clear a value and the attribute goes. Tags and attributes added in WooCommerce by hand are left alone. Text, date, link and file fields are not imported yet. After adding a field in MoySklad, press Reconnect with the fields empty and reload the page for it to appear in the table.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'Weight and the barcode come without any setting: the weight into the product\'s weight in the shop\'s own unit, a real EAN or GTIN into the product\'s GTIN field. The numbers MoySklad invents for products without a barcode start with 2 and are not GTINs, so they are not written. If two products carry the same barcode, the second does not get it and the log says which product holds it.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How are products with variants (size, colour) imported from MoySklad?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'As variable products, with nothing to set up. Each variant becomes a variation with its own price, stock, warehouse split, barcode and first photo; each characteristic becomes a global WooCommerce attribute, so the storefront filters by size and colour work. An attribute the shop already has under the same name is used rather than a second one. A variation\'s SKU is the variant\'s article, or its code when there is no article.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'The product follows MoySklad. A product that gets variants becomes variable, and one that loses all of them becomes simple again. A variant deleted in MoySklad is disabled with zero stock rather than deleted, so orders that bought it still show it; it is switched back on if the variant returns. Variable products are not in the YML and CSV feeds yet.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'A product whose variations were made by hand in WooCommerce is left as it is, with a warning in the log. To have MoySklad fill it, delete those variations and run the import.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'MoySklad will not let the manager move the document on — a state is missing from the dropdown', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'That is the business process in MoySklad, not the plugin. It is found under Settings, in the business processes section, and it also opens from the "Configure…" line at the bottom of the state dropdown on the document itself.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'A business process is a list of stages. Each stage starts from one state and names the states a document may go to next; a manager is offered nothing else. A state that no stage starts from is a dead end — the document arrives there and stops, which is exactly what the empty dropdown means. Add a stage that starts from it, list the states it should lead to, and save.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'The same screen carries a warning worth heeding: a state left out of the active business process becomes unavailable on documents altogether. If the mapping table on the MoySklad tab points a WooCommerce status at such a state, nothing will ever arrive there.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'The document moved in MoySklad, but the order here still shows the old status', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'Four things to check, in this order. Is "Follow MoySklad" on, on the MoySklad tab? Is that state matched to a status in the table under it — an unmatched state deliberately leaves the order alone, which is how the state new documents start in is set up? Has a check run since the document moved? The button next to the schedule runs one immediately and reports what it saw.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'The fourth is the order itself. Only orders this site sent across are followed — a document typed into MoySklad by hand has no order here to update. And an order whose status was changed by hand on this site is left alone on purpose until its document moves again; the panel under the status field says so when that is the case.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'If the check is not running on its own, it is the usual scheduling story: WordPress only runs its jobs while somebody is browsing. The fix is the same real cron job on the server described below.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'The stock refresh is set to every 15 minutes, but nothing happens', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'WordPress has no clock of its own: its scheduled jobs run when somebody opens the site. On a quiet site "every 15 minutes" therefore means "every 15 minutes, as long as there are visitors", and overnight it can mean nothing at all.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'The fix is a real cron job on the server, pointed at stock-sync-runner.php in the plugin folder. It keeps the interval it was given whether anyone is visiting or not. Ask the hosting provider to add it if the control panel has no cron section.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'The other reason for a quiet refresh is a legitimate one: it steps aside while a full import is running, and it only writes where the quantity actually changed. "0 products updated" in the log means the shop already agreed with the warehouse.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'What happens to products missing from the new price list?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'Products not found in the new price list will have their stock set to 0 and status changed to "out of stock". They are not deleted or moved to draft.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'What happens to categories missing from the new price list?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'A category the supplier deleted is removed from the catalogue, and the products left inside it go to the trash, where WordPress keeps them for 30 days. A product the supplier merely moved to another category is not affected — the import re-assigns it first, so the old category is already empty.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'Three cases keep a category in place, each reported in the log: the price list lost more than a tenth of its categories at once (that reads as a truncated file, and nothing is deleted at all); the category still has subcategories in the catalogue; the category still holds products the current price list lists.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'With several warehouses set up, a run that could not download every price list skips the removal completely — a warehouse that failed to answer would otherwise look like a supplier deleting all of its categories.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'A customer ordered goods, then the import ran. Is the order still covered?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'Yes, as long as "Goods in open orders" is on — it is by default. The price list states what lies in the supplier\'s warehouse; the supplier knows nothing about orders taken in this shop, while the shop has already set those goods aside. The import subtracts what open orders hold and writes what is genuinely still for sale, so a second buyer cannot order what the first one already bought.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'Orders on hold and in progress count as holding goods. A completed order does not: those goods have left, and the supplier\'s next price list accounts for them. Cancel an order and the goods come back on their own — the stock returns to the price-list figure, not above it.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'If a delivery turns out smaller than what is already promised, the product goes to zero and the log names it with the number of missing units. That line is worth reading after each import: it is the only warning before someone goes to pick the order.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'The supplier uploads the price list onto my site — can anyone download it?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'By default, yes. A file lying in a folder of the site is served to whoever asks for its address, and search engines index it — that is the entire catalogue with prices, stock and barcodes, handed to a competitor in one request. Switch on "Close the price list" under Source on the Settings tab.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'The plugin issues a secret key, adds a rule to the site .htaccess that answers 403 to everyone without it, and appends the key to the source addresses so imports carry on unchanged. The supplier is unaffected: the price list arrives over FTP, and the rule governs downloads over HTTP only.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'Saving is not the same as believing: the plugin then asks the live site whether the file is really refused without the key and really served with it. If the server ignores .htaccess — nginx serving static files itself, or .htaccess switched off for the site — the rule is taken back out and the switch stays off, with the reason on screen. Then the way forward is a rule from the hosting provider, or having the price list moved out of the public folder.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'The key is part of the address, so treat that address as a password: anyone holding it can download the file. If it leaks, press "Issue a new key" — the old one stops working at once. Do not close the file in robots.txt as well: a crawler barred from fetching it never sees the 403 and keeps the address in the index. Let it come, collect the 403, and drop the page by itself.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How do I use the wholesale and dealer prices in my theme?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php
					printf(
						/* translators: 1: wholesale meta key in <code>, 2: dealer meta key in <code> */
						esc_html__( 'Map the "Wholesale Price" and "Dealer Price" columns on the Mapping tab (they sit right after "Old Price"). On every import the values are parsed and saved on each product in the %1$s and %2$s meta fields. You can also see and edit them by hand in the WooCommerce product editor, in the fields added under the regular/sale price inputs.', 'mvweb-price-importer' ),
						'<code>_mvweb_pi_wholesale_price</code>',
						'<code>_mvweb_pi_dealer_price</code>'
					);
					?>
				</p>
				<p>
					<?php esc_html_e( 'Suppliers name the dealer column differently — <pricedealer>, "дилерская цена", "dealer" — so auto-detect may miss it. Pick the column by hand and the mapping is remembered.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Both prices are stored on their own and are never used as the storefront price — WooCommerce keeps charging the regular or sale price. Deciding where to show them, and whether to charge one under any condition (customer role, quantity, order total), is left entirely to the theme. Read the meta and render it wherever you need:', 'mvweb-price-importer' ); ?>
				</p>
				<pre class="mvweb-codeblock"><code><?php echo esc_html( "\$wholesale = get_post_meta( \$product->get_id(), '_mvweb_pi_wholesale_price', true );\n\$dealer    = get_post_meta( \$product->get_id(), '_mvweb_pi_dealer_price', true );\nif ( '' !== \$wholesale ) {\n    echo 'Опт: ' . wc_price( \$wholesale );\n}" ); ?></code></pre>
				<p>
					<?php esc_html_e( 'WooCommerce core has no wholesale- or dealer-price field, so these are dedicated meta keys of the importer — no third-party wholesale plugin reads or writes them. The same values are also exported to generated YML feeds as <wholesale> and <pricedealer> elements, so they round-trip: re-importing such a feed reads them back automatically.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How do I set up multiple warehouses?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'In the "Main" tab → "Source" section press "Add Warehouse". Enter a unique ID, a display name and the URL for each warehouse. Stock quantities from all warehouses are summed for the total WooCommerce stock; per-warehouse stock is displayed on the product page if "Visible" is enabled.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'When a warehouse is removed from the settings, its leftover source file is deleted and it stops contributing to stock. On the next import a product that was only in that warehouse drops to zero stock (out of stock, hidden from the shop when "Hide out of stock" is on); a product also stocked in other warehouses keeps just their combined quantity.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How do I show per-warehouse stock in my theme?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p><?php esc_html_e( 'WooCommerce core has no concept of warehouses — it keeps a single stock number per product. This plugin sums every warehouse into that native stock (so the cart, checkout and stock reservation keep working) and stores the per-warehouse breakdown separately.', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'The simplest way: tick "Visible" for a warehouse. Its name and quantity are then appended to the standard stock line on the product page automatically, via the native woocommerce_get_stock_html filter — no theme code needed.', 'mvweb-price-importer' ); ?></p>
				<p>
					<?php
					printf(
						/* translators: 1: product meta key in <code>, 2: option name in <code> */
						esc_html__( 'For full control in the theme, read the breakdown yourself. Each product stores it in the %1$s meta as JSON (warehouse id → quantity); the warehouse names live in the %2$s option. Example:', 'mvweb-price-importer' ),
						'<code>_mvweb_pi_stocks</code>',
						'<code>mvweb_pi_settings</code>'
					);
					?>
				</p>
				<pre class="mvweb-codeblock"><code><?php echo esc_html( "\$stocks   = json_decode( (string) get_post_meta( \$product->get_id(), '_mvweb_pi_stocks', true ), true );\n\$settings = get_option( 'mvweb_pi_settings', array() );\n\$names    = wp_list_pluck( \$settings['warehouses'] ?? array(), 'name', 'id' );\n\nif ( is_array( \$stocks ) ) {\n    foreach ( \$stocks as \$wh_id => \$qty ) {\n        printf( '%s: %d pcs', esc_html( \$names[ \$wh_id ] ?? \$wh_id ), (int) \$qty );\n    }\n}" ); ?></code></pre>
				<p><?php esc_html_e( 'The same warehouse quantities are also written to the per-warehouse YML feeds on the Feeds tab, so an aggregator or a downstream shop sees exactly what is available at each location.', 'mvweb-price-importer' ); ?></p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'What does the "Download" button do?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'Fetches the source price files from every configured URL (single Source URL or each warehouse) and stores them under wp-content/uploads/pricelists/ as source-{warehouse}-{uuid}.{ext}. No WooCommerce products are touched.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Before downloading, the plugin issues a HEAD request and compares ETag / Last-Modified / Content-Length with the values saved from the previous run. If nothing changed, the source is marked "File unchanged" and the full body is not fetched — exactly the same logic the scheduled import uses to skip work. Use this button when you want to refresh a source file by hand without running a full import, or to verify that the URL is reachable.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'What does the "Convert" button do?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'Parses every source file already saved by "Download" with the column mapping configured on the Mapping tab and reports how many products would be imported, how many rows are invalid, and how many duplicate SKUs were found. This is a dry-run — no products in WooCommerce are created or updated.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Use it after changing the mapping or to debug a problematic source — invalid rows and duplicates show up here long before they corrupt the catalog. If you press "Convert" before "Download", the plugin returns "No downloaded source files found" — press "Download" first.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php
					printf(
						/* translators: %s: setting name */
						esc_html__( 'When the %s setting is enabled, "Convert" also writes a CSV checkpoint of the parsed products and a separate file with all invalid rows into the upload directory, so you can inspect them in Excel.', 'mvweb-price-importer' ),
						'<code>' . esc_html__( 'Debug: save converter checkpoint', 'mvweb-price-importer' ) . '</code>'
					);
					?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'What does the "Reset Hash" button do, and when should I use it?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'Clears the saved ETag / Last-Modified / Content-Length values for every source. The next download (manual or scheduled) will therefore re-fetch each file in full, regardless of whether the supplier updated the change-detection headers.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'The button is named after the header-based fingerprint the plugin stores per source — it is not a content hash of the file itself. Reach for it in these situations:', 'mvweb-price-importer' ); ?>
				</p>
				<ul>
					<li><?php esc_html_e( 'The supplier edited the price list but did not change ETag or Last-Modified — the import keeps saying "All sources unchanged" while you can see fresh data in the file.', 'mvweb-price-importer' ); ?></li>
					<li><?php esc_html_e( 'The source URL changed (different server, new export, switched from Google Sheets to direct download) and you want a clean baseline.', 'mvweb-price-importer' ); ?></li>
					<li><?php esc_html_e( 'You just changed the column mapping and want the next scheduled run to start from a fresh download instead of reusing a possibly-cached old file.', 'mvweb-price-importer' ); ?></li>
				</ul>
				<p>
					<?php esc_html_e( 'The button only resets bookkeeping — it does not delete already-downloaded files or any imported products.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'Why is automatic import not running on time?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'The "Auto-import Interval" setting on the Main tab uses WordPress cron (wp-cron). The timer itself does not run anything — the scheduled job only fires when a visitor opens any page of the site (front-end, admin, or REST). With a steady flow of traffic the import runs within a few minutes of the time shown next to "Next import at …". On a low-traffic B2B catalog there may be no visitor for hours, and the import will be delayed by exactly that gap.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'For predictable runs configure a real system cron on the hosting panel — the exact command is in the yellow Note box at the bottom of this page. When system cron is active, change the "Auto-import Interval" on the Main tab to "Disabled" so the same import is not started twice.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How do feeds get updated, and do I need a separate cron for them?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'By default feeds are regenerated at the end of every successful import — that is the "Auto-generate" checkbox on the Feeds tab. For most shops this is enough: feeds always reflect the latest import.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'A separate cron job for feeds is only needed in two cases:', 'mvweb-price-importer' ); ?>
				</p>
				<ul>
					<li><?php esc_html_e( 'The price source rarely changes (e.g. updated once a day) but you want the feed timestamp refreshed more often so Yandex.Market re-fetches it.', 'mvweb-price-importer' ); ?></li>
					<li><?php esc_html_e( 'You want feeds rebuilt even when the import is skipped because the source ETag has not changed (in that case the auto-generate hook does not fire — the import returns "skipped" before reaching it).', 'mvweb-price-importer' ); ?></li>
				</ul>
				<p>
					<?php esc_html_e( 'When that applies, add the second crontab line from the yellow Note box at the bottom of this page. It calls feeds-cron-runner.php directly: WooCommerce products are read as-is, no source download or product update happens. The feeds cron is fully independent of the import cron — pick the interval that suits each one.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'If you do NOT add the second cron, feeds still update — just on the same cadence as the import.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'My theme registers a custom image size and product images miss it — why?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'During import the plugin generates only the four image sizes WooCommerce templates strictly require: thumbnail (admin), woocommerce_thumbnail (catalog tile), woocommerce_single (product page) and woocommerce_gallery_thumbnail (gallery). Every other size — including theme-registered ones like "card", "hero", responsive WP variants like medium_large / 1536x1536 / 2048x2048, and the WP "large" size — is skipped to cut Imagick CPU and memory roughly in half on shared hosting. A 1400-SKU feed becomes minutes-faster per cron cycle and stops blowing through Beget\'s 256 MB cgroup.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Missing sizes are not lost. WordPress generates them on first request to wp_get_attachment_image() / wp_get_attachment_image_src() and caches the result in the attachment metadata — native behaviour since WP 5.3. The first visitor to a product page pays a one-off ~200 ms for that size; everyone after sees it instantly.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php
					printf(
						/* translators: %s: command name in <code> */
						esc_html__( 'If you want every size pre-generated for an existing catalog (for example, you just switched to a new theme that registers its own sizes), run %s once. WordPress will fill in every missing size in batches.', 'mvweb-price-importer' ),
						'<code>wp media regenerate</code>'
					);
					?>
				</p>
				<p>
					<?php
					printf(
						/* translators: %s: filter name in <code> */
						esc_html__( 'To change which sizes are generated during import — for example, add a theme size that you know will be used on every product page — use the %s filter:', 'mvweb-price-importer' ),
						'<code>mvweb_pi_keep_image_sizes</code>'
					);
					?>
				</p>
				<pre class="mvweb-codeblock"><code><?php echo esc_html( "add_filter( 'mvweb_pi_keep_image_sizes', function ( \$sizes ) {\n    \$sizes[] = 'my_theme_card';\n    return \$sizes;\n} );" ); ?></code></pre>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'Where are logs stored and how often are they cleaned?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php
					printf(
						/* translators: %s: log file path */
						esc_html__( 'Logs are stored in JSONL format at %s and read in the "Log" tab.', 'mvweb-price-importer' ),
						'<code>wp-content/uploads/pricelists/mvweb_pi.log</code>'
					);
					?>
				</p>
				<p>
					<?php esc_html_e( 'Rotation is automatic and triggered lazily on the next log write — there is no separate cron job. Two thresholds:', 'mvweb-price-importer' ); ?>
				</p>
				<ul>
					<li><?php esc_html_e( 'When the file passes 10 MB, it is renamed to a dated .bak archive next to it and a fresh log starts.', 'mvweb-price-importer' ); ?></li>
					<li><?php esc_html_e( 'When the file is older than 30 days, the same archive-and-restart happens regardless of size.', 'mvweb-price-importer' ); ?></li>
					<li><?php esc_html_e( 'Archive files (.bak) older than 30 days are deleted on the same write.', 'mvweb-price-importer' ); ?></li>
				</ul>
				<p>
					<?php esc_html_e( 'In practice the log file never grows unboundedly — a busy import that produces hundreds of warnings per run still rolls over within a single day at 10 MB. The "Clear Log" button on the Log tab erases the current file and all archives immediately.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How do I see verbose / developer-level details?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'The log has two layers. Without any extra configuration you only see operator-grade events — downloads completed, conversion summary, import results, errors. That keeps the screen readable when everything is fine.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'When you need to chase a slow or broken import, enable the "Verbose logging" checkbox in Main → Import Schedule. From the next write onward the plugin also records per-batch progress, per-source download details, and individual image-404 misses. Switch the Level filter on the Log tab to "Debug (verbose)" to focus on those entries.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Turn the checkbox back off once you are done — debug mode produces orders of magnitude more lines and is what causes log rotation to kick in early.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'How do I turn a price list column into a product tag?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'Open Mapping → Product Tags and add a rule. Pick the source column, list the values that mean "yes", and give the tag a name. Nothing else is needed: the tag is created in Products → Tags on the first import that runs into a product carrying that value.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'The source can be anything the parser sees — a column in CSV or Excel, an XML tag, a <param> entry, or an attribute of the <offer> element such as newest="true" or hit="true". Press "Detect columns" first so the dropdown lists everything your file offers.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Several rules may read the same column with different values, which is how a single "status" column can feed three separate tags.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'Will my import overwrite a tag I renamed?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'No. The plugin remembers which tag belongs to which rule internally, not by its name, so you can rename "sellout" to "Sale" (or anything else) in Products → Tags and every following import keeps your wording. The name in the rule is only used the first time, when the tag has to be created.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Renaming the tag inside the rule afterwards does not rename the tag itself — edit it in Products → Tags instead.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>

		<details class="mvweb-faq">
			<summary><?php esc_html_e( 'What happens when the price list stops marking a product?', 'mvweb-price-importer' ); ?></summary>
			<div class="mvweb-faq__body">
				<p>
					<?php esc_html_e( 'The tag is removed from that product on the next import. This applies to the tag named in the rule even if you attached it by hand, so avoid reusing a rule name for a tag you curate manually. Tags that no rule covers are never touched.', 'mvweb-price-importer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'A product that disappears from the price list entirely keeps its tags — only its stock is zeroed. Deleting a rule also changes nothing that is already in the catalog: the tag and its products stay, the import simply stops managing them.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</details>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'System cron commands', 'mvweb-price-importer' ); ?></div>
		</div>

		<div class="mvweb-alert mvweb-alert--warning">
			<div class="mvweb-alert__body">
				<p class="mvweb-alert__title"><?php esc_html_e( 'Import cron', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'WordPress cron (wp-cron) fires only while visitors are on the site. For B2B shops with low traffic, use system cron for reliable scheduling:', 'mvweb-price-importer' ); ?></p>
				<pre class="mvweb-codeblock"><code><?php echo esc_html( $cron_command ); ?></code></pre>
			</div>
		</div>

		<div class="mvweb-alert mvweb-alert--warning">
			<div class="mvweb-alert__body">
				<p class="mvweb-alert__title"><?php esc_html_e( 'Feeds cron (optional)', 'mvweb-price-importer' ); ?></p>
				<p><?php esc_html_e( 'Add a second crontab line if you need feeds refreshed on a different cadence than the import itself — for example, import once a day but regenerate feeds every hour from already-imported products:', 'mvweb-price-importer' ); ?></p>
				<pre class="mvweb-codeblock"><code><?php echo esc_html( $feeds_cron_command ); ?></code></pre>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-price-importer' ); ?></div>
		</div>
		<p>
			<?php
			printf(
				/* translators: %s: MVweb plugin URL */
				esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-price-importer' ),
				'<a href="https://mvweb.ru/plugins/mvweb-price-importer" target="_blank" rel="noopener noreferrer">mvweb.ru</a>'
			);
			?>
		</p>
	</div>

</div>
