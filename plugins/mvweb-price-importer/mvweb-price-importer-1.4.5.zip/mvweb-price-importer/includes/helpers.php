<?php
/**
 * Helper functions for MVweb Price Importer
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

declare(strict_types=1);

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get plugin option with default value.
 *
 * @since 1.0.0
 * @param string $key     Option key (without mvweb_pi_ prefix).
 * @param mixed  $default Default value.
 * @return mixed Option value.
 */
function mvweb_pi_get_option( string $key, $default = '' ) {
	return get_option( 'mvweb_pi_' . $key, $default );
}

/**
 * Update plugin option.
 *
 * @since 1.0.0
 * @param string $key   Option key (without mvweb_pi_ prefix).
 * @param mixed  $value Option value.
 * @return bool True if updated, false otherwise.
 */
function mvweb_pi_update_option( string $key, $value ): bool {
	return update_option( 'mvweb_pi_' . $key, $value );
}

/**
 * Delete plugin option.
 *
 * @since 1.0.0
 * @param string $key Option key (without mvweb_pi_ prefix).
 * @return bool True if deleted, false otherwise.
 */
function mvweb_pi_delete_option( string $key ): bool {
	return delete_option( 'mvweb_pi_' . $key );
}

/**
 * Where this site takes its catalogue from.
 *
 * Exactly one source is in charge of a site, never two. The plugin's category
 * map, its category tree sidecar and its stock-out pass all assume the feed
 * they see describes the whole managed catalogue; a second source running
 * alongside would make that assumption false and the stock-out pass would zero
 * the other source's products. Stored in its own option rather than inside
 * `mvweb_pi_settings`, which is rebuilt from scratch on every save and would
 * silently drop a key not listed in its whitelist.
 *
 * @since 1.1.0
 * @return string `file` (price list by URL) or `moysklad` (JSON API).
 */
function mvweb_pi_source_mode(): string {
	$mode = (string) get_option( 'mvweb_pi_source_mode', 'file' );

	return isset( mvweb_pi_source_modes()[ $mode ] ) ? $mode : 'file';
}

/**
 * Source modes and their operator-facing labels.
 *
 * @since 1.1.0
 * @return array<string, string> mode => label.
 */
function mvweb_pi_source_modes(): array {
	return array(
		'file'     => __( 'Price list by URL (CSV, YML, XLSX, XLS)', 'mvweb-price-importer' ),
		'moysklad' => __( 'MoySklad (JSON API)', 'mvweb-price-importer' ),
	);
}

/**
 * What to do with a product that has a wholesale price but no retail one.
 *
 * `skip` leaves it out of the catalogue, as every version before 1.4.0 did.
 * `reference` imports it with no storefront price, so WooCommerce offers no way
 * to buy it. `wholesale` imports it at the wholesale price, so it can be ordered
 * at that price. Without a wholesale price the product is left out either way.
 *
 * @since 1.4.0
 * @return string `skip`, `reference` or `wholesale`.
 */
function mvweb_pi_no_retail_mode(): string {
	$settings = get_option( 'mvweb_pi_settings', array() );
	$mode     = is_array( $settings ) ? (string) ( $settings['no_retail'] ?? 'skip' ) : 'skip';

	return isset( mvweb_pi_no_retail_modes()[ $mode ] ) ? $mode : 'skip';
}

/**
 * Modes for products without a retail price, with their operator-facing labels.
 *
 * @since 1.4.0
 * @return array<string, string> mode => label.
 */
function mvweb_pi_no_retail_modes(): array {
	return array(
		'skip'      => __( 'Leave them out of the catalogue', 'mvweb-price-importer' ),
		'reference' => __( 'Import for reference: a dash instead of the price, cannot be ordered', 'mvweb-price-importer' ),
		'wholesale' => __( 'Import and let them be ordered at the wholesale price', 'mvweb-price-importer' ),
	);
}

/**
 * Caption put before the wholesale price of a product without a retail one.
 *
 * @since 1.4.0
 * @return string Plain text.
 */
function mvweb_pi_no_retail_label(): string {
	$settings = get_option( 'mvweb_pi_settings', array() );
	$label    = is_array( $settings ) ? trim( (string) ( $settings['no_retail_label'] ?? '' ) ) : '';

	return '' !== $label ? $label : __( 'Wholesale:', 'mvweb-price-importer' );
}

/**
 * Whether the wholesale price is shown next to the dash.
 *
 * Off when the theme already prints the wholesale price itself, so it does not
 * appear twice.
 *
 * @since 1.4.2
 * @return bool
 */
function mvweb_pi_no_retail_show_wholesale(): bool {
	$settings = get_option( 'mvweb_pi_settings', array() );

	return ! ( is_array( $settings ) && ! empty( $settings['no_retail_hide_wholesale'] ) );
}

/**
 * Retail price for a row, or null when the row goes in without one.
 *
 * Shared by both sources so a price list and MoySklad treat the same product
 * the same way. The row is kept only when a wholesale price is there to show
 * next to the dash; with neither price there is nothing to sell or to quote.
 *
 * @since 1.4.0
 * @param float|null $retail    Retail price as read, null or zero when missing.
 * @param float|null $wholesale Wholesale price as read.
 * @return array{keep: bool, no_retail: bool} Whether to keep the row, and whether it lacks a retail price.
 */
function mvweb_pi_no_retail_decision( ?float $retail, ?float $wholesale ): array {
	if ( null !== $retail && $retail > 0 ) {
		return array(
			'keep'      => true,
			'no_retail' => false,
		);
	}

	$keep = 'skip' !== mvweb_pi_no_retail_mode() && null !== $wholesale && $wholesale > 0;

	return array(
		'keep'      => $keep,
		'no_retail' => $keep,
	);
}

/**
 * Forget everything the previous source taught the plugin.
 *
 * Called when the operator switches source mode. The category map keys terms by
 * the source's own external ids, the tree sidecar mirrors that source's tree,
 * and the category filter ticks its ids — all of them meaningless, and in
 * include mode actively harmful, once the ids come from somewhere else. The SKU
 * snapshot, the checkpoint and the statistics describe a run of the old source.
 *
 * Products are deliberately left alone: the first run of the new source matches
 * them by SKU and adopts them. Column mapping and tag rules are left alone too —
 * they belong to the file path and have to survive a round trip.
 *
 * @since 1.1.0
 * @return void
 */
function mvweb_pi_reset_source_state(): void {
	$options = array(
		'mvweb_pi_category_map',
		'mvweb_pi_category_meta',
		'mvweb_pi_excluded_categories',
		'mvweb_pi_category_filter_mode',
		'mvweb_pi_flatten_roots',
		'mvweb_pi_known_skus',
		'mvweb_pi_import_progress',
		'mvweb_pi_import_stats',
		'mvweb_pi_last_etags',
	);

	foreach ( $options as $option ) {
		delete_option( $option );
	}
}

/**
 * Every warehouse a product's per-warehouse stock can refer to.
 *
 * Two sources name warehouses and neither knows about the other: the price-list
 * path keeps them in its own settings, MoySklad reports its stores when the
 * account is connected. The storefront and the order screen only ever see the
 * ids stored on a product, so they ask here rather than in one place each.
 *
 * @since 1.3.0
 * @return array<string, array{name: string, visible: bool}> Warehouse id => how to show it.
 */
function mvweb_pi_warehouse_directory(): array {
	$directory = array();

	$settings = get_option( 'mvweb_pi_settings', array() );
	foreach ( (array) ( is_array( $settings ) ? ( $settings['warehouses'] ?? array() ) : array() ) as $warehouse ) {
		if ( ! is_array( $warehouse ) || '' === (string) ( $warehouse['id'] ?? '' ) ) {
			continue;
		}
		$directory[ (string) $warehouse['id'] ] = array(
			'name'    => (string) ( $warehouse['name'] ?? '' ),
			'visible' => '1' === (string) ( $warehouse['visible'] ?? '0' ),
		);
	}

	$ms      = get_option( 'mvweb_pi_moysklad', array() );
	$ms      = is_array( $ms ) ? $ms : array();
	$visible = array_flip( array_map( 'strval', (array) ( $ms['stores_visible'] ?? array() ) ) );
	foreach ( (array) ( $ms['stores'] ?? array() ) as $id => $name ) {
		$directory[ (string) $id ] = array(
			'name'    => (string) $name,
			'visible' => isset( $visible[ (string) $id ] ),
		);
	}

	return $directory;
}

/**
 * The global WooCommerce attribute a MoySklad field or characteristic fills.
 *
 * The taxonomy it filled before if that still exists, so a field renamed in
 * MoySklad keeps its attribute; otherwise an attribute the shop already has
 * under the same name; otherwise a new one with a transliterated slug. A new
 * attribute is registered for the rest of the request straight away, the way
 * WooCommerce's own product importer does it: without that, a product written
 * in the same request would be refused the taxonomy until the next page load.
 *
 * @since 1.3.0
 * @param string $label    Attribute name.
 * @param string $previous Taxonomy it filled before, or ''.
 * @return string Taxonomy (`pa_…`), or '' when none could be made.
 */
function mvweb_pi_wc_attribute( string $label, string $previous = '' ): string {
	if ( ! function_exists( 'wc_create_attribute' ) || '' === trim( $label ) ) {
		return '';
	}

	if ( '' !== $previous && wc_attribute_taxonomy_id_by_name( $previous ) > 0 ) {
		return $previous;
	}

	foreach ( wc_get_attribute_taxonomies() as $attribute ) {
		if ( 0 === strcasecmp( trim( (string) $attribute->attribute_label ), trim( $label ) ) ) {
			return wc_attribute_taxonomy_name( (string) $attribute->attribute_name );
		}
	}

	$limit = function_exists( 'wc_get_attribute_slug_max_byte_length' ) ? (int) wc_get_attribute_slug_max_byte_length() : 28;
	$base  = trim( substr( MVweb_PI_Categories::build_slug( $label ), 0, $limit ), '-' );
	$tries = array( '' !== $base ? $base : 'ms-field' );
	for ( $i = 2; $i <= 5; $i++ ) {
		$tries[] = trim( substr( $tries[0], 0, $limit - strlen( "-$i" ) ), '-' ) . "-$i";
	}
	// The last resort when the name transliterates into something WordPress
	// reserves ("type", "order") or every variant above is taken.
	$tries[] = 'ms-' . substr( md5( $label ), 0, 8 );

	foreach ( $tries as $slug ) {
		if ( wc_attribute_taxonomy_id_by_name( $slug ) > 0 ) {
			continue;
		}

		$created = wc_create_attribute(
			array(
				'name'         => $label,
				'slug'         => $slug,
				'type'         => 'select',
				'order_by'     => 'menu_order',
				'has_archives' => false,
			)
		);

		if ( is_wp_error( $created ) ) {
			continue;
		}

		$taxonomy = wc_attribute_taxonomy_name( $slug );
		if ( ! taxonomy_exists( $taxonomy ) ) {
			register_taxonomy(
				$taxonomy,
				apply_filters( 'woocommerce_taxonomy_objects_' . $taxonomy, array( 'product' ) ),
				apply_filters(
					'woocommerce_taxonomy_args_' . $taxonomy,
					array(
						'labels'                => array( 'name' => $label ),
						'hierarchical'          => false,
						'update_count_callback' => '_update_post_term_count',
						'show_ui'               => false,
						'query_var'             => true,
						'rewrite'               => false,
					)
				)
			);

			global $wc_product_attributes;
			$wc_product_attributes = array();
			foreach ( wc_get_attribute_taxonomies() as $attribute ) {
				$wc_product_attributes[ wc_attribute_taxonomy_name( (string) $attribute->attribute_name ) ] = $attribute;
			}
		}

		return $taxonomy;
	}

	return '';
}

/**
 * Get the pricelists upload directory path.
 *
 * @since 1.0.0
 * @return string Absolute path to pricelists directory.
 */
function mvweb_pi_get_upload_dir(): string {
	$upload_dir = wp_upload_dir();
	return $upload_dir['basedir'] . '/pricelists/';
}

/**
 * Get the feeds directory path.
 *
 * @since 1.0.0
 * @return string Absolute path to feeds directory.
 */
function mvweb_pi_get_feeds_dir(): string {
	return mvweb_pi_get_upload_dir() . 'feeds/';
}

/**
 * Get the feeds directory URL.
 *
 * @since 1.0.0
 * @return string URL to feeds directory.
 */
function mvweb_pi_get_feeds_url(): string {
	$upload_dir = wp_upload_dir();
	return $upload_dir['baseurl'] . '/pricelists/feeds/';
}

/**
 * Strip Basic Auth credentials from any URL appearing inside a string.
 *
 * `https://user:secret@host/path` → `https://***:***@host/path`. Used to
 * sanitize log messages and email bodies so supplier credentials embedded
 * in source URLs don't leak into shared log files (which can be world-
 * readable on Nginx where the bundled .htaccess does nothing).
 *
 * @since 1.0.0
 * @param string $value Arbitrary string that may contain URLs.
 * @return string Sanitized string.
 */
function mvweb_pi_mask_credentials( string $value ): string {
	if ( '' === $value ) {
		return $value;
	}
	return preg_replace(
		'#(https?://)([^:/@\s]+):([^@/\s]+)@#i',
		'$1***:***@',
		$value
	);
}

/**
 * URL cut down to scheme, host and path — the form that is safe to log.
 *
 * A source URL can carry the price list access key in its query string, and
 * the log file lives in the same uploads folder that is only protected by an
 * .htaccess Nginx never reads. Dropping the query keeps the whole diagnostic
 * value — which host, which file — without writing the secret down.
 *
 * @since 1.1.0
 * @param string $url Full URL.
 * @return string URL without query string and credentials.
 */
function mvweb_pi_url_for_log( string $url ): string {
	$parts = wp_parse_url( $url );
	if ( empty( $parts['host'] ) ) {
		return mvweb_pi_mask_credentials( $url );
	}

	$port = isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '';

	return ( $parts['scheme'] ?? 'https' ) . '://' . $parts['host'] . $port . ( $parts['path'] ?? '' );
}

/**
 * Log message to JSONL file via MVweb_PI_Logger.
 *
 * Always writes to the JSONL log file (wp-content/uploads/pricelists/mvweb_pi.log).
 * Additionally writes to PHP error_log when WP_DEBUG is enabled.
 *
 * @since 1.0.0
 * @param mixed  $message Message to log.
 * @param string $level   Log level (info, warning, error).
 * @param array  $context Optional context data.
 * @return void
 */
function mvweb_pi_log( $message, $level = 'info', $context = array() ) {
	if ( is_array( $message ) || is_object( $message ) ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_print_r
		$message = print_r( $message, true );
	}

	$message = mvweb_pi_mask_credentials( (string) $message );

	// Mask credentials inside context values too, in case a URL string slips in.
	if ( ! empty( $context ) ) {
		array_walk_recursive(
			$context,
			static function ( &$item ) {
				if ( is_string( $item ) ) {
					$item = mvweb_pi_mask_credentials( $item );
				}
			}
		);
	}

	// Write to JSONL log file.
	if ( class_exists( 'MVweb_PI_Logger' ) ) {
		$logger = MVweb_PI_Logger::get_instance();
		$logger->log( $level, $message, $context );
	}

	// Also write to PHP error_log when debugging.
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		$log_message = sprintf(
			'[MVweb Price Importer] [%s] %s',
			strtoupper( $level ),
			$message
		);
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( $log_message );
	}
}

/**
 * Source ids the current settings expect to import from.
 *
 * With warehouses configured, that is each warehouse id; otherwise the single
 * `default` source when a source URL is set. Used to ignore (and clean up)
 * leftover `source-{id}-{uuid}` files of warehouses that were removed from the
 * settings — without this a manual Convert would re-merge a removed warehouse's
 * stock into the total and the general feed even though no feed exists for it
 * any more.
 *
 * @since 1.0.0
 * @param array $settings The `mvweb_pi_settings` option array.
 * @return string[] Expected source ids.
 */
function mvweb_pi_expected_source_ids( array $settings ): array {
	$warehouses = $settings['warehouses'] ?? array();

	if ( ! empty( $warehouses ) && is_array( $warehouses ) ) {
		$ids = array();
		foreach ( $warehouses as $wh ) {
			$id = isset( $wh['id'] ) ? (string) $wh['id'] : '';
			if ( '' !== $id ) {
				$ids[] = $id;
			}
		}
		return $ids;
	}

	return ! empty( $settings['source_url'] ) ? array( 'default' ) : array();
}

/**
 * Normalise supplier text: decode HTML entities and strip invisible characters.
 *
 * Price lists routinely arrive with text mangled by an exporter that encoded it
 * more than once — `Bluetooth-гарнитура &amp;quot;Saches&amp;quot; R3` — and with
 * non-breaking spaces glued into names. Neither sanitize_text_field() nor
 * wp_kses_post() decodes entities, so without this the mangled text lands in the
 * catalogue verbatim.
 *
 * Order matters: entities are decoded BEFORE sanitising, so anything that
 * surfaces from the encoding still passes through the filter. That order is the
 * whole point — WordPress does not filter post_title/post_content on insert
 * (only `pre_term_name` is protected by core), so for products this is the only
 * line of defence.
 *
 * @since 1.0.25
 * @param string $value      Raw text from the price list.
 * @param bool   $allow_html Whether the field keeps HTML (product description).
 * @return string Normalised text, sanitised for its context.
 */
function mvweb_pi_clean_text( string $value, bool $allow_html = false ): string {
	if ( '' === $value ) {
		return $value;
	}

	// Control bytes carry no meaning in product text, and the two used below as
	// placeholders would be mistaken for angle brackets on the way back — a feed
	// carrying them verbatim would lose the text around them. Drop them first.
	$value = str_replace( array( "\x01", "\x02" ), '', $value );

	// Remember the angle brackets that arrived as real markup. Everything that
	// only appears AFTER decoding is text the supplier encoded on purpose, and
	// it must not become markup: wp_kses_post() drops everything between "<"
	// and the next ">", so an encoded "вес &lt; 5 кг, длина &gt; 2 м" would lose
	// that whole fragment once decoding turned it into brackets. Brackets that
	// arrive raw are markup as far as the feed is concerned and keep going
	// through kses unchanged, exactly as they did before this normalisation.
	if ( $allow_html ) {
		$value = str_replace( array( '<', '>' ), array( "\x01", "\x02" ), $value );
	}

	// Decode until the string settles. Two passes cover the common double
	// encoding; the third is headroom for exporters that stack another layer.
	// The cap is a safety stop, not a correctness requirement — decoding always
	// reaches a fixed point on its own.
	for ( $pass = 0; $pass < 3; $pass++ ) {
		$decoded = html_entity_decode( $value, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		if ( $decoded === $value ) {
			break;
		}
		$value = $decoded;
	}

	if ( $allow_html ) {
		// Anything that surfaced from the encoding goes back to a harmless
		// entity, then the original markup is restored.
		$value = str_replace( array( '<', '>' ), array( '&lt;', '&gt;' ), $value );
		$value = str_replace( array( "\x01", "\x02" ), array( '<', '>' ), $value );
	}

	// Invisible characters and the non-breaking space, byte-wise on purpose: a
	// /u regex returns null on malformed UTF-8 and would wipe the whole field.
	// The non-breaking space becomes a regular one so that neighbouring words
	// never glue together; a doubled space is collapsed below.
	$value = str_replace(
		array( "\xE2\x80\x8B", "\xEF\xBB\xBF", "\xC2\xAD", "\xC2\xA0" ),
		array( '', '', '', ' ' ),
		$value
	);

	$value = $allow_html ? wp_kses_post( $value ) : sanitize_text_field( $value );

	// Collapse runs of spaces left behind by the replacements. For descriptions
	// only horizontal whitespace is touched so line breaks survive.
	$value = $allow_html
		? (string) preg_replace( '/[ \t]{2,}/', ' ', $value )
		: (string) preg_replace( '/ {2,}/', ' ', $value );

	return trim( $value );
}
