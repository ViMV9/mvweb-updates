<?php
/**
 * UI class — frontend display.
 *
 * Displays per-warehouse stock on product pages
 * and in admin order view.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_UI
 *
 * Hooks into WooCommerce to show per-warehouse stock levels
 * on the single product page and in admin order item meta.
 *
 * @since 1.0.0
 */
class MVweb_PI_UI {

	/**
	 * Constructor — register WooCommerce hooks.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_filter( 'woocommerce_get_stock_html', array( $this, 'stock_html' ), 10, 2 );
		add_action( 'woocommerce_after_order_itemmeta', array( $this, 'order_item_stocks' ), 10, 3 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_styles' ) );
		add_filter( 'woocommerce_get_price_html', array( $this, 'no_retail_price_html' ), 20, 2 );
	}

	/**
	 * Put a dash and the wholesale price where a product without a retail price
	 * would show its price.
	 *
	 * Runs through WooCommerce's own price HTML, so the catalogue, the product
	 * page, search results and the admin product list all read the same. The
	 * mark is written by the importer and removed once a retail price arrives.
	 *
	 * @since 1.4.0
	 * @param string      $html    Price HTML WooCommerce built.
	 * @param \WC_Product $product Product or variation.
	 * @return string
	 */
	public function no_retail_price_html( $html, $product ) {
		if ( ! $product instanceof \WC_Product || '1' !== (string) get_post_meta( $product->get_id(), '_mvweb_pi_no_retail', true ) ) {
			return $html;
		}

		$out       = '<span class="mvweb-pi-no-retail"><span class="mvweb-pi-no-retail__dash">&mdash;</span>';
		$wholesale = mvweb_pi_no_retail_show_wholesale() ? (float) get_post_meta( $product->get_id(), '_mvweb_pi_wholesale_price', true ) : 0.0;
		if ( $wholesale > 0 ) {
			$out .= ' <span class="mvweb-pi-no-retail__wholesale">' . esc_html( mvweb_pi_no_retail_label() ) . ' '
				. wc_price( wc_get_price_to_display( $product, array( 'price' => $wholesale ) ) ) . '</span>';
		}

		return $out . '</span>';
	}

	/**
	 * Append per-warehouse stock levels to WooCommerce stock HTML.
	 *
	 * Replaces the default "X in stock" with a breakdown by warehouse.
	 * Only warehouses with `visible` flag set to '1' are displayed.
	 *
	 * Uses BEM: .mvweb-pi-stocks / .mvweb-pi-stocks__item (TZ 12.1).
	 *
	 * @since 1.0.0
	 * @param string      $html    Default WooCommerce stock HTML.
	 * @param \WC_Product $product WooCommerce product instance.
	 * @return string Modified stock HTML with per-warehouse breakdown.
	 */
	public function stock_html( string $html, $product ): string {
		if ( ! $product instanceof \WC_Product ) {
			return $html;
		}

		$stocks_json = get_post_meta( $product->get_id(), '_mvweb_pi_stocks', true );
		if ( empty( $stocks_json ) ) {
			return $html;
		}

		$stocks = json_decode( $stocks_json, true );
		if ( ! is_array( $stocks ) || empty( $stocks ) ) {
			return $html;
		}

		$warehouses = mvweb_pi_warehouse_directory();

		$items = array();
		foreach ( $stocks as $wh_id => $qty ) {
			$wh = $warehouses[ (string) $wh_id ] ?? null;

			// Skip if warehouse config not found or visibility is off.
			if ( ! $wh || ! $wh['visible'] ) {
				continue;
			}

			$qty_int = absint( $qty );
			$name    = ! empty( $wh['name'] ) ? $wh['name'] : $wh_id;

			$items[] = sprintf(
				'<span class="mvweb-pi-stocks__item"><span class="mvweb-pi-stocks__label">%s:</span> <span class="mvweb-pi-stocks__qty">%d %s</span></span>',
				esc_html( $name ),
				$qty_int,
				esc_html( _n( 'pc', 'pcs', $qty_int, 'mvweb-price-importer' ) )
			);
		}

		if ( empty( $items ) ) {
			return $html;
		}

		return $html . sprintf(
			'<div class="mvweb-pi-stocks">%s</div>',
			implode( '', $items )
		);
	}

	/**
	 * Display per-warehouse stock levels under order item in admin.
	 *
	 * Hooked to `woocommerce_after_order_itemmeta` (TZ 12.2).
	 *
	 * @since 1.0.0
	 * @param int                    $item_id Order item ID.
	 * @param \WC_Order_Item         $item    Order item object.
	 * @param \WC_Product|false|null $product Product object or false/null.
	 * @return void
	 */
	public function order_item_stocks( int $item_id, $item, $product ): void {
		if ( ! $product instanceof \WC_Product ) {
			return;
		}

		$stocks_json = get_post_meta( $product->get_id(), '_mvweb_pi_stocks', true );
		if ( empty( $stocks_json ) ) {
			return;
		}

		$stocks = json_decode( $stocks_json, true );
		if ( ! is_array( $stocks ) || empty( $stocks ) ) {
			return;
		}

		$warehouses = mvweb_pi_warehouse_directory();

		$parts = array();
		foreach ( $stocks as $wh_id => $qty ) {
			$wh   = $warehouses[ (string) $wh_id ] ?? null;
			$name = $wh && ! empty( $wh['name'] ) ? $wh['name'] : $wh_id;
			$parts[] = sprintf( '%s: %d', esc_html( $name ), absint( $qty ) );
		}

		if ( empty( $parts ) ) {
			return;
		}

		printf(
			'<div class="mvweb-pi-stocks mvweb-pi-stocks--admin"><small>%s: %s</small></div>',
			esc_html__( 'Warehouse stock', 'mvweb-price-importer' ),
			implode( ', ', $parts )
		);
	}

	/**
	 * Enqueue frontend CSS on product and shop pages.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function enqueue_frontend_styles(): void {
		if ( ! is_product() && ! is_shop() && ! is_product_category() && ! is_product_tag() ) {
			return;
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_style(
			'mvweb-pi-frontend',
			MVWEB_PI_URL . 'public/css/frontend' . $suffix . '.css',
			array(),
			MVWEB_PI_VERSION
		);
	}
}
