<?php
/**
 * Feeds class — YML feed generation for Yandex.Market.
 *
 * Generates YML feeds using XMLWriter (streaming, no DOM).
 * Supports general feed and per-warehouse feeds.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Feeds
 *
 * Generates YML feeds for Yandex.Market using XMLWriter for
 * memory-efficient streaming output. Supports a general feed
 * (all products in stock) and per-warehouse feeds.
 *
 * Feed files are stored in wp-content/uploads/pricelists/feeds/
 * which is intentionally public (no .htaccess restriction).
 *
 * @since 1.0.0
 */
class MVweb_PI_Feeds {

	/**
	 * Option key for company name.
	 *
	 * @var string
	 */
	const OPTION_COMPANY = 'mvweb_pi_feeds_company';

	/**
	 * Option key for currency.
	 *
	 * @var string
	 */
	const OPTION_CURRENCY = 'mvweb_pi_feeds_currency';

	/**
	 * Option key for auto-generate after import setting.
	 *
	 * @var string
	 */
	const OPTION_AUTO_GENERATE = 'mvweb_pi_feeds_auto_generate';

	/**
	 * Option key for the feed filename slug (e.g. "poisk123" →
	 * products-feed-poisk123.yml). Empty value falls back to "all"
	 * to preserve legacy file URLs.
	 *
	 * @var string
	 */
	const OPTION_SLUG = 'mvweb_pi_feeds_slug';

	/**
	 * Default slug used when no per-instance slug is set. Matches the
	 * filename the plugin shipped with before slugs became configurable.
	 *
	 * @var string
	 */
	const DEFAULT_SLUG = 'all';

	/**
	 * Option key for the feed category filter list (WooCommerce product_cat
	 * term ids). Numeric ids, distinct from the parser's source-category
	 * option `mvweb_pi_excluded_categories` (external string ids).
	 *
	 * @var string
	 */
	const OPTION_FEED_EXCLUDED_CATEGORIES = 'mvweb_pi_feed_excluded_categories';

	/**
	 * Option key for the feed category filter mode ('exclude' | 'include').
	 *
	 * @var string
	 */
	const OPTION_FEED_CATEGORY_FILTER_MODE = 'mvweb_pi_feed_category_filter_mode';

	/**
	 * Option holding the resumable generation checkpoint.
	 *
	 * Present only while a generation is in flight; deleted the moment the
	 * last feed in the queue is published.
	 *
	 * @since 1.0.27
	 * @var string
	 */
	const OPTION_PROGRESS = 'mvweb_pi_feed_progress';

	/**
	 * Option guarding a resumable generation against a second driver.
	 *
	 * The admin AJAX loop and the scheduled continuation both call
	 * {@see self::step()}. Without the lock they would each build their own
	 * copy of the feed while overwriting each other's checkpoint, and the
	 * half that lost the race would be published as a complete document.
	 *
	 * @since 1.0.27
	 * @var string
	 */
	const LOCK_OPTION = 'mvweb_pi_feed_lock';

	/**
	 * Seconds after which a generation lock is considered abandoned.
	 *
	 * Comfortably longer than any single slice, so a live run never has its
	 * lock stolen, while a slice killed by a fatal frees the queue on its own.
	 *
	 * @since 1.0.27
	 * @var int
	 */
	const LOCK_TTL = 300;

	/**
	 * Products handled per chunk.
	 *
	 * Small enough that a chunk costs well under a second even on shared
	 * hosting, so a wall-clock budget is honoured with fine granularity;
	 * large enough that the per-chunk query overhead stays negligible.
	 *
	 * @since 1.0.27
	 * @var int
	 */
	const CHUNK_SIZE = 250;

	/**
	 * Memoised feed category filter for the current request, or null when no
	 * filter is configured. Shape: array{mode: string, ids: int[], expanded: int[]}.
	 *
	 * @var array{mode: string, ids: int[], expanded: int[]}|null
	 */
	private ?array $feed_cat_filter = null;

	/**
	 * Whether the feed category filter has been resolved this request.
	 *
	 * @var bool
	 */
	private bool $feed_cat_filter_loaded = false;

	/**
	 * Resolve the feed category filter once per request.
	 *
	 * Reads the picked product_cat term ids and mode, then expands the picked
	 * ids with all their descendant terms so a chosen parent covers its whole
	 * branch — mirroring the include_children gating applied at the WP_Query
	 * level. Returns null when nothing is picked, so callers leave the feed
	 * untouched (full backward compatibility).
	 *
	 * @since 1.0.24
	 * @return array{mode: string, ids: int[], expanded: int[]}|null
	 */
	private function get_feed_category_filter(): ?array {
		if ( $this->feed_cat_filter_loaded ) {
			return $this->feed_cat_filter;
		}
		$this->feed_cat_filter_loaded = true;

		$ids = array_values(
			array_unique(
				array_filter(
					array_map( 'absint', (array) get_option( self::OPTION_FEED_EXCLUDED_CATEGORIES, array() ) )
				)
			)
		);
		if ( empty( $ids ) ) {
			$this->feed_cat_filter = null;
			return null;
		}

		$mode = get_option( self::OPTION_FEED_CATEGORY_FILTER_MODE, 'exclude' );
		$mode = ( 'include' === $mode ) ? 'include' : 'exclude';

		$expanded = $ids;
		foreach ( $ids as $id ) {
			$children = get_term_children( $id, 'product_cat' );
			if ( ! is_wp_error( $children ) && ! empty( $children ) ) {
				$expanded = array_merge( $expanded, array_map( 'intval', $children ) );
			}
		}

		$this->feed_cat_filter = array(
			'mode'     => $mode,
			'ids'      => $ids,
			'expanded' => array_values( array_unique( $expanded ) ),
		);
		return $this->feed_cat_filter;
	}

	/**
	 * Build the product_cat tax_query clause for the configured filter.
	 *
	 * Empty when no filter is set. include_children is on so a picked parent
	 * gates its whole branch at the query level.
	 *
	 * @since 1.0.24
	 * @return array<int, array<string, mixed>> tax_query clause, or empty array.
	 */
	private function get_feed_tax_query(): array {
		$filter = $this->get_feed_category_filter();
		if ( null === $filter ) {
			return array();
		}

		return array(
			array(
				'taxonomy'         => 'product_cat',
				'field'            => 'term_id',
				'terms'            => $filter['ids'],
				'operator'         => 'include' === $filter['mode'] ? 'IN' : 'NOT IN',
				'include_children' => true,
			),
		);
	}

	/**
	 * Reduce a product's term ids to only those the feed filter allows.
	 *
	 * The tax_query gates products at the row level. In include mode ("IN") a
	 * kept product may still carry a sibling term outside the pick, so
	 * intersecting here keeps <categories> and <categoryId> in lock-step with
	 * the picked branches and nothing outside the selection leaks in. In exclude
	 * mode ("NOT IN") the query already drops any product carrying a picked
	 * term, so the array_diff is a no-op there — kept only for symmetry.
	 *
	 * @since 1.0.24
	 * @param int[] $term_ids Product's product_cat term ids.
	 * @return int[] Allowed subset (unchanged when no filter is set).
	 */
	private function filter_offer_terms( array $term_ids ): array {
		$filter = $this->get_feed_category_filter();
		if ( null === $filter ) {
			return $term_ids;
		}

		return 'include' === $filter['mode']
			? array_values( array_intersect( $term_ids, $filter['expanded'] ) )
			: array_values( array_diff( $term_ids, $filter['expanded'] ) );
	}

	/**
	 * Get company name for feed.
	 *
	 * @since 1.0.0
	 * @return string Company name.
	 */
	public function get_company(): string {
		return get_option( self::OPTION_COMPANY, get_bloginfo( 'name' ) );
	}

	/**
	 * Get currency for feed.
	 *
	 * @since 1.0.0
	 * @return string Currency code (RUR, USD, EUR).
	 */
	public function get_currency(): string {
		return get_option( self::OPTION_CURRENCY, 'RUR' );
	}

	/**
	 * Get the configured feed slug, falling back to DEFAULT_SLUG.
	 *
	 * Slugs are validated on save to match /^[a-z0-9-]+$/, so the value
	 * stored in the option is always safe for direct filename use.
	 *
	 * @since 1.0.3
	 * @return string Slug, never empty.
	 */
	public function get_slug(): string {
		$slug = (string) get_option( self::OPTION_SLUG, '' );
		return self::sanitize_slug( $slug );
	}

	/**
	 * Normalise a user-supplied slug down to the safe charset and
	 * fall back to DEFAULT_SLUG if nothing usable remains.
	 *
	 * @since 1.0.3
	 * @param string $raw Raw input.
	 * @return string Safe slug — non-empty, matches /^[a-z0-9-]+$/.
	 */
	public static function sanitize_slug( string $raw ): string {
		$slug = strtolower( $raw );
		$slug = preg_replace( '/[^a-z0-9-]+/', '', $slug ) ?? '';
		$slug = trim( $slug, '-' );
		return '' === $slug ? self::DEFAULT_SLUG : $slug;
	}

	/**
	 * Generate all feeds: general + per-warehouse.
	 *
	 * @since 1.0.0
	 * @return array<string, array{file: string, url: string, products: int}> Results keyed by feed slug.
	 */
	public function generate_all(): array {
		$results = array();

		foreach ( $this->build_queue() as $item ) {
			$results[ $this->result_key( $item['slug'], $item['wh_id'] ) ] = $this->generate( $item['slug'], $item['wh_id'] );
		}

		return $results;
	}

	/**
	 * Build the list of feeds a full generation covers.
	 *
	 * The general feed first, then one per configured warehouse. The
	 * warehouse id stays part of the filename so each warehouse feed stays
	 * addressable even when the operator changes the base slug.
	 *
	 * @since 1.0.27
	 * @return array<int, array{slug: string, wh_id: string}> Queue items.
	 */
	private function build_queue(): array {
		$settings   = get_option( 'mvweb_pi_settings', array() );
		$warehouses = $settings['warehouses'] ?? array();
		$base_slug  = $this->get_slug();

		$queue = array(
			array(
				'slug'  => $base_slug,
				'wh_id' => '',
			),
		);

		foreach ( $warehouses as $wh ) {
			$wh_id = (string) ( $wh['id'] ?? '' );
			if ( '' === $wh_id ) {
				continue;
			}
			$queue[] = array(
				'slug'  => $base_slug . '-' . sanitize_title( $wh['feed_name'] ?? $wh['name'] ?? $wh_id ),
				'wh_id' => $wh_id,
			);
		}

		return $queue;
	}

	/**
	 * Key a feed takes in the results array returned to callers.
	 *
	 * Warehouse feeds are keyed by warehouse id, the general feed by its
	 * slug — the shape callers have consumed since 1.0.0.
	 *
	 * @since 1.0.27
	 * @param string $slug  Feed slug.
	 * @param string $wh_id Warehouse id, empty for the general feed.
	 * @return string Result key.
	 */
	private function result_key( string $slug, string $wh_id ): string {
		return '' === $wh_id ? $slug : $wh_id;
	}

	/**
	 * Generate a single YML feed.
	 *
	 * Uses XMLWriter for streaming output directly to file,
	 * avoiding DOM accumulation in memory (TZ 9.3).
	 *
	 * @since 1.0.0
	 * @param string $slug  Feed slug for filename (e.g. 'all', 'moscow').
	 * @param string $wh_id Warehouse ID. Empty string for general feed.
	 * @return array{file: string, url: string, products: int} Generation result.
	 */
	public function generate( string $slug = 'all', string $wh_id = '' ): array {
		$state = $this->begin_feed( $slug, $wh_id );
		$this->advance( $state, 0, null );

		return $this->finish_feed( $state );
	}

	/**
	 * Move a resumable generation forward by one time slice.
	 *
	 * Picks up the checkpoint left by the previous slice (or starts a fresh
	 * queue), works until the wall-clock budget runs out, then persists the
	 * checkpoint and hands control back. Callers keep calling until `done`
	 * comes back true — the admin screen from its AJAX loop, the cron layer
	 * from a scheduled continuation.
	 *
	 * A whole catalogue no longer has to fit in one PHP request: the feed is
	 * built in a `.building` file that only gets published (atomic rename)
	 * once its last offer is written, so a slice dying mid-way costs a retry,
	 * never a truncated feed served live.
	 *
	 * @since 1.0.27
	 * @param int $deadline_ts Unix timestamp to stop at. 0 runs to completion.
	 * @return array{done: bool, results: array<string, array{file: string, url: string, products: int}>, progress: array{slug: string, phase: string, scanned: int, total: int, written: int, feeds_done: int, feeds_total: int}} Slice outcome.
	 */
	public function step( int $deadline_ts = 0 ): array {
		if ( ! $this->acquire_lock() ) {
			// Another driver is already moving this generation along; report
			// where it currently is so the caller can keep watching.
			$held = get_option( self::OPTION_PROGRESS, array() );
			return array(
				'done'     => false,
				'results'  => is_array( $held ) ? ( $held['results'] ?? array() ) : array(),
				'progress' => $this->progress_summary(
					is_array( $held ) ? $held : array(),
					is_array( $held ) && ! empty( $held['state'] ) ? $held['state'] : null
				),
			);
		}

		try {
			return $this->run_slice( $deadline_ts );
		} finally {
			$this->release_lock();
		}
	}

	/**
	 * Body of {@see self::step()}, run under the generation lock.
	 *
	 * @since 1.0.27
	 * @param int $deadline_ts Unix timestamp to stop at. 0 runs to completion.
	 * @return array Slice outcome, shaped as step() documents.
	 */
	private function run_slice( int $deadline_ts ): array {
		$progress = get_option( self::OPTION_PROGRESS, array() );

		// A checkpoint nobody came back for within the hour belongs to a run
		// whose driver is gone (browser tab closed mid-loop, cron continuation
		// never fired). Resuming it would publish a feed built from a catalogue
		// state that no longer holds, so start over instead.
		$stale = ! empty( $progress ) && is_array( $progress )
			&& ( time() - (int) ( $progress['started'] ?? 0 ) ) > HOUR_IN_SECONDS;
		if ( $stale ) {
			// Straight to the cleanup: the lock is already ours, and asking for
			// it again here would be refused by our own hold, leaving the
			// abandoned building file on disk for good.
			$this->discard_progress();
			$progress = array();
		}

		if ( ! is_array( $progress ) || ! isset( $progress['queue'] ) ) {
			$queue    = $this->build_queue();
			$progress = array(
				'queue'   => $queue,
				'state'   => null,
				'results' => array(),
				'planned' => count( $queue ),
				'started' => time(),
			);
		}

		$checkpoint = function ( array $state ) use ( &$progress ): void {
			$progress['state'] = $state;
			update_option( self::OPTION_PROGRESS, $progress, false );
		};

		while ( true ) {
			if ( empty( $progress['state'] ) ) {
				$next = array_shift( $progress['queue'] );
				if ( null === $next ) {
					delete_option( self::OPTION_PROGRESS );
					return array(
						'done'     => true,
						'results'  => $progress['results'],
						'progress' => $this->progress_summary( $progress, null ),
					);
				}
				$progress['state'] = $this->begin_feed( $next['slug'], $next['wh_id'] );
			}

			$state    = $progress['state'];
			$complete = $this->advance( $state, $deadline_ts, $checkpoint );

			$progress['state'] = $state;

			if ( $complete ) {
				$result = $this->finish_feed( $state );
				$progress['results'][ $this->result_key( $state['slug'], $state['wh_id'] ) ] = $result;
				$progress['state'] = null;

				// Record the publication immediately: a process dying between
				// here and the next chunk's checkpoint would otherwise resume
				// on a feed that is already on disk and build it a second time.
				update_option( self::OPTION_PROGRESS, $progress, false );
			}

			if ( $deadline_ts > 0 && time() >= $deadline_ts ) {
				update_option( self::OPTION_PROGRESS, $progress, false );
				return array(
					'done'     => false,
					'results'  => $progress['results'],
					'progress' => $this->progress_summary( $progress, $state ),
				);
			}
		}
	}

	/**
	 * Take the generation lock, stealing it once it looks abandoned.
	 *
	 * Adding the option is an INSERT at MySQL level, so the first caller wins
	 * outright — the same single-shot atomicity the import lock relies on,
	 * down to the conditional UPDATE used to steal a dead holder's row.
	 *
	 * @since 1.0.27
	 * @return bool True when this process may generate.
	 */
	private function acquire_lock(): bool {
		global $wpdb;

		$now = time();

		if ( add_option( self::LOCK_OPTION, (string) $now, '', 'no' ) ) {
			return true;
		}

		$held = (int) get_option( self::LOCK_OPTION, 0 );
		if ( $held > 0 && ( $now - $held ) < self::LOCK_TTL ) {
			return false;
		}

		// Steal the abandoned lock the same way the import lock does it: a plain
		// get_option()+update_option() is a TOCTOU race — two drivers reading the
		// same stale value would both write and both believe they hold the lock,
		// which is exactly the parallel generation this guard exists to prevent.
		// The conditional UPDATE only mutates the row while option_value is still
		// what we read, so MySQL picks a single winner.
		$stolen = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
				(string) $now,
				self::LOCK_OPTION,
				(string) $held
			)
		);

		if ( 1 !== (int) $stolen ) {
			return false;
		}

		// Drop the option out of the alloptions cache so this process and the
		// others read the new value back rather than the one they just lost.
		wp_cache_delete( 'alloptions', 'options' );
		wp_cache_delete( self::LOCK_OPTION, 'options' );

		if ( $held > 0 ) {
			mvweb_pi_log(
				sprintf(
					/* translators: %d: seconds since the abandoned lock was taken */
					__( 'Taking over an abandoned feed generation lock (%d seconds old).', 'mvweb-price-importer' ),
					$now - $held
				),
				'warning'
			);
		}

		return true;
	}

	/**
	 * Release the generation lock.
	 *
	 * @since 1.0.27
	 * @return void
	 */
	private function release_lock(): void {
		delete_option( self::LOCK_OPTION );
	}

	/**
	 * Whether a generation is currently in flight.
	 *
	 * @since 1.0.27
	 * @return bool True when a checkpoint is stored.
	 */
	public function is_running(): bool {
		return ! empty( get_option( self::OPTION_PROGRESS, array() ) );
	}

	/**
	 * Drop the checkpoint and the half-built file it points at.
	 *
	 * Used by the admin screen to start over after a failed run. Takes the
	 * generation lock first: deleting the building file of a slice that is
	 * running right now (the scheduled continuation after an import, while the
	 * operator presses "Generate" in another tab) would leave that slice
	 * appending to a file with no header, and it would publish that as the live
	 * feed. A refusal here is not an error — it means someone else is already
	 * doing the work, and the caller should watch rather than restart.
	 *
	 * @since 1.0.27
	 * @return bool True when the checkpoint was dropped, false when a live run holds it.
	 */
	public function reset_progress(): bool {
		if ( ! $this->acquire_lock() ) {
			return false;
		}

		try {
			$this->discard_progress();
		} finally {
			$this->release_lock();
		}

		return true;
	}

	/**
	 * Throw away the checkpoint and its building file.
	 *
	 * Callers that already hold the generation lock use this directly: the
	 * lock carries no notion of ownership, so a process asking for it a second
	 * time is refused by its own hold, and the cleanup would silently never
	 * happen.
	 *
	 * @since 1.0.27
	 * @return void
	 */
	private function discard_progress(): void {
		$progress = get_option( self::OPTION_PROGRESS, array() );
		$tmp      = $progress['state']['tmp'] ?? '';

		if ( '' !== $tmp && file_exists( $tmp ) ) {
			wp_delete_file( $tmp );
		}

		delete_option( self::OPTION_PROGRESS );
	}

	/**
	 * Summarise the checkpoint for the progress bar on screen.
	 *
	 * @since 1.0.27
	 * @param array      $progress Whole checkpoint.
	 * @param array|null $state    Feed currently being built, if any.
	 * @return array{slug: string, phase: string, scanned: int, total: int, written: int, feeds_done: int, feeds_total: int} Summary.
	 */
	private function progress_summary( array $progress, ?array $state ): array {
		return array(
			'slug'        => (string) ( $state['slug'] ?? '' ),
			'phase'       => (string) ( $state['phase'] ?? 'offers' ),
			'scanned'     => (int) ( $state['scanned'] ?? 0 ),
			'total'       => (int) ( $state['total'] ?? 0 ),
			'written'     => (int) ( $state['written'] ?? 0 ),
			'feeds_done'  => count( $progress['results'] ?? array() ),
			'feeds_total' => (int) ( $progress['planned'] ?? count( $progress['results'] ?? array() ) ),
		);
	}

	/**
	 * Open a feed: reserve its building file and prepare the checkpoint.
	 *
	 * Nothing is written yet — the header can only be composed once the
	 * category pass knows which branches carry products.
	 *
	 * @since 1.0.27
	 * @param string $slug  Feed slug for the filename.
	 * @param string $wh_id Warehouse id. Empty for the general feed.
	 * @return array Checkpoint for the new feed.
	 */
	private function begin_feed( string $slug, string $wh_id ): array {
		$feeds_dir = mvweb_pi_get_feeds_dir();

		// Ensure feeds directory exists and is world-readable so that the
		// generated YML feed can actually be served by the web server.
		// Hosts with restrictive umasks (e.g. Beget VDS with extended ACLs)
		// otherwise create 0700/0600 entries that nginx returns 403 for.
		wp_mkdir_p( $feeds_dir );
		@chmod( $feeds_dir, 0755 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		$file_path = $feeds_dir . "products-feed-{$slug}.yml";

		// Build into a separate file and publish it with an atomic rename, so
		// the live feed is only ever the previous complete document or the new
		// complete one — never a run that died half-way. The PID keeps two
		// generators (auto-run after import vs. the admin button) out of each
		// other's file; the last one to finish wins with a whole document.
		$tmp_path = $file_path . '.' . getmypid() . '.building';
		if ( file_exists( $tmp_path ) ) {
			wp_delete_file( $tmp_path );
		}

		return array(
			'slug'     => $slug,
			'wh_id'    => $wh_id,
			'file'     => $file_path,
			'tmp'      => $tmp_path,
			'phase'    => 'collect',
			'after_id' => 0,
			'keep'     => array(),
			'scanned'  => 0,
			'written'  => 0,
			'total'    => $this->count_candidates(),
			'bytes'    => 0,
		);
	}

	/**
	 * Work the current feed until it is finished or the budget expires.
	 *
	 * @since 1.0.27
	 * @param array         $state       Checkpoint, updated in place.
	 * @param int           $deadline_ts Unix timestamp to stop at, 0 for no limit.
	 * @param callable|null $checkpoint  Called with the state after every chunk.
	 * @return bool True when the feed is fully written and ready to publish.
	 */
	private function advance( array &$state, int $deadline_ts, ?callable $checkpoint ): bool {
		$this->rewind_to_checkpoint( $state );

		while ( true ) {
			if ( 'collect' === $state['phase'] ) {
				if ( $this->collect_chunk( $state ) ) {
					$this->write_header( $state );
					$state['phase']    = 'offers';
					$state['after_id'] = 0;
					$state['scanned']  = 0;
				}
			} elseif ( $this->offers_chunk( $state ) ) {
				return true;
			}

			// Drop the in-process cache the chunk just primed. Without this every
			// post, meta row and term the run touched stays in a PHP array until
			// the process ends — the reason a 14 000-product catalogue used to
			// peak above 300 MB and die on a 256 MB limit. Deliberately the
			// runtime flush and not wp_cache_flush(): on a site with Redis or
			// Memcached the latter would wipe the shared cache for every visitor,
			// dozens of times over a single generation.
			wp_cache_flush_runtime();

			if ( null !== $checkpoint ) {
				$checkpoint( $state );
			}

			if ( $deadline_ts > 0 && time() >= $deadline_ts ) {
				return false;
			}
		}
	}

	/**
	 * Publish the finished feed and report the result.
	 *
	 * @since 1.0.27
	 * @param array $state Checkpoint of a fully written feed.
	 * @return array{file: string, url: string, products: int} Generation result.
	 */
	private function finish_feed( array $state ): array {
		$url = mvweb_pi_get_feeds_url() . basename( $state['file'] );

		$this->append( $state, "    </offers>\n  </shop>\n</yml_catalog>\n" );

		// World-readable BEFORE the rename, so the public path is correct the
		// instant it appears: file writes honour umask, which on some hosts
		// produces 0600 and locks nginx out.
		@chmod( $state['tmp'], 0644 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		if ( ! @rename( $state['tmp'], $state['file'] ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			if ( file_exists( $state['tmp'] ) ) {
				wp_delete_file( $state['tmp'] );
			}
			mvweb_pi_log(
				sprintf(
					/* translators: %s: feed slug */
					__( 'Feed "%s" generation failed: could not publish the temp file.', 'mvweb-price-importer' ),
					$state['slug']
				),
				'error'
			);
			return array(
				'file'     => $state['file'],
				'url'      => $url,
				'products' => 0,
			);
		}

		mvweb_pi_log(
			sprintf(
				/* translators: 1: feed slug, 2: product count */
				__( 'Feed "%1$s" generated: %2$d products.', 'mvweb-price-importer' ),
				$state['slug'],
				$state['written']
			),
			'info'
		);

		return array(
			'file'     => $state['file'],
			'url'      => $url,
			'products' => (int) $state['written'],
		);
	}

	/**
	 * Append a fragment to the building file and record the new length.
	 *
	 * The recorded length is what makes a resumed run safe: see
	 * {@see self::rewind_to_checkpoint()}.
	 *
	 * @since 1.0.27
	 * @param array  $state    Checkpoint, updated in place.
	 * @param string $fragment XML fragment to append.
	 * @return void
	 * @throws RuntimeException When the fragment could not be written in full.
	 */
	private function append( array &$state, string $fragment ): void {
		if ( '' === $fragment ) {
			return;
		}

		$written = file_put_contents( $state['tmp'], $fragment, FILE_APPEND ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

		// A failed or short write must abort the run: swallowing it would carry
		// on to finish_feed(), cap a document with a hole in it and publish that
		// over the last good feed. Disk full and a directory that lost its write
		// permission both land here.
		if ( false === $written || strlen( $fragment ) !== $written ) {
			throw new RuntimeException(
				sprintf(
					/* translators: %s: feed file path */
					__( 'Could not write the feed being built: %s', 'mvweb-price-importer' ),
					$state['tmp']
				)
			);
		}

		clearstatcache( true, $state['tmp'] );
		$state['bytes'] = (int) filesize( $state['tmp'] );
	}

	/**
	 * Cut the building file back to the last acknowledged chunk.
	 *
	 * A slice that dies between appending a chunk and saving its checkpoint
	 * leaves offers in the file that the checkpoint does not know about; the
	 * resumed run would write them a second time. Truncating to the recorded
	 * length makes a resume exact rather than merely likely.
	 *
	 * @since 1.0.27
	 * @param array $state Checkpoint.
	 * @return void
	 */
	private function rewind_to_checkpoint( array $state ): void {
		if ( ! file_exists( $state['tmp'] ) ) {
			return;
		}

		clearstatcache( true, $state['tmp'] );
		if ( (int) filesize( $state['tmp'] ) <= (int) $state['bytes'] ) {
			return;
		}

		$handle = fopen( $state['tmp'], 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		if ( ! $handle ) {
			return;
		}
		ftruncate( $handle, (int) $state['bytes'] );
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
	}

	/**
	 * Write everything that precedes the offers: shop details and categories.
	 *
	 * `<shop>` and `<yml_catalog>` are deliberately left open — XMLWriter
	 * hands back the text it has generated so far, and the closing tags are
	 * appended by {@see self::finish_feed()} once the offers are in.
	 *
	 * @since 1.0.27
	 * @param array $state Checkpoint, updated in place.
	 * @return void
	 */
	private function write_header( array &$state ): void {
		$company = $this->get_company();

		$writer = new XMLWriter();
		$writer->openMemory();
		$writer->setIndent( true );
		$writer->setIndentString( '  ' );
		$writer->startDocument( '1.0', 'UTF-8' );

		$writer->startElement( 'yml_catalog' );
		$writer->writeAttribute( 'date', wp_date( 'Y-m-d H:i' ) );

		$writer->startElement( 'shop' );
		$writer->writeElement( 'name', $company );
		$writer->writeElement( 'company', $company );
		$writer->writeElement( 'url', home_url( '/' ) );

		$writer->startElement( 'currencies' );
		$writer->startElement( 'currency' );
		$writer->writeAttribute( 'id', $this->get_currency() );
		$writer->writeAttribute( 'rate', '1' );
		$writer->endElement(); // currency.
		$writer->endElement(); // currencies.

		$this->write_categories( $writer, $state['keep'] );

		$this->append( $state, $writer->outputMemory() . "\n    <offers>\n" );
	}

	/**
	 * Count the products a feed will walk, for the progress bar.
	 *
	 * Warehouse stock and the price gate are applied per product later, so
	 * this is the number of candidates scanned rather than of offers written.
	 *
	 * @since 1.0.27
	 * @return int Candidate count.
	 */
	private function count_candidates(): int {
		$query = new WP_Query( array_merge( $this->candidate_args( 1 ), array( 'no_found_rows' => false ) ) );

		return (int) $query->found_posts;
	}

	/**
	 * Shared WP_Query arguments for the products a feed considers.
	 *
	 * Ordering by ID is not cosmetic: the previous OFFSET pagination ordered
	 * by post_date, and a catalogue imported in one go shares that date down
	 * to the second, so MySQL was free to return rows in a different order per
	 * page — products were silently written twice while others never made it
	 * into the feed at all. An ID cursor also survives the catalogue changing
	 * between two chunks of a resumed run.
	 *
	 * @since 1.0.27
	 * @param int $limit Products per query.
	 * @return array<string, mixed> Query arguments.
	 */
	private function candidate_args( int $limit ): array {
		return array(
			'post_type'              => 'product',
			'post_status'            => 'publish',
			'posts_per_page'         => $limit,
			'orderby'                => 'ID',
			'order'                  => 'ASC',
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'ignore_sticky_posts'    => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				array(
					'key'     => '_stock',
					'value'   => '0',
					'compare' => '>',
					'type'    => 'NUMERIC',
				),
			),
			// Variable and grouped products were filtered out in PHP before;
			// doing it in the query means their rows are never fetched.
			'tax_query'              => array_merge( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				array(
					array(
						'taxonomy' => 'product_type',
						'field'    => 'slug',
						'terms'    => 'simple',
					),
				),
				$this->get_feed_tax_query()
			),
		);
	}

	/**
	 * Fetch the next page of product ids after the cursor.
	 *
	 * @since 1.0.27
	 * @param int $after_id Last id handled; 0 starts from the beginning.
	 * @param int $limit    Page size.
	 * @return int[] Product ids in ascending order.
	 */
	private function next_product_ids( int $after_id, int $limit ): array {
		$cursor = static function ( $where ) use ( $after_id ) {
			global $wpdb;
			return $where . $wpdb->prepare( " AND {$wpdb->posts}.ID > %d", $after_id );
		};

		add_filter( 'posts_where', $cursor );
		$query = new WP_Query( $this->candidate_args( $limit ) );
		remove_filter( 'posts_where', $cursor );

		return array_map( 'intval', $query->posts );
	}

	/**
	 * Collect the categories of one chunk of products.
	 *
	 * Reading terms and meta straight out of a primed cache instead of
	 * building a WC_Product per row is what took this pass from 58 700
	 * queries to a few hundred on a 14 000-product catalogue.
	 *
	 * @since 1.0.27
	 * @param array $state Checkpoint, updated in place.
	 * @return bool True when no products are left to scan.
	 */
	private function collect_chunk( array &$state ): bool {
		$ids = $this->next_product_ids( (int) $state['after_id'], self::CHUNK_SIZE );
		if ( empty( $ids ) ) {
			return true;
		}

		$state['after_id'] = (int) end( $ids );
		$state['scanned'] += count( $ids );

		_prime_post_caches( $ids, true, true );
		$parent = $this->get_parent_lookup();

		foreach ( $ids as $product_id ) {
			// Mirror write_single_offer() exactly: a product only contributes
			// its categories if it actually ships in this feed — warehouse
			// stock and a usable price both apply.
			if ( '' !== $state['wh_id'] && $this->warehouse_stock( $product_id, $state['wh_id'] ) <= 0 ) {
				continue;
			}

			if ( ! $this->has_price( $product_id ) ) {
				continue;
			}

			$terms = get_the_terms( $product_id, 'product_cat' );
			if ( ! $terms || is_wp_error( $terms ) ) {
				continue;
			}

			// Keep only the picked branches so <categories> never carries a
			// sibling term the filter left out (see filter_offer_terms).
			foreach ( $this->filter_offer_terms( wp_list_pluck( $terms, 'term_id' ) ) as $term_id ) {
				// Add the category and walk up its parent chain so the tree
				// stays connected. Stop at the first id already kept — its
				// ancestors are guaranteed present from a previous walk.
				$term_id = (int) $term_id;
				$depth   = 0;
				while ( $term_id > 0 && ! isset( $state['keep'][ $term_id ] ) && $depth < 64 ) {
					$state['keep'][ $term_id ] = true;
					$term_id                   = (int) ( $parent[ $term_id ] ?? 0 );
					++$depth;
				}
			}
		}

		return false;
	}

	/**
	 * Write the offers of one chunk of products.
	 *
	 * @since 1.0.27
	 * @param array $state Checkpoint, updated in place.
	 * @return bool True when no products are left to write.
	 */
	private function offers_chunk( array &$state ): bool {
		$ids = $this->next_product_ids( (int) $state['after_id'], self::CHUNK_SIZE );
		if ( empty( $ids ) ) {
			return true;
		}

		$state['after_id'] = (int) end( $ids );
		$state['scanned'] += count( $ids );

		_prime_post_caches( $ids, true, true );

		$currency = $this->get_currency();
		$writer   = new XMLWriter();
		$writer->openMemory();
		$writer->setIndent( true );
		$writer->setIndentString( '  ' );

		foreach ( $ids as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}

			if ( '' !== $state['wh_id'] ) {
				$stock_count = $this->warehouse_stock( $product_id, $state['wh_id'] );
				if ( $stock_count <= 0 ) {
					continue;
				}
			} else {
				$stock_count = (int) $product->get_stock_quantity();
			}

			// Resolve the category against the tree already committed to the
			// file. The two passes can be minutes apart on a resumed run, so a
			// product recategorised in between would otherwise emit a
			// categoryId that <categories> never declared — a feed an
			// aggregator rejects. Products whose categories the tree does not
			// carry keep shipping without the element, exactly as before.
			$category_id = $this->offer_category_id( $product_id, $state['keep'] );

			if ( $this->write_single_offer( $writer, $product, $currency, $stock_count, $category_id ) ) {
				++$state['written'];
			}
		}

		$this->append( $state, $writer->outputMemory() );

		return false;
	}

	/**
	 * Category a product's offer may reference in this feed.
	 *
	 * Only terms that survived the feed filter AND made it into the written
	 * category tree qualify, which is what keeps <categoryId> and <categories>
	 * in lock-step no matter how far apart the two passes ran.
	 *
	 * @since 1.0.27
	 * @param int              $product_id Product id.
	 * @param array<int, true> $keep       Term ids present in <categories>.
	 * @return int Term id to reference, 0 when the product has none.
	 */
	private function offer_category_id( int $product_id, array $keep ): int {
		$terms = get_the_terms( $product_id, 'product_cat' );
		if ( ! $terms || is_wp_error( $terms ) ) {
			return 0;
		}

		foreach ( $this->filter_offer_terms( wp_list_pluck( $terms, 'term_id' ) ) as $term_id ) {
			if ( isset( $keep[ (int) $term_id ] ) ) {
				return (int) $term_id;
			}
		}

		return 0;
	}

	/**
	 * Stock a product carries on one warehouse.
	 *
	 * @since 1.0.27
	 * @param int    $product_id Product id.
	 * @param string $wh_id      Warehouse id.
	 * @return int Stock quantity, 0 when the warehouse holds none.
	 */
	private function warehouse_stock( int $product_id, string $wh_id ): int {
		$stocks_json = get_post_meta( $product_id, '_mvweb_pi_stocks', true );
		$stocks      = ! empty( $stocks_json ) ? json_decode( $stocks_json, true ) : array();

		return (int) ( $stocks[ $wh_id ] ?? 0 );
	}

	/**
	 * Whether a product has a usable price for the feed.
	 *
	 * Matches the price gate in write_single_offer(): a regular or sale price
	 * greater than zero. Read from the primed meta cache rather than through a
	 * WC_Product, which for a simple product is the same two rows.
	 *
	 * @since 1.0.9
	 * @param int $product_id Product id.
	 * @return bool True if the product would be written to the feed.
	 */
	private function has_price( int $product_id ): bool {
		// A product without a retail price stays out of the feed even when a
		// sale price set by hand is still stored on it: that price is not what
		// the shop charges for it.
		if ( '1' === (string) get_post_meta( $product_id, '_mvweb_pi_no_retail', true ) ) {
			return false;
		}

		$regular = (float) get_post_meta( $product_id, '_regular_price', true );
		$sale    = (float) get_post_meta( $product_id, '_sale_price', true );

		return $sale > 0 || $regular > 0;
	}

	/**
	 * Write the collected categories to YML.
	 *
	 * Only categories that carry products in this feed are emitted, plus every
	 * parent on the way up to the root, so the tree stays connected (a child
	 * category can't reference a parentId that isn't in the feed). Empty
	 * branches are dropped entirely.
	 *
	 * @since 1.0.0
	 * @param XMLWriter        $writer XMLWriter instance.
	 * @param array<int, true> $keep   Term ids gathered by the category pass.
	 * @return void
	 */
	private function write_categories( XMLWriter $writer, array $keep ): void {
		$writer->startElement( 'categories' );

		// Ids missing from the DB (shouldn't happen, but a stale term cache
		// could) are skipped via the get_term guard.
		foreach ( array_keys( $keep ) as $term_id ) {
			$term = get_term( (int) $term_id, 'product_cat' );
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}

			$writer->startElement( 'category' );
			$writer->writeAttribute( 'id', (string) $term->term_id );

			// Only emit parentId when the parent is itself in the feed, so we
			// never point at a category we dropped as empty.
			if ( $term->parent > 0 && isset( $keep[ $term->parent ] ) ) {
				$writer->writeAttribute( 'parentId', (string) $term->parent );
			}

			$writer->text( $this->xml_text( $term->name ) );
			$writer->endElement(); // category.
		}

		$writer->endElement(); // categories.
	}

	/**
	 * Build a term_id => parent_id lookup for product_cat in one query.
	 *
	 * Rebuilt per chunk rather than memoised on the instance: the object cache
	 * is flushed between chunks to keep memory flat, and one term query per
	 * chunk costs nothing next to what that flush saves.
	 *
	 * @since 1.0.9
	 * @return array<int, int> Map of term id to its parent id.
	 */
	private function get_parent_lookup(): array {
		$lookup = array();
		$terms  = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) ) {
			return $lookup;
		}

		foreach ( $terms as $term ) {
			$lookup[ (int) $term->term_id ] = (int) $term->parent;
		}

		return $lookup;
	}

	/**
	 * Write a single offer element.
	 *
	 * XMLWriter automatically escapes special characters (&, <, >, ")
	 * in text content (TZ 9.3).
	 *
	 * @since 1.0.0
	 * @param XMLWriter   $writer      XMLWriter instance.
	 * @param WC_Product  $product     WooCommerce product.
	 * @param string      $currency    Currency code.
	 * @param int         $stock_count Stock quantity for this feed context
	 *                                 (total for general feed, warehouse-specific otherwise).
	 * @param int         $category_id Category to reference, already checked against
	 *                                 the tree written into <categories>. 0 omits it.
	 * @return bool True if the offer was written, false if it was skipped
	 *              (e.g. no usable price).
	 */
	private function write_single_offer( XMLWriter $writer, WC_Product $product, string $currency, int $stock_count = 0, int $category_id = 0 ): bool {
		$regular_price = $product->get_regular_price();
		$sale_price    = $product->get_sale_price();
		$has_sale      = ( '' !== $sale_price && (float) $sale_price > 0 );
		$effective     = $has_sale ? (float) $sale_price : (float) $regular_price;

		// A price-less offer is invalid in YML — Yandex.Market rejects an
		// empty/zero <price>, and a single bad offer can get the whole feed
		// bounced. Skip the offer entirely rather than emit <price></price>.
		if ( $effective <= 0 || '1' === (string) get_post_meta( $product->get_id(), '_mvweb_pi_no_retail', true ) ) {
			return false;
		}

		$writer->startElement( 'offer' );
		$writer->writeAttribute( 'id', (string) $product->get_id() );
		// Reflect the real WooCommerce stock status instead of hard-coding
		// "true": a product kept in catalogue but manually set out of stock
		// must not advertise availability to aggregators.
		$writer->writeAttribute( 'available', $product->is_in_stock() ? 'true' : 'false' );

		// URL.
		$writer->writeElement( 'url', get_permalink( $product->get_id() ) );

		// Price.
		if ( $has_sale ) {
			$writer->writeElement( 'price', $sale_price );
			if ( '' !== $regular_price && (float) $regular_price > 0 ) {
				$writer->writeElement( 'oldprice', $regular_price );
			}
		} else {
			$writer->writeElement( 'price', $regular_price );
		}

		// Wholesale price — custom element mirroring how <barcode> carries the
		// plugin's own `_mvweb_pi_*` meta into the feed. Emitted only when set,
		// and kept out of <price>/<oldprice> so it never changes the price an
		// aggregator or storefront shows. Re-importing this feed reads it back
		// via the generic tag capture in the YML parser, so the field round-trips.
		$wholesale = get_post_meta( $product->get_id(), '_mvweb_pi_wholesale_price', true );
		if ( '' !== (string) $wholesale && (float) $wholesale > 0 ) {
			$writer->writeElement( 'wholesale', (string) $wholesale );
		}

		// Dealer price — same contract as <wholesale> above. The element name
		// matches the one suppliers use in the wild, which is also the first
		// keyword auto-detect looks for, so a generated feed re-imports into the
		// dealer field without the operator mapping it by hand.
		$dealer = get_post_meta( $product->get_id(), '_mvweb_pi_dealer_price', true );
		if ( '' !== (string) $dealer && (float) $dealer > 0 ) {
			$writer->writeElement( 'pricedealer', (string) $dealer );
		}

		// Currency.
		$writer->writeElement( 'currencyId', $currency );

		if ( $stock_count > 0 ) {
			$writer->writeElement( 'count', (string) $stock_count );
		}

		// Category. The caller resolves it against the tree already written into
		// <categories>, so the emitted categoryId can never point at a category
		// this feed does not carry.
		if ( $category_id > 0 ) {
			$writer->writeElement( 'categoryId', (string) $category_id );
		}

		// Picture.
		$image_id = $product->get_image_id();
		if ( $image_id ) {
			$image_url = wp_get_attachment_url( $image_id );
			if ( $image_url ) {
				$writer->writeElement( 'picture', $image_url );
			}
		}

		// Gallery images.
		$gallery_ids = $product->get_gallery_image_ids();
		foreach ( $gallery_ids as $gallery_id ) {
			$gallery_url = wp_get_attachment_url( $gallery_id );
			if ( $gallery_url ) {
				$writer->writeElement( 'picture', $gallery_url );
			}
		}

		// Name.
		$writer->writeElement( 'name', $this->xml_text( $product->get_name() ) );

		// Description.
		$description = $product->get_description();
		if ( ! empty( $description ) ) {
			// Strip HTML tags for YML compatibility.
			$writer->writeElement( 'description', $this->xml_text( wp_strip_all_tags( $description ) ) );
		}

		// Barcode.
		$barcode = get_post_meta( $product->get_id(), '_mvweb_pi_barcode', true );
		if ( ! empty( $barcode ) ) {
			$writer->writeElement( 'barcode', $barcode );
		}

		$writer->endElement(); // offer.

		return true;
	}

	/**
	 * Decode stored HTML entities before handing text to XMLWriter.
	 *
	 * WordPress stores term names and post titles with entity-encoded
	 * specials (an ampersand is saved as &amp; in wp_terms / wp_posts). If we
	 * passed that raw string to XMLWriter it would escape the ampersand a
	 * second time and emit &amp;amp;, so an aggregator shows "Phones &amp;
	 * Tablets". Decode the entities back to real characters first; XMLWriter
	 * then escapes them exactly once and the feed reads correctly.
	 *
	 * @since 1.0.9
	 * @param string $text Raw text from the DB (possibly entity-encoded).
	 * @return string Decoded text safe to pass to XMLWriter.
	 */
	private function xml_text( string $text ): string {
		return html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	}

	/**
	 * Get list of existing feed files with metadata.
	 *
	 * Scans the feeds directory for YML files and returns
	 * info about each: slug, URL, last modified, product count.
	 *
	 * @since 1.0.0
	 * @return array<int, array{slug: string, url: string, file: string, modified: int, size: string}> Feed list.
	 */
	public function get_feed_list(): array {
		$feeds_dir = mvweb_pi_get_feeds_dir();
		$feeds_url = mvweb_pi_get_feeds_url();
		$feeds     = array();

		$files = glob( $feeds_dir . 'products-feed-*.yml' );
		if ( empty( $files ) ) {
			return $feeds;
		}

		foreach ( $files as $file ) {
			$basename = basename( $file );

			// Extract slug from filename: products-feed-{slug}.yml
			if ( ! preg_match( '/^products-feed-(.+)\.yml$/', $basename, $matches ) ) {
				continue;
			}

			$slug     = $matches[1];
			$modified = filemtime( $file );
			$size     = filesize( $file );

			// Count offers in the feed (quick scan).
			$product_count = $this->count_offers_in_file( $file );

			$feeds[] = array(
				'slug'     => $slug,
				'url'      => $feeds_url . $basename,
				'file'     => $file,
				'modified' => $modified,
				'size'     => size_format( $size ),
				'products' => $product_count,
			);
		}

		return $feeds;
	}

	/**
	 * Count <offer> elements in a YML file.
	 *
	 * Uses a lightweight regex scan instead of full XML parsing
	 * for performance on large files.
	 *
	 * @since 1.0.0
	 * @param string $file_path Absolute path to YML file.
	 * @return int Number of offers found.
	 */
	private function count_offers_in_file( string $file_path ): int {
		if ( ! file_exists( $file_path ) ) {
			return 0;
		}

		$count  = 0;
		$handle = fopen( $file_path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( ! $handle ) {
			return 0;
		}

		while ( ( $line = fgets( $handle ) ) !== false ) {
			if ( str_contains( $line, '<offer ' ) ) {
				++$count;
			}
		}

		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		return $count;
	}

	/**
	 * Delete a single generated feed file by its slug.
	 *
	 * The slug comes from user input via AJAX, so we re-validate it
	 * against the same charset the save flow enforces — guarding the
	 * filesystem against path traversal even if a future caller skips
	 * an earlier sanitization step.
	 *
	 * @since 1.0.3
	 * @param string $slug Feed slug (e.g. "all", "poisk123-moscow").
	 * @return bool True if the file existed and was deleted.
	 */
	public function delete( string $slug ): bool {
		if ( ! preg_match( '/^[a-z0-9-]+$/', $slug ) ) {
			return false;
		}

		$file = mvweb_pi_get_feeds_dir() . 'products-feed-' . $slug . '.yml';
		if ( ! file_exists( $file ) ) {
			return false;
		}

		wp_delete_file( $file );
		return ! file_exists( $file );
	}

	/**
	 * Delete all generated feed files.
	 *
	 * @since 1.0.0
	 * @return int Number of files deleted.
	 */
	public function delete_all(): int {
		$feeds_dir = mvweb_pi_get_feeds_dir();
		$files     = glob( $feeds_dir . 'products-feed-*.yml' );
		$count     = 0;

		if ( ! empty( $files ) ) {
			foreach ( $files as $file ) {
				if ( wp_delete_file( $file ) !== false ) {
					++$count;
				}
			}
		}

		return $count;
	}
}
