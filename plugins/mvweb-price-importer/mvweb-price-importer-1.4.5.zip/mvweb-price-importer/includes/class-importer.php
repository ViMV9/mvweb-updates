<?php
/**
 * Importer class — WooCommerce product import.
 *
 * Creates/updates simple products, manages stock,
 * handles images, and detects missing products.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Importer
 *
 * Imports products into WooCommerce from a generator pipeline.
 * Supports batch processing, image handling, gallery import,
 * and detection of missing (removed) products.
 *
 * @since 1.0.0
 */
class MVweb_PI_Importer {

	/**
	 * Import statistics.
	 *
	 * @since 1.0.0
	 * @var array{created: int, updated: int, skipped: int, errors: int, touched_ids: int[], variations_created: int, variations_updated: int, variations_disabled: int}
	 */
	private array $stats = array(
		'created'             => 0,
		'updated'             => 0,
		'skipped'             => 0,
		'errors'              => 0,
		'touched_ids'         => array(),
		'variations_created'  => 0,
		'variations_updated'  => 0,
		'variations_disabled' => 0,
	);

	/**
	 * Mark on a variation the import disabled because MoySklad dropped its variant.
	 *
	 * @since 1.3.0
	 * @var string
	 */
	const DISABLED_META = '_mvweb_pi_disabled';

	/**
	 * Category map: external_id => WooCommerce term_id.
	 *
	 * Loaded once from mvweb_pi_category_map option,
	 * populated by MVweb_PI_Categories during import.
	 *
	 * @since 1.0.0
	 * @var array<string, int>|null
	 */
	private ?array $category_map = null;

	/**
	 * Product tag rules, keyed by rule key.
	 *
	 * Mirrors what the Converter resolved into each product's `tags` array:
	 * the Converter decides yes/no, this class needs the rule's label to
	 * create the term the first time it is needed.
	 *
	 * @since 1.0.27
	 * @var array<string, array>|null
	 */
	private ?array $tag_rules = null;

	/**
	 * Tag map: rule key => WooCommerce product_tag term_id.
	 *
	 * Kept as a property because the import flushes the object cache between
	 * batches, and re-read lazily on each run because every cron continuation
	 * builds a fresh instance.
	 *
	 * @since 1.0.27
	 * @var array<string, int>|null
	 */
	private ?array $tag_map = null;

	/**
	 * Rule keys whose term was already validated in this run.
	 *
	 * Validation goes through term_exists(), which is an uncached query, so
	 * checking a mapped term on every product would cost one query per rule
	 * per product — 3 rules across a 14k-offer catalogue is ~44k queries for
	 * an answer that cannot change mid-run. Once per rule per run is enough.
	 *
	 * @since 1.0.27
	 * @var array<string, true>
	 */
	private array $tag_verified = array();

	/**
	 * Rule keys known to have no term yet, for this run.
	 *
	 * A rule whose flag reads "no" must not bring its tag into existence — a
	 * tag nobody wears has no reason to appear in the catalogue. Remembering
	 * the miss keeps that from costing a term lookup on every single product.
	 *
	 * @since 1.0.27
	 * @var array<string, true>
	 */
	private array $tag_missing = array();

	/**
	 * Attribute term IDs resolved in this run, by taxonomy and lowercased name.
	 *
	 * @since 1.3.0
	 * @var array<string, int>
	 */
	private array $attribute_terms = array();

	/**
	 * Attribute taxonomies already reported missing in this run.
	 *
	 * @since 1.3.0
	 * @var array<string, true>
	 */
	private array $attribute_missing = array();

	/**
	 * Variations without a MoySklad id, by product, counted in this batch.
	 *
	 * @since 1.3.0
	 * @var array<int, int>
	 */
	private array $handmade_variations = array();

	/**
	 * Progress option name for checkpoint/resume.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const PROGRESS_OPTION = 'mvweb_pi_import_progress';

	/**
	 * Maximum age (in seconds) for a progress record to be considered resumable.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const PROGRESS_TTL = 3600;

	/**
	 * Image-import policies (settings.image_mode).
	 *
	 * - `smart`    — download images on create, and on update refresh only
	 *                the items whose source URL changed (relies on
	 *                handle_image/handle_gallery's URL-equality short-circuit).
	 *                Default. Covers the common supplier case: photos change
	 *                occasionally, but for most rows the URL is stable.
	 * - `always`   — download/refresh images on every create AND update
	 *                (the original behaviour; safest but slowest).
	 * - `new_only` — download images only when the product is newly created.
	 *                Updates leave existing images alone, even if the source
	 *                URL changed. Useful for catalogs whose suppliers reissue
	 *                URLs on every export without changing the actual image.
	 * - `never`    — never download images at all (textual catalogs).
	 *
	 * @since 1.0.0
	 */
	private const IMAGE_MODE_SMART    = 'smart';
	private const IMAGE_MODE_ALWAYS   = 'always';
	private const IMAGE_MODE_NEW_ONLY = 'new_only';
	private const IMAGE_MODE_NEVER    = 'never';

	/**
	 * Cached image-import policy for the current run.
	 *
	 * @since 1.0.0
	 * @var string|null
	 */
	private ?string $image_mode = null;

	/**
	 * Units already promised to open orders, rebuilt once per batch.
	 *
	 * @since 1.1.0
	 * @var MVweb_PI_Reserved_Stock|null
	 */
	private ?MVweb_PI_Reserved_Stock $reserved = null;

	/**
	 * Products whose stock the price list could not cover, SKU => shortfall.
	 *
	 * @since 1.1.0
	 * @var array<string, int>
	 */
	private array $reserve_short = array();

	/**
	 * How many products had their stock reduced by what orders hold.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	private int $reserve_applied = 0;

	/**
	 * Mode for products without a retail price, read once per run.
	 *
	 * @since 1.4.0
	 * @var string|null
	 */
	private ?string $no_retail_mode = null;

	/**
	 * Run the import process.
	 *
	 * Accepts a generator of normalized product data and processes
	 * them in batches. After all products are processed, zeroes out
	 * stock for products missing from the new price list.
	 *
	 * Supports checkpoint/resume: saves progress after each batch.
	 * On resume, skips already-processed products via $skip_count.
	 *
	 * @since 1.0.0
	 * @since 1.1.0 Added $skip_count and $resume_skus parameters for checkpoint/resume.
	 * @since 1.0.0 Added $deadline_ts for cooperative wall-clock budgeting —
	 *              the cron layer uses it to chop long imports into
	 *              short-lived wp_schedule_single_event chunks on web/AJAX.
	 * @param \Generator $products    Generator yielding normalized product arrays.
	 * @param int        $skip_count  Number of products to skip (for resume after crash).
	 * @param string[]   $resume_skus SKUs already collected before crash (for zero_missing_stock).
	 * @param int        $deadline_ts Unix timestamp at which to stop and persist
	 *                                progress; 0 means "no limit, run to completion".
	 * @return array Import statistics, augmented with `incomplete` => bool when
	 *               the deadline was hit before the generator drained.
	 */
	public function run( \Generator $products, int $skip_count = 0, array $resume_skus = array(), int $deadline_ts = 0 ): array {
		// Raise PHP memory ceiling for the duration of the import. Imagick
		// keeps a large RSS while resizing big supplier photos, and Beget's
		// default 256M cgroup limit was killing long CLI runs with SIGBUS
		// somewhere mid-catalog. The legacy importer (mvweb-price-converter)
		// did the same and ran cleanly on the same host. Filterable so an
		// operator with a stricter host can pin a lower value.
		$memory_limit = apply_filters( 'mvweb_pi_import_memory_limit', '512M' );
		if ( $memory_limit ) {
			@ini_set( 'memory_limit', $memory_limit ); // phpcs:ignore WordPress.PHP.IniSet.Risky,WordPress.PHP.NoSilencedErrors
		}

		/**
		 * Fires before the import process begins.
		 *
		 * @since 1.0.0
		 */
		do_action( 'mvweb_pi_before_import' );

		// Skip non-essential image subsizes during import.
		// A standard WC + theme install registers ~10 subsizes; running each
		// one through Imagick on every photo dominates CPU and wall-clock
		// (≈2.2 s and ~250 MB RSS per photo on Beget's VDS). We keep only
		// the four sizes WooCommerce templates actually require — admin
		// thumbnail, catalog tile, product page, gallery thumb — and let
		// every other size be generated lazily by `image_make_intermediate_size()`
		// on first request (native WP behaviour since 5.3) or in bulk via
		// `wp media regenerate` when a new theme registers its own sizes.
		// Filterable in case a site genuinely needs a different baseline.
		$keep_sizes = apply_filters(
			'mvweb_pi_keep_image_sizes',
			array( 'thumbnail', 'woocommerce_thumbnail', 'woocommerce_single', 'woocommerce_gallery_thumbnail' )
		);
		$size_filter = function ( $sizes ) use ( $keep_sizes ) {
			if ( empty( $keep_sizes ) ) {
				return $sizes;
			}
			return array_intersect_key( $sizes, array_flip( (array) $keep_sizes ) );
		};
		add_filter( 'intermediate_image_sizes_advanced', $size_filter, 999 );

		// One-shot reconciliation when the operator newly excludes a
		// category between imports: remove every SKU we previously
		// imported under that branch and delete the now-orphan term,
		// so the storefront stops showing products the operator
		// explicitly opted out of. Only runs on a fresh start — a
		// resumed checkpoint already passed this point.
		// "Fresh start" is tested the same way the counter restore below tests
		// it, and for the same reason: a source that resumes by seeking arrives
		// with $skip_count === 0 and its accumulated SKUs in hand. Reading that
		// as a fresh start would re-run this pass on every continuation — and
		// this is the one pass that calls wp_delete_post( …, true ), which does
		// not go through the bin. For the price-list path the two tests are the
		// same test: the cron layer sets both values together.
		if ( 0 === $skip_count && empty( $resume_skus ) ) {
			$this->reconcile_excluded_categories();
		}

		// Default batch size: settings value if configured, otherwise 100.
		// Filter `mvweb_pi_batch_size` runs last so it can override both
		// the default and the settings value (TZ public hook contract).
		$settings = get_option( 'mvweb_pi_settings', array() );

		// Stock held by open orders. On by default, including on installs that
		// predate the setting: leaving the catalogue overselling until someone
		// finds the switch would be the wrong default.
		if ( ! array_key_exists( 'reserve_stock', $settings ) || ! empty( $settings['reserve_stock'] ) ) {
			$this->reserved = new MVweb_PI_Reserved_Stock();
		}

		$default = ! empty( $settings['batch_size'] ) ? absint( $settings['batch_size'] ) : 100;
		/** @var int $batch_size Number of products per batch. */
		$batch_size = (int) apply_filters( 'mvweb_pi_batch_size', $default );
		if ( $batch_size < 1 ) {
			$batch_size = 100;
		}

		$batch          = array();
		$batch_weight   = 0;
		$new_skus       = $resume_skus;
		$batch_num      = 0;
		$started_at     = gmdate( 'Y-m-d H:i:s' );
		$skipped_so_far = 0;

		// Restore stats from checkpoint if resuming.
		//
		// Either argument marks a resume. The file path always sets both — the
		// cron layer reads `processed` and `new_skus` out of the same checkpoint
		// in one block — so for it the two conditions are the same condition. A
		// source that cannot afford to rewind its stream (an HTTP API, where
		// skipping N products means downloading N products again just to throw
		// them away) resumes by seeking instead, and arrives here with
		// $skip_count === 0 and the accumulated SKUs in hand. Without the second
		// test its counters would silently restart from zero mid-import.
		if ( $skip_count > 0 || ! empty( $resume_skus ) ) {
			$progress = get_option( self::PROGRESS_OPTION );
			if ( is_array( $progress ) ) {
				$this->stats = array(
					'created'             => $progress['created'] ?? 0,
					'updated'             => $progress['updated'] ?? 0,
					'skipped'             => $progress['skipped'] ?? 0,
					'errors'              => $progress['errors'] ?? 0,
					'touched_ids'         => is_array( $progress['touched_ids'] ?? null ) ? $progress['touched_ids'] : array(),
					'variations_created'  => (int) ( $progress['variations_created'] ?? 0 ),
					'variations_updated'  => (int) ( $progress['variations_updated'] ?? 0 ),
					'variations_disabled' => (int) ( $progress['variations_disabled'] ?? 0 ),
				);
				$started_at = $progress['started_at'] ?? $started_at;
				$batch_num  = $progress['batch_num'] ?? 0;

				$this->reserve_applied = (int) ( $progress['reserve_applied'] ?? 0 );
				$this->reserve_short   = is_array( $progress['reserve_short'] ?? null ) ? $progress['reserve_short'] : array();
			}
		}

		// Defer term counting for the whole run. Every taxonomy write below
		// (category, visibility, tag) otherwise triggers an immediate recount
		// of the affected term — two queries plus a term-meta write each time
		// a relationship is created. The paired call lives in the `finally`
		// block, not next to recount_product_terms(), because run() also
		// returns early when the wall-clock budget runs out, and that exit is
		// the normal path for a large catalogue over web/wp-cron rather than a
		// crash. Missing the paired call would drop the queued recounts with
		// the PHP process and leave the counts in wp-admin stale for the whole
		// import.
		wp_defer_term_counting( true );

		try {

		foreach ( $products as $product_data ) {
			$new_skus[] = $product_data['sku'];

			// Skip already-processed products on resume.
			if ( $skipped_so_far < $skip_count ) {
				++$skipped_so_far;
				continue;
			}

			$batch[] = $product_data;

			// Weighed by what is written, not by lines: a product with fifty
			// variations is fifty-one posts, and a batch of a hundred such lines
			// would run far past the wall-clock budget checked between batches.
			$batch_weight += 1 + count( (array) ( $product_data['variations'] ?? array() ) );

			if ( $batch_weight >= $batch_size ) {
				$this->process_batch( $batch );
				$batch        = array();
				$batch_weight = 0;
				++$batch_num;

				// Release the per-request object cache between batches. On a CLI
				// run with no persistent cache, every get_post_meta() /
				// update_object_term_cache() the batch primed stays in a PHP
				// array for the rest of the process — across a 1400-SKU import
				// that is the main driver of RSS growth and the reason the
				// memory_limit had to be raised. Flushing keeps memory flat;
				// the next batch re-primes only the rows it actually touches.
				wp_cache_flush();

				// Checkpoint: save progress after each batch.
				$this->save_progress( $new_skus, $started_at, $batch_num );

				mvweb_pi_log(
					sprintf(
						'Batch %d processed (running totals: %d created, %d updated, %d skipped, %d errors).',
						$batch_num,
						$this->stats['created'],
						$this->stats['updated'],
						$this->stats['skipped'],
						$this->stats['errors']
					),
					'debug'
				);

				// Cooperative wall-clock budget: when the caller (web/AJAX)
				// gave us a deadline and we've crossed it, persist what we
				// have and bail. The cron layer reads `incomplete` and
				// schedules a continuation via wp_schedule_single_event().
				// We never bail mid-batch — finishing the current batch
				// guarantees a consistent checkpoint.
				if ( $deadline_ts > 0 && time() >= $deadline_ts ) {
					return array_merge( $this->stats, array(
						'incomplete' => true,
						'processed'  => count( $new_skus ),
					) );
				}
			}
		}

		// Process remaining products.
		if ( ! empty( $batch ) ) {
			$this->process_batch( $batch );
			++$batch_num;
		}

		// At this point the generator has fully drained — the SKU set is complete.
		// Only now is it safe to diff against known_skus and to overwrite known_skus.
		// If the process died inside the loop, save_progress() recorded a partial
		// new_skus but neither zero_missing_stock() nor the known_skus overwrite
		// have run — preserving stock data for products that simply hadn't been
		// streamed yet.
		$final_skus = array_values( array_unique( $new_skus ) );

		// Categories the supplier deleted on their side disappear from the feed
		// tree entirely. Drop them here — before the stock-out pass, so their
		// products leave the catalogue instead of lingering as zeroed rows.
		$this->remove_vanished_categories( $final_skus );

		// Zero stock for products missing from the new price list (TZ 6.4, 6.5.1).
		$this->zero_missing_stock( $final_skus );

		// The previous supplier's catalogue, if the operator asked for it to be
		// taken off the shelf when the source was switched. Here rather than at
		// the switch itself: only now has the new source proved it works, and
		// only now are its articles known — a product both suppliers carry has
		// just been updated and must not be retired.
		if ( class_exists( 'MVweb_PI_Retire' ) && null !== MVweb_PI_Retire::pending() ) {
			MVweb_PI_Retire::apply( $final_skus, $deadline_ts );
		}

		$this->report_reserved_stock();

		if ( $this->stats['variations_created'] + $this->stats['variations_updated'] + $this->stats['variations_disabled'] > 0 ) {
			mvweb_pi_log(
				sprintf(
					/* translators: 1: created count, 2: updated count, 3: disabled count */
					__( 'Variations: %1$d created, %2$d updated, %3$d disabled.', 'mvweb-price-importer' ),
					$this->stats['variations_created'],
					$this->stats['variations_updated'],
					$this->stats['variations_disabled']
				),
				'info'
			);
		}

		// Flush the deferred term counts before the final recount and before
		// `mvweb_pi_after_import` fires, so anything reading a term count from
		// that hook sees settled numbers. The paired call in `finally` stays as
		// the safety net for the early return and for exceptions; calling it
		// twice is harmless — the second pass has an empty queue.
		wp_defer_term_counting( false );

		// Refresh product_cat/product_tag counts. The import writes _stock_status
		// low-level (update_post_meta) for speed, which never fires the term-count
		// hook WooCommerce relies on, so the category counts shown in wp-admin drift
		// from the real number of visible products after every run.
		$this->recount_product_terms();

		// Persist total + last_run on the per-instance stats so callers
		// (cron wrapper, REST endpoint, AJAX handler) get a complete
		// payload that survives the array_merge in MVweb_PI_Cron::run().
		$this->stats['total']    = count( $final_skus );
		$this->stats['last_run'] = current_time( 'mysql' );

		// Save import statistics.
		update_option( 'mvweb_pi_import_stats', $this->stats, false );

		// Save known SKUs for next diff (autoload=false). Only the complete,
		// drained SKU set is persisted here; partial sets from interrupted
		// runs remain in the progress option and are recovered on resume.
		update_option( 'mvweb_pi_known_skus', $final_skus, false );

		// Clear progress — import completed successfully.
		delete_option( self::PROGRESS_OPTION );

		/**
		 * Fires after the import process completes.
		 *
		 * @since 1.0.0
		 * @param array $stats Import statistics.
		 */
		do_action( 'mvweb_pi_after_import', $this->stats );

		return $this->stats;

		} finally {
			remove_filter( 'intermediate_image_sizes_advanced', $size_filter, 999 );

			// Flush whatever term counts this slice queued. Reached on every
			// exit — full drain, early return on the wall-clock budget, and
			// exceptions alike.
			wp_defer_term_counting( false );
		}
	}

	/**
	 * Save import progress checkpoint.
	 *
	 * Persists current progress to wp_options so the import can be
	 * resumed if the PHP process is interrupted (timeout, OOM, restart).
	 *
	 * @since 1.1.0
	 * @param string[] $new_skus   Accumulated SKUs processed so far.
	 * @param string   $started_at Import start timestamp (GMT).
	 * @param int      $batch_num  Number of completed batches.
	 * @return void
	 */
	private function save_progress( array $new_skus, string $started_at, int $batch_num ): void {
		$processed = $this->stats['created'] + $this->stats['updated']
			+ $this->stats['skipped'] + $this->stats['errors'];

		update_option(
			self::PROGRESS_OPTION,
			array(
				'processed'           => $processed,
				'created'             => $this->stats['created'],
				'updated'             => $this->stats['updated'],
				'skipped'             => $this->stats['skipped'],
				'errors'              => $this->stats['errors'],
				'touched_ids'         => $this->stats['touched_ids'],
				'variations_created'  => $this->stats['variations_created'],
				'variations_updated'  => $this->stats['variations_updated'],
				'variations_disabled' => $this->stats['variations_disabled'],
				'new_skus'            => $new_skus,
				'started_at'          => $started_at,
				'batch_num'           => $batch_num,

				// Carried across continuations for the same reason as the
				// counters above: the report is written once, by whichever
				// continuation finishes the run, and it has to speak for the
				// whole import rather than for its last slice. A shortfall
				// found in the first chunk is exactly the one nobody would
				// otherwise hear about.
				'reserve_applied'     => $this->reserve_applied,
				'reserve_short'       => $this->reserve_short,
			),
			false
		);

		// A checkpoint is proof this run is alive, so it is also the right
		// moment to push the lock's timestamp forward. A CLI import of a large
		// catalogue with images runs far longer than the lock's 30-minute
		// staleness window, and without this the next scheduled tick would
		// steal the lock from a healthy process. Cheap: the call writes at most
		// once every ten minutes, see MVweb_PI_Cron::renew_lock().
		MVweb_PI_Cron::renew_lock();
	}

	/**
	 * Write down what open orders took out of this import.
	 *
	 * Two lines, both of them operator-grade. The second one is the only place
	 * anyone learns that a delivery did not cover an order already taken —
	 * before the picker discovers it at the shelf.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	private function report_reserved_stock(): void {
		if ( ! $this->reserved instanceof MVweb_PI_Reserved_Stock ) {
			return;
		}

		if ( $this->reserve_applied > 0 ) {
			mvweb_pi_log(
				sprintf(
					/* translators: %d: number of products */
					_n(
						'Stock of %d product was reduced by what open orders hold.',
						'Stock of %d products was reduced by what open orders hold.',
						$this->reserve_applied,
						'mvweb-price-importer'
					),
					$this->reserve_applied
				),
				'info'
			);
		}

		if ( empty( $this->reserve_short ) ) {
			return;
		}

		$listed = array_slice( $this->reserve_short, 0, 20, true );
		$parts  = array();
		foreach ( $listed as $sku => $shortfall ) {
			$parts[] = $sku . ' (' . (int) $shortfall . ')';
		}

		mvweb_pi_log(
			sprintf(
				/* translators: 1: number of products, 2: comma-separated SKUs with the shortfall in brackets */
				__( 'The price list did not cover open orders for %1$d product(s): %2$s. The figure in brackets is how many units are missing.', 'mvweb-price-importer' ),
				count( $this->reserve_short ),
				implode( ', ', $parts )
			),
			'warning'
		);
	}

	/**
	 * What is left of the supplier's stock once open orders take their share.
	 *
	 * Always computed from the price list, never from the number already in the
	 * database: subtracting from the stored value would take the same orders
	 * off again on every run and walk the catalogue down to zero.
	 *
	 * @since 1.1.0
	 * @param int    $product_id Product being written.
	 * @param int    $stock      Stock as the price list states it.
	 * @param string $sku        SKU, for the shortfall report.
	 * @return int Stock to write, never below zero.
	 */
	private function available_stock( int $product_id, int $stock, string $sku ): int {
		if ( ! $this->reserved instanceof MVweb_PI_Reserved_Stock ) {
			return $stock;
		}

		$held = $this->reserved->held( $product_id );
		if ( $held <= 0 ) {
			return $stock;
		}

		++$this->reserve_applied;

		// The supplier brought less than the shop has promised. The order cannot
		// be filled from this delivery, and nobody would learn about it before
		// picking — so it goes into the log by name.
		if ( $held > $stock && '' !== $sku ) {
			$this->reserve_short[ $sku ] = $held - $stock;
		}

		return max( 0, $stock - $held );
	}

	/**
	 * Process a batch of products.
	 *
	 * For each product, determines whether to create or update
	 * based on existing SKU in WooCommerce.
	 *
	 * @since 1.0.0
	 * @since 1.0.11 Resolves every duplicate copy per SKU and zeroes the extra
	 *               copies so only the canonical (lowest-id) product carries the
	 *               feed's stock.
	 * @param array[] $batch Array of normalized product data.
	 * @return void
	 */
	private function process_batch( array $batch ): void {
		// Refresh what open orders hold before touching stock. Per batch rather
		// than once per run: an order placed while the import is walking the
		// catalogue would otherwise have its deduction overwritten and stay
		// overwritten until the next run hours later. WooCommerce primes the
		// line items of the whole order set in one query, so the query count is
		// flat — 21 whether there are twenty open orders or two hundred, and 3
		// when there are none. Time is not flat, because the order objects are
		// hydrated in PHP: measured 7 ms at twenty open orders and 47 ms at two
		// hundred, so 130 batches of a 13 000-product catalogue add about a
		// second in the first case and six in the second.
		if ( $this->reserved instanceof MVweb_PI_Reserved_Stock ) {
			$this->reserved->refresh();
		}

		// Resolve every copy of each SKU in one SELECT, then prime the postmeta
		// and term caches so update_product()'s get_post_meta() diff reads hit
		// cache instead of issuing cold SELECTs per row on a CLI runner. A SKU
		// can map to several duplicate products (created by an older plugin
		// build that failed to dedupe); the feed describes one logical SKU, so
		// we update the canonical (lowest-id) copy and force the rest out of
		// stock — otherwise stale duplicates keep showing as in stock.
		$sku_to_ids = $this->resolve_all_ids_by_skus(
			array_column( $batch, 'sku' )
		);

		// Barcode fallback. A supplier that mints a new offer id when a product
		// is edited changes its SKU, so the same physical item would be matched
		// by neither SKU and re-created as a duplicate (leaving the old one
		// orphaned in stock). Resolve barcodes for every offer the SKU lookup
		// missed; below we reuse the existing product when exactly one carries
		// that barcode, migrating it onto the new SKU instead of duplicating.
		$missing_barcodes = array();
		foreach ( $batch as $data ) {
			if ( empty( $sku_to_ids[ $data['sku'] ] ) && ! empty( $data['barcode'] ) ) {
				$missing_barcodes[] = $data['barcode'];
			}
		}
		$barcode_to_ids = ! empty( $missing_barcodes )
			? $this->resolve_all_ids_by_barcodes( $missing_barcodes )
			: array();

		$prime_ids = $sku_to_ids ? array_merge( ...array_values( $sku_to_ids ) ) : array();
		if ( $barcode_to_ids ) {
			$prime_ids = array_merge( $prime_ids, ...array_values( $barcode_to_ids ) );
		}
		if ( ! empty( $prime_ids ) ) {
			$prime_ids = array_values( array_unique( $prime_ids ) );
			update_meta_cache( 'post', $prime_ids );
			update_object_term_cache( $prime_ids, 'product' );
		}

		foreach ( $batch as $data ) {
			try {
				$ids        = $sku_to_ids[ $data['sku'] ] ?? array();
				$product_id = $ids[0] ?? 0; // Lowest id is the canonical copy.

				// SKU miss → try the stable barcode. Reuse the existing product
				// only when exactly one carries the barcode; if several do
				// (supplier data error) we can't tell which is canonical, so log
				// it and fall through to create rather than corrupt the wrong row.
				if ( ! $product_id && ! empty( $data['barcode'] ) ) {
					$barcode_ids = $barcode_to_ids[ $data['barcode'] ] ?? array();
					if ( 1 === count( $barcode_ids ) ) {
						$product_id = $barcode_ids[0];
					} elseif ( count( $barcode_ids ) > 1 ) {
						mvweb_pi_log(
							sprintf(
								/* translators: 1: barcode, 2: SKU */
								__( 'Barcode %1$s is shared by several products; creating a new product for SKU %2$s instead of guessing.', 'mvweb-price-importer' ),
								$data['barcode'],
								$data['sku']
							),
							'warning'
						);
					}
				}

				// Zero any extra duplicates regardless of how the canonical copy
				// is handled below — they are stale rows the feed describes once,
				// so only one copy should carry its stock. Unconditional so a
				// duplicate is never left in stock even if update_product() bails
				// on the canonical copy (e.g. the post vanished mid-run). The
				// plugin never deletes products — removing the duplicate rows is
				// left to a manual catalog tidy.
				foreach ( array_slice( $ids, 1 ) as $dup_id ) {
					$this->zero_out_product( $dup_id );
				}

				// A product whose variations were put together by hand in
				// WooCommerce, matched by the article of a MoySklad product.
				// Writing MoySklad's variations beside the shop's would sell every
				// size twice, and turning it simple would strand them — so it is
				// left exactly as it is.
				if ( $product_id && isset( $data['type'] ) && $this->has_handmade_variations( $product_id ) ) {
					mvweb_pi_log(
						sprintf(
							/* translators: 1: SKU, 2: product ID */
							__( 'Product %1$s (#%2$d) has variations made by hand in WooCommerce, so the import leaves it as it is. To have MoySklad fill it, delete those variations.', 'mvweb-price-importer' ),
							$data['sku'],
							$product_id
						),
						'warning'
					);
					++$this->stats['skipped'];
					continue;
				}

				// A grouped or external product is a choice made in the shop, and
				// variations cannot hang off one: they would be written as posts
				// nobody sees, with nothing in the log to say so.
				if ( $product_id && 'variable' === ( $data['type'] ?? '' )
					&& ! has_term( 'simple', 'product_type', $product_id )
					&& ! has_term( 'variable', 'product_type', $product_id ) ) {
					mvweb_pi_log(
						sprintf(
							/* translators: 1: SKU, 2: product ID */
							__( 'Product %1$s (#%2$d) has variants in MoySklad but is neither a simple nor a variable product in WooCommerce, so the import leaves it as it is.', 'mvweb-price-importer' ),
							$data['sku'],
							$product_id
						),
						'warning'
					);
					++$this->stats['skipped'];
					continue;
				}

				// update_product() returns false on a stale id (the post was
				// deleted but its _sku row lingered); fall through to the create
				// path in that case.
				if ( $product_id && $this->update_product( $product_id, $data ) ) {
					++$this->stats['updated'];
					continue;
				}

				$result = $this->create_product( $data );
				if ( is_wp_error( $result ) ) {
					mvweb_pi_log(
						/* translators: 1: SKU, 2: error message */
						sprintf( __( 'Error creating product %1$s: %2$s', 'mvweb-price-importer' ), $data['sku'], $result->get_error_message() ),
						'error'
					);
					++$this->stats['errors'];
					continue;
				}
				// create_product() writes the row with a low-level
				// wp_insert_post() that never populates wc_product_meta_lookup.
				// Seed it now so the next import resolves this SKU as existing
				// (otherwise every run re-creates the same SKU as a duplicate)
				// and so catalog price/stock filters and ordering work.
				self::refresh_product_lookup( (int) $result );
				++$this->stats['created'];
			} catch ( \Exception $e ) {
				mvweb_pi_log(
					/* translators: 1: SKU, 2: error message */
					sprintf( __( 'Exception processing product %1$s: %2$s', 'mvweb-price-importer' ), $data['sku'], $e->getMessage() ),
					'error'
				);
				++$this->stats['errors'];
			}
		}
	}

	/**
	 * Resolve a batch of SKUs to every live product ID carrying each one.
	 *
	 * The feed describes one logical SKU, but the catalog can hold several
	 * products sharing it — duplicates created by an older plugin build that
	 * failed to dedupe. The stock-out and feed-update paths must touch ALL of
	 * them, not just the one wc_get_product_id_by_sku() happens to return (it
	 * reads wc_product_meta_lookup, which holds a single row per SKU). Querying
	 * the _sku postmeta directly returns every copy, survives a missing/empty
	 * lookup row, and resolves the whole batch in one SELECT instead of one per
	 * SKU. Trashed products are excluded — a binned SKU should resurface as a
	 * fresh product, not be silently revived.
	 *
	 * @since 1.0.11
	 * @param string[] $skus SKUs to resolve.
	 * @return array<string,int[]> SKU → product IDs (ascending), only for SKUs that exist.
	 */
	private function resolve_all_ids_by_skus( array $skus ): array {
		$skus = array_values( array_unique( array_filter( array_map( 'strval', $skus ), 'strlen' ) ) );
		if ( empty( $skus ) ) {
			return array();
		}

		global $wpdb;

		$placeholders = implode( ',', array_fill( 0, count( $skus ), '%s' ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.post_id, pm.meta_value AS sku
				FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = '_sku'
				AND pm.meta_value IN ({$placeholders})
				AND p.post_type = 'product'
				AND p.post_status != 'trash'
				ORDER BY pm.post_id ASC",
				$skus
			)
		);

		$map = array();
		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$map[ (string) $row->sku ][] = (int) $row->post_id;
			}
		}

		return $map;
	}

	/**
	 * Resolve a batch of barcodes to every live product ID carrying each one.
	 *
	 * A supplier that regenerates a product's offer id on edit (so the SKU
	 * changes) still keeps the physical barcode stable. When a SKU can't be
	 * found, the importer falls back to the barcode to recognise the same
	 * product and update it in place instead of creating a duplicate. The
	 * barcode is stored low-level in `_mvweb_pi_barcode`. Several products can
	 * share a barcode (supplier data error) — this returns all of them so the
	 * caller can detect the ambiguity and refuse to guess. Trashed products are
	 * excluded, matching resolve_all_ids_by_skus().
	 *
	 * @since 1.1.0
	 * @param string[] $barcodes Barcodes to resolve.
	 * @return array<string,int[]> Barcode → product IDs (ascending), only for existing ones.
	 */
	private function resolve_all_ids_by_barcodes( array $barcodes ): array {
		$barcodes = array_values( array_unique( array_filter( array_map( 'strval', $barcodes ), 'strlen' ) ) );
		if ( empty( $barcodes ) ) {
			return array();
		}

		global $wpdb;

		$placeholders = implode( ',', array_fill( 0, count( $barcodes ), '%s' ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.post_id, pm.meta_value AS barcode
				FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = '_mvweb_pi_barcode'
				AND pm.meta_value IN ({$placeholders})
				AND p.post_type = 'product'
				AND p.post_status != 'trash'
				ORDER BY pm.post_id ASC",
				$barcodes
			)
		);

		$map = array();
		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				$map[ (string) $row->barcode ][] = (int) $row->post_id;
			}
		}

		return $map;
	}

	/**
	 * Refresh the wc_product_meta_lookup row for a product.
	 *
	 * create_product() and update_product() write meta with low-level
	 * update_post_meta() calls that bypass WC_Product->save(), so the
	 * wc_product_meta_lookup row WooCommerce normally maintains is never
	 * written. That breaks two things: the SKU dedup lookup in
	 * resolve_existing_skus() (every run re-creates the same SKUs as
	 * duplicates) and the catalog price/stock filters and ordering, which
	 * all read this table. WC's own column set for the lookup row is
	 * version-dependent (COGS, global_unique_id, rating columns appear
	 * across releases), so rather than hand-build the INSERT we call WC's
	 * native WC_Product_Data_Store_CPT::update_lookup_table(), which derives
	 * the full row from post meta itself. The method is protected, so we
	 * reach it through reflection on the live data-store class — this stays
	 * correct across WC schema upgrades. A direct call would fatal
	 * (the method is protected on the WC_Data_Store_WP base).
	 *
	 * @since 1.0.9
	 * @since 1.1.0 Static, so the stock sync can reuse it: it writes the same
	 *               stock meta the same low-level way and owes the lookup table
	 *               the same refresh.
	 * @param int $product_id WooCommerce product ID.
	 * @return void
	 */
	public static function refresh_product_lookup( int $product_id ): void {
		if ( $product_id <= 0 || ! class_exists( 'WC_Data_Store' ) ) {
			return;
		}

		try {
			$store = \WC_Data_Store::load( 'product' );
			$class = $store->get_current_class_name();
			if ( ! class_exists( $class ) ) {
				return;
			}
			$instance = new $class();
			$method   = new \ReflectionMethod( $instance, 'update_lookup_table' );
			$method->setAccessible( true );
			$method->invoke( $instance, $product_id, 'wc_product_meta_lookup' );
		} catch ( \Throwable $e ) {
			// Lookup is an optimisation, not correctness-critical for the
			// write itself — log and move on rather than abort the import.
			mvweb_pi_log(
				/* translators: 1: product ID, 2: error message */
				sprintf( __( 'Could not refresh product lookup for #%1$d: %2$s', 'mvweb-price-importer' ), $product_id, $e->getMessage() ),
				'warning'
			);
		}
	}

	/**
	 * Create a new WooCommerce simple product.
	 *
	 * @since 1.0.0
	 * @param array $data Normalized product data.
	 * @return int|\WP_Error Product ID on success, WP_Error on failure.
	 */
	private function create_product( array $data ): int|\WP_Error {
		// Low-level product creation: bypasses WC_Product->save() and the
		// woocommerce_new_product hook chain that runs ~30+ callbacks
		// (lookup-table rewrite, search index, currency normalization,
		// caching). On a Beget VDS save() costs 200-300 ms per product;
		// the legacy importer (mvweb-price-converter) wrote products via
		// wp_insert_post + direct update_post_meta and ran in tens of
		// milliseconds per row. We mirror that here. The product_type
		// term is attached explicitly so wc_get_product() resolves the
		// row as a simple product on later reads.
		$product_id = wp_insert_post(
			array(
				'post_title'   => $data['name'],
				'post_content' => $data['description'],
				'post_status'  => 'publish',
				'post_type'    => 'product',
			)
		);

		if ( ! $product_id || is_wp_error( $product_id ) ) {
			return new \WP_Error(
				'product_save_failed',
				/* translators: %s: product SKU */
				sprintf( __( 'Failed to save product: %s', 'mvweb-price-importer' ), $data['sku'] )
			);
		}

		// A product sold through its variations: its price and stock are theirs.
		$variable = 'variable' === ( $data['type'] ?? '' );

		// Required WC product type marker. Without it wc_get_product()
		// returns false because WC can't resolve the data store.
		wp_set_object_terms( $product_id, $variable ? 'variable' : 'simple', 'product_type', false );

		// Catalog visibility taxonomy — the modern (WC 3.0+) replacement
		// for the legacy _visibility meta. Empty terms = "visible in
		// shop AND in search", which is the default the WC admin sets
		// for a freshly-created product.
		wp_set_object_terms( $product_id, array(), 'product_visibility', false );

		// Price + stock + WC-default flags through direct meta. Mirrors
		// what WC_Product->save() writes, minus the lookup-table rewrite,
		// hook fan-out and post-cache flush.
		update_post_meta( $product_id, '_sku', $data['sku'] );

		if ( $variable ) {
			// Stock is kept on each variation; the status comes from them when
			// the variations are written below.
			update_post_meta( $product_id, '_manage_stock', 'no' );
		} else {
			$sale   = ( ! empty( $data['sale_price'] ) && $data['sale_price'] > 0 ) ? (string) $data['sale_price'] : '';
			$prices = $this->storefront_prices( $data, $sale );

			update_post_meta( $product_id, '_regular_price', $prices['regular'] );
			if ( '' !== $sale && ! $prices['no_retail'] ) {
				update_post_meta( $product_id, '_sale_price', $sale );
			}
			update_post_meta( $product_id, '_price', $prices['effective'] );
			$this->sync_no_retail_mark( $product_id, $prices['no_retail'] );

			// Wholesale and dealer prices — plugin-owned meta, deliberately separate
			// from the WC pricing keys above so neither affects the storefront price.
			if ( ! empty( $data['wholesale_price'] ) && $data['wholesale_price'] > 0 ) {
				update_post_meta( $product_id, '_mvweb_pi_wholesale_price', (string) $data['wholesale_price'] );
			}

			if ( ! empty( $data['dealer_price'] ) && $data['dealer_price'] > 0 ) {
				update_post_meta( $product_id, '_mvweb_pi_dealer_price', (string) $data['dealer_price'] );
			}

			update_post_meta( $product_id, '_manage_stock', 'yes' );
			update_post_meta( $product_id, '_stock', (string) $data['stock'] );
			update_post_meta( $product_id, '_stock_status', $data['stock'] > 0 ? 'instock' : 'outofstock' );

			// A product created with zero stock must carry the product_visibility
			// 'outofstock' term, exactly as WC_Product->save() would. WooCommerce
			// writes that term whatever the hide-out-of-stock option says, and the
			// catalogue query reads it only while the option is on — so a shop that
			// switches the option on later hides the right products. The empty
			// product_visibility set above only covers the in-stock case.
			if ( 0 >= (int) $data['stock'] ) {
				wp_set_object_terms( $product_id, 'outofstock', 'product_visibility', true );
			}
		}

		// WC-default product flags. Without these the WC admin renders
		// the row with broken icons and the "Tax status" filter excludes
		// the product. Values match what WC_Product_Simple sets on save.
		update_post_meta( $product_id, '_virtual', 'no' );
		update_post_meta( $product_id, '_downloadable', 'no' );
		update_post_meta( $product_id, '_tax_status', 'taxable' );
		update_post_meta( $product_id, '_tax_class', '' );
		update_post_meta( $product_id, '_visibility', 'visible' );
		update_post_meta( $product_id, '_featured', 'no' );
		update_post_meta( $product_id, '_backorders', 'no' );
		update_post_meta( $product_id, '_sold_individually', 'no' );

		// Category assignment (TZ 6.2). Append mode (`true`) so an
		// existing taxonomy (set by other means) isn't replaced on
		// re-import. We remember the feed term in postmeta so
		// update_product() can recognise a supplier-side category move
		// and swap our term out without touching manual categories.
		if ( ! empty( $data['category_id'] ) ) {
			$term_id = $this->resolve_category( $data['category_id'], $data['parent_cat_id'] ?? '' );
			if ( $term_id ) {
				wp_set_object_terms( $product_id, array( (int) $term_id ), 'product_cat', true );
				update_post_meta( $product_id, '_mvweb_pi_feed_cat_term_id', (int) $term_id );
			}
		}

		// Product tags driven by price-list flags. No rules configured means
		// an empty array here and no work at all.
		if ( ! empty( $data['tags'] ) && is_array( $data['tags'] ) ) {
			$this->apply_tags( $product_id, $data['tags'], true );
		}

		// Per-warehouse stock meta (TZ 3.3, 16.3). Written even when empty: a
		// MoySklad product whose every warehouse is no longer counted arrives
		// with no split at all, and skipping the write would leave the old
		// per-warehouse figures on the product page next to a zero total. A price
		// list always carries at least its own warehouse, so nothing changes there.
		if ( ! $variable && isset( $data['stocks'] ) && is_array( $data['stocks'] ) ) {
			update_post_meta( $product_id, '_mvweb_pi_stocks', wp_json_encode( $data['stocks'] ) );
		}

		// Barcode meta (TZ 16.3).
		if ( ! empty( $data['barcode'] ) ) {
			update_post_meta( $product_id, '_mvweb_pi_barcode', sanitize_text_field( $data['barcode'] ) );
		}

		$this->apply_measures( $product_id, $data );

		if ( isset( $data['attributes'] ) && is_array( $data['attributes'] ) ) {
			$this->apply_attributes( $product_id, $data['attributes'], true );
		}

		// The source's own identifier for this product, when the source has one.
		// A price-list file does not, and the key is simply absent then. See
		// MVweb_PI_Stock_Sync, the one thing that reads it.
		if ( ! empty( $data['ms_id'] ) ) {
			update_post_meta( $product_id, MVweb_PI_Stock_Sync::ID_META, sanitize_text_field( $data['ms_id'] ) );
		}

		// Images: on create we honour every mode except `never`. The first
		// run is the only place Imagick legitimately needs to fire for a
		// brand-new SKU.
		if ( self::IMAGE_MODE_NEVER !== $this->get_image_mode() ) {
			$this->handle_image( $product_id, $data['image'] ?? '' );
			$this->handle_gallery( $product_id, $data['gallery'] ?? array() );
		}

		if ( $variable ) {
			$this->write_variations( $product_id, $data, true );
		}

		// Mark the row touched. The bootstrap's `mvweb_pi_after_import`
		// handler runs `wc_delete_product_transients()` once per touched
		// ID at the end of the run; calling it inline per-product cost
		// ~5600 wp_options DELETEs across a 1400-SKU import (each call
		// is itself 3–5 transient + cache-group operations).
		$this->stats['touched_ids'][] = (int) $product_id;

		/**
		 * Fires after a new product is created during import.
		 *
		 * @since 1.0.0
		 * @param int   $product_id WooCommerce product ID.
		 * @param array $data       Normalized product data.
		 */
		do_action( 'mvweb_pi_product_created', $product_id, $data );

		return $product_id;
	}

	/**
	 * Resolve the image-import policy for this run.
	 *
	 * Reads `mvweb_pi_settings.image_mode` once and caches it. Unknown values
	 * fall back to `smart` — the default that handles changed supplier photos
	 * without paying Imagick cost for unchanged ones.
	 *
	 * @since 1.0.0
	 * @return string One of self::IMAGE_MODE_*.
	 */
	private function get_image_mode(): string {
		if ( null !== $this->image_mode ) {
			return $this->image_mode;
		}

		$settings = get_option( 'mvweb_pi_settings', array() );
		$mode     = $settings['image_mode'] ?? self::IMAGE_MODE_SMART;

		$allowed = array(
			self::IMAGE_MODE_SMART,
			self::IMAGE_MODE_ALWAYS,
			self::IMAGE_MODE_NEW_ONLY,
			self::IMAGE_MODE_NEVER,
		);
		if ( ! in_array( $mode, $allowed, true ) ) {
			$mode = self::IMAGE_MODE_SMART;
		}

		$this->image_mode = $mode;
		return $mode;
	}

	/**
	 * Update an existing WooCommerce product.
	 *
	 * Updates all fields: name, price, stock, description, category,
	 * images, and per-warehouse stock meta.
	 *
	 * @since 1.0.0
	 * @param int   $product_id WooCommerce product ID.
	 * @param array $data       Normalized product data.
	 * @return bool True if the row was updated, false if the post id was
	 *              missing or pointed to something other than a product.
	 */
	private function update_product( int $product_id, array $data ): bool {
		// Low-level update path: read current meta via get_post_meta()
		// (memoized by WP after the first call per request) and compare
		// to the incoming feed row, writing only on real diffs. The old
		// path constructed a WC_Product, called setters, and finished
		// with $product->save() — which on a catalog where 99 % of rows
		// don't change between imports cost 200-300 ms per product
		// purely on hook fan-out and lookup-table rewrites. The legacy
		// importer (mvweb-price-converter) did exactly this kind of
		// surgical update and was an order of magnitude faster.
		//
		// One trade-off: this path doesn't synchronously refresh
		// wc_product_meta_lookup (price filtering, sort-by-price, etc.).
		// The importer fires `mvweb_pi_after_import` at the end of the
		// run, and the bootstrap can hook a lookup rebuild there if a
		// site needs catalog filters in lock-step with imports.
		$post = get_post( $product_id );
		if ( ! $post || 'product' !== $post->post_type ) {
			return false;
		}

		// A trashed product still resolves through wc_product_meta_lookup (the
		// lookup row isn't cleared on trash). Updating it in place would keep
		// the SKU buried in the bin instead of resurfacing a live product — bail
		// so process_batch() falls through to create_product() and the SKU comes
		// back as a published product.
		if ( 'trash' === $post->post_status ) {
			return false;
		}

		// SKU migration. When this product was matched by its barcode (the
		// supplier reissued the offer id, so the SKU changed) the stored _sku is
		// stale. Adopt the new SKU so future imports resolve it directly and the
		// catalogue keeps one record instead of spawning a duplicate. The lookup
		// table (which indexes SKU) is refreshed once at the end of this method,
		// so we don't refresh here. A normal SKU match is a no-op (current ===
		// incoming).
		$incoming_sku = (string) $data['sku'];
		if ( '' !== $incoming_sku && (string) get_post_meta( $product_id, '_sku', true ) !== $incoming_sku ) {
			update_post_meta( $product_id, '_sku', $incoming_sku );
		}

		// A MoySklad product gains or loses variants over its life; its type
		// follows. A price-list row carries no type and never changes one.
		$variable = 'variable' === ( $data['type'] ?? '' );
		if ( isset( $data['type'] ) ) {
			$this->switch_product_type( $product_id, $variable );
		}

		// Sale price, sparse-safe. Unlike the stock or the regular price, this
		// one has two kinds of silence. A source that carries a sale-price field
		// and leaves it empty for this offer is saying "no sale", and clearing
		// the stored price is right. A source that carries no such field at all
		// is saying nothing — and treating that as "no sale" would strip every
		// sale price the shop set by hand, on the very first import, with no
		// threshold to stop it the way the stock-out pass has one. So when the
		// key is absent the stored value stands, and it also stands in as the
		// effective price below.
		$cur_sale = (string) get_post_meta( $product_id, '_sale_price', true );
		$new_sale = array_key_exists( 'sale_price', $data )
			? ( ( ! empty( $data['sale_price'] ) && $data['sale_price'] > 0 ) ? (string) $data['sale_price'] : '' )
			: $cur_sale;

		// Everything below works from this number, not from the raw feed value:
		// the quantity written to _stock and the in-stock flag have to come out
		// of one formula, or a product sold out by its own orders would sit in
		// the catalogue at zero while still marked as available.
		$new_stock       = $variable ? 0 : $this->available_stock( $product_id, (int) $data['stock'], (string) $data['sku'] );
		$new_status      = ( $new_stock > 0 ) ? 'instock' : 'outofstock';
		$prices          = $this->storefront_prices( $data, $new_sale );
		$effective_price = $prices['effective'];

		// Post fields (title/content) — wp_update_post hits wp_posts once
		// when at least one column changes; skip when both match.
		//
		// A sparse YML feed carries <description>/<name> on only some offers, so
		// an empty value means "not supplied", NOT "clear it". Overwriting a
		// non-empty field with an empty feed value would wipe descriptions the
		// operator wrote by hand for SEO. Only update when the feed actually
		// provides a value.
		$needs_post_update = false;
		$post_update       = array( 'ID' => $product_id );
		if ( '' !== (string) $data['name'] && (string) $post->post_title !== (string) $data['name'] ) {
			$post_update['post_title'] = $data['name'];
			$needs_post_update         = true;
		}
		if ( '' !== (string) $data['description'] && (string) $post->post_content !== (string) $data['description'] ) {
			$post_update['post_content'] = $data['description'];
			$needs_post_update           = true;
		}
		if ( $needs_post_update ) {
			wp_update_post( $post_update );
		}

		if ( ! $variable ) {
			// Meta diffs — update_post_meta is a no-op when the value already
			// matches, but we still pay one SELECT per call; reading the full
			// meta row once keeps this to N comparisons + writes only on diff.
			$cur_regular = (string) get_post_meta( $product_id, '_regular_price', true );
			if ( $cur_regular !== $prices['regular'] ) {
				update_post_meta( $product_id, '_regular_price', $prices['regular'] );
			}

			if ( $cur_sale !== $new_sale ) {
				if ( '' === $new_sale ) {
					delete_post_meta( $product_id, '_sale_price' );
				} else {
					update_post_meta( $product_id, '_sale_price', $new_sale );
				}
			}

			$cur_price = (string) get_post_meta( $product_id, '_price', true );
			if ( $cur_price !== $effective_price ) {
				update_post_meta( $product_id, '_price', $effective_price );
			}

			$this->sync_no_retail_mark( $product_id, $prices['no_retail'] );

			// Wholesale and dealer prices — sparse-safe: overwrite only when the feed
			// supplies a positive value, so an offer that omits one keeps the stored
			// price instead of losing it (same policy as the name/description fields).
			// Kept out of the WC price keys above, so neither affects the storefront.
			if ( ! empty( $data['wholesale_price'] ) && $data['wholesale_price'] > 0 ) {
				$new_wholesale = (string) $data['wholesale_price'];
				if ( (string) get_post_meta( $product_id, '_mvweb_pi_wholesale_price', true ) !== $new_wholesale ) {
					update_post_meta( $product_id, '_mvweb_pi_wholesale_price', $new_wholesale );
				}
			}

			if ( ! empty( $data['dealer_price'] ) && $data['dealer_price'] > 0 ) {
				$new_dealer = (string) $data['dealer_price'];
				if ( (string) get_post_meta( $product_id, '_mvweb_pi_dealer_price', true ) !== $new_dealer ) {
					update_post_meta( $product_id, '_mvweb_pi_dealer_price', $new_dealer );
				}
			}

			$cur_stock = (string) get_post_meta( $product_id, '_stock', true );
			if ( $cur_stock !== (string) $new_stock ) {
				update_post_meta( $product_id, '_stock', (string) $new_stock );
			}

			$cur_status = (string) get_post_meta( $product_id, '_stock_status', true );
			if ( $cur_status !== $new_status ) {
				update_post_meta( $product_id, '_stock_status', $new_status );

				// Keep the product_visibility 'outofstock' term in sync with the new
				// status. WooCommerce hides products carrying that term from the
				// catalogue and search when woocommerce_hide_out_of_stock_items is on,
				// and it only maintains the term inside WC_Product->save() — which this
				// low-level path skips. Without this, a SKU that drops to zero and later
				// comes back in stock stays tagged out of stock and invisible on the
				// storefront even though its stock meta says instock. The term is kept
				// whatever the hide option says, exactly as WC_Product_Data_Store_CPT
				// ::update_visibility() does: only the catalogue query looks at the
				// option, so a shop that turns it on later finds its products already
				// tagged. append=true / removing a single term leaves other visibility
				// terms (featured, exclude-from-*) intact.
				if ( 'instock' === $new_status ) {
					wp_remove_object_terms( $product_id, 'outofstock', 'product_visibility' );
				} else {
					wp_set_object_terms( $product_id, 'outofstock', 'product_visibility', true );
				}
			}

			// Ensure manage_stock stays set — legacy products may not have it.
			$cur_manage = (string) get_post_meta( $product_id, '_manage_stock', true );
			if ( 'yes' !== $cur_manage ) {
				update_post_meta( $product_id, '_manage_stock', 'yes' );
			}
		} elseif ( 'no' !== (string) get_post_meta( $product_id, '_manage_stock', true ) ) {
			// Stock counted on the product itself would decide its availability
			// over the variations' own figures, and WooCommerce would stop
			// deriving the product's status from them.
			update_post_meta( $product_id, '_manage_stock', 'no' );
			delete_post_meta( $product_id, '_stock' );
		}

		// Product tags driven by price-list flags. A flag that turned false
		// takes its tag off the product; tags outside the rules are never
		// touched. See apply_tags().
		//
		// Runs before the category block on purpose: wp_set_object_terms()
		// there clears this product's term cache, and apply_tags() reads the
		// current tags out of exactly that cache. Below the category block it
		// would pay a fresh query per product instead of a cache hit.
		if ( ! empty( $data['tags'] ) && is_array( $data['tags'] ) ) {
			$this->apply_tags( $product_id, $data['tags'] );
		}

		// Attribute terms, for the same reason as the tags just above: read from
		// the term cache the batch primed, before the category block clears it.
		if ( isset( $data['attributes'] ) && is_array( $data['attributes'] ) ) {
			$this->apply_attributes( $product_id, $data['attributes'] );
		}

		// Category assignment (TZ 6.3). Append mode (`true`) so existing
		// terms attached out-of-band (manual edit in WP Admin, other
		// integrations) survive re-import. Idempotent against the feed
		// term because we skip the call when the term is already there.
		if ( ! empty( $data['category_id'] ) ) {
			$term_id = $this->resolve_category( $data['category_id'], $data['parent_cat_id'] ?? '' );
			if ( $term_id ) {
				$current_terms = wp_get_object_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
				if ( ! is_wp_error( $current_terms ) ) {
					$current_ids = array_map( 'intval', (array) $current_terms );
					$prev_feed_term_id = (int) get_post_meta( $product_id, '_mvweb_pi_feed_cat_term_id', true );

					// Supplier moved the SKU to a different category — drop
					// only the term WE assigned last time, keep any manual
					// ones (admin UI, other integrations).
					if ( $prev_feed_term_id > 0 && $prev_feed_term_id !== (int) $term_id ) {
						$current_ids = array_values( array_diff( $current_ids, array( $prev_feed_term_id ) ) );
					}

					if ( ! in_array( (int) $term_id, $current_ids, true ) ) {
						$current_ids[] = (int) $term_id;
					}

					wp_set_object_terms( $product_id, $current_ids, 'product_cat', false );
				}
				update_post_meta( $product_id, '_mvweb_pi_feed_cat_term_id', (int) $term_id );
			}
		}

		// Per-warehouse stock meta (TZ 3.3, 16.3). Written even when empty: a
		// MoySklad product whose every warehouse is no longer counted arrives
		// with no split at all, and skipping the write would leave the old
		// per-warehouse figures on the product page next to a zero total. A price
		// list always carries at least its own warehouse, so nothing changes there.
		if ( ! $variable && isset( $data['stocks'] ) && is_array( $data['stocks'] ) ) {
			update_post_meta( $product_id, '_mvweb_pi_stocks', wp_json_encode( $data['stocks'] ) );
		}

		// Barcode meta.
		if ( ! empty( $data['barcode'] ) ) {
			update_post_meta( $product_id, '_mvweb_pi_barcode', sanitize_text_field( $data['barcode'] ) );
		}

		$this->apply_measures( $product_id, $data );

		// The source's own identifier — written on update as well as on create,
		// so products imported before this existed pick it up on the next run
		// rather than staying invisible to the stock sync forever.
		if ( ! empty( $data['ms_id'] ) ) {
			$new_ms_id = sanitize_text_field( $data['ms_id'] );
			if ( (string) get_post_meta( $product_id, MVweb_PI_Stock_Sync::ID_META, true ) !== $new_ms_id ) {
				update_post_meta( $product_id, MVweb_PI_Stock_Sync::ID_META, $new_ms_id );
			}
		}

		// A product an earlier source switch took off the shelf, carried again by
		// the source that owns the catalogue now. The retirement was about a
		// supplier who left; this one has not, and has just refreshed the price
		// and the stock above. Leaving it a draft would hide a product the shop
		// currently sells — the case is a round trip, where somebody switches
		// source and then switches back.
		if ( class_exists( 'MVweb_PI_Retire' ) && '' !== (string) get_post_meta( $product_id, MVweb_PI_Retire::META, true ) ) {
			MVweb_PI_Retire::restore_one( $product_id );
		}

		// Images on update:
		// - `always`   touches every product unconditionally.
		// - `smart`    delegates the decision to handle_image/handle_gallery,
		//              which short-circuit when the source URL hasn't changed,
		//              so Imagick still runs at most once per *changed* SKU.
		// - `new_only` and `never` skip the whole branch — `new_only` leaves
		//              existing images alone even if the URL changed, which
		//              is what suppliers reissuing URLs every export need.
		$mode = $this->get_image_mode();
		if ( self::IMAGE_MODE_ALWAYS === $mode || self::IMAGE_MODE_SMART === $mode ) {
			$this->handle_image( $product_id, $data['image'] ?? '' );
			$this->handle_gallery( $product_id, $data['gallery'] ?? array() );
		}

		if ( $variable ) {
			$this->write_variations( $product_id, $data, false );
		}

		// Mark the row touched. Transient invalidation is batched into
		// the `mvweb_pi_after_import` handler — see create_product().
		$this->stats['touched_ids'][] = (int) $product_id;

		// Keep wc_product_meta_lookup in step with the meta we just wrote so
		// catalog price/stock filters and the SKU dedup lookup stay accurate.
		// Idempotent — a row that didn't actually change re-writes the same
		// values. See refresh_product_lookup() for why this goes through WC's
		// native lookup builder rather than a hand-built query.
		self::refresh_product_lookup( (int) $product_id );

		/**
		 * Fires after an existing product is updated during import.
		 *
		 * @since 1.0.0
		 * @param int   $product_id WooCommerce product ID.
		 * @param array $data       Normalized product data.
		 */
		do_action( 'mvweb_pi_product_updated', $product_id, $data );

		return true;
	}

	/**
	 * Handle featured image for a product.
	 *
	 * Downloads and sets the featured image. If the URL hasn't changed,
	 * skips downloading. If URL changed, removes old image and sets new one.
	 * Only removes images originally uploaded by this plugin.
	 *
	 * @since 1.0.0
	 * @param int    $product_id Product ID.
	 * @param string $image_url  Image URL from the price list.
	 * @return void
	 */
	private function handle_image( int $product_id, string $image_url ): void {
		if ( empty( $image_url ) ) {
			return;
		}

		// Validate image URL (SSRF protection, TZ 2.4).
		$loader = new MVweb_PI_Loader();
		$valid  = $loader->validate_url( $image_url );
		if ( is_wp_error( $valid ) ) {
			mvweb_pi_log(
				/* translators: 1: product ID, 2: error message */
				sprintf( __( 'Image URL validation failed for product %1$d: %2$s', 'mvweb-price-importer' ), $product_id, $valid->get_error_message() ),
				'warning'
			);
			return;
		}

		// Check if image URL has changed (TZ 6.6).
		$saved_url = get_post_meta( $product_id, '_mvweb_pi_image_source', true );
		if ( $saved_url === $image_url ) {
			// Same source URL as last time — skip the re-download, but only if
			// the attachment it produced still exists and is still the product
			// thumbnail. If someone deleted the image from the media library by
			// hand, the cached URL would otherwise pin the product to a missing
			// picture forever. Fall through to re-import when the thumbnail is
			// gone. (handle_gallery() does the same existence check on its hits.)
			$cached_id = (int) get_post_meta( $product_id, '_mvweb_pi_image_attach_id', true );
			if ( $cached_id > 0
				&& 'attachment' === get_post_type( $cached_id )
				&& (int) get_post_thumbnail_id( $product_id ) === $cached_id ) {
				return;
			}
		}

		// Delete old image if it was uploaded by this plugin (TZ 6.6).
		$old_attach_id = (int) get_post_meta( $product_id, '_mvweb_pi_image_attach_id', true );
		if ( $old_attach_id && get_post_meta( $old_attach_id, '_mvweb_pi_uploaded', true ) ) {
			wp_delete_attachment( $old_attach_id, true );
		}

		// Download and attach new image.
		$attach_id = $this->download_and_attach_image( $image_url, $product_id );
		if ( is_wp_error( $attach_id ) ) {
			// Demoted to debug — broken image URLs are routine in supplier
			// feeds (HTTP 404 on stale photos) and would otherwise flood
			// the log with one warning per missing thumbnail per import.
			mvweb_pi_log(
				/* translators: 1: product ID, 2: error message */
				sprintf( __( 'Image download failed for product %1$d: %2$s', 'mvweb-price-importer' ), $product_id, $attach_id->get_error_message() ),
				'debug'
			);
			return;
		}

		set_post_thumbnail( $product_id, $attach_id );
		update_post_meta( $product_id, '_mvweb_pi_image_source', $image_url );
		update_post_meta( $product_id, '_mvweb_pi_image_attach_id', $attach_id );

		// Mark as uploaded by plugin — private key, hidden from REST API (TZ 6.6, 16.5).
		update_post_meta( $attach_id, '_mvweb_pi_uploaded', 1 );
	}

	/**
	 * Handle gallery images for a product.
	 *
	 * Downloads gallery images, deduplicates against the previously imported
	 * set (stored in meta `_mvweb_pi_gallery_sources`), and assigns the
	 * resulting attachment IDs as the product's gallery. Validates each URL
	 * for SSRF protection.
	 *
	 * @since 1.0.0
	 * @since 1.0.0 Added URL-based dedup to prevent attachment duplication
	 *              on repeated imports.
	 * @param int      $product_id Product ID.
	 * @param string[] $gallery    Array of gallery image URLs.
	 * @return void
	 */
	private function handle_gallery( int $product_id, array $gallery ): void {
		if ( empty( $gallery ) ) {
			return;
		}

		$loader = new MVweb_PI_Loader();

		// Previously stored mapping: url => attach_id.
		$saved_sources = get_post_meta( $product_id, '_mvweb_pi_gallery_sources', true );
		if ( ! is_array( $saved_sources ) ) {
			$saved_sources = array();
		}

		$new_sources    = array();
		$attachment_ids = array();
		$seen_urls      = array();

		foreach ( $gallery as $image_url ) {
			if ( empty( $image_url ) || isset( $seen_urls[ $image_url ] ) ) {
				continue;
			}
			$seen_urls[ $image_url ] = true;

			// Reuse existing attachment if the URL was imported previously
			// and the attachment still exists.
			if ( isset( $saved_sources[ $image_url ] ) ) {
				$existing_id = (int) $saved_sources[ $image_url ];
				if ( $existing_id > 0 && 'attachment' === get_post_type( $existing_id ) ) {
					$attachment_ids[]            = $existing_id;
					$new_sources[ $image_url ]  = $existing_id;
					continue;
				}
			}

			// Validate URL (SSRF protection, TZ 2.4).
			$valid = $loader->validate_url( $image_url );
			if ( is_wp_error( $valid ) ) {
				continue;
			}

			$attach_id = $this->download_and_attach_image( $image_url, $product_id );
			if ( is_wp_error( $attach_id ) ) {
				continue;
			}

			// Mark as uploaded by plugin (TZ 16.5).
			update_post_meta( $attach_id, '_mvweb_pi_uploaded', 1 );

			$attachment_ids[]          = $attach_id;
			$new_sources[ $image_url ] = $attach_id;
		}

		// Short-circuit: if the ordered URL → attachment mapping is identical
		// to the previous import, there's nothing to write. Saves
		// N × $product->save() on large catalogs where galleries rarely
		// change between runs. Ordered comparison so a reshuffled gallery
		// in the source feed still propagates to WooCommerce.
		if ( array_keys( $new_sources ) === array_keys( $saved_sources )
			&& $new_sources === $saved_sources
		) {
			return;
		}

		// Delete attachments that are no longer in the gallery
		// (only ones uploaded by this plugin).
		$stale_urls = array_diff_key( $saved_sources, $new_sources );
		foreach ( $stale_urls as $stale_id ) {
			$stale_id = (int) $stale_id;
			if ( $stale_id > 0 && get_post_meta( $stale_id, '_mvweb_pi_uploaded', true ) ) {
				wp_delete_attachment( $stale_id, true );
			}
		}

		// Persist the new mapping for the next import.
		if ( ! empty( $new_sources ) ) {
			update_post_meta( $product_id, '_mvweb_pi_gallery_sources', $new_sources );
		} else {
			delete_post_meta( $product_id, '_mvweb_pi_gallery_sources' );
		}

		if ( ! empty( $attachment_ids ) ) {
			update_post_meta(
				$product_id,
				'_product_image_gallery',
				implode( ',', array_map( 'intval', $attachment_ids ) )
			);
		} else {
			delete_post_meta( $product_id, '_product_image_gallery' );
		}
	}

	/**
	 * Download an image from URL and attach it to a product.
	 *
	 * Uses the plugin loader (SSRF-protected, no redirect following)
	 * to download to a temp file, then runs the file through the
	 * WordPress sideload pipeline to create the attachment. This is
	 * deliberately not `media_sideload_image()` — that helper performs
	 * its own HTTP request which follows redirects and would bypass
	 * SSRF protection (TZ 16.x security fix).
	 *
	 * @since 1.0.0
	 * @since 1.0.0 Replaced media_sideload_image() with a hardened pipeline.
	 * @param string $url        Image URL to download.
	 * @param int    $product_id Product ID to attach to.
	 * @return int|\WP_Error Attachment ID on success, WP_Error on failure.
	 */
	private function download_and_attach_image( string $url, int $product_id ): int|\WP_Error {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		/**
		 * Filters the URL an image is actually fetched from.
		 *
		 * The row keeps a stable address, which is what repeat imports compare;
		 * a source whose files sit behind short-lived links swaps in the link
		 * here, right before the download.
		 *
		 * @since 1.3.0
		 * @param string $url        Image URL from the row.
		 * @param int    $product_id Product the image is for.
		 */
		$fetch = apply_filters( 'mvweb_pi_image_url', $url, $product_id );
		if ( is_wp_error( $fetch ) ) {
			return $fetch;
		}
		$url = (string) $fetch;

		// Download via the SSRF-protected loader to a temp file under uploads/pricelists/.
		$loader   = new MVweb_PI_Loader();
		$path     = wp_parse_url( $url, PHP_URL_PATH ) ?? '';
		$basename = sanitize_file_name( wp_basename( $path ) );
		// Storage links often carry no extension in the path — MoySklad's end in
		// an id and pass the name as `filename=` — and the media library refuses
		// a file it cannot tell the type of by its name.
		parse_str( (string) wp_parse_url( $url, PHP_URL_QUERY ), $query );
		if ( '' === pathinfo( $basename, PATHINFO_EXTENSION ) && ! empty( $query['filename'] ) && is_string( $query['filename'] ) ) {
			$basename = sanitize_file_name( wp_basename( $query['filename'] ) );
		}
		if ( '' === $basename ) {
			$basename = 'image-' . wp_generate_uuid4() . '.jpg';
		}
		$tmp_name = mvweb_pi_get_upload_dir() . 'img-' . wp_generate_uuid4() . '-' . $basename;

		// Suppress per-image log noise. The loader's debug/info lines are
		// useful for the top-level price-list download (one per source), but
		// firing them 1000+ times per import flooded the log with mechanical
		// noise. Image failures are still reported by handle_image() itself.
		// $log=false (no per-image log noise), $check_rebinding=true (SSRF
		// rebinding guard stays on — see Loader::download()).
		$result = $loader->download( $url, $tmp_name, false, true );
		if ( is_wp_error( $result ) ) {
			if ( file_exists( $tmp_name ) ) {
				wp_delete_file( $tmp_name );
			}
			return $result;
		}

		// Still no extension: name the file after what it actually is.
		if ( '' === pathinfo( $basename, PATHINFO_EXTENSION ) ) {
			$mime      = wp_get_image_mime( $tmp_name );
			$extension = $mime ? wp_get_default_extension_for_mime_type( $mime ) : false;
			if ( $extension ) {
				$basename .= '.' . $extension;
			}
		}

		// Sideload the local file into the media library — no HTTP request,
		// no redirect-following, no second SSRF surface.
		$file_array = array(
			'name'     => $basename,
			'tmp_name' => $tmp_name,
		);

		$overrides = array(
			'test_form' => false,
			'test_size' => true,
		);

		$sideload = wp_handle_sideload( $file_array, $overrides );

		if ( isset( $sideload['error'] ) ) {
			if ( file_exists( $tmp_name ) ) {
				wp_delete_file( $tmp_name );
			}
			return new \WP_Error( 'image_sideload_failed', $sideload['error'] );
		}

		// Remove the temp file if wp_handle_sideload() copied rather than moved
		// it. For files that aren't real $_FILES uploads sideload may leave the
		// source behind; across a 1000-image import those orphans pile up in the
		// pricelists dir. The moved/copied destination is $sideload['file'] — only
		// delete the temp when it's a different path that still exists.
		if ( isset( $sideload['file'] ) && $sideload['file'] !== $tmp_name && file_exists( $tmp_name ) ) {
			wp_delete_file( $tmp_name );
		}

		// Create the attachment post.
		$attachment = array(
			'post_mime_type' => $sideload['type'],
			'post_title'     => preg_replace( '/\.[^.]+$/', '', $basename ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		);

		$attach_id = wp_insert_attachment( $attachment, $sideload['file'], $product_id );
		if ( is_wp_error( $attach_id ) || 0 === $attach_id ) {
			return new \WP_Error( 'attachment_insert_failed', __( 'Failed to insert attachment.', 'mvweb-price-importer' ) );
		}

		$metadata = wp_generate_attachment_metadata( $attach_id, $sideload['file'] );
		wp_update_attachment_metadata( $attach_id, $metadata );

		return $attach_id;
	}

	/**
	 * Zero out stock for products missing from the new price list.
	 *
	 * The source of truth is the LIVE catalogue, not a remembered SKU snapshot.
	 * Earlier builds diffed against `mvweb_pi_known_skus` — the SKU set produced
	 * by the previous import. That set only ever held what passed the category
	 * filter on the previous run, so once a feed (or the include filter) narrowed
	 * it shrank, and any product imported under a wider feed fell out of it
	 * permanently: never zeroed, stuck in stock forever. We now read the products
	 * actually present in the managed categories straight from the database and
	 * zero whichever ones the current feed no longer carries — so a product can
	 * never drift out of tracking.
	 *
	 * Honours the include/exclude filter: only products whose category is in
	 * scope of the current filter are candidates, so a narrow include import
	 * never touches products belonging to categories it doesn't cover.
	 *
	 * Products are NOT deleted or unpublished (TZ 6.4) — only stock is zeroed.
	 *
	 * @since 1.0.0
	 * @param string[] $new_skus SKUs present in the current import.
	 * @return void
	 */
	private function zero_missing_stock( array $new_skus ): void {
		// Live catalogue in the categories this import is responsible for.
		$candidates = $this->collect_managed_catalog_skus();
		if ( empty( $candidates ) ) {
			return;
		}

		// Truncated-feed guard. A supplier export can return HTTP 200 with a
		// physically truncated body (CDN hiccup, export crashing mid-write) or a
		// temporarily near-empty feed. Zeroing then would wipe stock on hundreds
		// of live products. Refuse when the feed is suspiciously small versus the
		// catalogue it manages — a real catalogue doesn't lose half its SKUs in
		// one import. Compared against the managed catalogue size, not a remembered
		// snapshot, so a legitimately narrow import isn't blocked forever.
		$threshold = (float) apply_filters( 'mvweb_pi_zero_stock_min_ratio', 0.5 );
		if ( $threshold > 0 && count( $new_skus ) < count( $candidates ) * $threshold ) {
			mvweb_pi_log(
				sprintf(
					/* translators: 1: new SKU count, 2: managed catalogue size */
					__( 'Skipped zeroing stock for missing products: the new feed has %1$d SKUs versus %2$d in the managed catalogue, which looks like a truncated or partial feed. Stock left untouched to avoid wiping the catalogue.', 'mvweb-price-importer' ),
					count( $new_skus ),
					count( $candidates )
				),
				'warning'
			);
			return;
		}

		$new_set      = array_flip( array_map( 'strval', $new_skus ) );
		$zeroed_count = 0;

		// zero_out_product() asks each product whether it has variations. A
		// product that left the feed long ago is asked again on every import, so
		// its terms are read in chunks here rather than one query per product.
		$missing = array();
		foreach ( $candidates as $product_id => $sku ) {
			if ( '' !== $sku && ! isset( $new_set[ $sku ] ) ) {
				$missing[] = (int) $product_id;
			}
		}
		foreach ( array_chunk( $missing, 500 ) as $chunk ) {
			update_object_term_cache( $chunk, 'product' );
		}

		foreach ( $candidates as $product_id => $sku ) {
			// Leave products without a SKU alone — they were not created from a
			// feed offer (manual additions), so the feed can't speak to them.
			if ( '' === $sku || isset( $new_set[ $sku ] ) ) {
				continue;
			}
			// A product that left the price list altogether while an open order
			// still holds units is the sharpest case of all: no delivery is
			// coming at all. The stock is zero either way, so nothing changes
			// in the data — but without this line nobody would hear about it.
			if ( $this->reserved instanceof MVweb_PI_Reserved_Stock ) {
				$held = $this->reserved->held( (int) $product_id );
				if ( $held > 0 ) {
					$this->reserve_short[ $sku ] = $held;
				}
			}

			if ( $this->zero_out_product( (int) $product_id ) ) {
				++$zeroed_count;
			}
		}

		if ( $zeroed_count > 0 ) {
			mvweb_pi_log(
				/* translators: %d: number of products */
				sprintf( __( 'Zeroed stock for %d products no longer in the feed.', 'mvweb-price-importer' ), $zeroed_count ),
				'info'
			);
		}
	}

	/**
	 * Collect SKUs of every product in the categories this import manages.
	 *
	 * Returns the live catalogue the current filter is responsible for, as a
	 * product_id => SKU map, so {@see zero_missing_stock()} can diff it against
	 * the feed without relying on a remembered SKU list. Honours include/exclude
	 * mode; when no category filter is configured, the whole plugin catalogue
	 * (every category in `mvweb_pi_category_map`) is managed.
	 *
	 * @since 1.1.0
	 * @since 1.1.0 Public: the source switch takes its snapshot of the outgoing
	 *               catalogue through this, while the category map that defines
	 *               it is still standing.
	 * @return array<int,string> product_id => SKU.
	 */
	public function collect_managed_catalog_skus(): array {
		$term_ids = $this->get_managed_term_ids();
		if ( empty( $term_ids ) ) {
			return array();
		}

		$catalog    = array();
		$batch_size = 500;
		$paged      = 1;

		do {
			$product_ids = get_posts(
				array(
					'post_type'      => 'product',
					'post_status'    => 'publish',
					'fields'         => 'ids',
					'posts_per_page' => $batch_size,
					'paged'          => $paged,
					'no_found_rows'  => true,
					'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
						array(
							'taxonomy'         => 'product_cat',
							'field'            => 'term_id',
							'terms'            => $term_ids,
							'include_children' => false,
						),
					),
				)
			);
			$product_ids = array_map( 'intval', (array) $product_ids );
			if ( empty( $product_ids ) ) {
				break;
			}

			update_meta_cache( 'post', $product_ids );
			foreach ( $product_ids as $pid ) {
				$catalog[ $pid ] = (string) get_post_meta( $pid, '_sku', true );
			}

			++$paged;
		} while ( count( $product_ids ) === $batch_size );

		return $catalog;
	}

	/**
	 * Resolve the WP term_ids of the categories the current filter manages.
	 *
	 * Walks the feed category tree (`mvweb_pi_category_meta`) and keeps the terms
	 * that the import is responsible for: in include mode the ticked branches, in
	 * exclude mode everything outside them. With no filter configured, every
	 * category the plugin created (`mvweb_pi_category_map`) is managed. Mirrors
	 * the product-side filter so stock-zeroing scope matches what gets imported.
	 *
	 * @since 1.1.0
	 * @return int[] WP product_cat term_ids.
	 */
	private function get_managed_term_ids(): array {
		$map = get_option( 'mvweb_pi_category_map', array() );
		if ( ! is_array( $map ) || empty( $map ) ) {
			return array();
		}

		$ticked = get_option( 'mvweb_pi_excluded_categories', array() );

		// No filter configured — the whole plugin catalogue is managed.
		if ( ! is_array( $ticked ) || empty( $ticked ) ) {
			return array_values( array_filter( array_map( 'intval', $map ), static function ( $t ) {
				return $t > 0;
			} ) );
		}

		$meta = get_option( 'mvweb_pi_category_meta', array() );
		if ( ! is_array( $meta ) ) {
			$meta = array();
		}
		$include    = ( 'include' === get_option( 'mvweb_pi_category_filter_mode', 'exclude' ) );
		$ticked_set = array_flip( array_map( 'strval', $ticked ) );

		$term_ids = array();
		foreach ( $map as $ext_id => $tid ) {
			$tid = (int) $tid;
			if ( $tid <= 0 ) {
				continue;
			}
			$under   = $this->category_under_ticked( (string) $ext_id, $ticked_set, $meta );
			$managed = $include ? $under : ! $under;
			if ( $managed ) {
				$term_ids[] = $tid;
			}
		}

		return array_values( array_unique( $term_ids ) );
	}

	/**
	 * Whether a feed category sits under any ticked branch.
	 *
	 * Walks up the parent chain in the feed tree, with a seen-guard against
	 * malformed cyclic parent_id data.
	 *
	 * @since 1.1.0
	 * @param string                $ext_id     Feed category external id.
	 * @param array<string,int>     $ticked_set Ticked external ids as a lookup set.
	 * @param array<string,mixed[]> $meta       Feed category tree.
	 * @return bool
	 */
	private function category_under_ticked( string $ext_id, array $ticked_set, array $meta ): bool {
		$cursor = $ext_id;
		$seen   = array();
		while ( '' !== $cursor && ! isset( $seen[ $cursor ] ) ) {
			$seen[ $cursor ] = true;
			if ( isset( $ticked_set[ $cursor ] ) ) {
				return true;
			}
			$cursor = (string) ( $meta[ $cursor ]['parent_id'] ?? '' );
		}
		return false;
	}

	/**
	 * Recount product category and tag terms.
	 *
	 * Delegates to WooCommerce's own wc_recount_all_terms(), which recounts
	 * product_cat and product_tag taking visibility (hidden out-of-stock
	 * products) into account. Called once at the end of an import so the term
	 * counts in wp-admin reflect the catalogue after the low-level stock writes,
	 * which never trigger the native term-count hook.
	 *
	 * @since 1.0.15
	 * @return void
	 */
	private function recount_product_terms(): void {
		if ( function_exists( 'wc_recount_all_terms' ) ) {
			wc_recount_all_terms();
		}
	}

	/**
	 * Force a single product out of stock.
	 *
	 * Sets quantity to 0, status to outofstock, syncs the product_visibility
	 * term, zeroes the per-warehouse stock meta, and reseeds the lookup row so
	 * catalog price/stock filters reflect the change. Shared by the "missing
	 * from feed" path (zero_missing_stock) and the duplicate sweep in
	 * process_batch so both apply identical stock-out semantics to every copy
	 * of a SKU.
	 *
	 * Low-level path — mirrors update_product()/create_product() and does NOT
	 * call WC_Product->save(). save() fans out ~30 WooCommerce hooks per call,
	 * so on a feed where hundreds of SKUs disappear at once the old save()-based
	 * sweep cost minutes and timed out mid-import on shared hosting. We write the
	 * stock meta, sync the visibility term, and reseed wc_product_meta_lookup
	 * directly — the same trade-off (skipping the save() hook chain) already made
	 * by create/update. Third-party listeners on woocommerce_product_set_stock*
	 * do not fire here, which is acceptable for a bulk stock-out.
	 *
	 * @since 1.0.11
	 * @since 1.0.19 Low-level path; no WC_Product->save().
	 * @param int $product_id WooCommerce product ID.
	 * @return bool True if the product was zeroed, false if it could not load.
	 */
	private function zero_out_product( int $product_id ): bool {
		if ( $product_id <= 0 ) {
			return false;
		}

		$post = get_post( $product_id );
		if ( ! $post || 'product' !== $post->post_type || 'trash' === $post->post_status ) {
			return false;
		}

		// A product with variations is bought through them, and a variation stays
		// on sale while its parent says nothing. Its own variations from MoySklad
		// are zeroed instead; ones the shop added by hand are not the import's.
		if ( has_term( 'variable', 'product_type', $product_id ) ) {
			$changed = false;
			foreach ( array_keys( $this->our_variations( $product_id ) ) as $variation_id ) {
				if ( $this->zero_variation( $variation_id ) ) {
					self::refresh_product_lookup( $variation_id );
					$changed = true;
				}
			}
			if ( $changed ) {
				self::sync_variable_parent( $product_id );
			}
			return $changed;
		}

		// Track whether anything actually changed. A product already zeroed on a
		// previous run (its SKU stays out of the feed every import) must short-
		// circuit: without this every import would re-run the expensive
		// refresh_product_lookup() on hundreds of long-gone products and the
		// "zeroed N" log would count them as freshly zeroed each time.
		$changed = false;

		// Stock quantity + status, written only on a real diff (update_post_meta
		// is a no-op on an unchanged value but still costs a SELECT).
		if ( '0' !== (string) get_post_meta( $product_id, '_stock', true ) ) {
			update_post_meta( $product_id, '_stock', '0' );
			$changed = true;
		}

		if ( 'outofstock' !== (string) get_post_meta( $product_id, '_stock_status', true ) ) {
			update_post_meta( $product_id, '_stock_status', 'outofstock' );
			$changed = true;

			// Keep the product_visibility 'outofstock' term in sync — WooCommerce
			// hides products carrying it from the catalogue/search when
			// woocommerce_hide_out_of_stock_items is on, and only WC_Product->save()
			// maintains it natively (which this low-level path skips). Written
			// whatever the option says, as WooCommerce itself does. append=true
			// leaves other visibility terms (featured, exclude-from-*) intact.
			wp_set_object_terms( $product_id, 'outofstock', 'product_visibility', true );
		}

		// Zero per-warehouse stocks — only rewrite when a non-zero value remains.
		$stocks = get_post_meta( $product_id, '_mvweb_pi_stocks', true );
		if ( $stocks ) {
			$decoded = json_decode( $stocks, true );
			if ( is_array( $decoded ) && array_filter( $decoded ) ) {
				$zeroed = array_map( function () {
					return 0;
				}, $decoded );
				update_post_meta( $product_id, '_mvweb_pi_stocks', wp_json_encode( $zeroed ) );
				$changed = true;
			}
		}

		// Nothing to do — already fully zeroed on an earlier import.
		if ( ! $changed ) {
			return false;
		}

		// Reseed wc_product_meta_lookup (stock_status column) so catalog stock
		// filters and sort-by reflect the stock-out. WC_Product->save() did this
		// implicitly; the low-level path must do it explicitly.
		self::refresh_product_lookup( $product_id );

		return true;
	}

	/**
	 * Un-hide products left tagged out of stock while their stock says instock.
	 *
	 * Older builds of update_product() changed _stock_status to 'instock' on a
	 * returning SKU without clearing the product_visibility 'outofstock' term
	 * (only WC_Product->save() maintains that term, and the low-level update
	 * path skips it). With woocommerce_hide_out_of_stock_items enabled those
	 * products stayed invisible in the catalogue and search despite being in
	 * stock. This one-shot reconciliation drops the stale term from every such
	 * product in a single DELETE, then fixes the term's count. Idempotent — a
	 * second run finds nothing to remove. Safe to call regardless of the hide
	 * option: an instock product should never carry the term either way.
	 *
	 * @since 1.0.14
	 * @return int Number of products whose stale term was removed.
	 */
	public static function resync_hidden_instock_visibility(): int {
		global $wpdb;

		$tt_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT tt.term_taxonomy_id
				FROM {$wpdb->term_taxonomy} tt
				INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
				WHERE tt.taxonomy = 'product_visibility' AND t.slug = %s",
				'outofstock'
			)
		);

		if ( $tt_id <= 0 ) {
			return 0;
		}

		// Remove the 'outofstock' visibility term wherever the stock meta says
		// instock. One DELETE, indexed joins, no per-row PHP loop — cheap even on
		// a 1400+ product catalogue. The same post types and statuses as
		// resync_outofstock_visibility(), so the pair cannot leave a product
		// tagged in one direction and untouched in the other.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$removed = (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE tr FROM {$wpdb->term_relationships} tr
				INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id
				INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = tr.object_id
				WHERE tr.term_taxonomy_id = %d
				AND p.post_type IN ( 'product', 'product_variation' )
				AND p.post_status IN ( 'publish', 'private' )
				AND pm.meta_key = '_stock_status'
				AND pm.meta_value = 'instock'",
				$tt_id
			)
		);

		if ( $removed > 0 ) {
			// Recount the term natively. wp_update_term_count() takes
			// term_taxonomy_ids and delegates to the taxonomy's registered
			// count callback — WooCommerce's own, which counts only the right
			// post statuses — and clears the term cache itself, so this fixes
			// both the count and the cache after the bulk DELETE above.
			wp_update_term_count( array( $tt_id ), 'product_visibility' );
		}

		return $removed;
	}

	/**
	 * Tag products that are out of stock but carry no visibility term.
	 *
	 * The mirror of resync_hidden_instock_visibility(). Until 1.4.3 the term was
	 * written only while woocommerce_hide_out_of_stock_items was on, and only at
	 * the moment the status changed — so a product that ran out while the option
	 * was off, or that was already out of stock before the plugin maintained the
	 * term at all, never got it and kept showing in a catalogue that is meant to
	 * hide it. One INSERT over the products whose stock meta says outofstock,
	 * then a native recount. Idempotent — a second run finds nothing to add.
	 *
	 * @since 1.4.3
	 * @return int Number of products the term was added to.
	 */
	public static function resync_outofstock_visibility(): int {
		global $wpdb;

		// WooCommerce creates the term on install, so this lookup normally finds
		// it; a shop whose term was deleted gets it back rather than losing the
		// whole migration.
		$term = get_term_by( 'slug', 'outofstock', 'product_visibility' );
		if ( ! $term instanceof \WP_Term ) {
			$created = wp_insert_term( 'outofstock', 'product_visibility' );
			if ( is_wp_error( $created ) ) {
				return 0;
			}
			$term = get_term( (int) $created['term_id'], 'product_visibility' );
		}

		if ( ! $term instanceof \WP_Term ) {
			return 0;
		}

		$tt_id = (int) $term->term_taxonomy_id;

		// Products and variations alike: WooCommerce tags both, and a variation's
		// term is what keeps a sold-out variation out of its parent's price range.
		// IGNORE skips the rows already tagged, which is what makes this idempotent.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$added = (int) $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$wpdb->term_relationships} (object_id, term_taxonomy_id, term_order)
				SELECT p.ID, %d, 0
				FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
				WHERE p.post_type IN ( 'product', 'product_variation' )
				AND p.post_status IN ( 'publish', 'private' )
				AND pm.meta_key = '_stock_status'
				AND pm.meta_value = 'outofstock'",
				$tt_id
			)
		);

		if ( $added > 0 ) {
			wp_update_term_count( array( $tt_id ), 'product_visibility' );

			// Category and tag counts leave hidden products out only while the
			// hide option is on (`_wc_term_recount()` reads the option to decide
			// whether to exclude the term), so with the option off the counts the
			// term just changed are the same counts as before and the recount —
			// the one expensive part of this migration — is skipped. WooCommerce
			// makes the same call conditional for the same reason in
			// wc_recount_after_stock_change().
			if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) && function_exists( 'wc_recount_all_terms' ) ) {
				wc_recount_all_terms();
			}
		}

		return $added;
	}

	/**
	 * Resolve external category ID to WooCommerce term_id.
	 *
	 * Checks the category map option for a cached mapping.
	 * Falls back to searching by name if MVweb_PI_Categories
	 * is not yet implemented (Stage 5).
	 *
	 * @since 1.0.0
	 * @param string $external_id     External category ID from the price list.
	 * @param string $parent_ext_id   External parent category ID (optional).
	 * @return int Term ID or 0 if not found.
	 */
	private function resolve_category( string $external_id, string $parent_ext_id = '' ): int {
		if ( empty( $external_id ) ) {
			return 0;
		}

		// Load category map once (populated by MVweb_PI_Categories).
		if ( null === $this->category_map ) {
			$this->category_map = get_option( 'mvweb_pi_category_map', array() );
			if ( ! is_array( $this->category_map ) ) {
				$this->category_map = array();
			}
		}

		if ( isset( $this->category_map[ $external_id ] ) ) {
			$term_id = absint( $this->category_map[ $external_id ] );
			// Validate that the cached id still refers to a live product_cat
			// term — a manual DB cleanup (or syncing from a fresh dump)
			// can drop the wp_term_taxonomy row while the option survives,
			// and wp_set_object_terms() then silently no-ops on a missing
			// term. The MVweb_PI_Categories::import() pass that runs
			// before each batch already re-creates the term and refreshes
			// the option, so it's enough to re-read on a miss.
			if ( $term_id > 0 && term_exists( $term_id, 'product_cat' ) ) {
				return $term_id;
			}
			$this->category_map = get_option( 'mvweb_pi_category_map', array() );
			if ( ! is_array( $this->category_map ) ) {
				$this->category_map = array();
			}
			if ( isset( $this->category_map[ $external_id ] ) ) {
				$term_id = absint( $this->category_map[ $external_id ] );
				if ( $term_id > 0 && term_exists( $term_id, 'product_cat' ) ) {
					return $term_id;
				}
			}
		}

		return 0;
	}

	/**
	 * Resolve a tag rule to its product_tag term, creating it on first use.
	 *
	 * Identity lives in the term meta `mvweb_pi_tag_key`, never in the term's
	 * name or slug: the whole point is that the shop owner can rename "sellout"
	 * to "Распродажа" in Products → Tags and keep that rename across imports.
	 * The option is only a lookup cache in front of that meta, exactly as
	 * mvweb_pi_category_map is for categories.
	 *
	 * Unlike resolve_category(), this creates the term when it is missing —
	 * categories get their own pre-pass before the products stream, tags have
	 * none, so the first product that needs a tag brings it into being.
	 *
	 * @since 1.0.27
	 * @param array $rule   Tag rule (key, source, match, label).
	 * @param bool  $create Create the term when it does not exist yet. False
	 *                      for a flag that reads "no": there is nothing to
	 *                      remove from a product if the tag was never created.
	 * @return int Term ID, or 0 when the term could not be resolved or created.
	 */
	private function resolve_tag_term( array $rule, bool $create = true ): int {
		$key   = (string) ( $rule['key'] ?? '' );
		$label = (string) ( $rule['label'] ?? '' );

		if ( '' === $key || '' === $label ) {
			return 0;
		}

		if ( ! $create && isset( $this->tag_missing[ $key ] ) ) {
			return 0;
		}

		if ( null === $this->tag_map ) {
			$this->tag_map = get_option( 'mvweb_pi_tag_map', array() );
			if ( ! is_array( $this->tag_map ) ) {
				$this->tag_map = array();
			}
		}

		// 1. Cache hit. The mapped term is validated once per run — it can have
		// been deleted by hand between imports, but not during one.
		if ( isset( $this->tag_map[ $key ] ) ) {
			$term_id = absint( $this->tag_map[ $key ] );
			if ( isset( $this->tag_verified[ $key ] ) ) {
				return $term_id;
			}
			if ( $term_id > 0 && term_exists( $term_id, 'product_tag' ) ) {
				$this->tag_verified[ $key ] = true;
				return $term_id;
			}
			unset( $this->tag_map[ $key ] );
		}

		// 2. Source of truth: the term carrying our key.
		$existing = get_terms(
			array(
				'taxonomy'   => 'product_tag',
				'meta_key'   => 'mvweb_pi_tag_key', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value' => $key, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'hide_empty' => false,
				'fields'     => 'ids',
				'number'     => 1,
			)
		);

		if ( ! empty( $existing ) && ! is_wp_error( $existing ) ) {
			return $this->remember_tag_term( $key, (int) $existing[0] );
		}

		// The flag says "no" and no term exists: nothing to take off the
		// product, and creating an empty tag would only litter the catalogue.
		if ( ! $create ) {
			$this->tag_missing[ $key ] = true;
			return 0;
		}

		// 3. Create it. Transliterated slug for the same reason categories use
		// one: sanitize_title() leaves Cyrillic percent-encoded on hosts with
		// no transliteration filter, which bloats the slug column.
		$result = wp_insert_term(
			$label,
			'product_tag',
			array( 'slug' => MVweb_PI_Categories::build_slug( $label ) )
		);

		if ( is_wp_error( $result ) ) {
			// A tag with this name already exists — most likely one the shop
			// owner created by hand. Adopt it: the operator was warned about
			// exactly this when the rule was saved. Logged so the takeover
			// stays visible afterwards.
			if ( 'term_exists' === $result->get_error_code() ) {
				$term_id = (int) $result->get_error_data();
				if ( $term_id > 0 ) {
					mvweb_pi_log(
						sprintf(
							/* translators: %s: tag name */
							__( 'Existing product tag "%s" is now managed by an import rule.', 'mvweb-price-importer' ),
							$label
						),
						'warning'
					);
					return $this->remember_tag_term( $key, $term_id );
				}
			}

			mvweb_pi_log(
				sprintf(
					/* translators: 1: tag name, 2: error message */
					__( 'Failed to create product tag "%1$s": %2$s', 'mvweb-price-importer' ),
					$label,
					$result->get_error_message()
				),
				'error'
			);
			return 0;
		}

		return $this->remember_tag_term( $key, (int) $result['term_id'] );
	}

	/**
	 * Bind a term to a tag rule and persist the lookup cache.
	 *
	 * Written straight to the option rather than at the end of the run: terms
	 * are created a handful of times in the lifetime of a rule, and every cron
	 * continuation starts with an empty in-memory map.
	 *
	 * @since 1.0.27
	 * @param string $key     Rule key.
	 * @param int    $term_id Term ID.
	 * @return int The same term ID, for chaining.
	 */
	private function remember_tag_term( string $key, int $term_id ): int {
		if ( $term_id <= 0 ) {
			return 0;
		}

		update_term_meta( $term_id, 'mvweb_pi_tag_key', $key );

		$this->tag_map[ $key ]      = $term_id;
		$this->tag_verified[ $key ] = true;
		unset( $this->tag_missing[ $key ] );
		update_option( 'mvweb_pi_tag_map', $this->tag_map, false );

		return $term_id;
	}

	/**
	 * Write weight and GTIN, where the source supplied them.
	 *
	 * Both keys are absent unless the source has a value, and absence leaves the
	 * stored value alone — a weight typed into WooCommerce by hand survives a
	 * source that does not know it.
	 *
	 * Weight arrives in kilograms and is stored in the shop's own unit.
	 *
	 * The GTIN needs care this path otherwise skips. WooCommerce keeps GTINs
	 * unique, but only its setter checks that, and the importer writes meta
	 * directly. Two products sharing a barcode is a supplier error the importer
	 * already meets elsewhere; writing the second one silently would leave two
	 * products answering to the same GTIN on every marketplace that reads it. So
	 * the second is not written, and the log says which product holds it.
	 *
	 * @since 1.3.0
	 * @param int   $product_id Product ID.
	 * @param array $data       Normalised product row.
	 * @return void
	 */
	private function apply_measures( int $product_id, array $data ): void {
		if ( isset( $data['weight'] ) && (float) $data['weight'] > 0 && function_exists( 'wc_get_weight' ) ) {
			$unit   = (string) get_option( 'woocommerce_weight_unit', 'kg' );
			$weight = wc_format_decimal( wc_get_weight( (float) $data['weight'], $unit, 'kg' ) );

			if ( (string) get_post_meta( $product_id, '_weight', true ) !== (string) $weight ) {
				update_post_meta( $product_id, '_weight', $weight );
			}
		}

		$gtin = isset( $data['gtin'] ) ? preg_replace( '/[^0-9Xx\-]/', '', (string) $data['gtin'] ) : '';
		if ( '' === $gtin || ! function_exists( 'wc_get_product_id_by_global_unique_id' ) ) {
			return;
		}

		if ( (string) get_post_meta( $product_id, '_global_unique_id', true ) === $gtin ) {
			return;
		}

		$holder = (int) wc_get_product_id_by_global_unique_id( $gtin );
		if ( $holder > 0 && $holder !== $product_id ) {
			mvweb_pi_log(
				sprintf(
					/* translators: 1: GTIN, 2: SKU of the product being imported, 3: ID of the product that already has the GTIN */
					__( 'GTIN %1$s was not given to %2$s: product #%3$d already has it. WooCommerce keeps GTINs unique — check the barcodes in the source.', 'mvweb-price-importer' ),
					$gtin,
					(string) ( $data['sku'] ?? '' ),
					$holder
				),
				'warning'
			);
			return;
		}

		update_post_meta( $product_id, '_global_unique_id', $gtin );
	}

	/**
	 * Set a product's attribute terms from the source.
	 *
	 * Written low-level like the rest of this importer, which leaves the two
	 * things WC_Product->save() would do otherwise to be done here: the
	 * `_product_attributes` list that makes the attribute show on the product
	 * page, and the lookup table the storefront's attribute filters read from.
	 * The lookup update is only asked for when a term actually changed — it goes
	 * through WooCommerce's own queue, and a catalogue whose attributes did not
	 * move should not fill that queue on every import.
	 *
	 * Only the taxonomies passed in are touched: attributes the shop added by
	 * hand stay, both as terms and in the product's attribute list. A taxonomy
	 * that is passed in is MoySklad's on the products it imports — including an
	 * attribute the shop already had under the same name, which the settings
	 * screen reuses rather than duplicating. A value typed into that attribute
	 * by hand on such a product is replaced by what MoySklad says, and removed
	 * when MoySklad says nothing.
	 *
	 * @since 1.3.0
	 * @param int                   $product_id Product ID.
	 * @param array<string, string> $attributes Taxonomy => term name, '' to clear.
	 * @param bool                  $is_new     True for a freshly created product.
	 * @return void
	 */
	private function apply_attributes( int $product_id, array $attributes, bool $is_new = false ): void {
		$list    = get_post_meta( $product_id, '_product_attributes', true );
		$list    = is_array( $list ) ? $list : array();
		$changed = false;

		foreach ( $attributes as $taxonomy => $name ) {
			$taxonomy = (string) $taxonomy;
			$name     = (string) $name;

			if ( ! taxonomy_exists( $taxonomy ) ) {
				if ( ! isset( $this->attribute_missing[ $taxonomy ] ) ) {
					$this->attribute_missing[ $taxonomy ] = true;
					mvweb_pi_log(
						sprintf(
							/* translators: %s: attribute taxonomy name */
							__( 'Attribute %s does not exist in WooCommerce any more. Open the MoySklad tab and save it to create it again.', 'mvweb-price-importer' ),
							$taxonomy
						),
						'warning'
					);
				}
				continue;
			}

			$current = array();
			if ( ! $is_new ) {
				$terms   = get_the_terms( $product_id, $taxonomy );
				$current = is_array( $terms ) ? array_map( 'intval', wp_list_pluck( $terms, 'term_id' ) ) : array();
			}

			$wanted = '' === $name ? array() : array( $this->attribute_term( $taxonomy, $name ) );
			$wanted = array_values( array_filter( $wanted ) );

			sort( $current );
			if ( $current !== $wanted ) {
				wp_set_object_terms( $product_id, $wanted, $taxonomy, false );
				$changed = true;
			}

			$slug = sanitize_title( $taxonomy );
			if ( empty( $wanted ) ) {
				if ( isset( $list[ $slug ] ) ) {
					unset( $list[ $slug ] );
					$changed = true;
				}
			} elseif ( ! isset( $list[ $slug ] ) ) {
				$list[ $slug ] = array(
					'name'         => $taxonomy,
					'value'        => '',
					'position'     => count( $list ),
					'is_visible'   => 1,
					'is_variation' => 0,
					'is_taxonomy'  => 1,
				);
				$changed       = true;
			}
		}

		if ( ! $changed ) {
			return;
		}

		update_post_meta( $product_id, '_product_attributes', $list );

		self::refresh_attribute_filters( $product_id );
	}

	/**
	 * Bring the storefront's attribute filter table up to date for a product.
	 *
	 * WooCommerce queues the work itself; for a product with variations it
	 * rebuilds the rows of every variation too. Public for the stock sync, which
	 * changes whether a variation is in stock — a column of that table.
	 *
	 * @since 1.3.0
	 * @param int $product_id Product ID.
	 * @return void
	 */
	public static function refresh_attribute_filters( int $product_id ): void {
		if ( ! function_exists( 'wc_get_container' ) || ! class_exists( '\Automattic\WooCommerce\Internal\ProductAttributesLookup\LookupDataStore' ) ) {
			return;
		}

		try {
			wc_get_container()
				->get( \Automattic\WooCommerce\Internal\ProductAttributesLookup\LookupDataStore::class )
				->on_product_changed( $product_id );
		} catch ( \Throwable $e ) {
			mvweb_pi_log(
				/* translators: 1: product ID, 2: error message */
				sprintf( __( 'Could not refresh attribute filters for #%1$d: %2$s', 'mvweb-price-importer' ), $product_id, $e->getMessage() ),
				'warning'
			);
		}
	}

	/**
	 * Term ID for an attribute value, created the first time it is seen.
	 *
	 * @since 1.3.0
	 * @param string $taxonomy Attribute taxonomy.
	 * @param string $name     Term name.
	 * @return int Term ID, or 0 when it could not be created.
	 */
	private function attribute_term( string $taxonomy, string $name ): int {
		$key = $taxonomy . "\0" . mb_strtolower( $name, 'UTF-8' );
		if ( isset( $this->attribute_terms[ $key ] ) ) {
			return $this->attribute_terms[ $key ];
		}

		$term = get_term_by( 'name', $name, $taxonomy );
		if ( $term instanceof \WP_Term ) {
			$this->attribute_terms[ $key ] = (int) $term->term_id;
			return (int) $term->term_id;
		}

		$result = wp_insert_term( $name, $taxonomy, array( 'slug' => MVweb_PI_Categories::build_slug( $name ) ) );
		if ( is_wp_error( $result ) ) {
			// Two values that differ only in case or spacing share a slug; the
			// term that already holds it is the same value.
			$existing = 'term_exists' === $result->get_error_code() ? (int) $result->get_error_data() : 0;
			if ( $existing <= 0 ) {
				mvweb_pi_log(
					sprintf(
						/* translators: 1: value, 2: attribute taxonomy, 3: error message */
						__( 'Could not add the value "%1$s" to attribute %2$s: %3$s', 'mvweb-price-importer' ),
						$name,
						$taxonomy,
						$result->get_error_message()
					),
					'warning'
				);
			}
			$this->attribute_terms[ $key ] = $existing;
			return $existing;
		}

		$this->attribute_terms[ $key ] = (int) $result['term_id'];
		return (int) $result['term_id'];
	}

	/**
	 * Is this a product whose variations were put together by hand?
	 *
	 * Variations the import writes carry the MoySklad id; a product that has
	 * variations and not one of them with an id was built in WooCommerce.
	 *
	 * @since 1.3.0
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	private function has_handmade_variations( int $product_id ): bool {
		if ( ! has_term( 'variable', 'product_type', $product_id ) ) {
			return false;
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS total, COUNT(ms.meta_id) AS ours
				FROM {$wpdb->posts} p
				LEFT JOIN {$wpdb->postmeta} ms ON ms.post_id = p.ID AND ms.meta_key = %s
				WHERE p.post_parent = %d
				AND p.post_type = 'product_variation'
				AND p.post_status != 'trash'",
				MVweb_PI_Stock_Sync::ID_META,
				$product_id
			)
		);

		$total = $row ? (int) $row->total : 0;
		$ours  = $row ? (int) $row->ours : 0;

		// Remembered for apply_variation_attributes(): a product can carry MoySklad's
		// variations and one added by hand beside them.
		$this->handmade_variations[ $product_id ] = $total - $ours;

		return $total > 0 && 0 === $ours;
	}

	/**
	 * Storefront prices for a product or variation row.
	 *
	 * A row marked `no_retail` has a wholesale price and no retail one. It goes
	 * in with an empty regular price, so WooCommerce shows no price of its own
	 * and the price-list feed leaves it out. Its selling price is empty too —
	 * WooCommerce then offers no way to buy it — unless the operator lets such
	 * products be ordered at the wholesale price. A sale price does not apply to
	 * a product that has no regular price to be on sale from.
	 *
	 * @since 1.4.0
	 * @param array  $data Normalised row.
	 * @param string $sale Sale price in force, or ''.
	 * @return array{regular: string, effective: string, no_retail: bool}
	 */
	private function storefront_prices( array $data, string $sale ): array {
		if ( empty( $data['no_retail'] ) ) {
			$regular = (string) ( $data['price'] ?? '' );

			return array(
				'regular'   => $regular,
				'effective' => '' !== $sale ? $sale : $regular,
				'no_retail' => false,
			);
		}

		if ( null === $this->no_retail_mode ) {
			$this->no_retail_mode = mvweb_pi_no_retail_mode();
		}

		$wholesale = ( ! empty( $data['wholesale_price'] ) && $data['wholesale_price'] > 0 ) ? (string) $data['wholesale_price'] : '';

		return array(
			'regular'   => '',
			'effective' => 'wholesale' === $this->no_retail_mode ? $wholesale : '',
			'no_retail' => true,
		);
	}

	/**
	 * Mark or unmark a product as having no retail price.
	 *
	 * The mark is what the storefront reads to put a dash and the wholesale price
	 * where the price would be. It is removed as soon as a retail price arrives.
	 *
	 * @since 1.4.0
	 * @param int  $id        Product or variation id.
	 * @param bool $no_retail Whether the product has no retail price.
	 * @return bool Whether the stored mark changed.
	 */
	private function sync_no_retail_mark( int $id, bool $no_retail ): bool {
		$marked = '1' === (string) get_post_meta( $id, '_mvweb_pi_no_retail', true );
		if ( $marked === $no_retail ) {
			return false;
		}

		if ( $no_retail ) {
			update_post_meta( $id, '_mvweb_pi_no_retail', '1' );
		} else {
			delete_post_meta( $id, '_mvweb_pi_no_retail' );
		}

		return true;
	}

	/**
	 * Make a product simple or variable, as MoySklad now has it.
	 *
	 * Simple to variable: the product's own price and stock go — they belong to
	 * the variations from now on, and a variable product that kept them would
	 * show a stale price in the catalogue until something saved it. Variable to
	 * simple: every stored price row goes before the simple path writes one,
	 * since a variable product keeps a row per distinct variation price and
	 * updating the meta would set all of them to one value; the variations are
	 * disabled rather than deleted, so an order that bought one still shows it.
	 * WooCommerce's own type switch deletes them outright.
	 *
	 * Grouped and external products never get here with variants —
	 * process_batch() leaves them out.
	 *
	 * @since 1.3.0
	 * @param int  $product_id Product ID.
	 * @param bool $variable   Whether MoySklad has variants for it.
	 * @return void
	 */
	private function switch_product_type( int $product_id, bool $variable ): void {
		if ( has_term( 'variable', 'product_type', $product_id ) === $variable ) {
			return;
		}

		if ( $variable ) {
			wp_set_object_terms( $product_id, 'variable', 'product_type', false );
			update_post_meta( $product_id, '_manage_stock', 'no' );
			foreach ( array( '_stock', '_mvweb_pi_stocks', '_regular_price', '_sale_price', '_price', '_mvweb_pi_wholesale_price', '_mvweb_pi_dealer_price', '_mvweb_pi_no_retail' ) as $key ) {
				delete_post_meta( $product_id, $key );
			}
		} else {
			delete_post_meta( $product_id, '_price' );
			wp_set_object_terms( $product_id, 'simple', 'product_type', false );
			// The attributes the variations were chosen by go too: a simple
			// product would keep showing every colour it no longer comes in. An
			// extra field on the same attribute is written back right after.
			$this->apply_variation_attributes( $product_id, array(), false );
			self::refresh_attribute_filters( $product_id );
			foreach ( $this->our_variations( $product_id ) as $variation_id => $status ) {
				if ( $this->disable_variation( $variation_id, $status ) ) {
					++$this->stats['variations_disabled'];
				}
			}
		}

		self::forget_product( $product_id );

		mvweb_pi_log(
			sprintf(
				$variable
					/* translators: %d: product ID */
					? __( 'Product #%d has variants in MoySklad now and became a variable product.', 'mvweb-price-importer' )
					/* translators: %d: product ID */
					: __( 'Product #%d has no variants in MoySklad any more and became a simple product; its variations are disabled.', 'mvweb-price-importer' ),
				$product_id
			),
			'info'
		);
	}

	/**
	 * Write a variable product's variations and bring the product in line.
	 *
	 * Variations are found by their MoySklad id, never by SKU: a variant's code
	 * is generated by MoySklad and may be edited, the id may not. One found
	 * under another product — the product was re-created under a new article —
	 * is moved to this one. A variation MoySklad no longer has is disabled, not
	 * deleted: orders keep pointing at it, and it comes back if the variant does.
	 * Variations made in WooCommerce without an id are never touched.
	 *
	 * @since 1.3.0
	 * @param int   $parent_id Product ID.
	 * @param array $data      Normalised product row with `variations`.
	 * @param bool  $is_new    True for a product created in this call.
	 * @return void
	 */
	private function write_variations( int $parent_id, array $data, bool $is_new ): void {
		$incoming = array();
		foreach ( (array) ( $data['variations'] ?? array() ) as $variation ) {
			if ( is_array( $variation ) && '' !== (string) ( $variation['ms_id'] ?? '' ) && ! empty( $variation['attributes'] ) ) {
				$incoming[ (string) $variation['ms_id'] ] = $variation;
			}
		}

		// One variation per MoySklad id, the lowest ID. A second one under this
		// product — meta copied by hand — would stay on sale beside it unseen,
		// so it is disabled like a variant MoySklad dropped. Copies under another
		// product, as WooCommerce's Duplicate leaves them, are that product's.
		$existing   = array();
		$duplicates = array();
		foreach ( $this->find_variations( $parent_id, array_keys( $incoming ) ) as $found ) {
			if ( ! isset( $existing[ $found['ms_id'] ] ) ) {
				$existing[ $found['ms_id'] ] = $found;
			} elseif ( $found['post_parent'] === $parent_id ) {
				$duplicates[] = $found;
			}
		}
		if ( ! empty( $existing ) ) {
			_prime_post_caches( array_map( 'intval', array_column( $existing, 'ID' ) ) );
		}

		$changed = $this->apply_variation_attributes( $parent_id, $incoming, $is_new );
		$filters = $changed;
		$title   = (string) get_post_field( 'post_title', $parent_id );

		$position = 0;
		foreach ( $incoming as $ms_id => $variation ) {
			$found = $existing[ $ms_id ] ?? null;

			if ( null === $found ) {
				if ( $this->create_variation( $parent_id, $title, $variation, $position ) > 0 ) {
					++$this->stats['variations_created'];
					$changed = true;
					$filters = true;
				}
			} else {
				$result = $this->update_variation( $found, $parent_id, $title, $variation, $position );
				if ( $result > 0 ) {
					++$this->stats['variations_updated'];
					$changed = true;
					$filters = $filters || 2 === $result;
				}
			}

			++$position;
		}

		$gone = array_filter(
			$existing,
			static function ( $found ) use ( $incoming, $parent_id ) {
				return ! isset( $incoming[ $found['ms_id'] ] ) && $found['post_parent'] === $parent_id;
			}
		);

		foreach ( array_merge( array_values( $gone ), $duplicates ) as $found ) {
			if ( $this->disable_variation( (int) $found['ID'], (string) $found['post_status'] ) ) {
				++$this->stats['variations_disabled'];
				$changed = true;
				$filters = true;
			}
		}

		if ( $changed || $is_new ) {
			self::sync_variable_parent( $parent_id );
		}

		// The filter table holds a row per variation, with its stock status: a
		// price or quantity change alone does not move it.
		if ( $filters ) {
			self::refresh_attribute_filters( $parent_id );
		}
	}

	/**
	 * Variations carrying these MoySklad ids or belonging to this product.
	 *
	 * @since 1.3.0
	 * @param int      $parent_id Product ID.
	 * @param string[] $ms_ids    MoySklad variant ids.
	 * @return array<int, array{ID: int, post_parent: int, post_status: string, ms_id: string}> Lowest ID first.
	 */
	private function find_variations( int $parent_id, array $ms_ids ): array {
		global $wpdb;

		$args  = array( MVweb_PI_Stock_Sync::ID_META, $parent_id );
		$by_id = '';
		if ( ! empty( $ms_ids ) ) {
			$by_id = ' OR ms.meta_value IN (' . implode( ',', array_fill( 0, count( $ms_ids ), '%s' ) ) . ')';
			$args  = array_merge( $args, $ms_ids );
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID, p.post_parent, p.post_status, ms.meta_value AS ms_id
				FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} ms ON ms.post_id = p.ID AND ms.meta_key = %s
				WHERE p.post_type = 'product_variation'
				AND p.post_status != 'trash'
				AND ( p.post_parent = %d{$by_id} )
				ORDER BY p.ID ASC",
				$args
			),
			ARRAY_A
		);
		// phpcs:enable

		$found = array();
		foreach ( (array) $rows as $row ) {
			$found[] = array(
				'ID'          => (int) $row['ID'],
				'post_parent' => (int) $row['post_parent'],
				'post_status' => (string) $row['post_status'],
				'ms_id'       => (string) $row['ms_id'],
			);
		}

		return $found;
	}

	/**
	 * This product's variations that came from MoySklad.
	 *
	 * @since 1.3.0
	 * @param int $parent_id Product ID.
	 * @return array<int, string> Variation ID => post status.
	 */
	private function our_variations( int $parent_id ): array {
		$ours = array();
		foreach ( $this->find_variations( $parent_id, array() ) as $found ) {
			$ours[ $found['ID'] ] = $found['post_status'];
		}

		return $ours;
	}

	/**
	 * Set the attributes a variable product's variations are chosen by.
	 *
	 * The terms are the values its variations have, and nothing else: a value
	 * no variant uses any more leaves the product. An attribute an earlier
	 * import used for variations and no variant has now is taken off too.
	 * Attributes that are not for variations — extra fields, ones added by
	 * hand — are left where they are.
	 *
	 * @since 1.3.0
	 * @param int     $parent_id Product ID.
	 * @param array[] $incoming  Variation rows.
	 * @param bool    $is_new    True for a product created in this call.
	 * @return bool Whether anything changed.
	 */
	private function apply_variation_attributes( int $parent_id, array $incoming, bool $is_new ): bool {
		$values = array();
		foreach ( $incoming as $variation ) {
			foreach ( (array) $variation['attributes'] as $taxonomy => $name ) {
				$values[ (string) $taxonomy ][ mb_strtolower( (string) $name, 'UTF-8' ) ] = (string) $name;
			}
		}

		$list    = get_post_meta( $parent_id, '_product_attributes', true );
		$list    = is_array( $list ) ? $list : array();
		$changed = false;
		$kept    = ( ! $is_new && ( $this->handmade_variations[ $parent_id ] ?? 0 ) > 0 )
			? $this->handmade_variation_terms( $parent_id )
			: array();

		foreach ( $list as $slug => $entry ) {
			$taxonomy = (string) ( $entry['name'] ?? '' );
			if ( ! empty( $entry['is_variation'] ) && ! empty( $entry['is_taxonomy'] ) && ! isset( $values[ $taxonomy ] ) && ! isset( $kept[ $taxonomy ] ) ) {
				wp_set_object_terms( $parent_id, array(), $taxonomy, false );
				unset( $list[ $slug ] );
				$changed = true;
			}
		}

		foreach ( $values as $taxonomy => $names ) {
			if ( ! taxonomy_exists( $taxonomy ) ) {
				if ( ! isset( $this->attribute_missing[ $taxonomy ] ) ) {
					$this->attribute_missing[ $taxonomy ] = true;
					mvweb_pi_log(
						sprintf(
							/* translators: %s: attribute taxonomy name */
							__( 'Attribute %s does not exist in WooCommerce any more, so variations are not told apart by it in this run. The next import creates it again.', 'mvweb-price-importer' ),
							$taxonomy
						),
						'warning'
					);
				}
				continue;
			}

			$wanted = array();
			foreach ( $names as $name ) {
				$term_id = $this->attribute_term( $taxonomy, $name );
				if ( $term_id > 0 ) {
					$wanted[ $term_id ] = $term_id;
				}
			}
			// A value only a hand-made variation uses stays on the product, or
			// that variation could no longer be chosen.
			foreach ( $kept[ $taxonomy ] ?? array() as $term_id ) {
				$wanted[ $term_id ] = $term_id;
			}
			$wanted = array_values( $wanted );
			sort( $wanted );

			$current = array();
			if ( ! $is_new ) {
				$terms   = get_the_terms( $parent_id, $taxonomy );
				$current = is_array( $terms ) ? array_map( 'intval', wp_list_pluck( $terms, 'term_id' ) ) : array();
				sort( $current );
			}

			if ( $current !== $wanted ) {
				wp_set_object_terms( $parent_id, $wanted, $taxonomy, false );
				$changed = true;
			}

			$slug  = sanitize_title( $taxonomy );
			$entry = array(
				'name'         => $taxonomy,
				'value'        => '',
				'position'     => isset( $list[ $slug ]['position'] ) ? (int) $list[ $slug ]['position'] : count( $list ),
				'is_visible'   => 1,
				'is_variation' => 1,
				'is_taxonomy'  => 1,
			);
			// Loose on purpose: WooCommerce stores the numbers as strings or
			// integers depending on who saved the product last.
			if ( ( $list[ $slug ] ?? null ) != $entry ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseNotEqual
				$list[ $slug ] = $entry;
				$changed       = true;
			}
		}

		if ( $changed ) {
			update_post_meta( $parent_id, '_product_attributes', $list );
			if ( class_exists( 'WC_Cache_Helper' ) ) {
				\WC_Cache_Helper::invalidate_attribute_count( array_keys( $values ) );
			}
		}

		return $changed;
	}

	/**
	 * Attribute terms the product's hand-made variations are chosen by.
	 *
	 * @since 1.3.0
	 * @param int $parent_id Product ID.
	 * @return array<string, int[]> Taxonomy => term IDs.
	 */
	private function handmade_variation_terms( int $parent_id ): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DISTINCT pm.meta_key, pm.meta_value
				FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key LIKE %s
				LEFT JOIN {$wpdb->postmeta} ms ON ms.post_id = p.ID AND ms.meta_key = %s
				WHERE p.post_parent = %d
				AND p.post_type = 'product_variation'
				AND p.post_status != 'trash'
				AND ms.meta_id IS NULL",
				$wpdb->esc_like( 'attribute_pa_' ) . '%',
				MVweb_PI_Stock_Sync::ID_META,
				$parent_id
			),
			ARRAY_A
		);

		$kept = array();
		foreach ( (array) $rows as $row ) {
			$taxonomy = substr( (string) $row['meta_key'], strlen( 'attribute_' ) );
			$term     = '' !== (string) $row['meta_value'] ? get_term_by( 'slug', (string) $row['meta_value'], $taxonomy ) : false;
			if ( $term instanceof \WP_Term ) {
				$kept[ $taxonomy ][] = (int) $term->term_id;
			}
		}

		return $kept;
	}

	/**
	 * Create one variation.
	 *
	 * @since 1.3.0
	 * @param int    $parent_id Product ID.
	 * @param string $title     Product title.
	 * @param array  $variation Variation row.
	 * @param int    $position  Order among the product's variations.
	 * @return int Variation ID, 0 on failure.
	 */
	private function create_variation( int $parent_id, string $title, array $variation, int $position ): int {
		$id = wp_insert_post(
			array(
				'post_type'    => 'product_variation',
				'post_parent'  => $parent_id,
				'post_status'  => 'publish',
				'post_title'   => self::variation_title( $title, $variation['attributes'] ),
				'post_excerpt' => self::variation_summary( $variation['attributes'] ),
				'menu_order'   => $position,
				// Written with the post itself: a batch cut short and run again
				// finds the variation by this id rather than creating it twice.
				'meta_input'   => array( MVweb_PI_Stock_Sync::ID_META => sanitize_text_field( (string) $variation['ms_id'] ) ),
			),
			true
		);

		if ( is_wp_error( $id ) || ! $id ) {
			mvweb_pi_log(
				sprintf(
					/* translators: 1: variation SKU, 2: error message */
					__( 'Error creating variation %1$s: %2$s', 'mvweb-price-importer' ),
					(string) $variation['sku'],
					is_wp_error( $id ) ? $id->get_error_message() : ''
				),
				'error'
			);
			++$this->stats['errors'];
			return 0;
		}

		foreach ( $this->variation_slugs( $variation['attributes'] ) as $taxonomy => $slug ) {
			update_post_meta( $id, 'attribute_' . $taxonomy, $slug );
		}

		$this->write_variation_sku( $id, (string) $variation['sku'] );

		$prices = $this->storefront_prices( $variation, '' );
		update_post_meta( $id, '_regular_price', $prices['regular'] );
		update_post_meta( $id, '_price', $prices['effective'] );
		$this->sync_no_retail_mark( $id, $prices['no_retail'] );
		if ( ! empty( $variation['wholesale_price'] ) && $variation['wholesale_price'] > 0 ) {
			update_post_meta( $id, '_mvweb_pi_wholesale_price', (string) $variation['wholesale_price'] );
		}
		if ( ! empty( $variation['dealer_price'] ) && $variation['dealer_price'] > 0 ) {
			update_post_meta( $id, '_mvweb_pi_dealer_price', (string) $variation['dealer_price'] );
		}

		$stock = $this->available_stock( $id, (int) $variation['stock'], (string) $variation['sku'] );
		update_post_meta( $id, '_manage_stock', 'yes' );
		update_post_meta( $id, '_stock', (string) $stock );
		update_post_meta( $id, '_stock_status', $stock > 0 ? 'instock' : 'outofstock' );
		// WooCommerce marks an out-of-stock variation whatever the shop's
		// hide-out-of-stock option says; the product's price range reads it.
		if ( $stock <= 0 ) {
			wp_set_object_terms( $id, 'outofstock', 'product_visibility', false );
		}

		update_post_meta( $id, '_mvweb_pi_stocks', wp_json_encode( (array) ( $variation['stocks'] ?? array() ) ) );
		if ( ! empty( $variation['barcode'] ) ) {
			update_post_meta( $id, '_mvweb_pi_barcode', sanitize_text_field( (string) $variation['barcode'] ) );
		}

		update_post_meta( $id, '_virtual', 'no' );
		update_post_meta( $id, '_downloadable', 'no' );
		update_post_meta( $id, '_tax_status', 'taxable' );
		update_post_meta( $id, '_tax_class', 'parent' );
		update_post_meta( $id, '_backorders', 'no' );
		// Without a version WooCommerce treats the product as older than 2.4
		// and walks every variation's meta to rebuild the attributes on sync.
		update_post_meta( $id, '_product_version', defined( 'WC_VERSION' ) ? WC_VERSION : '' );

		$this->apply_measures( $id, $variation );

		if ( self::IMAGE_MODE_NEVER !== $this->get_image_mode() ) {
			$this->handle_image( $id, (string) ( $variation['image'] ?? '' ) );
		}

		self::refresh_product_lookup( $id );

		return (int) $id;
	}

	/**
	 * Update one variation, writing only what differs.
	 *
	 * @since 1.3.0
	 * @param array  $found     Row from {@see find_variations()}.
	 * @param int    $parent_id Product ID.
	 * @param string $title     Product title.
	 * @param array  $variation Variation row.
	 * @param int    $position  Order among the product's variations.
	 * @return int 0 unchanged, 1 changed, 2 changed including its stock status.
	 */
	private function update_variation( array $found, int $parent_id, string $title, array $variation, int $position ): int {
		$id   = (int) $found['ID'];
		$post = get_post( $id );
		if ( ! $post ) {
			return 0;
		}

		$changed        = false;
		$status_changed = false;

		$update = array();
		if ( (int) $post->post_parent !== $parent_id ) {
			$update['post_parent'] = $parent_id;
		}
		if ( 'publish' !== $post->post_status && '' !== (string) get_post_meta( $id, self::DISABLED_META, true ) ) {
			$update['post_status'] = 'publish';
			delete_post_meta( $id, self::DISABLED_META );
		}
		$new_title = self::variation_title( $title, $variation['attributes'] );
		if ( $post->post_title !== $new_title ) {
			$update['post_title'] = $new_title;
		}
		$summary = self::variation_summary( $variation['attributes'] );
		if ( $post->post_excerpt !== $summary ) {
			$update['post_excerpt'] = $summary;
		}
		if ( (int) $post->menu_order !== $position ) {
			$update['menu_order'] = $position;
		}
		if ( ! empty( $update ) ) {
			$update['ID'] = $id;
			wp_update_post( $update );
			$changed = true;
		}

		$slugs = $this->variation_slugs( $variation['attributes'] );
		$meta  = get_post_meta( $id );
		foreach ( $slugs as $taxonomy => $slug ) {
			if ( (string) ( $meta[ 'attribute_' . $taxonomy ][0] ?? '' ) !== $slug ) {
				update_post_meta( $id, 'attribute_' . $taxonomy, $slug );
				$changed = true;
			}
		}
		foreach ( array_keys( (array) $meta ) as $key ) {
			if ( str_starts_with( (string) $key, 'attribute_' ) && ! isset( $slugs[ substr( (string) $key, 10 ) ] ) ) {
				delete_post_meta( $id, (string) $key );
				$changed = true;
			}
		}

		$sku_before = (string) get_post_meta( $id, '_sku', true );
		$this->write_variation_sku( $id, (string) $variation['sku'] );
		$changed = $changed || (string) get_post_meta( $id, '_sku', true ) !== $sku_before;

		// A sale price set by hand on the variation stands; MoySklad has none.
		$sale   = (string) get_post_meta( $id, '_sale_price', true );
		$prices = $this->storefront_prices( $variation, $sale );
		if ( (string) get_post_meta( $id, '_regular_price', true ) !== $prices['regular'] ) {
			update_post_meta( $id, '_regular_price', $prices['regular'] );
			$changed = true;
		}
		if ( (string) get_post_meta( $id, '_price', true ) !== $prices['effective'] ) {
			update_post_meta( $id, '_price', $prices['effective'] );
			$changed = true;
		}
		$changed = $this->sync_no_retail_mark( $id, $prices['no_retail'] ) || $changed;

		$b2b = array(
			'wholesale_price' => '_mvweb_pi_wholesale_price',
			'dealer_price'    => '_mvweb_pi_dealer_price',
		);
		foreach ( $b2b as $key => $meta_key ) {
			if ( ! empty( $variation[ $key ] ) && $variation[ $key ] > 0 && (string) get_post_meta( $id, $meta_key, true ) !== (string) $variation[ $key ] ) {
				update_post_meta( $id, $meta_key, (string) $variation[ $key ] );
				$changed = true;
			}
		}

		$stock  = $this->available_stock( $id, (int) $variation['stock'], (string) $variation['sku'] );
		$status = $stock > 0 ? 'instock' : 'outofstock';
		if ( (string) get_post_meta( $id, '_stock', true ) !== (string) $stock ) {
			update_post_meta( $id, '_stock', (string) $stock );
			$changed = true;
		}
		if ( (string) get_post_meta( $id, '_stock_status', true ) !== $status ) {
			update_post_meta( $id, '_stock_status', $status );
			if ( 'instock' === $status ) {
				wp_remove_object_terms( $id, 'outofstock', 'product_visibility' );
			} else {
				wp_set_object_terms( $id, 'outofstock', 'product_visibility', true );
			}
			$changed        = true;
			$status_changed = true;
		}
		if ( 'yes' !== (string) get_post_meta( $id, '_manage_stock', true ) ) {
			update_post_meta( $id, '_manage_stock', 'yes' );
			$changed = true;
		}

		$stocks = (string) wp_json_encode( (array) ( $variation['stocks'] ?? array() ) );
		if ( (string) get_post_meta( $id, '_mvweb_pi_stocks', true ) !== $stocks ) {
			update_post_meta( $id, '_mvweb_pi_stocks', $stocks );
			$changed = true;
		}

		if ( ! empty( $variation['barcode'] ) ) {
			$barcode = sanitize_text_field( (string) $variation['barcode'] );
			if ( (string) get_post_meta( $id, '_mvweb_pi_barcode', true ) !== $barcode ) {
				update_post_meta( $id, '_mvweb_pi_barcode', $barcode );
				$changed = true;
			}
		}

		$gtin_before = (string) get_post_meta( $id, '_global_unique_id', true );
		$this->apply_measures( $id, $variation );
		$changed = $changed || (string) get_post_meta( $id, '_global_unique_id', true ) !== $gtin_before;

		$mode = $this->get_image_mode();
		if ( self::IMAGE_MODE_ALWAYS === $mode || self::IMAGE_MODE_SMART === $mode ) {
			$this->handle_image( $id, (string) ( $variation['image'] ?? '' ) );
		}

		if ( $changed ) {
			self::refresh_product_lookup( $id );
		}

		if ( $status_changed ) {
			return 2;
		}

		return $changed ? 1 : 0;
	}

	/**
	 * Give a variation its SKU, unless another product already has it.
	 *
	 * WooCommerce keeps SKUs unique across products and variations, and only
	 * its setter checks. A variation left without one shows the product's SKU.
	 *
	 * @since 1.3.0
	 * @param int    $id  Variation ID.
	 * @param string $sku SKU.
	 * @return void
	 */
	private function write_variation_sku( int $id, string $sku ): void {
		if ( '' === $sku || (string) get_post_meta( $id, '_sku', true ) === $sku ) {
			return;
		}

		if ( function_exists( 'wc_product_has_unique_sku' ) && ! wc_product_has_unique_sku( $id, $sku ) ) {
			mvweb_pi_log(
				sprintf(
					/* translators: 1: SKU, 2: variation ID */
					__( 'SKU %1$s was not given to variation #%2$d: another product already has it. WooCommerce keeps SKUs unique — check the articles and codes in MoySklad.', 'mvweb-price-importer' ),
					$sku,
					$id
				),
				'warning'
			);
			return;
		}

		update_post_meta( $id, '_sku', $sku );
	}

	/**
	 * Take a variation MoySklad no longer has off sale.
	 *
	 * Private is WooCommerce's own "disabled" for a variation. The mark tells a
	 * variation the import disabled from one the shop switched off by hand, so
	 * only the first is switched back on when the variant returns.
	 *
	 * @since 1.3.0
	 * @param int    $id     Variation ID.
	 * @param string $status Its post status.
	 * @return bool Whether anything changed.
	 */
	private function disable_variation( int $id, string $status ): bool {
		$changed = $this->zero_variation( $id );

		if ( 'publish' === $status ) {
			wp_update_post(
				array(
					'ID'          => $id,
					'post_status' => 'private',
				)
			);
			update_post_meta( $id, self::DISABLED_META, '1' );
			$changed = true;
		}

		if ( $changed ) {
			self::refresh_product_lookup( $id );
		}

		return $changed;
	}

	/**
	 * Put a variation at zero stock, per warehouse too.
	 *
	 * @since 1.3.0
	 * @param int $id Variation ID.
	 * @return bool Whether anything changed.
	 */
	private function zero_variation( int $id ): bool {
		$changed = false;

		if ( '0' !== (string) get_post_meta( $id, '_stock', true ) ) {
			update_post_meta( $id, '_stock', '0' );
			$changed = true;
		}

		if ( 'outofstock' !== (string) get_post_meta( $id, '_stock_status', true ) ) {
			update_post_meta( $id, '_stock_status', 'outofstock' );
			wp_set_object_terms( $id, 'outofstock', 'product_visibility', true );
			$changed = true;
		}

		$stocks = json_decode( (string) get_post_meta( $id, '_mvweb_pi_stocks', true ), true );
		if ( is_array( $stocks ) && array_filter( $stocks ) ) {
			update_post_meta( $id, '_mvweb_pi_stocks', wp_json_encode( array_fill_keys( array_keys( $stocks ), 0 ) ) );
			$changed = true;
		}

		return $changed;
	}

	/**
	 * Attribute term slugs a variation is stored with.
	 *
	 * @since 1.3.0
	 * @param array<string, string> $attributes Taxonomy => value.
	 * @return array<string, string> Taxonomy => term slug.
	 */
	private function variation_slugs( array $attributes ): array {
		$slugs = array();

		foreach ( $attributes as $taxonomy => $name ) {
			if ( ! taxonomy_exists( (string) $taxonomy ) ) {
				continue;
			}

			$term_id = $this->attribute_term( (string) $taxonomy, (string) $name );
			$term    = $term_id > 0 ? get_term( $term_id, (string) $taxonomy ) : null;
			if ( $term instanceof \WP_Term ) {
				$slugs[ (string) $taxonomy ] = $term->slug;
			}
		}

		return $slugs;
	}

	/**
	 * A variation's title, by WooCommerce's own rule.
	 *
	 * The product title, followed by the values when there are fewer than three
	 * attributes and, with two, neither name has a hyphen. Kept identical so
	 * saving the variation by hand does not rename it.
	 *
	 * @since 1.3.0
	 * @param string                $title      Product title.
	 * @param array<string, string> $attributes Taxonomy => value.
	 * @return string
	 */
	private static function variation_title( string $title, array $attributes ): string {
		$include = count( $attributes ) < 3;
		if ( $include && count( $attributes ) > 1 ) {
			foreach ( array_keys( $attributes ) as $taxonomy ) {
				if ( str_contains( (string) $taxonomy, '-' ) ) {
					$include = false;
					break;
				}
			}
		}

		return $include ? $title . ' - ' . implode( ', ', array_values( $attributes ) ) : $title;
	}

	/**
	 * A variation's attribute summary, "Colour: Red, Size: M".
	 *
	 * @since 1.3.0
	 * @param array<string, string> $attributes Taxonomy => value.
	 * @return string
	 */
	private static function variation_summary( array $attributes ): string {
		$parts = array();
		foreach ( $attributes as $taxonomy => $name ) {
			$label   = function_exists( 'wc_attribute_label' ) ? wc_attribute_label( (string) $taxonomy ) : (string) $taxonomy;
			$parts[] = $label . ': ' . $name;
		}

		return implode( ', ', $parts );
	}

	/**
	 * Bring a variable product's price and stock status in line with its variations.
	 *
	 * WooCommerce's own sync, without the save that follows it everywhere else:
	 * that save costs as much as the whole low-level write it would follow. The
	 * sync writes the price rows and the lookup itself; the stock status it only
	 * works out, and is written here the way the rest of the importer writes it.
	 *
	 * The caches go first. WooCommerce remembers a product's type and its list
	 * of children, and a product that was simple a moment ago would otherwise be
	 * loaded as simple — the sync would then do nothing and say nothing.
	 *
	 * @since 1.3.0
	 * @param int $parent_id Product ID.
	 * @return void
	 */
	public static function sync_variable_parent( int $parent_id ): void {
		if ( ! class_exists( 'WC_Product_Variable' ) ) {
			return;
		}

		self::forget_product( $parent_id );

		$product = wc_get_product( $parent_id );
		if ( ! $product instanceof \WC_Product_Variable ) {
			return;
		}

		\WC_Product_Variable::sync( $product, false );

		$status = (string) $product->get_stock_status();
		if ( (string) get_post_meta( $parent_id, '_stock_status', true ) !== $status ) {
			update_post_meta( $parent_id, '_stock_status', $status );

			if ( 'outofstock' === $status ) {
				wp_set_object_terms( $parent_id, 'outofstock', 'product_visibility', true );
			} else {
				wp_remove_object_terms( $parent_id, 'outofstock', 'product_visibility' );
			}
		}

		self::refresh_product_lookup( $parent_id );

		// The object built above still holds the status it was loaded with.
		self::forget_product( $parent_id );
	}

	/**
	 * Drop what WooCommerce and WordPress remember about a product.
	 *
	 * @since 1.3.0
	 * @param int $product_id Product ID.
	 * @return void
	 */
	private static function forget_product( int $product_id ): void {
		delete_transient( 'wc_product_children_' . $product_id );
		delete_transient( 'wc_var_prices_' . $product_id );
		clean_post_cache( $product_id );

		if ( class_exists( 'WC_Cache_Helper' ) ) {
			\WC_Cache_Helper::invalidate_cache_group( 'product_' . $product_id );
		}

		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' )
			&& class_exists( '\Automattic\WooCommerce\Internal\Caches\ProductCache' )
			&& \Automattic\WooCommerce\Utilities\FeaturesUtil::feature_is_enabled( 'product_instance_caching' ) ) {
			wc_get_container()->get( \Automattic\WooCommerce\Internal\Caches\ProductCache::class )->remove( $product_id );
		}
	}

	/**
	 * Split resolved tag flags into term IDs to add and term IDs to remove.
	 *
	 * @since 1.0.27
	 * @param array<string, bool> $flags Rule key => flag state, from the Converter.
	 * @return array{0: int[], 1: int[]} Term IDs wanted, term IDs unwanted.
	 */
	private function tag_term_ids( array $flags ): array {
		if ( empty( $flags ) ) {
			return array( array(), array() );
		}

		if ( null === $this->tag_rules ) {
			$this->tag_rules = array();
			foreach ( (array) get_option( 'mvweb_pi_tag_rules', array() ) as $rule ) {
				if ( ! empty( $rule['key'] ) ) {
					$this->tag_rules[ (string) $rule['key'] ] = $rule;
				}
			}

			// MoySklad's flag fields are rules too, kept with the rest of that
			// source's settings rather than in the Mapping tab's option: that tab
			// rewrites its option from the form on every save of the settings
			// screen, and would wipe them.
			$ms = get_option( 'mvweb_pi_moysklad', array() );
			foreach ( (array) ( is_array( $ms ) ? ( $ms['attribute_rules'] ?? array() ) : array() ) as $field_id => $rule ) {
				if ( 'tag' === ( $rule['as'] ?? '' ) && '' !== (string) ( $rule['label'] ?? '' ) ) {
					$key                     = MVweb_PI_MoySklad_Source::tag_key( (string) $field_id );
					$this->tag_rules[ $key ] = array(
						'key'   => $key,
						'label' => (string) $rule['label'],
					);
				}
			}
		}

		$wanted   = array();
		$unwanted = array();

		foreach ( $flags as $key => $state ) {
			if ( ! isset( $this->tag_rules[ $key ] ) ) {
				continue;
			}

			$term_id = $this->resolve_tag_term( $this->tag_rules[ $key ], (bool) $state );
			if ( $term_id <= 0 ) {
				continue;
			}

			if ( $state ) {
				$wanted[] = $term_id;
			} else {
				$unwanted[] = $term_id;
			}
		}

		return array( $wanted, $unwanted );
	}

	/**
	 * Apply resolved tag flags to a product.
	 *
	 * Reads the product's current tags through get_the_terms(), which serves
	 * them from the term cache process_batch() primes for the whole batch —
	 * wp_get_object_terms() would go to the database once per product instead.
	 * Writes only on an actual difference, so a catalogue whose flags did not
	 * change costs no queries at all.
	 *
	 * append = true on the add, and a targeted removal for the rest: a plain
	 * wp_set_object_terms() with append = false would wipe every tag the shop
	 * owner attached outside the importer.
	 *
	 * @since 1.0.27
	 * @param int                 $product_id Product ID.
	 * @param array<string, bool> $flags      Rule key => flag state.
	 * @param bool                $is_new     True for a freshly created product.
	 * @return void
	 */
	private function apply_tags( int $product_id, array $flags, bool $is_new = false ): void {
		list( $wanted, $unwanted ) = $this->tag_term_ids( $flags );

		if ( empty( $wanted ) && empty( $unwanted ) ) {
			return;
		}

		// A product created moments ago carries no relationships yet, so there
		// is nothing to read and nothing to remove.
		if ( $is_new ) {
			if ( ! empty( $wanted ) ) {
				wp_set_object_terms( $product_id, $wanted, 'product_tag', true );
			}
			return;
		}

		$current     = get_the_terms( $product_id, 'product_tag' );
		$current_ids = is_array( $current ) ? array_map( 'intval', wp_list_pluck( $current, 'term_id' ) ) : array();

		$add    = array_values( array_diff( $wanted, $current_ids ) );
		$remove = array_values( array_intersect( $unwanted, $current_ids ) );

		if ( ! empty( $add ) ) {
			wp_set_object_terms( $product_id, $add, 'product_tag', true );
		}

		if ( ! empty( $remove ) ) {
			wp_remove_object_terms( $product_id, $remove, 'product_tag' );
		}
	}

	/**
	 * Reconcile newly excluded categories with the existing catalog.
	 *
	 * When the operator ticks a category in the "Excluded categories"
	 * UI, the converter starts filtering its SKUs out of the feed
	 * stream — but the products it created on earlier runs are still
	 * in WooCommerce. This pass closes that loop: every excluded
	 * branch (the category itself plus its descendants in the
	 * `mvweb_pi_category_meta` tree) gets its products force-deleted
	 * via `wp_delete_post( $id, true )` (skips trash so the SKU is
	 * free for re-import), and the term itself is removed via
	 * `wp_delete_term()`. We also wipe the corresponding entry from
	 * `mvweb_pi_category_map` so the next run doesn't accidentally
	 * resurrect the term through the cache. `mvweb_pi_known_skus`
	 * gets the removed SKUs subtracted so `zero_missing_stock()`
	 * doesn't try to act on them as "missing from the feed".
	 *
	 * Idempotent — re-running it after everything is clean does
	 * nothing.
	 *
	 * Honours the include/exclude filter mode: in exclude mode the ticked
	 * branches are the ones to drop; in include mode it is the INVERSE — every
	 * category that does NOT sit under a ticked branch is the one to drop, so
	 * the closure is built by negating the per-category branch test. This
	 * mirrors the product filter in the converter; without it, include mode
	 * would delete exactly the categories the operator wants to keep.
	 *
	 * @since 1.0.7
	 * @since 1.0.16 Honours include/exclude filter mode.
	 * @return void
	 */
	private function reconcile_excluded_categories(): void {
		$ticked = get_option( 'mvweb_pi_excluded_categories', array() );
		if ( ! is_array( $ticked ) || empty( $ticked ) ) {
			return;
		}

		$meta = get_option( 'mvweb_pi_category_meta', array() );
		if ( ! is_array( $meta ) ) {
			$meta = array();
		}

		$mode    = get_option( 'mvweb_pi_category_filter_mode', 'exclude' );
		$include = ( 'include' === $mode );

		// For each category, is it under any ticked branch? Walk up the parent
		// chain in $meta. The closure (categories to DROP) is then:
		//   exclude mode → categories under a ticked branch
		//   include mode → categories NOT under a ticked branch (the inverse)
		$ticked_set = array_flip( array_map( 'strval', $ticked ) );
		$closure    = array();
		foreach ( $meta as $ext_id => $row ) {
			$cursor = (string) $ext_id;
			$seen   = array();
			$in_set = false;
			while ( '' !== $cursor && ! isset( $seen[ $cursor ] ) ) {
				$seen[ $cursor ] = true;
				if ( isset( $ticked_set[ $cursor ] ) ) {
					$in_set = true;
					break;
				}
				$cursor = (string) ( $meta[ $cursor ]['parent_id'] ?? '' );
			}

			$drop = $include ? ! $in_set : $in_set;
			if ( $drop ) {
				$closure[ (string) $ext_id ] = true;
			}
		}

		if ( empty( $closure ) ) {
			return;
		}

		$map = get_option( 'mvweb_pi_category_map', array() );
		if ( ! is_array( $map ) ) {
			$map = array();
		}

		$term_ids_to_drop = array();
		foreach ( array_keys( $closure ) as $ext_id ) {
			$tid = (int) ( $map[ (string) $ext_id ] ?? 0 );
			if ( $tid > 0 && term_exists( $tid, 'product_cat' ) ) {
				$term_ids_to_drop[ $tid ] = $ext_id;
			}
		}

		if ( empty( $term_ids_to_drop ) ) {
			return;
		}

		// Delete every product attached to any of these terms, in pages rather
		// than one posts_per_page=-1 query: a wide include-mode exclusion on a
		// large catalogue could otherwise pull thousands of IDs into memory at
		// once. We always read page 1 because each deletion shrinks the result
		// set — the next batch's "page 1" is the previous page 2. Attached via
		// `_mvweb_pi_feed_cat_term_id` is intentional: this also catches
		// manually-categorised products sharing the term, which is what
		// excluding the whole category opts into.
		$removed_skus = array();
		$batch_size   = 200;
		$prev_batch   = array();

		do {
			$product_ids = get_posts(
				array(
					'post_type'      => 'product',
					'post_status'    => 'any',
					'fields'         => 'ids',
					'posts_per_page' => $batch_size,
					'no_found_rows'  => true,
					'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
						array(
							'taxonomy'         => 'product_cat',
							'field'            => 'term_id',
							'terms'            => array_keys( $term_ids_to_drop ),
							'include_children' => false,
						),
					),
				)
			);
			$product_ids = array_map( 'intval', (array) $product_ids );

			// Stall guard: if this page returns the exact same IDs as the last
			// one, nothing got deleted (e.g. a third-party pre_delete_post filter
			// is blocking wp_delete_post on these products). Without this the
			// always-page-1 loop would spin forever on the same rows. Bail and
			// log rather than hang the import.
			if ( ! empty( $product_ids ) && $product_ids === $prev_batch ) {
				mvweb_pi_log(
					sprintf(
						/* translators: %d: number of products that could not be deleted */
						__( 'Reconcile stalled: %d products could not be deleted (deletion blocked). Skipping the rest.', 'mvweb-price-importer' ),
						count( $product_ids )
					),
					'warning'
				);
				break;
			}
			$prev_batch = $product_ids;

			foreach ( $product_ids as $pid ) {
				$sku = (string) get_post_meta( $pid, '_sku', true );
				if ( '' !== $sku ) {
					$removed_skus[] = $sku;
				}
				wp_delete_post( $pid, true );
			}

			// Keep the object cache from growing unbounded across pages.
			wp_cache_flush();
		} while ( count( $product_ids ) === $batch_size );

		foreach ( $term_ids_to_drop as $tid => $ext_id ) {
			wp_delete_term( (int) $tid, 'product_cat' );
			unset( $map[ (string) $ext_id ] );
		}

		update_option( 'mvweb_pi_category_map', $map );

		// Subtract removed SKUs from known_skus so the next pass
		// doesn't treat them as "missing from this import" and try
		// to zero out stock on already-deleted posts.
		if ( ! empty( $removed_skus ) ) {
			$known = get_option( 'mvweb_pi_known_skus', array() );
			if ( is_array( $known ) ) {
				$known = array_values( array_diff( $known, $removed_skus ) );
				update_option( 'mvweb_pi_known_skus', $known, false );
			}
		}

		mvweb_pi_log(
			sprintf(
				/* translators: 1: number of categories removed, 2: number of products removed */
				__( 'Excluded categories reconciled: %1$d categories and %2$d products removed.', 'mvweb-price-importer' ),
				count( $term_ids_to_drop ),
				count( $removed_skus )
			),
			'info'
		);
	}

	/**
	 * Remove categories that vanished from the price list.
	 *
	 * A category deleted on the supplier's side stops appearing in the feed
	 * tree, but its term and products stay in WooCommerce forever — the
	 * stock-out pass only zeroes the products, so the branch keeps showing in
	 * the storefront. This pass closes that loop: the term is deleted and its
	 * products go to the trash, where they stay recoverable for the WordPress
	 * retention window. A trashed SKU is invisible to
	 * {@see resolve_all_ids_by_skus()}, so a product the supplier brings back
	 * later returns as a fresh row rather than being silently revived.
	 *
	 * Deleting is irreversible, and a supplier export can lie — an HTTP 200
	 * with a truncated body drops categories that were never really gone.
	 * Three guards stand in the way:
	 *
	 * - A feed that lost more than a tenth of the mapped categories at once is
	 *   treated as truncated: nothing is deleted and the run logs a warning.
	 * - A category whose subcategories are still alive keeps its term.
	 *   `wp_delete_term()` re-parents orphaned children to the grandparent,
	 *   which would strand a live branch at the top of the catalogue.
	 * - A category still holding products the current feed lists is left
	 *   alone — the feed contradicts itself, and guessing costs data.
	 *
	 * A fourth guard lives in {@see MVweb_PI_Cron::run()}, which switches this
	 * pass off entirely when a multi-warehouse run could not download every
	 * source: the missing warehouse takes its whole branch of the tree with it.
	 *
	 * Deepest categories are processed first, so a vanished branch collapses
	 * from its leaves upwards within a single run.
	 *
	 * @since 1.1.0
	 * @param string[] $feed_skus Every SKU the current feed carries.
	 * @return void
	 */
	private function remove_vanished_categories( array $feed_skus ): void {
		/**
		 * Filters whether categories missing from the feed are deleted.
		 *
		 * @since 1.1.0
		 * @param bool $enabled Whether to delete vanished categories.
		 */
		if ( ! apply_filters( 'mvweb_pi_delete_vanished_categories', true ) ) {
			return;
		}

		$map  = get_option( 'mvweb_pi_category_map', array() );
		$tree = get_option( 'mvweb_pi_category_meta', array() );

		// An empty tree means the feed carried no categories at all — that is a
		// broken export, not a supplier deleting their whole catalogue.
		if ( ! is_array( $map ) || empty( $map ) || ! is_array( $tree ) || empty( $tree ) ) {
			return;
		}

		$vanished = array();
		foreach ( $map as $ext_id => $term_id ) {
			$term_id = (int) $term_id;
			if ( $term_id > 0 && ! isset( $tree[ (string) $ext_id ] ) ) {
				$vanished[ (string) $ext_id ] = $term_id;
			}
		}

		if ( empty( $vanished ) ) {
			return;
		}

		/**
		 * Filters the share of mapped categories that must survive an import
		 * before any deletion is allowed.
		 *
		 * @since 1.1.0
		 * @param float $min_ratio Minimum surviving share, 0..1. Zero disables the guard.
		 */
		$min_ratio = (float) apply_filters( 'mvweb_pi_vanished_min_ratio', 0.9 );

		/**
		 * Filters how many categories may vanish before the share is consulted.
		 *
		 * @since 1.1.0
		 * @param int $free_count Vanished categories always allowed through.
		 */
		$free_count = (int) apply_filters( 'mvweb_pi_vanished_free_count', 5 );

		// The share alone would freeze small catalogues: on a ten-category feed
		// a single deleted category is already a tenth of the tree. A handful of
		// categories therefore passes on its own; the share only speaks up once
		// the loss is big enough in absolute terms to look like a broken export.
		$surviving = count( $map ) - count( $vanished );

		if ( $min_ratio > 0 && count( $vanished ) > $free_count && $surviving < count( $map ) * $min_ratio ) {
			mvweb_pi_log(
				sprintf(
					/* translators: 1: number of categories missing from the feed, 2: number of mapped categories */
					__( 'Skipped removing categories missing from the price list: %1$d of %2$d mapped categories are gone at once, which looks like a truncated feed. Nothing deleted.', 'mvweb-price-importer' ),
					count( $vanished ),
					count( $map )
				),
				'warning'
			);
			return;
		}

		// Deepest first, so children are gone by the time their parent is
		// considered and the parent can pass the live-children check. Depths are
		// resolved once up front — inside the comparator they would be
		// recomputed on every comparison.
		$depths = array();
		foreach ( $vanished as $ext_id => $term_id ) {
			$depths[ $ext_id ] = count( get_ancestors( $term_id, 'product_cat', 'taxonomy' ) );
		}
		uksort(
			$vanished,
			static function ( $a, $b ) use ( $depths ) {
				return ( $depths[ $b ] ?? 0 ) <=> ( $depths[ $a ] ?? 0 );
			}
		);

		$feed_set      = array_flip( array_map( 'strval', $feed_skus ) );
		$removed_count = 0;
		$trashed_total = 0;
		$map_changed   = false;

		foreach ( $vanished as $ext_id => $term_id ) {
			$term = get_term( $term_id, 'product_cat' );

			// The map outlived the term (deleted by hand in wp-admin). Drop the
			// stale row so the next run doesn't reconsider it.
			if ( ! $term instanceof WP_Term ) {
				unset( $map[ $ext_id ] );
				$map_changed = true;
				continue;
			}

			$children = get_terms(
				array(
					'taxonomy'   => 'product_cat',
					'parent'     => $term_id,
					'hide_empty' => false,
					'fields'     => 'ids',
				)
			);

			// A failed lookup is not an empty one: deleting a branch we could
			// not inspect is the outcome nobody can undo.
			if ( is_wp_error( $children ) ) {
				mvweb_pi_log(
					sprintf(
						/* translators: %s: category name */
						__( 'Could not check the subcategories of "%s" — the category is left in place.', 'mvweb-price-importer' ),
						$term->name
					),
					'warning'
				);
				continue;
			}

			if ( ! empty( $children ) ) {
				mvweb_pi_log(
					sprintf(
						/* translators: 1: category name, 2: number of subcategories */
						__( 'Category "%1$s" is missing from the price list but still has %2$d subcategories in the catalogue — left in place.', 'mvweb-price-importer' ),
						$term->name,
						count( $children )
					),
					'warning'
				);
				continue;
			}

			// Read the whole category before touching anything: a single product
			// the feed still lists keeps the category, and trashing half of its
			// neighbours first would leave the catalogue in a state that depends
			// on the order rows came back in.
			$products = $this->collect_category_products( $term_id, $feed_set );

			$trashed = 0;
			if ( is_array( $products ) ) {
				foreach ( $products as $product_id ) {
					if ( wp_trash_post( $product_id ) ) {
						++$trashed;
					}
				}

				if ( $trashed > 0 ) {
					// Keep the object cache from carrying the whole branch.
					wp_cache_flush();
				}
			}

			$trashed_total += $trashed;

			// Anything left means the feed still lists those products, or a
			// third-party filter blocked the trashing. Either way the term keeps
			// its contents and must stay.
			if ( ! $this->category_is_empty( $term_id ) ) {
				mvweb_pi_log(
					sprintf(
						/* translators: %s: category name */
						__( 'Category "%s" is missing from the price list but still holds products — left in place.', 'mvweb-price-importer' ),
						$term->name
					),
					'warning'
				);
				continue;
			}

			wp_delete_term( $term_id, 'product_cat' );
			unset( $map[ $ext_id ] );
			$map_changed = true;

			++$removed_count;

			mvweb_pi_log(
				sprintf(
					/* translators: 1: category name, 2: number of products moved to trash */
					__( 'Removed category "%1$s" (missing from the price list); %2$d products moved to trash.', 'mvweb-price-importer' ),
					$term->name,
					$trashed
				),
				'info'
			);
		}

		if ( $map_changed ) {
			update_option( 'mvweb_pi_category_map', $map, false );
		}

		if ( $removed_count > 0 ) {
			mvweb_pi_log(
				sprintf(
					/* translators: 1: number of categories, 2: number of products */
					__( 'Removed %1$d categories missing from the price list, with %2$d products moved to trash.', 'mvweb-price-importer' ),
					$removed_count,
					$trashed_total
				),
				'info'
			);
		}
	}

	/**
	 * Move every product of one category to the trash.
	 *
	 * Products the current feed still lists are skipped — see
	 * {@see remove_vanished_categories()} for why. Reading happens in ordered
	 * pages and changes nothing, so paging by offset is exact; the caller does
	 * the trashing afterwards on the complete list. Bailing on the first
	 * still-listed product also saves reading the rest of a category that is
	 * going to stay anyway.
	 *
	 * @since 1.1.0
	 * @param int               $term_id  Category term ID.
	 * @param array<string,int> $feed_set SKUs of the current feed as a lookup set.
	 * @return int[]|null Product IDs to trash, or null when the feed still lists one of them.
	 */
	private function collect_category_products( int $term_id, array $feed_set ): ?array {
		$collected  = array();
		$batch_size = 200;
		$paged      = 1;

		do {
			$product_ids = get_posts(
				array(
					'post_type'      => 'product',
					'post_status'    => 'any',
					'fields'         => 'ids',
					'posts_per_page' => $batch_size,
					'paged'          => $paged,
					'orderby'        => 'ID',
					'order'          => 'ASC',
					'no_found_rows'  => true,
					'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
						array(
							'taxonomy'         => 'product_cat',
							'field'            => 'term_id',
							'terms'            => array( $term_id ),
							'include_children' => false,
						),
					),
				)
			);
			$product_ids = array_map( 'intval', (array) $product_ids );
			$page_size   = count( $product_ids );

			foreach ( $product_ids as $product_id ) {
				$sku = (string) get_post_meta( $product_id, '_sku', true );
				if ( '' !== $sku && isset( $feed_set[ $sku ] ) ) {
					return null;
				}

				$collected[] = $product_id;
			}

			++$paged;
		} while ( $page_size === $batch_size );

		return $collected;
	}

	/**
	 * Whether a category holds no products outside the trash.
	 *
	 * @since 1.1.0
	 * @param int $term_id Category term ID.
	 * @return bool
	 */
	private function category_is_empty( int $term_id ): bool {
		$product_ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => 1,
				'no_found_rows'  => true,
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					array(
						'taxonomy'         => 'product_cat',
						'field'            => 'term_id',
						'terms'            => array( $term_id ),
						'include_children' => false,
					),
				),
			)
		);

		return empty( $product_ids );
	}

	/**
	 * Get current import statistics.
	 *
	 * @since 1.0.0
	 * @return array{created: int, updated: int, skipped: int, errors: int}
	 */
	public function get_stats(): array {
		return $this->stats;
	}
}
