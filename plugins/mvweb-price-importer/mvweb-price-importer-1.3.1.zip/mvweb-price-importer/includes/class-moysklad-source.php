<?php
/**
 * MoySklad catalogue source.
 *
 * Turns the JSON API into the same normalised product rows the price-list
 * converter produces, so the importer downstream cannot tell the two apart.
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_MoySklad_Source
 *
 * The catalogue is fetched once per run into a local file, and the import then
 * streams that file. Reading the API straight into the importer looks simpler
 * on paper and is worse in practice: a web import runs in 50-second slices, and
 * resuming a slice means starting the stream again — which for an HTTP source
 * is re-downloading every page already processed, on every continuation, purely
 * to throw the results away. Spent against an account that gets blocked for an
 * hour after too many rejected requests, that is the one mistake worth
 * designing out. Fetched into a file, a resume rewinds a local disk, which is
 * exactly what the price-list path already does well.
 *
 * The dump is written under a temporary name and moved into place only once the
 * last page has arrived. A half-written dump must never reach the importer: it
 * would look like a catalogue that had lost most of its products, and the
 * import would take the missing ones off sale.
 *
 * @since 1.1.0
 */
class MVweb_PI_MoySklad_Source {

	/**
	 * Products per assortment page. The API's ceiling.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const PAGE = 1000;

	/**
	 * How many rows are checked against the catalogue in one query.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const LOOKUP_CHUNK = 200;

	/**
	 * File name prefix of a catalogue dump in the current shape.
	 *
	 * @since 1.3.0
	 * @var string
	 */
	const DUMP_PREFIX = 'moysklad-catalog-v2-';

	/**
	 * Option mapping MoySklad characteristic ids to attribute taxonomies.
	 *
	 * Kept apart from the MoySklad settings: those are rebuilt from the form on
	 * every save of the tab, and this map is written by the import.
	 *
	 * @since 1.3.0
	 * @var string
	 */
	const CHARACTERISTICS_OPTION = 'mvweb_pi_ms_characteristics';

	/**
	 * Failed picture requests in a row after which no more are sent this run.
	 *
	 * @since 1.3.0
	 * @var int
	 */
	const PICTURE_FAILURES = 3;

	/**
	 * Picture requests that have failed in a row.
	 *
	 * @since 1.3.0
	 * @var int
	 */
	private int $picture_failures = 0;

	/**
	 * Characteristic id => attribute taxonomy, for this fetch.
	 *
	 * @since 1.3.0
	 * @var array<string, string>|null
	 */
	private ?array $characteristics = null;

	/**
	 * Whether this fetch added to the characteristic map.
	 *
	 * @since 1.3.0
	 * @var bool
	 */
	private bool $characteristics_changed = false;

	/**
	 * Characteristic id => taxonomy already checked in this fetch.
	 *
	 * @since 1.3.0
	 * @var array<string, string>
	 */
	private array $resolved = array();

	/**
	 * Transport.
	 *
	 * @since 1.1.0
	 * @var MVweb_PI_MoySklad_Client
	 */
	private MVweb_PI_MoySklad_Client $client;

	/**
	 * MoySklad settings (`mvweb_pi_moysklad`).
	 *
	 * @since 1.1.0
	 * @var array
	 */
	private array $settings;

	/**
	 * Category filter, borrowed from the converter so both sources filter alike.
	 *
	 * @since 1.1.0
	 * @var MVweb_PI_Converter|null
	 */
	private ?MVweb_PI_Converter $filter = null;

	/**
	 * Assortment rows the last fetch could not use because of their kind.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	private int $skipped = 0;

	/**
	 * Assortment rows the last fetch could not use because they carried no price.
	 *
	 * Counted separately and reported: a product silently missing from the shop
	 * is the kind of absence nobody notices until a customer asks for it.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	private int $unpriced = 0;

	/**
	 * Constructor.
	 *
	 * @since 1.1.0
	 * @param MVweb_PI_MoySklad_Client $client   Transport.
	 * @param array                    $settings MoySklad settings.
	 */
	public function __construct( MVweb_PI_MoySklad_Client $client, array $settings ) {
		$this->client   = $client;
		$this->settings = $settings;
	}

	/**
	 * The newest complete dump on disk, or an empty string when there is none.
	 *
	 * A dump is two files sharing one random name — the products and the group
	 * tree they were fetched with — and it counts as complete only when both are
	 * there. That pairing is what makes the fetch safe to interrupt: a run that
	 * dies between writing the two leaves a name that no longer matches
	 * anything, so the next run fetches again rather than importing a fresh
	 * catalogue against a stale tree.
	 *
	 * The name is random for the same reason every other file this plugin puts
	 * in the uploads folder is: it holds the supplier's whole assortment, with
	 * the wholesale and dealer prices that never appear in a public feed, and
	 * the folder is protected by an .htaccess that Nginx does not read.
	 *
	 * @since 1.1.0
	 * @return string Absolute path of the products file, or ''.
	 */
	public static function dump_path(): string {
		// Only dumps in the current shape. One written before products with
		// variants were grouped carries no `type` and none of their variants; a
		// run interrupted before the plugin was updated fetches afresh instead
		// of resuming from it.
		$found = glob( mvweb_pi_get_upload_dir() . self::DUMP_PREFIX . '*.jsonl' );
		if ( empty( $found ) ) {
			return '';
		}

		// Newest first: an older leftover must never win over the dump the last
		// fetch produced.
		usort(
			$found,
			static function ( $a, $b ) {
				return filemtime( $b ) <=> filemtime( $a );
			}
		);

		foreach ( $found as $file ) {
			if ( file_exists( self::tree_path( $file ) ) ) {
				return $file;
			}
		}

		return '';
	}

	/**
	 * Path of the group tree belonging to a given products file.
	 *
	 * @since 1.1.0
	 * @param string $dump Products file, as returned by {@see dump_path()}.
	 * @return string
	 */
	public static function tree_path( string $dump ): string {
		return (string) preg_replace( '/moysklad-catalog-(.+)\.jsonl$/', 'moysklad-folders-$1.json', $dump );
	}

	/**
	 * Is there a complete dump on disk to import from?
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function has_dump(): bool {
		return '' !== self::dump_path();
	}

	/**
	 * Remove every catalogue dump, complete or half-written.
	 *
	 * @since 1.1.0
	 * @param string $keep Dump to spare, by absolute path.
	 * @return void
	 */
	public static function drop_dump( string $keep = '' ): void {
		$dir   = mvweb_pi_get_upload_dir();
		$files = array_merge(
			(array) glob( $dir . 'moysklad-catalog-*' ),
			(array) glob( $dir . 'moysklad-folders-*' )
		);

		foreach ( $files as $file ) {
			if ( $keep === $file || self::tree_path( $keep ) === $file ) {
				continue;
			}
			wp_delete_file( $file );
		}
	}

	/**
	 * Pull the whole catalogue from MoySklad into a local dump.
	 *
	 * Cheap in requests and expensive in nothing else: a ten-thousand product
	 * catalogue is ten pages of assortment plus three small calls. Pictures,
	 * which are what actually make an import take hours, are deliberately left
	 * out of this phase — the link to a file expires after a minute, so it can
	 * only be asked for at the moment the product is written.
	 *
	 * @since 1.1.0
	 * @return array{products: int, skipped: int, unpriced: int, requests: int} What was fetched.
	 * @throws \RuntimeException When the dump cannot be written or put in place.
	 * @throws \Throwable Whatever the API layer raised, once the half-written dump is cleaned up.
	 */
	public function refresh(): array {
		$final   = mvweb_pi_get_upload_dir() . self::DUMP_PREFIX . wp_generate_uuid4() . '.jsonl';
		$partial = $final . '.part';
		// Products with variants wait here until the last page: their variants
		// can come on any page, before or after them.
		$waiting = $final . '.variable';
		$folders = $this->fetch_folders();
		// With the zero lines: the per-warehouse figures a product carries are
		// replaced as a whole on every import, and a warehouse that ran out has
		// to be written as zero rather than left showing yesterday's number.
		$stock   = $this->fetch_stock( true );
		$offset  = 0;
		$written = 0;

		// A field deleted in MoySklad stops arriving on every product at once,
		// which the rows cannot tell from "empty everywhere": without this check
		// the next scheduled import would take its tag or attribute off the whole
		// catalogue. Its rule is left out instead, as if it had been removed from
		// the tab, until the account is reconnected and the settings saved.
		if ( ! empty( $this->settings['attribute_rules'] ) ) {
			$fields = self::describe_attributes( (array) ( $this->client->get( 'entity/product/metadata/attributes' )['rows'] ?? array() ) );

			$this->settings['attribute_rules'] = array_intersect_key( (array) $this->settings['attribute_rules'], $fields );
		}

		$this->skipped  = 0;
		$this->unpriced = 0;

		// Variants by the id of their product, each one kept encoded: a clothing
		// catalogue carries several per product, and a string takes a fraction
		// of the memory the same array does.
		$variants = array();

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streaming a multi-megabyte dump line by line.
		$handle = fopen( $partial, 'w' );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		$held = false !== $handle ? fopen( $waiting, 'w' ) : false;
		if ( false === $handle || false === $held ) {
			if ( false !== $handle ) {
				fclose( $handle );
				wp_delete_file( $partial );
			}
			throw new \RuntimeException(
				sprintf(
					/* translators: %s: file path */
					__( 'Cannot write the catalogue dump: %s', 'mvweb-price-importer' ),
					false === $handle ? $partial : $waiting
				)
			);
		}

		try {
			do {
				$page = $this->client->get(
					'entity/assortment',
					array(
						'limit'  => self::PAGE,
						'offset' => $offset,
					),
					array(
						// Without this header the request goes to the old
						// endpoint, which computes stock on the fly and is
						// being retired in 2027.
						'X-Lognex-Remap-Beta-Feature' => 'assortmentWithoutStock',
					)
				);

				$rows = isset( $page['rows'] ) && is_array( $page['rows'] ) ? $page['rows'] : array();
				$size = isset( $page['meta']['size'] ) ? (int) $page['meta']['size'] : 0;

				foreach ( $rows as $row ) {
					if ( 'variant' === (string) ( $row['meta']['type'] ?? '' ) ) {
						$variant = $this->normalize_variant( $row, $stock );
						if ( null !== $variant ) {
							$variants[ $variant['parent'] ][] = (string) wp_json_encode( $variant );
						}
						continue;
					}

					$product = $this->normalize( $row, $stock );
					if ( null === $product ) {
						continue;
					}

					if ( 'variable' === $product['type'] ) {
						fwrite( $held, (string) wp_json_encode( $product ) . "\n" );
						continue;
					}

					fwrite( $handle, (string) wp_json_encode( $product ) . "\n" );
					++$written;
				}

				$offset += self::PAGE;
				// A short page is the end of the catalogue. `meta.size` is only
				// a second opinion: when the API omits it, the page length is
				// the one signal left, and treating a missing size as "nothing
				// more to fetch" would silently import the first page alone.
				$page_size = count( $rows );
			} while ( self::PAGE === $page_size && ( 0 === $size || $offset < $size ) );

			fclose( $held );
			$held     = false;
			$written += $this->join_variants( $waiting, $handle, $variants );
		} catch ( \Throwable $e ) {
			fclose( $handle );
			if ( false !== $held ) {
				fclose( $held );
			}
			wp_delete_file( $partial );
			wp_delete_file( $waiting );
			throw $e;
		}

		fclose( $handle );
		wp_delete_file( $waiting );

		if ( $this->characteristics_changed ) {
			update_option( self::CHARACTERISTICS_OPTION, $this->characteristics, false );
		}

		// The tree goes down first, under the new dump's name, and the products
		// file is renamed into place after it. That order is what makes the pair
		// complete in a single step: until the rename, dump_path() still finds
		// the previous dump and its own tree, and a fetch that dies here leaves
		// a tree that belongs to no products file rather than a fresh catalogue
		// paired with a stale tree.
		file_put_contents( self::tree_path( $final ), (string) wp_json_encode( $folders ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

		if ( ! rename( $partial, $final ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
			wp_delete_file( $partial );
			wp_delete_file( self::tree_path( $final ) );
			throw new \RuntimeException(
				__( 'The catalogue was fetched but could not be moved into place.', 'mvweb-price-importer' )
			);
		}

		// Now that the new dump is the one on disk, everything older can go —
		// including any tree left behind by a fetch that never finished.
		self::drop_dump( $final );

		return array(
			'products' => $written,
			'skipped'  => $this->skipped,
			'unpriced' => $this->unpriced,
			'requests' => $this->client->sent(),
		);
	}

	/**
	 * Write each held-back product with its variants into the dump.
	 *
	 * One line per product, variants inside it, so the import still reads one
	 * line as one product and resumes by counting lines. A product left with no
	 * usable variant is not written: its article drops out of the catalogue, and
	 * the import takes an existing copy off sale like any product that vanished.
	 *
	 * @since 1.3.0
	 * @param string   $waiting  File the products with variants were held in.
	 * @param resource $handle   Dump being written.
	 * @param array    $variants Encoded variants by product id.
	 * @return int Products written.
	 * @throws \RuntimeException When the held products cannot be read back.
	 */
	private function join_variants( string $waiting, $handle, array $variants ): int {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		$reader = fopen( $waiting, 'r' );
		if ( false === $reader ) {
			throw new \RuntimeException(
				sprintf(
					/* translators: %s: file path */
					__( 'Cannot write the catalogue dump: %s', 'mvweb-price-importer' ),
					$waiting
				)
			);
		}

		$written = 0;

		try {
			while ( false !== ( $line = fgets( $reader ) ) ) {
				$product = json_decode( trim( $line ), true );
				if ( ! is_array( $product ) ) {
					continue;
				}

				$id         = (string) $product['ms_id'];
				$variations = array();
				foreach ( $variants[ $id ] ?? array() as $encoded ) {
					$variation = json_decode( $encoded, true );
					if ( is_array( $variation ) ) {
						unset( $variation['parent'] );
						$variations[] = $variation;
					}
				}
				unset( $variants[ $id ] );

				if ( empty( $variations ) ) {
					++$this->skipped;
					continue;
				}

				// A characteristic and an extra field land on one attribute when
				// they share a name. On a product with variants the attribute is
				// what the customer picks by, so the extra field gives way.
				foreach ( $variations as $variation ) {
					foreach ( array_keys( $variation['attributes'] ) as $taxonomy ) {
						unset( $product['attributes'][ $taxonomy ] );
					}
				}

				$product['variations'] = $variations;
				fwrite( $handle, (string) wp_json_encode( $product ) . "\n" );
				++$written;
			}
		} finally {
			fclose( $reader );
		}

		$orphans = array_sum( array_map( 'count', $variants ) );
		if ( $orphans > 0 ) {
			mvweb_pi_log(
				sprintf(
					/* translators: %d: number of variants */
					__( 'MoySklad: %d variants were left out because their product is not in the import (archived, or skipped for another reason).', 'mvweb-price-importer' ),
					$orphans
				),
				'info'
			);
		}

		return $written;
	}

	/**
	 * The category tree that belongs to the current dump.
	 *
	 * Shaped for {@see MVweb_PI_Categories::import()}: a flat list of
	 * `id`/`name`/`parent_id`, keyed by MoySklad's own identifiers rather than
	 * by name — so renaming a group in MoySklad renames the WooCommerce
	 * category instead of creating a second one beside it.
	 *
	 * @since 1.1.0
	 * @return array[]
	 */
	public function categories(): array {
		$dump = self::dump_path();
		if ( '' === $dump ) {
			return array();
		}

		$raw = json_decode( (string) file_get_contents( self::tree_path( $dump ) ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

		return is_array( $raw ) ? $raw : array();
	}

	/**
	 * Stream the dump as normalised product rows.
	 *
	 * Two things happen here rather than at fetch time. The category filter,
	 * because it reads the tree the import has only just created, and because a
	 * change of filter should not cost a second trip to the API. And pictures,
	 * listed for the rows about to be written; the link to each file is asked
	 * for later still, by {@see resolve_picture()} at download time, since it
	 * lives for one minute.
	 *
	 * This generator never ends early. An API error becomes an exception, which
	 * travels out through the importer and leaves the run's checkpoint intact;
	 * returning instead would tell the importer the catalogue had ended, and
	 * every product not yet reached would be taken off sale.
	 *
	 * @since 1.1.0
	 * @return \Generator<int, array>
	 * @throws \RuntimeException When the dump is missing or the API cannot be read.
	 */
	public function products(): \Generator {
		// Resolved once and held: the generator is walked over several
		// continuations, and a fetch finishing in between would otherwise move
		// the stream to a different file mid-read.
		$dump = self::dump_path();
		if ( '' === $dump ) {
			throw new \RuntimeException(
				__( 'The catalogue dump is missing. Run the import again to fetch it.', 'mvweb-price-importer' )
			);
		}

		$with_images = 'never' !== ( $this->settings['images'] ?? 'new_only' );

		// Not removed when the walk ends: the importer writes its last batch
		// after this generator has finished.
		if ( $with_images ) {
			add_filter( 'mvweb_pi_image_url', array( $this, 'resolve_picture' ) );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streaming the dump line by line.
		$handle = fopen( $dump, 'r' );
		if ( false === $handle ) {
			throw new \RuntimeException(
				__( 'The catalogue dump could not be opened.', 'mvweb-price-importer' )
			);
		}

		try {
			$chunk = array();

			while ( false !== ( $line = fgets( $handle ) ) ) {
				$row = json_decode( trim( $line ), true );
				if ( ! is_array( $row ) || empty( $row['sku'] ) ) {
					continue;
				}

				if ( $this->excluded( (string) ( $row['category_id'] ?? '' ) ) ) {
					continue;
				}

				$chunk[] = $row;
				if ( count( $chunk ) < self::LOOKUP_CHUNK ) {
					continue;
				}

				foreach ( $this->with_pictures( $chunk, $with_images ) as $ready ) {
					yield $ready;
				}
				$chunk = array();
			}

			foreach ( $this->with_pictures( $chunk, $with_images ) as $ready ) {
				yield $ready;
			}
		} finally {
			fclose( $handle );
		}
	}

	/**
	 * Attach picture URLs to the rows that are about to become new products.
	 *
	 * Listing a product's pictures costs a request and downloading each costs
	 * another, so it is done for the rows that will actually use them — the ones
	 * whose article is not in the catalogue yet. Products that already exist
	 * keep the pictures they have: "has the picture changed?" would cost a
	 * listing request for every product on every run, and re-downloading every
	 * photo on every run would turn a three-second sync into a nine-hour one.
	 *
	 * @since 1.1.0
	 * @param array[] $chunk       Rows to prepare.
	 * @param bool    $with_images Whether pictures are wanted at all.
	 * @return array[] The same rows, ready for the importer.
	 * @throws \RuntimeException When the API cannot be read.
	 */
	private function with_pictures( array $chunk, bool $with_images ): array {
		if ( empty( $chunk ) ) {
			return array();
		}

		// Nothing in this chunk has a photo — and most chunks will not, since
		// only products with one carry an address. Skip the catalogue lookup
		// too: it exists solely to decide which of them to fetch.
		$wanted = $with_images && '' !== implode( '', array_column( $chunk, 'images_href' ) );

		$fresh = $wanted ? $this->unknown_skus( array_column( $chunk, 'sku' ) ) : array();

		// Variations get their first picture, on the same terms: only the ones
		// the shop does not have yet. One picture, because WooCommerce shows one
		// per variation — downloading the rest would spend a request on each for
		// nothing.
		$with_variant_pictures = array();
		foreach ( $chunk as $row ) {
			foreach ( (array) ( $row['variations'] ?? array() ) as $variation ) {
				if ( '' !== (string) ( $variation['images_href'] ?? '' ) ) {
					$with_variant_pictures[] = (string) $variation['ms_id'];
				}
			}
		}
		$fresh_variations = ( $with_images && $with_variant_pictures ) ? $this->unknown_variations( $with_variant_pictures ) : array();

		foreach ( $chunk as $index => $row ) {
			foreach ( (array) ( $row['variations'] ?? array() ) as $position => $variation ) {
				$href = (string) ( $variation['images_href'] ?? '' );
				unset( $chunk[ $index ]['variations'][ $position ]['images_href'] );

				if ( '' === $href || ! isset( $fresh_variations[ (string) $variation['ms_id'] ] ) ) {
					continue;
				}

				$pictures = $this->fetch_pictures( $href, 1 );
				if ( ! empty( $pictures ) ) {
					$chunk[ $index ]['variations'][ $position ]['image'] = $pictures[0];
				}
			}

			$href = (string) ( $row['images_href'] ?? '' );
			unset( $chunk[ $index ]['images_href'] );

			if ( '' === $href || ! isset( $fresh[ (string) $row['sku'] ] ) ) {
				continue;
			}

			$pictures = $this->fetch_pictures( $href );
			if ( empty( $pictures ) ) {
				continue;
			}

			$chunk[ $index ]['image']   = array_shift( $pictures );
			$chunk[ $index ]['gallery'] = $pictures;
		}

		return array_values( $chunk );
	}

	/**
	 * Which of these articles the catalogue does not have yet.
	 *
	 * Mirrors how the importer resolves an article to a product: straight from
	 * the `_sku` meta, with binned products left out so a deleted article comes
	 * back as a new product rather than being revived in the bin.
	 *
	 * @since 1.1.0
	 * @param string[] $skus Articles to look up.
	 * @return array<string, true> Articles with no product behind them.
	 */
	private function unknown_skus( array $skus ): array {
		$skus = array_values( array_unique( array_filter( array_map( 'strval', $skus ), 'strlen' ) ) );
		if ( empty( $skus ) ) {
			return array();
		}

		global $wpdb;

		$placeholders = implode( ',', array_fill( 0, count( $skus ), '%s' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$known = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT pm.meta_value
				FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = '_sku'
				AND pm.meta_value IN ({$placeholders})
				AND p.post_type = 'product'
				AND p.post_status != 'trash'",
				$skus
			)
		);
		// phpcs:enable

		$unknown = array_flip( $skus );
		foreach ( (array) $known as $sku ) {
			unset( $unknown[ (string) $sku ] );
		}

		return array_map(
			static function () {
				return true;
			},
			$unknown
		);
	}

	/**
	 * Which of these MoySklad variants the catalogue has no variation for yet.
	 *
	 * @since 1.3.0
	 * @param string[] $ids MoySklad variant ids.
	 * @return array<string, true> Ids with no variation behind them.
	 */
	private function unknown_variations( array $ids ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'strval', $ids ), 'strlen' ) ) );
		if ( empty( $ids ) ) {
			return array();
		}

		global $wpdb;

		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%s' ) );
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$known = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT pm.meta_value
				FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = %s
				AND pm.meta_value IN ({$placeholders})
				AND p.post_type = 'product_variation'
				AND p.post_status != 'trash'",
				array_merge( array( MVweb_PI_Stock_Sync::ID_META ), $ids )
			)
		);
		// phpcs:enable

		$unknown = array_fill_keys( $ids, true );
		foreach ( (array) $known as $id ) {
			unset( $unknown[ (string) $id ] );
		}

		return $unknown;
	}

	/**
	 * List one product's pictures by their download addresses.
	 *
	 * MoySklad's own links may not be used on a public page — the documentation
	 * says so in as many words — so the pictures are downloaded into the media
	 * library like any other supplier photo. The address is the API's
	 * `download/{id}`, which stays the same from one import to the next; the
	 * file behind it is reached by {@see resolve_picture()} at the moment of
	 * downloading, because the storage link it redirects to lives sixty seconds.
	 *
	 * @since 1.1.0
	 * @since 1.3.0 Added $limit. Returns download addresses, not storage links.
	 * @param string $href  Address of the product's image collection.
	 * @param int    $limit How many pictures to list, 0 for all.
	 * @return string[] Download addresses, main picture first.
	 * @throws \RuntimeException When the API cannot be read.
	 */
	private function fetch_pictures( string $href, int $limit = 0 ): array {
		$response = $this->client->get( $href );
		$rows     = isset( $response['rows'] ) && is_array( $response['rows'] ) ? $response['rows'] : array();
		$urls     = array();

		foreach ( $rows as $row ) {
			$download = (string) ( $row['meta']['downloadHref'] ?? '' );
			if ( '' === $download ) {
				continue;
			}

			$urls[] = $download;

			if ( $limit > 0 && count( $urls ) >= $limit ) {
				break;
			}
		}

		return $urls;
	}

	/**
	 * Turn a picture's download address into the storage link the file sits at.
	 *
	 * Bound to `mvweb_pi_image_url` while the catalogue is walked, so the link
	 * is asked for right before the importer fetches the file. Asked for any
	 * earlier, it expires: measured, the storage answered 200 at once and 401
	 * seventy seconds later, while a chunk of new products with photos takes
	 * minutes to write. The address needs the token; the link it redirects to
	 * does not, and must not receive it. Any other URL passes through untouched.
	 *
	 * A failure costs the picture, not the run: the importer catches per product,
	 * so a thrown error would not stop the import here the way it does while the
	 * catalogue is read. What it must not do is keep asking — an account that
	 * sends too many rejected requests is blocked — so after a few failures in a
	 * row no more pictures are asked for until the next run. One missing photo
	 * does not trip it: a success resets the count.
	 *
	 * @since 1.3.0
	 * @param string|\WP_Error $url Image URL about to be downloaded.
	 * @return string|\WP_Error Storage link, or why there is none.
	 */
	public function resolve_picture( $url ) {
		if ( ! is_string( $url ) || ! str_starts_with( $url, MVweb_PI_MoySklad_Client::BASE . 'download/' ) ) {
			return $url;
		}

		if ( $this->picture_failures >= self::PICTURE_FAILURES ) {
			return new \WP_Error( 'mvweb_pi_moysklad_picture', __( 'Photos from MoySklad are paused until the next run after repeated failures.', 'mvweb-price-importer' ) );
		}

		try {
			$link = $this->client->resolve_redirect( $url );
		} catch ( \Throwable $e ) {
			$message = $this->client->redact( $e->getMessage() );

			if ( ++$this->picture_failures >= self::PICTURE_FAILURES ) {
				mvweb_pi_log(
					sprintf(
						/* translators: 1: number of failures, 2: last error message */
						__( 'MoySklad: %1$d photos in a row could not be fetched (last error: %2$s). No more are asked for in this run, so products written from here on get no photo.', 'mvweb-price-importer' ),
						self::PICTURE_FAILURES,
						$message
					),
					'warning'
				);
			}

			return new \WP_Error( 'mvweb_pi_moysklad_picture', $message );
		}

		$this->picture_failures = 0;

		if ( '' === $link ) {
			return new \WP_Error( 'mvweb_pi_moysklad_picture', __( 'MoySklad did not say where the picture is stored.', 'mvweb-price-importer' ) );
		}

		return $link;
	}

	/**
	 * Read the whole group tree.
	 *
	 * @since 1.1.0
	 * @since 1.3.0 Public: the Category Filter reads it before the first import.
	 * @return array[] Flat list of id/name/parent_id.
	 * @throws \RuntimeException When the API cannot be read.
	 */
	public function fetch_folders(): array {
		$folders = array();
		$offset  = 0;

		do {
			$page = $this->client->get(
				'entity/productfolder',
				array(
					'limit'  => self::PAGE,
					'offset' => $offset,
				)
			);

			$rows = isset( $page['rows'] ) && is_array( $page['rows'] ) ? $page['rows'] : array();
			foreach ( $rows as $row ) {
				$id = (string) ( $row['id'] ?? '' );
				if ( '' === $id ) {
					continue;
				}
				$folders[] = array(
					'id'        => $id,
					'name'      => (string) ( $row['name'] ?? $id ),
					'parent_id' => self::id_from_href( (string) ( $row['productFolder']['meta']['href'] ?? '' ) ),
				);
			}

			$offset   += self::PAGE;
			$size      = isset( $page['meta']['size'] ) ? (int) $page['meta']['size'] : 0;
			$page_size = count( $rows );
		} while ( self::PAGE === $page_size && ( 0 === $size || $offset < $size ) );

		return $folders;
	}

	/**
	 * Read stock for the whole warehouse in one request.
	 *
	 * The short report, not the detailed one: the short report costs a single
	 * unit of the rate limit and answers without pagination, the detailed one
	 * costs five and pages. The documentation recommends the short report for
	 * exactly this — frequent, quick stock refreshes.
	 *
	 * `$include_zero` decides what an absent product means. A full import does
	 * not care: a row the report leaves out is read as zero, and the import
	 * knows the whole catalogue anyway. The stock sync does care — it sees only
	 * this report, and without the zero lines it cannot tell "sold out" from
	 * "not in this report", so it would leave a sold-out product on sale.
	 *
	 * Asked store by store, and still in one request. The split report takes the
	 * same stock type and answers for every warehouse at once, so the total a
	 * product ends up with is the sum over the warehouses the operator counts —
	 * with all of them counted, the same figure the undivided report gives.
	 *
	 * A reservation that belongs to no warehouse comes back as a row of its own
	 * with no store and a negative figure: measured, four and one on two shelves
	 * with one unit reserved in an order without a warehouse read as 4, 1 and -1,
	 * and the undivided report said 4. Those rows go into the total whatever is
	 * counted — leaving them out would sell the reserved unit twice — and into no
	 * warehouse's own figure, since they are not on any shelf.
	 *
	 * @since 1.1.0
	 * @since 1.1.0 Public, and able to ask for the zero lines.
	 * @since 1.3.0 Split by warehouse.
	 * @param bool $include_zero Whether to ask for products whose stock is zero.
	 * @return array{total: array<string, int>, stores: array<string, array<string, int>>}
	 *         Assortment id => quantity, and assortment id => warehouse id => quantity.
	 * @throws \RuntimeException When the API cannot be read.
	 */
	public function fetch_stock( bool $include_zero = false ): array {
		$type  = (string) ( $this->settings['stock_type'] ?? 'freeStock' );
		$query = array( 'stockType' => $type );
		if ( $include_zero ) {
			$query['include'] = 'zeroLines';
		}

		$rows     = $this->client->get( 'report/stock/bystore/current', $query );
		$excluded = array_flip( array_map( 'strval', (array) ( $this->settings['stores_excluded'] ?? array() ) ) );

		// Once the operator has switched some warehouses off, the ones left on
		// are the whole list: a warehouse opened in MoySklad afterwards — or an
		// archived one still holding stock — stays out until it is switched on.
		// Counting it by default would put another town's shelf on sale. Empty
		// means every warehouse is counted, new ones included.
		$counted = array_flip( array_map( 'strval', (array) ( $this->settings['stores_counted'] ?? array() ) ) );

		// Saved by 1.3.0, which kept only the switched-off list.
		if ( ! $counted && $excluded && is_array( $this->settings['stores'] ?? null ) ) {
			$counted = array_diff_key( array_flip( array_map( 'strval', array_keys( $this->settings['stores'] ) ) ), $excluded );
		}

		$sums   = array();
		$stores = array();
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) || empty( $row['assortmentId'] ) ) {
				continue;
			}

			$id    = (string) $row['assortmentId'];
			$store = (string) ( $row['storeId'] ?? '' );

			// Seen at all means reported, even when every line of it sits in a
			// warehouse that is not counted: the product is then at zero here,
			// not missing from the report.
			$sums[ $id ] = $sums[ $id ] ?? 0.0;

			if ( '' !== $store && ( $counted ? ! isset( $counted[ $store ] ) : isset( $excluded[ $store ] ) ) ) {
				continue;
			}

			// The quantity comes back under a key named after the stock type
			// that was asked for — `quantity`, `freeStock`, `reserve` — and only
			// the plain `stock` request answers with a field called `stock`.
			// Reading `stock` unconditionally is silently wrong for every other
			// type: the field is absent, every product reads as zero, and the
			// whole catalogue lands in the shop out of stock. Verified against a
			// live account, where the documented shape did not match.
			$quantity     = (float) ( $row[ $type ] ?? $row['stock'] ?? 0 );
			$sums[ $id ] += $quantity;

			if ( '' !== $store ) {
				$stores[ $id ][ $store ] = max( 0, (int) round( $quantity ) );
			}
		}

		$total = array();
		foreach ( $sums as $id => $sum ) {
			$total[ $id ] = max( 0, (int) round( $sum ) );
		}

		return array(
			'total'  => $total,
			'stores' => $stores,
		);
	}

	/**
	 * Boil the account's product field definitions down to what the tab offers.
	 *
	 * A reference field reports the kind of thing it points at as its type —
	 * `customentity` for a user-defined list, `counterparty`, `store` and so on
	 * for MoySklad's own — so every one of those becomes `reference`: the value
	 * arrives as an object with a `name`, and the name is what the shop can use.
	 *
	 * @since 1.3.0
	 * @param array $rows Rows of `entity/product/metadata/attributes`.
	 * @return array<string, array{name: string, type: string}> Field id => name and kind.
	 */
	public static function describe_attributes( array $rows ): array {
		$plain = array( 'boolean', 'string', 'text', 'long', 'double', 'time', 'link', 'file' );
		$out   = array();

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) || empty( $row['id'] ) ) {
				continue;
			}

			$type = (string) ( $row['type'] ?? '' );

			$out[ (string) $row['id'] ] = array(
				'name' => sanitize_text_field( (string) ( $row['name'] ?? $row['id'] ) ),
				'type' => in_array( $type, $plain, true ) ? $type : 'reference',
			);
		}

		return $out;
	}

	/**
	 * Turn one assortment row into the plugin's normalised product shape.
	 *
	 * Deliberately the same keys the price-list converter produces, with one
	 * difference that matters: there is no `sale_price` key at all. MoySklad
	 * has no notion of "the price before the discount", and passing an empty
	 * value would read as "this product has no sale" — which would strip every
	 * sale price the shop had set by hand.
	 *
	 * @since 1.1.0
	 * @param array $row   Assortment row.
	 * @param array $stock What {@see fetch_stock()} returned.
	 * @return array|null Normalised row, or null when the row cannot be used.
	 */
	private function normalize( array $row, array $stock ): ?array {
		$type = (string) ( $row['meta']['type'] ?? '' );
		// Services and bundles are not stocked goods and have no article of
		// their own to match on; variants are read by normalize_variant().
		// Anything else is skipped rather than guessed at.
		if ( 'product' !== $type ) {
			++$this->skipped;
			return null;
		}

		$id  = (string) ( $row['id'] ?? '' );
		$sku = $this->sku_of( $row );
		if ( '' === $id || '' === $sku ) {
			++$this->skipped;
			return null;
		}

		// A product with variants is sold through them: its stock is theirs, and
		// so is the price, which each variant carries even when it has none of
		// its own. Its own price is not required.
		$variable = (int) ( $row['variantsCount'] ?? 0 ) > 0;

		$prices = $this->prices_of( $row );
		if ( null === $prices['retail'] && ! $variable ) {
			++$this->unpriced;
			return null;
		}

		$folder = self::id_from_href( (string) ( $row['productFolder']['meta']['href'] ?? '' ) );

		$product = array(
			// Present on MoySklad rows only. A price-list row has no such key and
			// is never read as a product with variants.
			'type'            => $variable ? 'variable' : 'simple',
			'sku'             => sanitize_text_field( $sku ),
			// MoySklad's own identifier for this product, stored on the product
			// so the stock sync can find it again. The stock report answers with
			// identifiers and nothing else — no article, no name — so without
			// this the only way to read it would be to fetch the whole assortment
			// on every sync, which is the cost the sync exists to avoid.
			'ms_id'           => $id,
			'name'            => mvweb_pi_clean_text( (string) ( $row['name'] ?? '' ) ),
			'description'     => mvweb_pi_clean_text( (string) ( $row['description'] ?? '' ), true ),
			'price'           => $prices['retail'],
			'wholesale_price' => $prices['wholesale'],
			'dealer_price'    => $prices['dealer'],
			'stock'           => $stock['total'][ $id ] ?? 0,
			'image'           => '',
			'gallery'         => array(),
			'category_id'     => $folder,
			'category_name'   => '',
			'parent_cat_id'   => '',
			'parent_cat_name' => '',
			'barcode'         => self::barcode_of( $row ),
			'warehouse'       => 'moysklad',
			'stocks'          => $stock['stores'][ $id ] ?? array(),
			'tags'            => array(),
			// Kept only inside the dump; stripped before the row reaches the
			// importer, which has no use for an address it cannot fetch.
			//
			// Only for products that actually have a photo. The assortment row
			// already says how many there are, and asking a product with none
			// costs exactly as much as asking one with ten: measured against a
			// live account where one product in a thousand had a picture, that
			// is 999 requests spent to be told "nothing here" — about five
			// minutes of the account's rate limit, every import.
			'images_href'     => ( (int) ( $row['images']['meta']['size'] ?? 0 ) > 0 )
				? (string) ( $row['images']['meta']['href'] ?? '' )
				: '',
		);

		// Present only when MoySklad has a value, so the importer can tell "no
		// weight given" from "weighs nothing" and leaves a weight entered in
		// WooCommerce by hand alone in the first case.
		$weight = (float) ( $row['weight'] ?? 0 );
		if ( $weight > 0 ) {
			$product['weight'] = $weight;
		}

		$gtin = self::gtin_of( $row );
		if ( '' !== $gtin ) {
			$product['gtin'] = $gtin;
		}

		$product = array_merge( $product, $this->fields_of( $row ) );

		return $product;
	}

	/**
	 * Turn one variant row into a variation of its product.
	 *
	 * A variant has no group, extra fields or weight — those stay with its
	 * product — and its prices come back already filled from the product when
	 * it has none of its own: measured, three of four variants read the
	 * product's 1500 and the fourth its own 1700.
	 *
	 * @since 1.3.0
	 * @param array $row   Assortment row of type `variant`.
	 * @param array $stock What {@see fetch_stock()} returned.
	 * @return array|null Variation row with `parent` set, or null when unusable.
	 */
	private function normalize_variant( array $row, array $stock ): ?array {
		$id     = (string) ( $row['id'] ?? '' );
		$parent = self::id_from_href( (string) ( $row['product']['meta']['href'] ?? '' ) );
		$sku    = $this->sku_of( $row );
		if ( '' === $id || '' === $parent || '' === $sku ) {
			++$this->skipped;
			return null;
		}

		$prices = $this->prices_of( $row );
		if ( null === $prices['retail'] ) {
			++$this->unpriced;
			return null;
		}

		$attributes = array();
		foreach ( (array) ( $row['characteristics'] ?? array() ) as $characteristic ) {
			if ( ! is_array( $characteristic ) || empty( $characteristic['id'] ) ) {
				continue;
			}

			$taxonomy = $this->characteristic_taxonomy( (string) $characteristic['id'], (string) ( $characteristic['name'] ?? '' ) );
			$value    = self::attribute_text( $characteristic['value'] ?? '' );
			if ( '' !== $taxonomy && '' !== $value ) {
				$attributes[ $taxonomy ] = $value;
			}
		}

		// Nothing a customer could choose it by.
		if ( empty( $attributes ) ) {
			++$this->skipped;
			return null;
		}

		$variation = array(
			'ms_id'           => $id,
			'parent'          => $parent,
			'sku'             => sanitize_text_field( $sku ),
			'price'           => $prices['retail'],
			'wholesale_price' => $prices['wholesale'],
			'dealer_price'    => $prices['dealer'],
			'stock'           => $stock['total'][ $id ] ?? 0,
			'stocks'          => $stock['stores'][ $id ] ?? array(),
			'barcode'         => self::barcode_of( $row ),
			'attributes'      => $attributes,
			'image'           => '',
			'images_href'     => ( (int) ( $row['images']['meta']['size'] ?? 0 ) > 0 )
				? (string) ( $row['images']['meta']['href'] ?? '' )
				: '',
		);

		$gtin = self::gtin_of( $row );
		if ( '' !== $gtin ) {
			$variation['gtin'] = $gtin;
		}

		return $variation;
	}

	/**
	 * The attribute a characteristic becomes.
	 *
	 * Every characteristic becomes a global attribute, with nothing to set up:
	 * without an attribute a variation cannot be chosen at all, and a global one
	 * is what the storefront filters by size and colour work with. Matched by
	 * the characteristic's id, so renaming it in MoySklad does not bring a
	 * second attribute into the shop.
	 *
	 * @since 1.3.0
	 * @param string $id   Characteristic id.
	 * @param string $name Characteristic name.
	 * @return string Taxonomy, or '' when none could be had.
	 */
	private function characteristic_taxonomy( string $id, string $name ): string {
		if ( null === $this->characteristics ) {
			$saved                 = get_option( self::CHARACTERISTICS_OPTION, array() );
			$this->characteristics = is_array( $saved ) ? $saved : array();
			$this->resolved        = array();
		}

		if ( isset( $this->resolved[ $id ] ) ) {
			return $this->resolved[ $id ];
		}

		$previous = (string) ( $this->characteristics[ $id ] ?? '' );
		$taxonomy = mvweb_pi_wc_attribute( sanitize_text_field( $name ), $previous );

		if ( '' === $taxonomy ) {
			mvweb_pi_log(
				sprintf(
					/* translators: %s: characteristic name */
					__( 'MoySklad: the attribute "%s" could not be created in WooCommerce, so variants cannot be told apart by it. Create an attribute with this name under Products → Attributes.', 'mvweb-price-importer' ),
					$name
				),
				'warning'
			);
		} elseif ( $taxonomy !== $previous ) {
			$this->characteristics[ $id ]  = $taxonomy;
			$this->characteristics_changed = true;
		}

		$this->resolved[ $id ] = $taxonomy;

		return $taxonomy;
	}

	/**
	 * The barcode WooCommerce can keep as the product's GTIN.
	 *
	 * Only the kinds that are GTINs: a Code 128 is a warehouse label, and
	 * WooCommerce would reject it as one. The same product often carries an
	 * EAN-13 and the GTIN-14 built from it; the GTIN-14 is taken first when both
	 * are there, being the one marketplaces ask for.
	 *
	 * @since 1.3.0
	 * @param array $row Assortment row.
	 * @return string GTIN, or '' when the product has none.
	 */
	private static function gtin_of( array $row ): string {
		$barcodes = isset( $row['barcodes'] ) && is_array( $row['barcodes'] ) ? $row['barcodes'] : array();

		foreach ( array( 'gtin', 'ean13', 'ean8', 'upc' ) as $kind ) {
			foreach ( $barcodes as $barcode ) {
				$value = is_array( $barcode ) ? preg_replace( '/\D/', '', (string) ( $barcode[ $kind ] ?? '' ) ) : '';
				if ( '' !== $value && ! self::is_internal_number( $value ) ) {
					return $value;
				}
			}
		}

		return '';
	}

	/**
	 * Is this a shop's own number rather than a GTIN?
	 *
	 * GS1 keeps numbers starting with 2 — 02 for a twelve-digit UPC once padded to
	 * thirteen — for use inside one business, and MoySklad hands exactly such an EAN-13 to every
	 * product created without a barcode of its own: measured, `2000000000039`
	 * and on up the catalogue. They identify nothing outside the account, so they
	 * are not offered to WooCommerce as GTINs; a marketplace reading the feed
	 * would reject them, or match them to somebody else's goods.
	 *
	 * @since 1.3.0
	 * @param string $digits Barcode, digits only.
	 * @return bool
	 */
	private static function is_internal_number( string $digits ): bool {
		if ( 14 === strlen( $digits ) && '0' === $digits[0] ) {
			$digits = substr( $digits, 1 );
		}
		if ( 12 === strlen( $digits ) ) {
			$digits = '0' . $digits;
		}
		if ( 13 === strlen( $digits ) && str_starts_with( $digits, '02' ) ) {
			return true;
		}

		return in_array( strlen( $digits ), array( 8, 13 ), true ) && '2' === $digits[0];
	}

	/**
	 * What the product's extra fields say, shaped by the rules on the tab.
	 *
	 * An extra field never filled in MoySklad is not sent at all — measured: a
	 * product without "Hit" set simply has no such entry — while a flag unticked
	 * later comes back as false. So here, unlike a price list where a missing
	 * column means "nothing to say", a field that is absent from the row means
	 * its value is empty: the tag comes off, the attribute is cleared. Otherwise a
	 * product whose flag was never ticked could keep a tag set by an old import.
	 *
	 * @since 1.3.0
	 * @param array $row Assortment row.
	 * @return array{tags?: array<string, bool>, attributes?: array<string, string>}
	 */
	private function fields_of( array $row ): array {
		$rules = is_array( $this->settings['attribute_rules'] ?? null ) ? $this->settings['attribute_rules'] : array();
		if ( empty( $rules ) ) {
			return array();
		}

		$values = array();
		foreach ( (array) ( $row['attributes'] ?? array() ) as $field ) {
			if ( is_array( $field ) && ! empty( $field['id'] ) ) {
				$values[ (string) $field['id'] ] = $field['value'] ?? null;
			}
		}

		$tags       = array();
		$attributes = array();

		foreach ( $rules as $field_id => $rule ) {
			$value = $values[ (string) $field_id ] ?? null;

			if ( 'tag' === ( $rule['as'] ?? '' ) ) {
				$tags[ self::tag_key( (string) $field_id ) ] = true === $value;
				continue;
			}

			if ( 'attribute' === ( $rule['as'] ?? '' ) && '' !== (string) ( $rule['taxonomy'] ?? '' ) ) {
				$attributes[ (string) $rule['taxonomy'] ] = self::attribute_text( $value );
			}
		}

		$out = array();
		if ( $tags ) {
			$out['tags'] = $tags;
		}
		if ( $attributes ) {
			$out['attributes'] = $attributes;
		}

		return $out;
	}

	/**
	 * Key a MoySklad field's tag rule is known by.
	 *
	 * Prefixed so it can never collide with a price-list rule, whose keys are
	 * made up when the rule is added on the Mapping tab.
	 *
	 * @since 1.3.0
	 * @param string $field_id MoySklad field id.
	 * @return string
	 */
	public static function tag_key( string $field_id ): string {
		return 'ms:' . $field_id;
	}

	/**
	 * An extra field's value as the text of an attribute term.
	 *
	 * @since 1.3.0
	 * @param mixed $value Value as the API sent it.
	 * @return string Term name, or '' for no value.
	 */
	private static function attribute_text( $value ): string {
		if ( is_array( $value ) ) {
			// A reference to a list entry, a counterparty, a store: its name.
			$value = $value['name'] ?? '';
		} elseif ( is_float( $value ) ) {
			// 0.75 rather than 0.75000000000001, and 24 rather than 24.0.
			$value = rtrim( rtrim( number_format( $value, 6, '.', '' ), '0' ), '.' );
		} elseif ( is_bool( $value ) || null === $value ) {
			$value = '';
		}

		// A term name is capped at 200 characters by WordPress.
		return mb_substr( trim( mvweb_pi_clean_text( (string) $value ) ), 0, 200 );
	}

	/**
	 * The article this product is matched by.
	 *
	 * MoySklad's own identifier is the last resort: it is stable but meaningless
	 * to a shop assistant, and it would end up printed on the storefront.
	 *
	 * @since 1.1.0
	 * @param array $row Assortment row.
	 * @return string
	 */
	private function sku_of( array $row ): string {
		$preferred = 'code' === ( $this->settings['sku_field'] ?? 'article' ) ? 'code' : 'article';
		$fallback  = 'code' === $preferred ? 'article' : 'code';

		foreach ( array( $preferred, $fallback, 'id' ) as $field ) {
			$value = trim( (string) ( $row[ $field ] ?? '' ) );
			if ( '' !== $value ) {
				return $value;
			}
		}

		return '';
	}

	/**
	 * Pick the three prices out of the row's price list.
	 *
	 * MoySklad keeps money in kopecks. Forgetting to divide is the classic
	 * failure of this integration and it is not subtle: every price on the
	 * storefront comes out a hundred times too high.
	 *
	 * @since 1.1.0
	 * @param array $row Assortment row.
	 * @return array{retail: float|null, wholesale: float|null, dealer: float|null}
	 */
	private function prices_of( array $row ): array {
		$by_type = array();
		$list    = isset( $row['salePrices'] ) && is_array( $row['salePrices'] ) ? $row['salePrices'] : array();

		foreach ( $list as $price ) {
			$type = (string) ( $price['priceType']['id'] ?? '' );
			if ( '' === $type ) {
				continue;
			}
			$by_type[ $type ] = (float) ( $price['value'] ?? 0 ) / 100;
		}

		$pick = function ( string $key ) use ( $by_type ): ?float {
			$type = (string) ( $this->settings[ $key ] ?? '' );
			if ( '' === $type || ! isset( $by_type[ $type ] ) ) {
				return null;
			}
			return $by_type[ $type ] > 0 ? $by_type[ $type ] : null;
		};

		$retail = $pick( 'price_retail' );
		if ( null === $retail && ! empty( $by_type ) && '' === (string) ( $this->settings['price_retail'] ?? '' ) ) {
			// No retail price type chosen yet: take the first one MoySklad
			// lists rather than import the whole catalogue at no price.
			$first  = reset( $by_type );
			$retail = $first > 0 ? $first : null;
		}

		return array(
			'retail'    => $retail,
			'wholesale' => $pick( 'price_wholesale' ),
			'dealer'    => $pick( 'price_dealer' ),
		);
	}

	/**
	 * First barcode of any kind.
	 *
	 * @since 1.1.0
	 * @param array $row Assortment row.
	 * @return string
	 */
	private static function barcode_of( array $row ): string {
		$barcodes = isset( $row['barcodes'] ) && is_array( $row['barcodes'] ) ? $row['barcodes'] : array();

		foreach ( $barcodes as $barcode ) {
			if ( ! is_array( $barcode ) ) {
				continue;
			}
			foreach ( $barcode as $value ) {
				$value = trim( (string) $value );
				if ( '' !== $value ) {
					return sanitize_text_field( $value );
				}
			}
		}

		return '';
	}

	/**
	 * Pull the identifier out of a metadata link.
	 *
	 * MoySklad refers to related entities by URL, and the identifier is its last
	 * segment — with any query string (`?expand=…`) cut off first.
	 *
	 * @since 1.1.0
	 * @param string $href Metadata href.
	 * @return string
	 */
	private static function id_from_href( string $href ): string {
		if ( '' === $href ) {
			return '';
		}

		$path = (string) wp_parse_url( $href, PHP_URL_PATH );

		return (string) substr( strrchr( '/' . $path, '/' ), 1 );
	}

	/**
	 * Does the category filter drop this product?
	 *
	 * Borrowed from the converter rather than reimplemented: the two sources
	 * have to agree on what "excluded" means, and a second copy of the rule
	 * would drift from the first.
	 *
	 * @since 1.1.0
	 * @param string $category_id MoySklad group id.
	 * @return bool
	 */
	private function excluded( string $category_id ): bool {
		if ( null === $this->filter ) {
			$this->filter = new MVweb_PI_Converter();
		}

		return $this->filter->is_category_excluded( $category_id );
	}
}
