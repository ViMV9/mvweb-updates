<?php
/**
 * Keeping stock in step with MoySklad between full imports.
 *
 * A full import runs once or twice a day and rewrites everything: names,
 * prices, categories, photos. Stock does not keep those hours — a product sold
 * out in the warehouse at ten in the morning stays on sale here until the
 * evening run. This is the small, frequent counterpart: one request, the stock
 * figure and nothing else.
 *
 * What it deliberately does NOT do is the end-of-import reconciliation. The
 * full import knows the whole catalogue and may therefore zero what the source
 * no longer carries and remove categories that went away. This sync sees a
 * stock report and nothing more; a product missing from it has not been
 * withdrawn, it simply was not mentioned. Judging the catalogue from that would
 * empty the shop on the first report that arrives short.
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Stock_Sync
 *
 * @since 1.1.0
 */
class MVweb_PI_Stock_Sync {

	/**
	 * Cron hook name.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const HOOK = 'mvweb_pi_stock_sync';

	/**
	 * Where the result of the last run is kept, for the settings screen.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const LAST_RUN_OPTION = 'mvweb_pi_stock_sync_last';

	/**
	 * The product meta carrying MoySklad's own identifier.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const ID_META = '_mvweb_pi_ms_id';

	/**
	 * How many products are examined between meta-cache primings.
	 *
	 * Matches the importer's default batch — the number a catalogue of this kind
	 * is already known to handle in one go.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const SLICE = 100;

	/**
	 * Run one stock sync.
	 *
	 * @since 1.1.0
	 * @return array{status: string, message: string, updated?: int, matched?: int, reported?: int}
	 */
	public function run(): array {
		if ( 'moysklad' !== mvweb_pi_source_mode() ) {
			return array(
				'status'  => 'skipped',
				'message' => __( 'Stock sync does nothing while the site imports from a price-list file.', 'mvweb-price-importer' ),
			);
		}

		$settings = get_option( 'mvweb_pi_moysklad', array() );
		$settings = is_array( $settings ) ? $settings : array();
		$token    = (string) ( $settings['token'] ?? '' );

		if ( '' === $token ) {
			return array(
				'status'  => 'error',
				'message' => __( 'Stock sync has no MoySklad connection to work with.', 'mvweb-price-importer' ),
			);
		}

		// The same lock the full import takes, and for the reason locks exist at
		// all: both write `_stock` on the same products, and the loser of a race
		// between them would be whichever finished writing last, not whichever
		// held the newer number. A sync that cannot have the lock simply steps
		// aside — the import it collided with is about to write fresher stock
		// than this sync was going to, and the next tick is minutes away.
		$cron = new MVweb_PI_Cron();
		if ( ! $cron->acquire_lock() ) {
			mvweb_pi_log( 'Stock sync skipped: an import holds the lock.', 'debug' );
			return array(
				'status'  => 'locked',
				'message' => __( 'An import is running — stock sync will try again on its next turn.', 'mvweb-price-importer' ),
			);
		}

		// Same guard the import registers: a fatal never reaches the `finally`
		// below, and the lock this run holds would otherwise sit there for its
		// full half-hour TTL, holding off the import too.
		MVweb_PI_Cron::guard_lock_against_fatals();

		// A thousand products take a second and a half, but a catalogue ten
		// times that walked from a web-triggered wp-cron tick would meet the
		// host's wall clock halfway through.
		if ( function_exists( 'set_time_limit' ) ) {
			set_time_limit( 0 );
		}

		$client = null;

		try {
			$client = new MVweb_PI_MoySklad_Client(
				$token,
				(int) ( $settings['rate_limit'] ?? MVweb_PI_MoySklad_Client::DEFAULT_RATE )
			);
			$source = new MVweb_PI_MoySklad_Source( $client, $settings );

			// With the zero lines, so a product that sold out is reported as zero
			// rather than left out — see MVweb_PI_MoySklad_Source::fetch_stock().
			$stock = $source->fetch_stock( true );

			$result = $this->apply( $stock['total'], $stock['stores'] );

			update_option(
				self::LAST_RUN_OPTION,
				array(
					'time'     => time(),
					'reported' => $result['reported'],
					'matched'  => $result['matched'],
					'updated'  => $result['updated'],
				),
				false
			);

			mvweb_pi_log(
				sprintf(
					/* translators: 1: products whose stock changed, 2: products matched, 3: rows in the report */
					__( 'Stock sync: %1$d products updated out of %2$d matched, %3$d rows in the report.', 'mvweb-price-importer' ),
					$result['updated'],
					$result['matched'],
					$result['reported']
				),
				$result['updated'] > 0 ? 'info' : 'debug'
			);

			return array_merge(
				array(
					'status'  => 'success',
					'message' => __( 'Stock sync finished.', 'mvweb-price-importer' ),
				),
				$result
			);
		} catch ( \Throwable $e ) {
			// Redacted once, then used for both the log and the answer. The
			// client already strips the token before it throws, so nothing
			// leaks today — but a message assembled somewhere new would, and
			// the caller prints this one to a CLI/cron stream.
			$message = $client instanceof MVweb_PI_MoySklad_Client
				? $client->redact( $e->getMessage() )
				: $e->getMessage();

			mvweb_pi_log(
				sprintf(
					/* translators: %s: error message */
					__( 'Stock sync failed: %s', 'mvweb-price-importer' ),
					$message
				),
				'error'
			);

			return array(
				'status'  => 'error',
				'message' => $message,
			);
		} finally {
			$cron->release_lock();
		}
	}

	/**
	 * Write the reported quantities onto the products that carry those ids.
	 *
	 * @since 1.1.0
	 * @since 1.3.0 Takes the per-warehouse split as well.
	 * @param array<string, int>                $stock  MoySklad id => quantity.
	 * @param array<string, array<string, int>> $stores MoySklad id => warehouse id => quantity.
	 * @return array{reported: int, matched: int, updated: int}
	 */
	private function apply( array $stock, array $stores = array() ): array {
		$products = $this->products_by_ms_id();

		$reserved = null;
		$settings = get_option( 'mvweb_pi_settings', array() );
		$settings = is_array( $settings ) ? $settings : array();
		// Same default as the importer: on unless explicitly switched off, so a
		// site that predates the setting is not left overselling.
		if ( ! array_key_exists( 'reserve_stock', $settings ) || ! empty( $settings['reserve_stock'] ) ) {
			$reserved = new MVweb_PI_Reserved_Stock();
			$reserved->refresh();
		}

		$matched = 0;
		$touched = array();
		// Products whose variations came in or ran out: their own status and
		// price range follow the variations, and nothing else updates them.
		$parents = array();

		// Walked in slices, priming the meta cache of each before reading it.
		//
		// Priming is what lets this method read the stored values the same way it
		// writes them. Reading them straight out of the database instead would be
		// faster and quietly wrong on any site with a persistent object cache:
		// `update_post_meta()` compares against the cache and does nothing when
		// the value already matches there, so a sync that decided from the
		// database would report products as updated while writing nothing at all.
		// Measured on the test site, which runs one.
		//
		// In slices rather than all at once because a catalogue of fifteen
		// thousand is a single query answering with every meta row those products
		// have — hundreds of thousands of rows materialised in one go. The
		// importer primes per batch for the same reason.
		foreach ( array_chunk( array_keys( $stock ), self::SLICE ) as $slice ) {
			$ids = array();
			foreach ( $slice as $ms_id ) {
				if ( isset( $products[ $ms_id ] ) ) {
					$ids[] = $products[ $ms_id ]['id'];
				}
			}

			if ( empty( $ids ) ) {
				continue;
			}

			update_meta_cache( 'post', $ids );

			foreach ( $slice as $ms_id ) {
				if ( ! isset( $products[ $ms_id ] ) ) {
					continue;
				}

				$quantity   = $stock[ $ms_id ];
				$product_id = $products[ $ms_id ]['id'];
				$parent_id  = $products[ $ms_id ]['parent'];

				++$matched;

				// Always from the warehouse figure, never from the number already
				// stored: subtracting the same open orders again on every sync
				// would walk the catalogue down to zero in an afternoon.
				$held      = $reserved instanceof MVweb_PI_Reserved_Stock ? $reserved->held( $product_id ) : 0;
				$new_stock = max( 0, (int) $quantity - $held );
				$status    = $new_stock > 0 ? 'instock' : 'outofstock';

				$changed = false;

				if ( (string) get_post_meta( $product_id, '_stock', true ) !== (string) $new_stock ) {
					update_post_meta( $product_id, '_stock', (string) $new_stock );
					$changed = true;
				}

				if ( (string) get_post_meta( $product_id, '_stock_status', true ) !== $status ) {
					update_post_meta( $product_id, '_stock_status', $status );
					$changed = true;

					// WooCommerce hides products carrying this term when the
					// option is on, and only WC_Product->save() maintains it —
					// which this low-level path skips, as the importer does. The
					// term is written whatever the option says, as WooCommerce
					// itself does: the option is read by the catalogue query, not
					// by the product save.
					if ( 'instock' === $status ) {
						wp_remove_object_terms( $product_id, 'outofstock', 'product_visibility' );
					} else {
						wp_set_object_terms( $product_id, 'outofstock', 'product_visibility', true );
					}

					if ( $parent_id > 0 ) {
						$parents[ $parent_id ] = $parent_id;
					}
				}

				// The per-warehouse figure the storefront shows is the
				// warehouse's own, not the one open orders have been taken out
				// of — the same split the importer makes. Compared on its own
				// rather than written under the flag above: a delivery that
				// arrives while an order of the same size is placed leaves
				// `_stock` unchanged and this number stale, and the storefront
				// shows this one.
				//
				// Replaced as a whole, so a warehouse the operator stopped counting
				// drops out of the storefront along with the total.
				$stocks = wp_json_encode( $stores[ $ms_id ] ?? array() );
				if ( (string) get_post_meta( $product_id, '_mvweb_pi_stocks', true ) !== (string) $stocks ) {
					update_post_meta( $product_id, '_mvweb_pi_stocks', $stocks );
					$changed = true;
				}

				if ( ! $changed ) {
					continue;
				}

				MVweb_PI_Importer::refresh_product_lookup( $product_id );

				// A variation's transients live on its product.
				$touched[] = $parent_id > 0 ? $parent_id : $product_id;
			}
		}

		foreach ( $parents as $parent_id ) {
			MVweb_PI_Importer::sync_variable_parent( $parent_id );
			MVweb_PI_Importer::refresh_attribute_filters( $parent_id );
		}

		// Same batched invalidation the import does at the end of a run: the
		// writes above bypass WC_Product->save(), so WC's per-product transients
		// would otherwise keep serving the stock this sync just replaced.
		if ( function_exists( 'wc_delete_product_transients' ) ) {
			foreach ( array_unique( $touched ) as $product_id ) {
				wc_delete_product_transients( $product_id );
			}
		}

		return array(
			'reported' => count( $stock ),
			'matched'  => $matched,
			'updated'  => count( $touched ),
		);
	}

	/**
	 * Which product carries which MoySklad id.
	 *
	 * One query rather than a lookup per reported row: the report arrives whole,
	 * and a catalogue of ten thousand would otherwise spend ten thousand round
	 * trips working out who is who.
	 *
	 * Ordered so the lowest product id of a duplicated article wins. The importer
	 * treats that copy as the canonical one and zeroes the rest; writing stock
	 * onto the copies here would put duplicates back on sale behind its back.
	 *
	 * Only the id mapping comes from here. The stock a product currently holds is
	 * read through {@see get_post_meta()} instead — see apply().
	 *
	 * @since 1.1.0
	 * @since 1.3.0 Variations too, with their parent.
	 * @return array<string, array{id: int, parent: int}> MoySklad id => product or variation id, and its parent (0 for a product).
	 */
	private function products_by_ms_id(): array {
		global $wpdb;

		// Variations carry their variant's id and take its stock. A product with
		// variations is left out: it has no stock of its own, and a zero line
		// for it would put the product out of stock over its variations' heads.
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT ms.meta_value AS ms_id, p.ID AS product_id, p.post_parent AS parent_id
				 FROM {$wpdb->postmeta} ms
				 INNER JOIN {$wpdb->posts} p
				         ON p.ID = ms.post_id
				        AND p.post_type IN ( 'product', 'product_variation' )
				        AND p.post_status != 'trash'
				 WHERE ms.meta_key = %s
				   AND NOT EXISTS (
				       SELECT 1
				         FROM {$wpdb->term_relationships} tr
				         INNER JOIN {$wpdb->term_taxonomy} tt
				                 ON tt.term_taxonomy_id = tr.term_taxonomy_id
				                AND tt.taxonomy = 'product_type'
				         INNER JOIN {$wpdb->terms} t
				                 ON t.term_id = tt.term_id
				                AND t.slug = 'variable'
				        WHERE tr.object_id = p.ID
				   )
				 ORDER BY p.ID ASC",
				self::ID_META
			),
			ARRAY_A
		);

		$map = array();
		foreach ( (array) $rows as $row ) {
			$ms_id = (string) $row['ms_id'];
			if ( '' === $ms_id || isset( $map[ $ms_id ] ) ) {
				continue;
			}

			$map[ $ms_id ] = array(
				'id'     => (int) $row['product_id'],
				'parent' => (int) $row['parent_id'],
			);
		}

		return $map;
	}

	/**
	 * Schedule or unschedule the sync.
	 *
	 * @since 1.1.0
	 * @param string $interval Recurrence key, or 'disabled'.
	 * @return void
	 */
	public static function schedule( string $interval ): void {
		wp_clear_scheduled_hook( self::HOOK );

		if ( 'disabled' === $interval || '' === $interval ) {
			return;
		}

		// A stock sync against a price-list file has nothing to ask and nowhere
		// to ask it. The schedule is put back when the source is switched.
		if ( 'moysklad' !== mvweb_pi_source_mode() ) {
			return;
		}

		wp_schedule_event( time(), $interval, self::HOOK );
	}

	/**
	 * The interval the sync is running on, if any.
	 *
	 * @since 1.1.0
	 * @return string|false
	 */
	public static function get_schedule(): string|false {
		$event = wp_get_scheduled_event( self::HOOK );
		return $event ? $event->schedule : false;
	}

	/**
	 * When the sync runs next.
	 *
	 * @since 1.1.0
	 * @return int|false
	 */
	public static function get_next_run(): int|false {
		return wp_next_scheduled( self::HOOK );
	}

	/**
	 * The intervals offered in the settings.
	 *
	 * @since 1.1.0
	 * @return array<string, string>
	 */
	public static function get_interval_choices(): array {
		return array(
			'disabled'       => __( 'Disabled', 'mvweb-price-importer' ),
			'mvweb_pi_5min'  => __( 'Every 5 minutes', 'mvweb-price-importer' ),
			'mvweb_pi_15min' => __( 'Every 15 minutes', 'mvweb-price-importer' ),
			'mvweb_pi_30min' => __( 'Every 30 minutes', 'mvweb-price-importer' ),
			'hourly'         => __( 'Every hour', 'mvweb-price-importer' ),
		);
	}
}
