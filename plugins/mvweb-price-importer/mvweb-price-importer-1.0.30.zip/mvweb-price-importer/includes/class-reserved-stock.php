<?php
/**
 * How much of each product the shop already owes to orders it has not closed.
 *
 * The supplier's price list carries the physical stock of their warehouse and
 * knows nothing about orders taken here. WooCommerce, meanwhile, has already
 * subtracted the ordered quantity from `_stock` and marked the order as
 * stock-reduced. Writing the supplier's number on top erases that, and the
 * goods promised to one buyer go back on the shelf for the next one.
 *
 * This class answers the one question the importer needs before it writes:
 * how many units of this product are already spoken for.
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Reserved_Stock
 *
 * @since 1.1.0
 */
class MVweb_PI_Reserved_Stock {

	/**
	 * Product id => units held by open orders.
	 *
	 * @since 1.1.0
	 * @var array<int, int>
	 */
	private array $held = array();

	/**
	 * Rebuild the map from the current open orders.
	 *
	 * One pass over the orders, not one query per product: WooCommerce primes
	 * the line items of the whole result set with a single `IN (...)` query, so
	 * the cost is a flat dozen queries whether there are twenty open orders or
	 * two hundred.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function refresh(): void {
		$this->held = array();

		if ( ! function_exists( 'wc_get_orders' ) ) {
			return;
		}

		/**
		 * Order statuses whose goods count as spoken for.
		 *
		 * The default pair is the one where the goods are promised but not yet
		 * handed over. `completed` is deliberately absent: those goods have
		 * left the building, and the supplier's next price list already
		 * reflects that. Shops that ship on a different signal can say so.
		 *
		 * @since 1.1.0
		 * @param string[] $statuses Order statuses, `wc_` prefixed.
		 */
		$statuses = (array) apply_filters(
			'mvweb_pi_reserving_order_statuses',
			array( 'wc-on-hold', 'wc-processing' )
		);

		if ( empty( $statuses ) ) {
			return;
		}

		$orders = wc_get_orders(
			array(
				'status' => $statuses,
				'type'   => 'shop_order',
				'limit'  => -1,
				'return' => 'objects',
			)
		);

		foreach ( (array) $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			// The flag WooCommerce sets when it actually took the goods off the
			// shelf. An order that never reduced stock holds nothing. Read
			// through the order object, not post meta: under high-performance
			// order storage the value lives in a column, and get_post_meta()
			// would quietly return an empty string for every order.
			if ( ! $order->get_order_stock_reduced() ) {
				continue;
			}

			foreach ( $order->get_items() as $item ) {
				// What WooCommerce actually deducted for this line, which is
				// what it will hand back on cancellation. Not the ordered
				// quantity: a partial refund parts the two.
				$units = (int) $item->get_meta( '_reduced_stock', true );
				if ( $units <= 0 ) {
					continue;
				}

				$product = $item->get_product();
				if ( ! $product ) {
					continue;
				}

				// A variation can have its stock kept on the parent; the units
				// have to land on whichever product actually carries the count.
				$product_id = (int) $product->get_stock_managed_by_id();
				if ( $product_id <= 0 ) {
					continue;
				}

				$this->held[ $product_id ] = ( $this->held[ $product_id ] ?? 0 ) + $units;
			}
		}
	}

	/**
	 * Units of this product held by open orders.
	 *
	 * @since 1.1.0
	 * @param int $product_id Product id.
	 * @return int
	 */
	public function held( int $product_id ): int {
		return $this->held[ $product_id ] ?? 0;
	}
}
