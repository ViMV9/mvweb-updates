<?php
/**
 * YML Parser — Yandex.Market XML parsing via XMLReader.
 *
 * Uses LIBXML_NONET | LIBXML_NOENT for XXE protection.
 * Streaming parser — processes one offer at a time without loading
 * the entire XML document into memory.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Parser_YML
 *
 * Streaming YML (Yandex.Market XML) parser with XXE protection.
 *
 * @since 1.0.0
 */
class MVweb_PI_Parser_YML {

	/**
	 * Path to the YML file.
	 *
	 * @var string
	 */
	private string $file_path;

	/**
	 * Parsed categories from the YML file.
	 *
	 * @var array<string, array{id: string, name: string, parentId: string}>
	 */
	private array $categories = array();

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 * @param string $file_path Path to YML file.
	 */
	public function __construct( string $file_path ) {
		$this->file_path = $file_path;
	}

	/**
	 * Get headers (field names) available in the YML file.
	 *
	 * Unions field names across EVERY offer in the feed. YML is a sparse format
	 * — optional but important tags like <description> and <picture> appear only
	 * on the offers that carry them, often deep in the file (the first one may be
	 * offer #65). Field mapping is configured once and must surface every tag, so
	 * we scan the whole feed rather than a sample. XMLReader streams the file, so
	 * memory stays flat regardless of feed size, and a full ~900-offer feed scans
	 * in a few milliseconds.
	 *
	 * @since 1.0.0
	 * @return string[] Array of available field names.
	 */
	public function get_headers(): array {
		$reader = new \XMLReader();
		$opened = $reader->open( $this->file_path, null, LIBXML_NONET | LIBXML_NOENT );

		if ( ! $opened ) {
			return array();
		}

		// Walk the document with read() and collect field names from each
		// <offer> element. read() descends into the first offer's children
		// after expand(), but the localName/nodeType guard ignores everything
		// that isn't an <offer> open tag, so child nodes are skipped harmlessly
		// and every offer is still visited exactly once. expand() materialises
		// the current offer's subtree into XMLReader's internal document, which
		// is reset on the next expand(), keeping memory flat across the whole feed.
		$seen = array();

		try {
			while ( $reader->read() ) {
				if ( \XMLReader::ELEMENT !== $reader->nodeType || 'offer' !== $reader->localName ) {
					continue;
				}

				$node = $reader->expand();
				if ( $node instanceof \DOMElement ) {
					foreach ( $this->extract_field_names( $node ) as $field ) {
						$seen[ $field ] = true;
					}
				}
			}
		} finally {
			$reader->close();
		}

		return array_keys( $seen );
	}

	/**
	 * Parse categories from the YML file.
	 *
	 * @since 1.0.0
	 * @return array<string, array{id: string, name: string, parentId: string}> Categories indexed by ID.
	 */
	public function get_categories(): array {
		if ( ! empty( $this->categories ) ) {
			return $this->categories;
		}

		$reader = new \XMLReader();
		$opened = $reader->open( $this->file_path, null, LIBXML_NONET | LIBXML_NOENT );

		if ( ! $opened ) {
			return array();
		}

		while ( $reader->read() ) {
			if ( \XMLReader::ELEMENT === $reader->nodeType && 'category' === $reader->localName ) {
				$id        = $reader->getAttribute( 'id' ) ?? '';
				$parent_id = $reader->getAttribute( 'parentId' ) ?? '';
				$name      = $reader->readString();

				if ( '' !== $id ) {
					$this->categories[ $id ] = array(
						'id'       => $id,
						'name'     => $name,
						'parentId' => $parent_id,
					);
				}
			}

			// Stop after categories section (before offers).
			if ( \XMLReader::ELEMENT === $reader->nodeType && 'offers' === $reader->localName ) {
				break;
			}
		}

		$reader->close();

		return $this->categories;
	}

	/**
	 * Stream offer rows as a generator.
	 *
	 * Yields associative arrays with offer data.
	 * Uses XMLReader for streaming — one offer at a time.
	 *
	 * @since 1.0.0
	 * @return \Generator<int, array<string, string>> Yields offer data arrays.
	 */
	public function rows(): \Generator {
		// Pre-load categories for category name resolution.
		$this->get_categories();

		$reader = new \XMLReader();
		$opened = $reader->open( $this->file_path, null, LIBXML_NONET | LIBXML_NOENT );

		if ( ! $opened ) {
			return;
		}

		// finally guarantees the reader (and its file descriptor) is closed
		// even if the consumer throws while we're paused on a yield — without
		// it a mid-stream exception in the import loop would leak the handle
		// until GC, which matters on long-running CLI batch processes.
		try {
			while ( $reader->read() ) {
				if ( \XMLReader::ELEMENT !== $reader->nodeType || 'offer' !== $reader->localName ) {
					continue;
				}

				$node = $reader->expand();
				if ( ! $node instanceof \DOMElement ) {
					continue;
				}

				$offer = $this->parse_offer( $node );
				if ( ! empty( $offer ) ) {
					yield $offer;
				}
			}
		} finally {
			$reader->close();
		}
	}

	/**
	 * Parse a single offer element into an associative array.
	 *
	 * @since 1.0.0
	 * @param \DOMElement $node The offer DOM element.
	 * @return array<string, string> Parsed offer data.
	 */
	private function parse_offer( \DOMElement $node ): array {
		// The two historical attributes are read first and unconditionally, so
		// the key exists even when the attribute does not: an <offer> carrying
		// neither attributes nor children still yields a row and reaches the
		// converter, which records it as an empty-SKU invalid row instead of
		// vanishing without a trace. They also keep winning over a child tag of
		// the same name, exactly as before.
		$data = array(
			'id'        => $node->getAttribute( 'id' ),
			'available' => $node->getAttribute( 'available' ),
		);

		// Standard YML child elements.
		$standard_fields = array(
			'url', 'price', 'oldprice', 'currencyId', 'categoryId',
			'picture', 'name', 'description', 'vendor', 'vendorCode',
			'barcode', 'stock_quantity', 'count',
		);

		foreach ( $standard_fields as $field ) {
			$elements = $node->getElementsByTagName( $field );
			if ( $elements->length > 0 ) {
				if ( 'picture' === $field ) {
					// Collect all pictures.
					$pictures = array();
					for ( $i = 0; $i < $elements->length; $i++ ) {
						$pic = trim( $elements->item( $i )->textContent );
						if ( '' !== $pic ) {
							$pictures[] = $pic;
						}
					}
					$data['picture'] = $pictures[0] ?? '';
					if ( count( $pictures ) > 1 ) {
						$data['gallery'] = implode( ',', array_slice( $pictures, 1 ) );
					}
				} else {
					$data[ $field ] = trim( $elements->item( 0 )->textContent );
				}
			}
		}

		// Capture any remaining direct child element by its tag name. The
		// standard set above covers the well-known YML tags; this generic pass
		// makes custom, non-standard tags (e.g. a supplier-specific
		// <wholesale> element) readable and therefore mappable. It mirrors
		// extract_field_names(), so every column offered in the mapping
		// dropdown actually yields a value. The isset() guard keeps the
		// specialised handling above authoritative, and 'param'/'picture' are
		// skipped because they have their own dedicated handling.
		foreach ( $node->childNodes as $child ) {
			if ( XML_ELEMENT_NODE !== $child->nodeType ) {
				continue;
			}
			$tag = $child->localName;
			if ( 'param' === $tag || 'picture' === $tag || isset( $data[ $tag ] ) ) {
				continue;
			}
			$data[ $tag ] = trim( $child->textContent );
		}

		// Remaining offer attributes. Suppliers put product flags there — an
		// offer like <offer id="10995" newest="false" sellout="true"> carries
		// three of them, and reading only id/available dropped every one before
		// it could reach the mapping UI.
		//
		// Applied after the child elements and never over an existing key: a
		// child tag has always been the source for a custom field name, and an
		// attribute that happens to share that name must not silently take its
		// place on an existing feed.
		foreach ( $this->read_attributes( $node ) as $name => $value ) {
			if ( ! array_key_exists( $name, $data ) ) {
				$data[ $name ] = $value;
			}
		}

		// Parse <param name="..."> tags.
		$params = $node->getElementsByTagName( 'param' );
		for ( $i = 0; $i < $params->length; $i++ ) {
			$param      = $params->item( $i );
			$param_name = $param->getAttribute( 'name' );
			if ( '' !== $param_name ) {
				$data[ $this->param_key( $param_name ) ] = trim( $param->textContent );
			}
		}

		// Resolve category name from ID.
		if ( ! empty( $data['categoryId'] ) && isset( $this->categories[ $data['categoryId'] ] ) ) {
			$data['category_name'] = $this->categories[ $data['categoryId'] ]['name'];
			$parent_id             = $this->categories[ $data['categoryId'] ]['parentId'];
			if ( '' !== $parent_id && isset( $this->categories[ $parent_id ] ) ) {
				$data['parent_category_name'] = $this->categories[ $parent_id ]['name'];
			}
		}

		// Map vendorCode/id to sku field for consistency.
		if ( ! empty( $data['vendorCode'] ) ) {
			$data['sku'] = $data['vendorCode'];
		} elseif ( ! empty( $data['id'] ) ) {
			$data['sku'] = $data['id'];
		}

		// Map stock from <count> or <stock_quantity>. The `available` attribute
		// is deliberately not consulted: it is a yes/no flag, not a quantity,
		// and absint() would turn it into a zero stock for the whole feed.
		if ( ! empty( $data['count'] ) ) {
			$data['stock'] = $data['count'];
		} elseif ( ! empty( $data['stock_quantity'] ) ) {
			$data['stock'] = $data['stock_quantity'];
		}

		return $data;
	}

	/**
	 * Extract field names from an offer element.
	 *
	 * @since 1.0.0
	 * @param \DOMElement $node The offer DOM element.
	 * @return string[] Array of field names.
	 */
	private function extract_field_names( \DOMElement $node ): array {
		// `id` and `available` stay unconditionally so a mapping configured
		// against them keeps its dropdown entry even on a feed where the
		// attribute is absent from some offers.
		$names = array_merge( array( 'id', 'available' ), array_keys( $this->read_attributes( $node ) ) );

		foreach ( $node->childNodes as $child ) {
			if ( XML_ELEMENT_NODE !== $child->nodeType ) {
				continue;
			}

			$tag = $child->localName;

			if ( 'param' === $tag ) {
				$param_name = $child->getAttribute( 'name' );
				if ( '' !== $param_name ) {
					$names[] = $this->param_key( $param_name );
				}
			} else {
				$names[] = $tag;
			}
		}

		return array_unique( $names );
	}

	/**
	 * Read every attribute of an <offer> element into a field map.
	 *
	 * Must produce identical keys in parse_offer() and extract_field_names(),
	 * otherwise a mapped attribute would never match the parsed value — hence
	 * the single shared helper, same reasoning as param_key() below.
	 *
	 * Attribute names that collide with a key this parser or the converter
	 * derives itself are skipped. `category_name`, `parent_category_name` and
	 * `gallery` are read straight from the row by the converter without going
	 * through the operator's mapping, so a supplier attribute of that name
	 * would silently override a computed value; `sku`, `stock` and `picture`
	 * are rebuilt further down parse_offer() anyway. The generic child-tag
	 * pass guards itself with isset(), but that guard runs after the
	 * attributes and so cannot protect these keys.
	 *
	 * @since 1.0.27
	 * @param \DOMElement $node The offer DOM element.
	 * @return array<string, string> Attribute name => value.
	 */
	private function read_attributes( \DOMElement $node ): array {
		$reserved = array( 'sku', 'stock', 'picture', 'gallery', 'category_name', 'parent_category_name' );
		$data     = array();

		foreach ( $node->attributes as $attribute ) {
			$name = $attribute->localName; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM API property.
			if ( '' === $name || in_array( $name, $reserved, true ) ) {
				continue;
			}
			$data[ $name ] = trim( $attribute->value );
		}

		return $data;
	}

	/**
	 * Build a stable, collision-free header key for a <param name="…"> tag.
	 *
	 * WordPress' sanitize_key() strips every non-ASCII character, so a Cyrillic
	 * param name like «Оптовая цена» collapsed to the bare prefix `param_` —
	 * every Cyrillic-named param then shared one key and overwrote the others,
	 * both in the mapping dropdown and in the parsed row. We transliterate the
	 * Russian name to ASCII first (mirrors the category slug builder) so each
	 * param keeps a distinct, human-readable key (`param_optovaya_cena`) that an
	 * operator can recognise and map by hand. A name that leaves nothing after
	 * transliteration falls back to a short hash so it still stays unique.
	 *
	 * Must produce identical output in parse_offer() and extract_field_names(),
	 * otherwise the mapped column would never match the parsed value — hence the
	 * single shared helper.
	 *
	 * Backward-compatible for Latin param names: transliteration is a no-op on
	 * ASCII and sanitize_key() already lowercases, so a name like "Weight" still
	 * yields exactly `param_weight` as before this helper existed. Only Cyrillic
	 * names — which previously collapsed to the bare `param_` — change, and that
	 * path was broken to begin with, so no working mapping regresses.
	 *
	 * @since 1.0.0
	 * @param string $param_name Raw `name` attribute of the <param> tag.
	 * @return string Header key, always prefixed with `param_`.
	 */
	private function param_key( string $param_name ): string {
		$map = array(
			'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd',
			'е' => 'e', 'ё' => 'e', 'ж' => 'zh', 'з' => 'z', 'и' => 'i',
			'й' => 'y', 'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n',
			'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't',
			'у' => 'u', 'ф' => 'f', 'х' => 'h', 'ц' => 'c', 'ч' => 'ch',
			'ш' => 'sh', 'щ' => 'sch', 'ъ' => '', 'ы' => 'y', 'ь' => '',
			'э' => 'e', 'ю' => 'yu', 'я' => 'ya',
		);

		$slug = sanitize_key( strtr( mb_strtolower( $param_name, 'UTF-8' ), $map ) );

		if ( '' === $slug ) {
			$slug = substr( md5( $param_name ), 0, 8 );
		}

		return 'param_' . $slug;
	}
}
