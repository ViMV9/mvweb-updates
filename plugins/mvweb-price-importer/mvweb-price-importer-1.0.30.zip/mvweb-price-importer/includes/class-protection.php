<?php
/**
 * Price list protection — hand the price file out only against a key.
 *
 * Suppliers upload the price list onto the shop's own server, always to a
 * fixed path they choose. That leaves the whole catalogue — prices, stock,
 * barcodes — readable by anyone who guesses the URL and crawlable by search
 * engines. Renaming the file is not an option, so this class closes the door
 * instead: a rewrite rule answers 403 for the price directory unless the
 * request carries a secret key, and the importer's own source URLs get that
 * key appended.
 *
 * The supplier's upload is untouched. The rule lives in .htaccess and governs
 * HTTP reads only, while the price list arrives over FTP.
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Protection
 *
 * @since 1.1.0
 */
class MVweb_PI_Protection {

	/**
	 * Marker enclosing our block in .htaccess.
	 *
	 * Must never be `WordPress`: core rewrites everything between its own
	 * markers whenever permalinks are flushed, which would wipe our rules.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const MARKER = 'MVweb Price Importer';

	/**
	 * Query argument carrying the key.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const QUERY_ARG = 'k';

	/**
	 * Option holding the current key.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const KEY_OPTION = 'mvweb_pi_access_key';

	/**
	 * Directory names accepted into a rewrite pattern.
	 *
	 * A whitelist, not an escape pass: everything that reaches the Apache
	 * config is limited to letters, digits, hyphen and underscore, so no
	 * regex metacharacter, comment marker or line break can survive into the
	 * file. A blacklist here would be as unreliable as a blacklist against
	 * SQL injection.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const SEGMENT_PATTERN = '/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/';

	/**
	 * Current key, empty string when protection was never switched on.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function get_key(): string {
		$key = get_option( self::KEY_OPTION, '' );
		return is_string( $key ) ? $key : '';
	}

	/**
	 * Generate a fresh key.
	 *
	 * Letters and digits only: the key travels in a query string, and
	 * special characters would need encoding, which is one more chance for
	 * the stored URL and the rewrite condition to drift apart.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function generate_key(): string {
		return wp_generate_password( 32, false, false );
	}

	/**
	 * Turn protection on (or re-apply it after the source URL changed).
	 *
	 * Writes the rule and asks the live site whether it works, because a server
	 * that ignores .htaccess must never leave the operator believing the price
	 * list is closed. Anything the site does not confirm puts the previous
	 * rules back.
	 *
	 * @since 1.1.0
	 * @param array  $settings Settings array, modified in place (source URLs gain the key).
	 * @param string $key      Key to install.
	 * @return true|WP_Error True when proven, error describing what stopped us.
	 */
	public static function enable( array &$settings, string $key ) {
		if ( is_multisite() ) {
			return new WP_Error(
				'mvweb_pi_protect_multisite',
				__( 'Not available on a multisite network: every site there shares a single .htaccess file, so this switch would open or close the price list for the whole network.', 'mvweb-price-importer' )
			);
		}

		if ( ! preg_match( '/^[A-Za-z0-9]{16,64}$/', $key ) ) {
			return new WP_Error(
				'mvweb_pi_protect_key',
				__( 'Internal error: the access key is malformed.', 'mvweb-price-importer' )
			);
		}

		$file  = self::htaccess_file();
		$check = self::check_writable( $file );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$local = array();
		$dirs  = array();
		foreach ( self::source_urls( $settings ) as $field => $url ) {
			if ( ! self::is_local( $url ) ) {
				continue;
			}
			$dir = self::relative_dir( $url );
			if ( is_wp_error( $dir ) ) {
				return $dir;
			}
			$dirs[ $dir ]    = $dir;
			$local[ $field ] = $url;
		}

		if ( empty( $local ) ) {
			return new WP_Error(
				'mvweb_pi_protect_no_local_source',
				__( 'No price list on this site to protect. This switch closes a file that lies on this server; a price list hosted by the supplier can only be protected on their side.', 'mvweb-price-importer' )
			);
		}

		// Remember the rules currently in force, to put them back if the site
		// itself objects to the new ones.
		$previous = self::current_rules();

		// The key is stored before the rule is written, never after. A process
		// killed between the two would otherwise leave the folder demanding a
		// key that was recorded nowhere.
		update_option( self::KEY_OPTION, $key, false );

		if ( ! self::write( self::build_rules( $dirs, $key ) ) ) {
			return new WP_Error(
				'mvweb_pi_protect_write_failed',
				/* translators: %s: path to the .htaccess file */
				sprintf( __( 'Could not write to %s.', 'mvweb-price-importer' ), $file )
			);
		}

		// Every configured source is asked, not just the first one: with
		// several warehouses each lives in its own folder and gets its own
		// rule, and "checked" has to mean all of them.
		$verified = self::verify_site();
		foreach ( $local as $url ) {
			if ( ! is_wp_error( $verified ) ) {
				$verified = self::verify_source( $url, $key );
			}
		}

		if ( is_wp_error( $verified ) ) {
			self::write( $previous );
			return $verified;
		}

		self::stamp_key( $settings, $local, $key );

		mvweb_pi_log(
			sprintf(
				/* translators: %s: comma-separated directory names */
				__( 'Price list protection is on. Closed directories: %s.', 'mvweb-price-importer' ),
				implode( ', ', $dirs )
			),
			'info'
		);

		return true;
	}

	/**
	 * Turn protection off: drop the rule, the key, and the key in the URLs.
	 *
	 * The rule goes first and the addresses are only cleaned once it is gone.
	 * The other way round — a file that turned read-only meanwhile — would
	 * strip the key from the source URLs while the folder still demands one,
	 * and every import would start collecting 403s under a switch reading
	 * "off".
	 *
	 * @since 1.1.0
	 * @param array $settings Settings array, modified in place.
	 * @return bool True when the rule is gone.
	 */
	public static function disable( array &$settings ): bool {
		if ( ! empty( self::current_rules() ) && ! self::write( array() ) ) {
			return false;
		}

		delete_option( self::KEY_OPTION );

		foreach ( self::source_urls( $settings, true ) as $field => $url ) {
			if ( self::is_local( $url ) ) {
				self::put_url( $settings, $field, remove_query_arg( self::QUERY_ARG, $url ) );
			}
		}

		mvweb_pi_log( __( 'Price list protection is off — the file is public again.', 'mvweb-price-importer' ), 'info' );

		return true;
	}

	/**
	 * Absolute path of the site's root .htaccess.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function htaccess_file(): string {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		return get_home_path() . '.htaccess';
	}

	/**
	 * Refuse early when the file cannot be written.
	 *
	 * Same test core runs on the Permalinks screen before it offers to update
	 * the rules itself.
	 *
	 * @since 1.1.0
	 * @param string $file Path to .htaccess.
	 * @return true|WP_Error
	 */
	private static function check_writable( string $file ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable -- core runs the same plain check on this very file before offering to update the permalink rules.
		$writable = file_exists( $file ) ? is_writable( $file ) : is_writable( dirname( $file ) );
		if ( $writable ) {
			return true;
		}

		return new WP_Error(
			'mvweb_pi_protect_readonly',
			/* translators: %s: path to the .htaccess file */
			sprintf( __( 'The file %s is not writable, so the rule cannot be installed. Grant write access to it and try again.', 'mvweb-price-importer' ), $file )
		);
	}

	/**
	 * Source URLs actually used by an import, keyed by their storage slot.
	 *
	 * Mirrors MVweb_PI_Cron::build_sources(): warehouses win, and the single
	 * source URL is only used when no warehouse is configured. Protecting
	 * anything else would install rules for a file the importer never reads.
	 *
	 * @since 1.1.0
	 * @param array $settings Settings array.
	 * @param bool  $all      True to return every stored URL regardless of mode.
	 * @return array Map of field key => URL.
	 */
	private static function source_urls( array $settings, bool $all = false ): array {
		$urls       = array();
		$warehouses = ( ! empty( $settings['warehouses'] ) && is_array( $settings['warehouses'] ) ) ? $settings['warehouses'] : array();

		foreach ( $warehouses as $index => $wh ) {
			if ( ! empty( $wh['url'] ) ) {
				$urls[ 'warehouses.' . $index ] = (string) $wh['url'];
			}
		}

		if ( ( $all || empty( $urls ) ) && ! empty( $settings['source_url'] ) ) {
			$urls['source_url'] = (string) $settings['source_url'];
		}

		return $urls;
	}

	/**
	 * Write a URL back into the slot it came from.
	 *
	 * @since 1.1.0
	 * @param array  $settings Settings array, modified in place.
	 * @param string $field    Slot key produced by source_urls().
	 * @param string $url      New URL.
	 * @return void
	 */
	private static function put_url( array &$settings, string $field, string $url ): void {
		if ( 'source_url' === $field ) {
			$settings['source_url'] = $url;
			return;
		}

		$index = substr( $field, strlen( 'warehouses.' ) );
		if ( isset( $settings['warehouses'][ $index ] ) ) {
			$settings['warehouses'][ $index ]['url'] = $url;
		}
	}

	/**
	 * Stamp the key onto the source URLs the rule actually covers.
	 *
	 * Only those: a leftover single Source URL, ignored while warehouses are
	 * configured, gets no rule of its own, and showing it with a key would
	 * claim a protection it does not have. WordPress replaces an existing key
	 * instead of appending a second one, so repeated saves and key rotations
	 * never pile up `k=old&k=new`.
	 *
	 * @since 1.1.0
	 * @param array  $settings Settings array, modified in place.
	 * @param array  $local    Map of slot key => URL, as built by enable().
	 * @param string $key      Key to stamp.
	 * @return void
	 */
	private static function stamp_key( array &$settings, array $local, string $key ): void {
		foreach ( $local as $field => $url ) {
			self::put_url( $settings, $field, add_query_arg( self::QUERY_ARG, $key, $url ) );
		}
	}

	/**
	 * Is this URL served by this very site?
	 *
	 * Rewriting our own .htaccess does nothing for a file on the supplier's
	 * server, so foreign sources are left alone.
	 *
	 * @since 1.1.0
	 * @param string $url URL to test.
	 * @return bool
	 */
	private static function is_local( string $url ): bool {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		$home = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );

		return '' !== $host && $host === $home;
	}

	/**
	 * Directory holding the price file, relative to the site root.
	 *
	 * @since 1.1.0
	 * @param string $url Source URL.
	 * @return string|WP_Error Directory without slashes, or the reason it cannot be used.
	 */
	private static function relative_dir( string $url ) {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		$base = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$base = ( '' === $base ) ? '/' : $base;

		if ( 0 !== stripos( $path, $base ) ) {
			return new WP_Error(
				'mvweb_pi_protect_outside',
				/* translators: %s: price list URL */
				sprintf( __( 'The address %s lies outside the site root, so no rule can cover it.', 'mvweb-price-importer' ), $url )
			);
		}

		$relative = ltrim( substr( $path, strlen( $base ) ), '/' );
		$dir      = trim( dirname( '/' . $relative ), '/' );

		// A price list in the site root would turn the rule into a blanket
		// 403 for every request — the whole site would go dark. Refuse.
		if ( '' === $dir || '.' === $dir ) {
			return new WP_Error(
				'mvweb_pi_protect_root',
				__( 'The price list lies in the site root, and a rule for the root would answer 403 to the entire site. Ask the supplier to upload it into a folder of its own.', 'mvweb-price-importer' )
			);
		}

		$clean = array();
		foreach ( explode( '/', $dir ) as $segment ) {
			$decoded = rawurldecode( $segment );
			if ( ! preg_match( self::SEGMENT_PATTERN, $decoded ) ) {
				return new WP_Error(
					'mvweb_pi_protect_segment',
					sprintf(
						/* translators: %s: folder name taken from the price list URL */
						__( 'The folder name "%s" cannot be used in a server rule. Only Latin letters, digits, hyphen and underscore are accepted.', 'mvweb-price-importer' ),
						$segment
					)
				);
			}
			$clean[] = $decoded;
		}

		return implode( '/', $clean );
	}

	/**
	 * Rule lines for the given directories.
	 *
	 * Every RewriteCond binds to the single RewriteRule that follows it, so
	 * each directory gets its own pair.
	 *
	 * @since 1.1.0
	 * @param array  $dirs Directories relative to the site root.
	 * @param string $key  Key that opens the file.
	 * @return array Lines to place between the markers.
	 */
	private static function build_rules( array $dirs, string $key ): array {
		$lines = array(
			'<IfModule mod_rewrite.c>',
			'RewriteEngine On',
		);

		foreach ( $dirs as $dir ) {
			$lines[] = 'RewriteCond %{QUERY_STRING} !(^|&)' . self::QUERY_ARG . '=' . $key . '($|&)';
			$lines[] = 'RewriteRule ^' . $dir . '/ - [F,L]';
		}

		$lines[] = '</IfModule>';

		return $lines;
	}

	/**
	 * Put the block between our markers in the root .htaccess.
	 *
	 * Core writes its own permalink rules the very same way: nothing outside
	 * the markers is touched, the file is locked for the whole
	 * read-modify-write, and it is created when missing. An empty insertion
	 * clears our rules.
	 *
	 * @since 1.1.0
	 * @param array $lines Lines to write.
	 * @return bool
	 */
	private static function write( array $lines ): bool {
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		return (bool) insert_with_markers( self::htaccess_file(), self::MARKER, $lines );
	}

	/**
	 * Rule lines currently sitting between our markers.
	 *
	 * Comment lines are dropped: insert_with_markers() prepends its own
	 * explanatory comment on every write, so feeding them back would stack a
	 * fresh copy on top each time.
	 *
	 * @since 1.1.0
	 * @return array
	 */
	private static function current_rules(): array {
		$file = self::htaccess_file();
		if ( ! file_exists( $file ) ) {
			return array();
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file -- reading the file core itself writes with fopen().
		$lines  = file( $file, FILE_IGNORE_NEW_LINES );
		$rules  = array();
		$inside = false;

		foreach ( (array) $lines as $line ) {
			if ( str_contains( $line, '# BEGIN ' . self::MARKER ) ) {
				$inside = true;
				continue;
			}
			if ( str_contains( $line, '# END ' . self::MARKER ) ) {
				break;
			}
			if ( $inside && '' !== trim( $line ) && ! str_starts_with( ltrim( $line ), '#' ) ) {
				$rules[] = $line;
			}
		}

		return $rules;
	}

	/**
	 * The site must still be standing after the rule went in.
	 *
	 * A broken .htaccess answers 500 to everything; any other code belongs to
	 * the site's own doing — a login wall, maintenance mode — and is none of
	 * our business.
	 *
	 * @since 1.1.0
	 * @return true|WP_Error
	 */
	private static function verify_site() {
		$home = wp_remote_get(
			home_url( '/' ),
			array(
				'timeout'             => 15,
				'limit_response_size' => 2048,
			)
		);

		if ( is_wp_error( $home ) ) {
			return new WP_Error(
				'mvweb_pi_protect_unreachable',
				/* translators: %s: error message returned by the HTTP request */
				sprintf( __( 'The rule was rolled back: the site did not answer a test request (%s). The import fetches the price list the same way, so this has to work first.', 'mvweb-price-importer' ), $home->get_error_message() )
			);
		}

		if ( 500 === (int) wp_remote_retrieve_response_code( $home ) ) {
			return new WP_Error(
				'mvweb_pi_protect_broke_site',
				__( 'The rule was rolled back: after writing it the site started answering with a server error.', 'mvweb-price-importer' )
			);
		}

		return true;
	}

	/**
	 * Prove over real HTTP that the rule does what it promises.
	 *
	 * Neither PHP nor WordPress can tell whether Apache reads .htaccess at
	 * all: on nginx, or under `AllowOverride None`, the write succeeds and the
	 * rule is simply ignored. Only a live request settles it.
	 *
	 * Order matters: the file has to be fetched with the key before its refusal
	 * without the key proves anything. Our block sits below the WordPress one,
	 * so a path that does not exist on disk is swallowed by the core rewrite
	 * and never reaches our rule — and the site then answers a missing price
	 * list exactly as a server that ignores .htaccess would.
	 *
	 * @since 1.1.0
	 * @param string $url Price list URL to probe.
	 * @param string $key Key that must open it.
	 * @return true|WP_Error
	 */
	private static function verify_source( string $url, string $key ) {
		$args = array(
			'timeout'             => 15,
			'redirection'         => 0,
			'limit_response_size' => 2048,
		);

		// First: is there a price list at that address at all? With the key the
		// rule stands aside, so this is a plain fetch of the file. It has to
		// come first, because a missing file and an ignored rule answer the
		// keyless request with the very same code — WordPress catches paths
		// that do not exist on disk long before our rule is reached.
		$keyed = wp_remote_get( add_query_arg( self::QUERY_ARG, $key, $url ), $args );
		if ( is_wp_error( $keyed ) ) {
			return new WP_Error(
				'mvweb_pi_protect_unreachable',
				/* translators: %s: error message returned by the HTTP request */
				sprintf( __( 'The rule was rolled back: the price list did not answer a test request with the key (%s).', 'mvweb-price-importer' ), $keyed->get_error_message() )
			);
		}

		// A missing file is not reliably a 404: WordPress hands the request to
		// the theme, which answers 200 with a page. What never lies is the
		// content type — a price list is XML, CSV or a spreadsheet, never HTML.
		$keyed_code = (int) wp_remote_retrieve_response_code( $keyed );
		$keyed_type = strtolower( (string) wp_remote_retrieve_header( $keyed, 'content-type' ) );
		if ( 200 !== $keyed_code || str_contains( $keyed_type, 'text/html' ) ) {
			return new WP_Error(
				'mvweb_pi_protect_missing',
				sprintf(
					/* translators: 1: price list URL, 2: HTTP status code */
					__( 'The rule was rolled back: there is no price list at %1$s right now — the address answers HTTP %2$d and a web page rather than a file. Check the address, and switch protection on once the file is in place: a folder with nothing in it cannot be tested.', 'mvweb-price-importer' ),
					mvweb_pi_url_for_log( $url ),
					$keyed_code
				)
			);
		}

		// Second: the file is there, so a refusal without the key can only come
		// from our rule. This is the answer that proves the server reads
		// .htaccess at all.
		$open = wp_remote_get( remove_query_arg( self::QUERY_ARG, $url ), $args );
		if ( is_wp_error( $open ) ) {
			return new WP_Error(
				'mvweb_pi_protect_unreachable',
				/* translators: %s: error message returned by the HTTP request */
				sprintf( __( 'The rule was rolled back: the price list did not answer a test request (%s).', 'mvweb-price-importer' ), $open->get_error_message() )
			);
		}

		$open_code = (int) wp_remote_retrieve_response_code( $open );
		if ( 403 !== $open_code ) {
			return new WP_Error(
				'mvweb_pi_protect_ignored',
				sprintf(
					/* translators: 1: HTTP status code, 2: hint about the web server */
					__( 'The rule was rolled back: without a key the price list still answers HTTP %1$d instead of 403. %2$s', 'mvweb-price-importer' ),
					$open_code,
					self::server_hint()
				)
			);
		}

		return true;
	}

	/**
	 * Extra sentence for the "rule ignored" error.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function server_hint(): string {
		require_once ABSPATH . 'wp-admin/includes/misc.php';

		if ( ! got_mod_rewrite() ) {
			return __( 'This server does not report Apache with mod_rewrite — nginx serves static files itself and never reads .htaccess. Ask the hosting provider for an equivalent rule, or have the price list moved out of the public folder.', 'mvweb-price-importer' );
		}

		return __( 'The file was written, but the server did not act on it — .htaccess files are probably disabled for this site (AllowOverride None). Ask the hosting provider.', 'mvweb-price-importer' );
	}
}
