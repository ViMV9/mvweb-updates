<?php
/**
 * Sending WooCommerce orders to MoySklad.
 *
 * The first thing this plugin writes to somebody else's system, and the whole
 * design follows from that. An order sent twice is a real problem in a real
 * warehouse — goods reserved twice, a picker sent twice, a customer invoiced
 * twice — so every document carries a `syncId` derived from the WooCommerce
 * order it stands for. MoySklad answers a repeat of a request it has already
 * accepted with the entity it created the first time, which makes a retry after
 * a timeout safe and makes the timeout itself uninteresting.
 *
 * Nothing is sent from the checkout request. The order is marked as queued and
 * the sending happens on cron: a warehouse that is slow to answer must never be
 * something the customer waits for, and an API that is down must never be a
 * reason an order cannot be placed.
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Orders
 *
 * @since 1.1.0
 */
class MVweb_PI_Orders {

	/**
	 * Cron hook that drains the queue.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const HOOK = 'mvweb_pi_orders_sync';

	/**
	 * Cron hook that reads document states back from MoySklad.
	 *
	 * Separate from {@see self::HOOK} on purpose: the two run at different
	 * rhythms and can be switched on independently, and clearing one schedule
	 * must not take the other down with it.
	 *
	 * @since 1.2.0
	 * @var string
	 */
	const STATUS_HOOK = 'mvweb_pi_orders_status_sync';

	/**
	 * Order meta: the id MoySklad gave the document.
	 *
	 * Its presence is what "already sent" means.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const META_MS_ID = '_mvweb_pi_ms_order_id';

	/**
	 * Order meta: the document state this order was last seen in.
	 *
	 * Both a debounce and the thing that tells a manual override apart from a
	 * genuine move: while the document sits in the state we already know about,
	 * an order somebody unlocked by hand is left alone.
	 *
	 * @since 1.2.0
	 * @var string
	 */
	const META_MS_STATE = '_mvweb_pi_ms_state';

	/**
	 * Order meta: the status here was set by hand, against MoySklad.
	 *
	 * @since 1.2.0
	 * @var string
	 */
	const META_MANUAL = '_mvweb_pi_status_manual';

	/**
	 * Order meta: whether this order is waiting to be sent.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const META_QUEUED = '_mvweb_pi_ms_queued';

	/**
	 * Order meta: why the last attempt failed.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const META_ERROR = '_mvweb_pi_ms_error';

	/**
	 * Order meta: how many attempts this order has cost.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const META_ATTEMPTS = '_mvweb_pi_ms_attempts';

	/**
	 * Attempts before an order stops being retried.
	 *
	 * A failure that survives this many tries is not a hiccup — it is a document
	 * MoySklad refuses, and repeating it forever only spends the account's
	 * request budget. The order keeps its error message and can be sent again by
	 * hand once the cause is fixed.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const MAX_ATTEMPTS = 5;

	/**
	 * Orders sent per cron run.
	 *
	 * Each order costs two or three requests, so a backlog is drained over
	 * several runs rather than in one burst against the rate limit.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const PER_RUN = 20;

	/**
	 * Where the checkpoint of the last successful state read is kept.
	 *
	 * @since 1.2.0
	 * @var string
	 */
	const STATUS_SINCE_OPTION = 'mvweb_pi_status_sync_since';

	/**
	 * Where the result of the last state read is kept, for the settings screen.
	 *
	 * @since 1.2.0
	 * @var string
	 */
	const STATUS_LAST_OPTION = 'mvweb_pi_status_sync_last';

	/**
	 * Documents asked for per request.
	 *
	 * @since 1.2.0
	 * @var int
	 */
	const STATUS_PAGE = 100;

	/**
	 * How far before its checkpoint a run looks, in seconds.
	 *
	 * @since 1.2.0
	 * @var int
	 */
	const STATUS_OVERLAP = 43200;

	/**
	 * The one WooCommerce status this sync must never set.
	 *
	 * `refunded` creates a real refund record on the full order total and mails
	 * the customer about it, while returning neither the goods to stock nor the
	 * money through the gateway. A refund is a decision, not something a cron
	 * job arrives at. "Возврат" is matched to `cancelled` instead.
	 *
	 * @since 1.2.0
	 * @var string
	 */
	const FORBIDDEN_STATUS = 'refunded';

	/**
	 * Is sending switched on and configured?
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function enabled(): bool {
		if ( 'moysklad' !== mvweb_pi_source_mode() ) {
			return false;
		}

		$settings = get_option( 'mvweb_pi_moysklad', array() );
		if ( ! is_array( $settings ) ) {
			return false;
		}

		return ! empty( $settings['send_orders'] )
			&& '' !== (string) ( $settings['token'] ?? '' )
			&& '' !== (string) ( $settings['organization'] ?? '' );
	}

	/**
	 * WooCommerce statuses at which an order goes to MoySklad.
	 *
	 * @since 1.1.0
	 * @return string[] Statuses without the `wc-` prefix.
	 */
	public static function trigger_statuses(): array {
		$settings = get_option( 'mvweb_pi_moysklad', array() );
		$stored   = is_array( $settings ) && is_array( $settings['order_statuses'] ?? null )
			? $settings['order_statuses']
			: array( 'processing' );

		return array_values( array_filter( array_map( 'sanitize_key', $stored ) ) );
	}

	/**
	 * Is reading document states back from MoySklad switched on?
	 *
	 * Deliberately independent of {@see self::enabled()}: a shop can be given
	 * its statuses by MoySklad while its orders are entered there by hand.
	 *
	 * @since 1.2.0
	 * @return bool
	 */
	public static function pull_enabled(): bool {
		if ( 'moysklad' !== mvweb_pi_source_mode() ) {
			return false;
		}

		$settings = get_option( 'mvweb_pi_moysklad', array() );
		if ( ! is_array( $settings ) ) {
			return false;
		}

		return ! empty( $settings['pull_statuses'] ) && '' !== (string) ( $settings['token'] ?? '' );
	}

	/**
	 * Which MoySklad state turns into which WooCommerce status.
	 *
	 * Only entries the operator actually filled in come back, so an unmapped
	 * state is simply absent rather than present-and-empty.
	 *
	 * @since 1.2.0
	 * @return array<string, string> State id => status without the `wc-` prefix.
	 */
	public static function status_map(): array {
		$settings = get_option( 'mvweb_pi_moysklad', array() );
		$stored   = is_array( $settings ) && is_array( $settings['status_map'] ?? null )
			? $settings['status_map']
			: array();

		$map = array();
		foreach ( $stored as $state_id => $status ) {
			$status = sanitize_key( (string) $status );
			if ( '' === $status || self::FORBIDDEN_STATUS === $status ) {
				continue;
			}

			$map[ (string) $state_id ] = $status;
		}

		return $map;
	}

	/**
	 * Read the states of every document that changed, and apply them here.
	 *
	 * One request per page of a hundred documents, and normally one page: the
	 * filter asks only for what moved since the last successful run.
	 *
	 * @since 1.2.0
	 * @return array{seen: int, changed: int, skipped: int, status: string, message: string}
	 */
	public function check_statuses(): array {
		$result = array(
			'seen'    => 0,
			'changed' => 0,
			'skipped' => 0,
			'status'  => 'success',
			'message' => '',
		);

		if ( ! self::pull_enabled() ) {
			$result['status']  = 'skipped';
			$result['message'] = __( 'Statuses are not being read from MoySklad.', 'mvweb-price-importer' );
			return $result;
		}

		$map = self::status_map();
		if ( empty( $map ) ) {
			$result['status']  = 'skipped';
			$result['message'] = __( 'No MoySklad state has been matched to a WooCommerce status yet, so there is nothing to apply.', 'mvweb-price-importer' );
			return $result;
		}

		$settings = get_option( 'mvweb_pi_moysklad', array() );
		$settings = is_array( $settings ) ? $settings : array();

		$client = new MVweb_PI_MoySklad_Client(
			(string) ( $settings['token'] ?? '' ),
			(int) ( $settings['rate_limit'] ?? MVweb_PI_MoySklad_Client::DEFAULT_RATE )
		);

		// Taken before the request, not after: a document that changes while
		// this run is reading must be picked up by the next one rather than
		// fall into the gap between them.
		$started = time();

		// Read before anything writes it: this is what says the run is a first
		// one, and the first one is silent — see below.
		$first_run = ( (int) get_option( self::STATUS_SINCE_OPTION, 0 ) <= 0 );
		$since     = self::since( (int) ( $settings['status_window'] ?? 30 ) );

		// Every run, not only the first. A first run over a month of orders is
		// a few hundred status changes with a save behind each, and an ordinary
		// run has no ceiling on the number of pages it will walk either.
		// Timing out halfway leaves the checkpoint where it was, so the next
		// run redoes the same work and dies in the same place — the one shape
		// of failure that never resolves itself.
		if ( function_exists( 'set_time_limit' ) ) {
			set_time_limit( 0 );
		}

		// The catch-up run is silent. Every status change here is one the
		// manager made days or weeks ago, and the customer has long since been
		// told about it by other means — or has forgotten the order entirely.
		// Mailing all of them at once on the afternoon somebody switched this
		// on is the kind of thing a shop only gets to do to its customers once.
		// From the second run onwards, mail goes out as WooCommerce intends.
		if ( $first_run ) {
			add_filter( 'woocommerce_mail_callback', array( __CLASS__, 'silence_mail' ), 99 );
		}

		// A page is read and applied before the next one is asked for. Reading
		// the whole backlog into memory first would mean one `IN (…)` clause
		// carrying every document id in it, and would put a ceiling on how much
		// a single run can take in — and a ceiling here does not defer work to
		// the next run, it drops it: the checkpoint below moves to the moment
		// this run started regardless of how far it actually got.
		try {
			for ( $page = 0; ; $page++ ) {
				$documents = $this->changed_documents( $client, $since, $page );

				if ( ! empty( $documents['rows'] ) ) {
					$result['seen'] += count( $documents['rows'] );

					$applied            = $this->apply_states( $documents['rows'], $map );
					$result['changed'] += $applied['changed'];
					$result['skipped'] += $applied['skipped'];
				}

				// Only the API's own answer ends the walk. An empty page is not
				// the end of one: a full hundred documents that have no state
				// yet leave nothing to apply and everything behind them still
				// to read.
				if ( ! $documents['more'] ) {
					break;
				}
			}
		} catch ( \Throwable $e ) {
			$message = $client->redact( $e->getMessage() );

			mvweb_pi_log(
				sprintf(
					/* translators: %s: error message */
					__( 'Could not read order states from MoySklad: %s', 'mvweb-price-importer' ),
					$message
				),
				'error'
			);

			// The checkpoint is left where it was. A run that could not finish
			// must not declare that interval seen — the pages it did apply are
			// simply applied again next time, which changes nothing, because a
			// status that already matches is never written.
			$result['status']  = 'error';
			$result['message'] = $message;
			return $result;
		} finally {
			if ( $first_run ) {
				remove_filter( 'woocommerce_mail_callback', array( __CLASS__, 'silence_mail' ), 99 );
			}
		}

		$result['message'] = __( 'Order states read from MoySklad.', 'mvweb-price-importer' );

		if ( $first_run && $result['changed'] > 0 ) {
			mvweb_pi_log(
				sprintf(
					/* translators: %d: orders whose status changed */
					__( 'First check against MoySklad: %d order statuses were brought up to date without emailing the customers. From now on emails go out as usual.', 'mvweb-price-importer' ),
					$result['changed']
				),
				'info'
			);
		}

		update_option( self::STATUS_SINCE_OPTION, $started, false );
		update_option(
			self::STATUS_LAST_OPTION,
			array(
				'time'    => time(),
				'seen'    => $result['seen'],
				'changed' => $result['changed'],
			),
			false
		);

		mvweb_pi_log(
			sprintf(
				/* translators: 1: orders whose status changed, 2: documents examined */
				__( 'Order states from MoySklad: %1$d statuses changed, %2$d documents examined.', 'mvweb-price-importer' ),
				$result['changed'],
				$result['seen']
			),
			$result['changed'] > 0 ? 'info' : 'debug'
		);

		return $result;
	}

	/**
	 * What WooCommerce should send mail with while the first run catches up.
	 *
	 * One filter instead of one per email type: WC_Email::send() asks for its
	 * mailer here (`class-wc-email.php:1234`), and a function that does nothing
	 * stops every message the run would otherwise produce. Removed the moment
	 * the run is over.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	public static function silence_mail(): string {
		return '__return_false';
	}

	/**
	 * From which moment to ask MoySklad for changes.
	 *
	 * The checkpoint of the last successful run, less an overlap, and never
	 * further back than the window the operator allowed. The overlap is what
	 * covers the account's time zone: MoySklad reads the filter in the
	 * account's own local time and we have no way to know which that is, so the
	 * comparison is deliberately made in UTC with hours to spare. Asking for
	 * more than changed costs a no-op; asking for less loses a status silently.
	 *
	 * @since 1.2.0
	 * @param int $window_days How far back the first run may reach.
	 * @return int Unix timestamp.
	 */
	private static function since( int $window_days ): int {
		$floor      = time() - max( 1, $window_days ) * DAY_IN_SECONDS;
		$checkpoint = (int) get_option( self::STATUS_SINCE_OPTION, 0 );

		if ( $checkpoint <= 0 ) {
			return $floor;
		}

		return max( $floor, $checkpoint - self::STATUS_OVERLAP );
	}

	/**
	 * Documents changed since a given moment, with their states resolved.
	 *
	 * `expand=state` is what keeps this to one request: without it every
	 * document would need a second call to find out what its state is called.
	 *
	 * @since 1.2.0
	 * @param MVweb_PI_MoySklad_Client $client Transport.
	 * @param int                      $since  Unix timestamp to ask from.
	 * @param int                      $page   Which page to fetch, from zero.
	 * @return array{rows: array<string, array{state: string, name: string}>, more: bool}
	 * @throws \RuntimeException When the API cannot be read.
	 */
	private function changed_documents( MVweb_PI_MoySklad_Client $client, int $since, int $page ): array {
		$response = $client->get(
			'entity/customerorder',
			array(
				'limit'  => self::STATUS_PAGE,
				'offset' => $page * self::STATUS_PAGE,
				'expand' => 'state',
				'filter' => 'updated>=' . gmdate( 'Y-m-d H:i:s', $since ),
			)
		);

		$rows      = isset( $response['rows'] ) && is_array( $response['rows'] ) ? $response['rows'] : array();
		$documents = array();

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$ms_id    = (string) ( $row['id'] ?? '' );
			$state_id = (string) ( $row['state']['id'] ?? '' );

			// A document with no state at all is legal in MoySklad and
			// means nothing has been decided about it yet.
			if ( '' === $ms_id || '' === $state_id ) {
				continue;
			}

			$documents[ $ms_id ] = array(
				'state' => $state_id,
				'name'  => sanitize_text_field( (string) ( $row['state']['name'] ?? $state_id ) ),
			);
		}

		return array(
			'rows' => $documents,
			// A short page is the last page. Counted on what the API returned,
			// not on what survived the loop above: a page made entirely of
			// documents with no state yet is still a full page, and stopping on
			// it would leave everything behind it unread.
			'more' => ( count( $rows ) >= self::STATUS_PAGE ),
		);
	}

	/**
	 * Put the states that arrived onto the orders they belong to.
	 *
	 * @since 1.2.0
	 * @param array<string, array{state: string, name: string}> $documents Document id => state.
	 * @param array<string, string>                             $map       State id => WooCommerce status.
	 * @return array{changed: int, skipped: int}
	 */
	private function apply_states( array $documents, array $map ): array {
		$changed = 0;
		$skipped = 0;

		if ( empty( $documents ) || ! function_exists( 'wc_get_orders' ) ) {
			return array(
				'changed' => $changed,
				'skipped' => $skipped,
			);
		}

		// One query for the whole page rather than a lookup per document. Most
		// of what MoySklad reports back was never ours — documents the manager
		// created there by hand — and those cost nothing here.
		$orders = wc_get_orders(
			array(
				'limit'      => -1,
				'type'       => 'shop_order',
				'status'     => 'any',
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => self::META_MS_ID,
						'value'   => array_keys( $documents ),
						'compare' => 'IN',
					),
				),
			)
		);

		$known = wc_get_order_statuses();

		foreach ( (array) $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			$ms_id = (string) $order->get_meta( self::META_MS_ID );
			if ( ! isset( $documents[ $ms_id ] ) ) {
				continue;
			}

			$state_id = $documents[ $ms_id ]['state'];
			$seen     = (string) $order->get_meta( self::META_MS_STATE );

			// Somebody overrode this order by hand. Leave it alone until the
			// document moves again — otherwise the override would be undone
			// within the interval and read as a glitch.
			$manual = ( '' !== (string) $order->get_meta( self::META_MANUAL ) );
			if ( $manual && $state_id === $seen ) {
				++$skipped;
				continue;
			}

			$target = $map[ $state_id ] ?? '';
			if ( '' === $target ) {
				++$skipped;
				continue;
			}

			// A status the shop no longer has. WC_Abstract_Order::set_status()
			// answers an unknown slug by quietly substituting `pending`, which
			// would put the goods back on the shelf and reopen the order.
			if ( ! isset( $known[ 'wc-' . $target ] ) ) {
				++$skipped;
				mvweb_pi_log(
					sprintf(
						/* translators: 1: order number, 2: status slug */
						__( 'Order %1$s was left alone: the status "%2$s" it is matched to no longer exists in this shop.', 'mvweb-price-importer' ),
						$order->get_order_number(),
						$target
					),
					'warning'
				);
				continue;
			}

			// Only here, past every reason to leave the order alone, is the
			// override forgotten: a run that decided not to touch this order
			// must not quietly take the mark off it either, or the next state
			// that does map to something would arrive to find the override
			// already gone.
			if ( $manual ) {
				$order->delete_meta_data( self::META_MANUAL );
			}

			if ( $order->get_status() === $target ) {
				// Nothing to change, but the state may still have moved from
				// one that maps here to another that does too. Recorded with a
				// meta write alone: a full save would bill the site for an
				// analytics re-import and a webhook for no change at all.
				if ( $seen !== $state_id ) {
					$order->update_meta_data( self::META_MS_STATE, $state_id );
					$order->save_meta_data();
				}
				++$skipped;
				continue;
			}

			$order->update_meta_data( self::META_MS_STATE, $state_id );
			$order->update_status(
				$target,
				sprintf(
					/* translators: %s: name of the MoySklad document state */
					__( 'MoySklad: the document moved to "%s".', 'mvweb-price-importer' ),
					$documents[ $ms_id ]['name']
				)
			);

			++$changed;
		}

		return array(
			'changed' => $changed,
			'skipped' => $skipped,
		);
	}

	/**
	 * Queue an order when it reaches a status that should reach MoySklad.
	 *
	 * Bound to `woocommerce_order_status_changed`, which fires for every route
	 * into a status — checkout, payment gateway callback, an admin changing it by
	 * hand — so there is one place to hook rather than three.
	 *
	 * @since 1.1.0
	 * @param int    $order_id Order id.
	 * @param string $from     Previous status.
	 * @param string $to       New status.
	 * @return void
	 */
	public function on_status_change( $order_id, $from, $to ): void {
		if ( ! self::enabled() ) {
			return;
		}

		if ( ! in_array( (string) $to, self::trigger_statuses(), true ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		// Already there. The status can be reached more than once (on-hold →
		// processing → on-hold), and the document is created only once.
		if ( '' !== (string) $order->get_meta( self::META_MS_ID ) ) {
			return;
		}

		$order->update_meta_data( self::META_QUEUED, '1' );
		$order->save();

		// Runs after this request has answered the customer. If the site's
		// loopback cron never fires, the recurring schedule picks the order up
		// instead — the queue is the source of truth, not this event.
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_single_event( time() + 30, self::HOOK );
		}
	}

	/**
	 * Send everything waiting in the queue.
	 *
	 * @since 1.1.0
	 * @return array{sent: int, failed: int, skipped: int}
	 */
	public function process_queue(): array {
		$result = array(
			'sent'    => 0,
			'failed'  => 0,
			'skipped' => 0,
		);

		if ( ! self::enabled() ) {
			return $result;
		}

		$orders = wc_get_orders(
			array(
				'limit'      => self::PER_RUN,
				'orderby'    => 'date',
				'order'      => 'ASC',
				'type'       => 'shop_order',
				'status'     => array_map(
					static function ( $status ) {
						return 'wc-' . $status;
					},
					self::trigger_statuses()
				),
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => self::META_QUEUED,
						'value'   => '1',
						'compare' => '=',
					),
				),
			)
		);

		if ( empty( $orders ) ) {
			return $result;
		}

		$settings = get_option( 'mvweb_pi_moysklad', array() );
		$client   = new MVweb_PI_MoySklad_Client(
			(string) $settings['token'],
			(int) ( $settings['rate_limit'] ?? MVweb_PI_MoySklad_Client::DEFAULT_RATE )
		);

		foreach ( $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			$outcome = $this->send_order( $order, $client, $settings );

			if ( 'sent' === $outcome ) {
				++$result['sent'];
			} elseif ( 'skipped' === $outcome ) {
				++$result['skipped'];
			} else {
				++$result['failed'];
			}
		}

		mvweb_pi_log(
			sprintf(
				/* translators: 1: orders sent, 2: orders that failed, 3: orders skipped */
				__( 'Orders to MoySklad: %1$d sent, %2$d failed, %3$d skipped.', 'mvweb-price-importer' ),
				$result['sent'],
				$result['failed'],
				$result['skipped']
			),
			( $result['failed'] > 0 ) ? 'warning' : 'info'
		);

		return $result;
	}

	/**
	 * Send one order.
	 *
	 * @since 1.1.0
	 * @param WC_Order                 $order    Order to send.
	 * @param MVweb_PI_MoySklad_Client $client   Transport.
	 * @param array                    $settings MoySklad settings.
	 * @return string `sent`, `failed` or `skipped`.
	 */
	public function send_order( WC_Order $order, MVweb_PI_MoySklad_Client $client, array $settings ): string {
		if ( '' !== (string) $order->get_meta( self::META_MS_ID ) ) {
			$order->delete_meta_data( self::META_QUEUED );
			$order->save();
			return 'skipped';
		}

		$attempts = (int) $order->get_meta( self::META_ATTEMPTS );
		if ( $attempts >= self::MAX_ATTEMPTS ) {
			$order->delete_meta_data( self::META_QUEUED );
			$order->save();
			return 'skipped';
		}

		try {
			$created = $this->create_document( $order, $client, $settings );
			$ms_id   = (string) $created['id'];

			$order->update_meta_data( self::META_MS_ID, $ms_id );
			$order->delete_meta_data( self::META_QUEUED );
			$order->delete_meta_data( self::META_ERROR );
			$order->add_order_note(
				sprintf(
					/* translators: %s: MoySklad document number */
					__( 'Sent to MoySklad as order %s.', 'mvweb-price-importer' ),
					sanitize_text_field( (string) ( $created['name'] ?? $ms_id ) )
				)
			);
			$order->save();

			return 'sent';
		} catch ( \Throwable $e ) {
			$message = $client->redact( $e->getMessage() );

			$order->update_meta_data( self::META_ATTEMPTS, (string) ( $attempts + 1 ) );
			$order->update_meta_data( self::META_ERROR, sanitize_text_field( $message ) );

			// Out of attempts: stop retrying, but keep the reason where whoever
			// looks at the order will find it.
			if ( ( $attempts + 1 ) >= self::MAX_ATTEMPTS ) {
				$order->delete_meta_data( self::META_QUEUED );
				$order->add_order_note(
					sprintf(
						/* translators: %s: error message */
						__( 'Could not be sent to MoySklad: %s. No further attempts will be made automatically.', 'mvweb-price-importer' ),
						$message
					)
				);
			}

			$order->save();

			mvweb_pi_log(
				sprintf(
					/* translators: 1: order number, 2: error message */
					__( 'Order %1$s could not be sent to MoySklad: %2$s', 'mvweb-price-importer' ),
					$order->get_order_number(),
					$message
				),
				'error'
			);

			return 'failed';
		}
	}

	/**
	 * Build the document and hand it to MoySklad.
	 *
	 * Everything that can refuse the order lives here, so the caller's job is
	 * only to record what happened. The cheap refusals — a line with no MoySklad
	 * product behind it — come first, before a single request is spent.
	 *
	 * @since 1.1.0
	 * @param WC_Order                 $order    Order to send.
	 * @param MVweb_PI_MoySklad_Client $client   Transport.
	 * @param array                    $settings MoySklad settings.
	 * @return array The created document, with a non-empty `id`.
	 * @throws \RuntimeException When the order cannot be expressed or the API refuses it.
	 */
	private function create_document( WC_Order $order, MVweb_PI_MoySklad_Client $client, array $settings ): array {
		$positions = $this->positions( $order );

		$document = array(
			// The whole idempotency story. Same order, same id, no matter how
			// many times this runs.
			'syncId'       => self::sync_id( $order->get_id() ),
			'name'         => (string) $order->get_order_number(),
			'moment'       => self::moment( $order ),
			'organization' => self::meta_ref( 'organization', (string) $settings['organization'] ),
			'agent'        => self::meta_ref( 'counterparty', $this->counterparty( $order, $client ) ),
			'positions'    => $positions,
			'description'  => $this->description( $order ),
		);

		$address = $order->get_shipping_address_1()
			? $order->get_formatted_shipping_address()
			: $order->get_formatted_billing_address();

		if ( $address ) {
			// Either the string or the structured object, never both — the API
			// ignores the string when the object is present.
			$document['shipmentAddress'] = wp_strip_all_tags( str_replace( '<br/>', ', ', $address ) );
		}

		$created = $client->post( 'entity/customerorder', $document );

		if ( '' === (string) ( $created['id'] ?? '' ) ) {
			throw new \RuntimeException(
				__( 'MoySklad accepted the order but returned no identifier for it.', 'mvweb-price-importer' )
			);
		}

		return $created;
	}

	/**
	 * The order's lines, as MoySklad wants them.
	 *
	 * A line whose product has no MoySklad identifier cannot be expressed here,
	 * and sending the order without it would put a document in the warehouse
	 * that quietly disagrees with what the customer bought. The whole order is
	 * refused instead, with the reason on the order itself.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order.
	 * @return array[]
	 * @throws \RuntimeException When a line cannot be expressed.
	 */
	private function positions( WC_Order $order ): array {
		$positions = array();

		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}

			$product = $item->get_product();
			if ( ! $product ) {
				throw new \RuntimeException(
					sprintf(
						/* translators: %s: order line name */
						__( 'The product behind the line "%s" no longer exists in the shop.', 'mvweb-price-importer' ),
						$item->get_name()
					)
				);
			}

			// A variation imported from a MoySklad variant carries the variant's
			// own id, and MoySklad has to be told it is a variant: the product
			// behind it would reserve nothing and match no warehouse line.
			// Without one of its own, the variation belongs to a product that is
			// a single item in MoySklad — variations made in the shop — and the
			// line goes to that product.
			$ms_id = (string) get_post_meta( $product->get_id(), MVweb_PI_Stock_Sync::ID_META, true );
			$type  = ( '' !== $ms_id && $product->get_parent_id() ) ? 'variant' : 'product';
			if ( '' === $ms_id && $product->get_parent_id() ) {
				$ms_id = (string) get_post_meta( $product->get_parent_id(), MVweb_PI_Stock_Sync::ID_META, true );
			}

			if ( '' === $ms_id ) {
				throw new \RuntimeException(
					sprintf(
						/* translators: %s: product name */
						__( '"%s" did not come from MoySklad, so there is nothing to point the order line at.', 'mvweb-price-importer' ),
						$item->get_name()
					)
				);
			}

			$quantity = (float) $item->get_quantity();
			if ( $quantity <= 0 ) {
				continue;
			}

			$positions[] = array(
				'quantity'   => $quantity,
				// Kopecks, and the price of one unit after whatever the line
				// was discounted by — the discount itself is not reported
				// separately, so the two cannot disagree.
				'price'      => (int) round( ( (float) $item->get_total() / $quantity ) * 100 ),
				'assortment' => self::meta_ref( $type, $ms_id ),
			);
		}

		if ( empty( $positions ) ) {
			throw new \RuntimeException(
				__( 'The order has no lines that MoySklad could be told about.', 'mvweb-price-importer' )
			);
		}

		// The API refuses a document with more than a thousand lines.
		if ( count( $positions ) > 1000 ) {
			throw new \RuntimeException(
				__( 'The order has more than 1000 lines, which is more than MoySklad accepts in one document.', 'mvweb-price-importer' )
			);
		}

		return $positions;
	}

	/**
	 * The MoySklad counterparty this order belongs to, creating one if needed.
	 *
	 * Matched on email first and phone second — the two things a shop actually
	 * has. A new counterparty carries a `syncId` of its own, so a retry that
	 * failed after the counterparty was created but before the order was cannot
	 * leave a second copy of the customer behind.
	 *
	 * @since 1.1.0
	 * @param WC_Order                 $order  Order.
	 * @param MVweb_PI_MoySklad_Client $client Transport.
	 * @return string Counterparty id.
	 * @throws \RuntimeException When the API cannot be read or written.
	 */
	private function counterparty( WC_Order $order, MVweb_PI_MoySklad_Client $client ): string {
		$email = sanitize_email( $order->get_billing_email() );
		$phone = preg_replace( '/[^\d+]/', '', (string) $order->get_billing_phone() );

		$lookups = array(
			'email' => $email,
			'phone' => $phone,
		);

		foreach ( $lookups as $field => $value ) {
			if ( '' === (string) $value ) {
				continue;
			}

			$found = $client->get(
				'entity/counterparty',
				array(
					'filter' => $field . '=' . $value,
					'limit'  => 1,
				)
			);

			$id = (string) ( $found['rows'][0]['id'] ?? '' );
			if ( '' !== $id ) {
				return $id;
			}
		}

		$name = trim( $order->get_formatted_billing_full_name() );
		if ( '' === $name ) {
			$name = '' !== $email ? $email : sprintf(
				/* translators: %s: order number */
				__( 'Customer of order %s', 'mvweb-price-importer' ),
				$order->get_order_number()
			);
		}

		$body = array(
			'name'        => sanitize_text_field( $name ),
			'companyType' => 'individual',
			// Keyed on what identifies the customer, not on the order: the same
			// person ordering twice must land on the same counterparty.
			'syncId'      => self::uuid( 'counterparty|' . ( '' !== $email ? $email : $phone ) ),
		);

		if ( '' !== $email ) {
			$body['email'] = $email;
		}
		if ( '' !== (string) $phone ) {
			$body['phone'] = (string) $phone;
		}

		$created = $client->post( 'entity/counterparty', $body );

		$id = (string) ( $created['id'] ?? '' );
		if ( '' === $id ) {
			throw new \RuntimeException(
				__( 'MoySklad did not return an identifier for the newly created customer.', 'mvweb-price-importer' )
			);
		}

		return $id;
	}

	/**
	 * What goes in the document's comment field.
	 *
	 * Delivery cost lands here rather than as a line of its own: a shipping line
	 * would need a MoySklad service to point at, and inventing one on the
	 * account's behalf is not this plugin's business.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order.
	 * @return string
	 */
	private function description( WC_Order $order ): string {
		$parts = array(
			sprintf(
				/* translators: 1: order number, 2: shop URL */
				__( 'Order %1$s from %2$s', 'mvweb-price-importer' ),
				$order->get_order_number(),
				wp_parse_url( home_url(), PHP_URL_HOST )
			),
		);

		$shipping = (float) $order->get_shipping_total();
		if ( $shipping > 0 ) {
			$parts[] = sprintf(
				/* translators: 1: shipping method name, 2: shipping cost */
				__( 'Delivery: %1$s, %2$s', 'mvweb-price-importer' ),
				$order->get_shipping_method(),
				html_entity_decode( wp_strip_all_tags( wc_price( $shipping, array( 'currency' => $order->get_currency() ) ) ) )
			);
		}

		$note = $order->get_customer_note();
		if ( '' !== $note ) {
			$parts[] = sprintf(
				/* translators: %s: customer's note */
				__( 'Customer note: %s', 'mvweb-price-importer' ),
				$note
			);
		}

		return implode( "\n", $parts );
	}

	/**
	 * When the order was placed, in the format the API expects.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order.
	 * @return string
	 */
	private static function moment( WC_Order $order ): string {
		$date = $order->get_date_created();

		return $date ? $date->format( 'Y-m-d H:i:s' ) : current_time( 'Y-m-d H:i:s' );
	}

	/**
	 * A reference to an entity, in the shape MoySklad reads.
	 *
	 * @since 1.1.0
	 * @param string $type Entity type, e.g. `organization`.
	 * @param string $id   Entity id.
	 * @return array
	 */
	private static function meta_ref( string $type, string $id ): array {
		return array(
			'meta' => array(
				'href'      => MVweb_PI_MoySklad_Client::BASE . 'entity/' . $type . '/' . $id,
				'type'      => $type,
				'mediaType' => 'application/json',
			),
		);
	}

	/**
	 * The identifier that makes sending an order twice harmless.
	 *
	 * @since 1.1.0
	 * @param int $order_id Order id.
	 * @return string
	 */
	private static function sync_id( int $order_id ): string {
		return self::uuid( 'order|' . $order_id );
	}

	/**
	 * A UUID derived from a string, stable for the life of the site.
	 *
	 * Includes the site address, so a staging copy of the database cannot send
	 * documents that collide with the live shop's.
	 *
	 * @since 1.1.0
	 * @param string $seed What the id stands for.
	 * @return string
	 */
	private static function uuid( string $seed ): string {
		$hash = md5( home_url() . '|' . $seed );

		return sprintf(
			'%s-%s-%s-%s-%s',
			substr( $hash, 0, 8 ),
			substr( $hash, 8, 4 ),
			substr( $hash, 12, 4 ),
			substr( $hash, 16, 4 ),
			substr( $hash, 20, 12 )
		);
	}

	/**
	 * Drop everything waiting to be sent, and say so on each order.
	 *
	 * Called when the site changes data source. A queued order is a promise to
	 * send it to a particular MoySklad account, and that promise does not
	 * survive the site being pointed somewhere else: left alone, the marks sit
	 * there dormant while the source is a price list and the queue springs back
	 * to life — possibly months later, possibly against a different account —
	 * the moment MoySklad is selected again.
	 *
	 * Orders already sent keep their document id. Only the intent to send is
	 * withdrawn, and the order says why, because an order that silently never
	 * arrives is the kind of thing nobody notices until stocktaking.
	 *
	 * @since 1.1.0
	 * @return int How many orders were taken out of the queue.
	 */
	public static function abandon_queue(): int {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return 0;
		}

		$orders = wc_get_orders(
			array(
				'limit'      => -1,
				'type'       => 'shop_order',
				'status'     => 'any',
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => self::META_QUEUED,
						'value'   => '1',
						'compare' => '=',
					),
				),
			)
		);

		$dropped = 0;
		foreach ( (array) $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			$order->delete_meta_data( self::META_QUEUED );
			$order->add_order_note(
				__( 'Was waiting to be sent to MoySklad, but the site changed its data source. The order was not sent and will not be sent automatically.', 'mvweb-price-importer' )
			);
			$order->save();
			++$dropped;
		}

		return $dropped;
	}

	/**
	 * Schedule or unschedule the queue drain.
	 *
	 * @since 1.1.0
	 * @param string $interval Recurrence key, or 'disabled'.
	 * @return void
	 */
	public static function schedule( string $interval ): void {
		wp_clear_scheduled_hook( self::HOOK );

		if ( 'disabled' === $interval || '' === $interval || ! self::enabled() ) {
			return;
		}

		wp_schedule_event( time(), $interval, self::HOOK );
	}

	/**
	 * Schedule or unschedule the reading of document states.
	 *
	 * @since 1.2.0
	 * @param string $interval Recurrence key, or 'disabled'.
	 * @return void
	 */
	public static function schedule_status_sync( string $interval ): void {
		wp_clear_scheduled_hook( self::STATUS_HOOK );

		if ( 'disabled' === $interval || '' === $interval || ! self::pull_enabled() ) {
			return;
		}

		wp_schedule_event( time(), $interval, self::STATUS_HOOK );
	}

	/**
	 * When the next state read is due.
	 *
	 * @since 1.2.0
	 * @return int|false
	 */
	public static function get_status_next_run(): int|false {
		return wp_next_scheduled( self::STATUS_HOOK );
	}

	/**
	 * A first guess at which state means which status.
	 *
	 * Offered when the account is connected and nothing has been matched yet,
	 * so the operator adjusts a filled-in table rather than facing seven empty
	 * selects. It changes nothing on its own: reading states back is off until
	 * somebody switches it on, and the table is on screen before that happens.
	 *
	 * The names are the ones a MoySklad account is created with. Anything else
	 * falls back to the state's type, which is the account-independent part:
	 * a state marked as a successful ending means the order is done, one marked
	 * unsuccessful means it is not going to happen. Everything in between is
	 * left unmatched — including "Новый", which is the state a document is
	 * created in and therefore the one an order arrives in from this very site.
	 *
	 * @since 1.2.0
	 * @param array<string, array{name: string, type: string}> $states State id => name and type.
	 * @return array<string, string> State id => status without the `wc-` prefix.
	 */
	public static function default_status_map( array $states ): array {
		$by_name = array(
			'подтвержден' => 'processing',
			'собран'      => 'processing',
			'отгружен'    => 'completed',
			'доставлен'   => 'completed',
			'возврат'     => 'cancelled',
			'отменен'     => 'cancelled',
		);

		$by_type = array(
			'Successful'   => 'completed',
			'Unsuccessful' => 'cancelled',
		);

		$known = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();
		$map   = array();

		foreach ( $states as $state_id => $state ) {
			// "ё" and "е" are the same letter to everyone but a string
			// comparison, and MoySklad accounts carry both spellings.
			$name   = str_replace( 'ё', 'е', mb_strtolower( (string) ( $state['name'] ?? '' ) ) );
			$status = $by_name[ $name ] ?? ( $by_type[ (string) ( $state['type'] ?? '' ) ] ?? '' );

			if ( '' === $status || ! isset( $known[ 'wc-' . $status ] ) ) {
				continue;
			}

			$map[ (string) $state_id ] = $status;
		}

		return $map;
	}
}
