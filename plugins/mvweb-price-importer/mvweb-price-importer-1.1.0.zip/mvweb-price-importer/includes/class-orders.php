<?php
/**
 * Sending WooCommerce orders to MoySklad.
 *
 * The first thing this plugin writes to somebody else's system, and the whole
 * design follows from that. An order sent twice is a real problem in a real
 * warehouse — goods reserved twice, a picker sent twice, a customer invoiced
 * twice — so every document carries a `syncId` derived from the WooCommerce
 * order it stands for. MoySklad answers a repeat of a request it has already
 * accepted with the entity it created the first time, which makes a retry after
 * a timeout safe and makes the timeout itself uninteresting.
 *
 * Nothing is sent from the checkout request. The order is marked as queued and
 * the sending happens on cron: a warehouse that is slow to answer must never be
 * something the customer waits for, and an API that is down must never be a
 * reason an order cannot be placed.
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Orders
 *
 * @since 1.1.0
 */
class MVweb_PI_Orders {

	/**
	 * Cron hook that drains the queue.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const HOOK = 'mvweb_pi_orders_sync';

	/**
	 * Order meta: the id MoySklad gave the document.
	 *
	 * Its presence is what "already sent" means.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const META_MS_ID = '_mvweb_pi_ms_order_id';

	/**
	 * Order meta: whether this order is waiting to be sent.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const META_QUEUED = '_mvweb_pi_ms_queued';

	/**
	 * Order meta: why the last attempt failed.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const META_ERROR = '_mvweb_pi_ms_error';

	/**
	 * Order meta: how many attempts this order has cost.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const META_ATTEMPTS = '_mvweb_pi_ms_attempts';

	/**
	 * Attempts before an order stops being retried.
	 *
	 * A failure that survives this many tries is not a hiccup — it is a document
	 * MoySklad refuses, and repeating it forever only spends the account's
	 * request budget. The order keeps its error message and can be sent again by
	 * hand once the cause is fixed.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const MAX_ATTEMPTS = 5;

	/**
	 * Orders sent per cron run.
	 *
	 * Each order costs two or three requests, so a backlog is drained over
	 * several runs rather than in one burst against the rate limit.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const PER_RUN = 20;

	/**
	 * Is sending switched on and configured?
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function enabled(): bool {
		if ( 'moysklad' !== mvweb_pi_source_mode() ) {
			return false;
		}

		$settings = get_option( 'mvweb_pi_moysklad', array() );
		if ( ! is_array( $settings ) ) {
			return false;
		}

		return ! empty( $settings['send_orders'] )
			&& '' !== (string) ( $settings['token'] ?? '' )
			&& '' !== (string) ( $settings['organization'] ?? '' );
	}

	/**
	 * WooCommerce statuses at which an order goes to MoySklad.
	 *
	 * @since 1.1.0
	 * @return string[] Statuses without the `wc-` prefix.
	 */
	public static function trigger_statuses(): array {
		$settings = get_option( 'mvweb_pi_moysklad', array() );
		$stored   = is_array( $settings ) && is_array( $settings['order_statuses'] ?? null )
			? $settings['order_statuses']
			: array( 'processing' );

		return array_values( array_filter( array_map( 'sanitize_key', $stored ) ) );
	}

	/**
	 * Queue an order when it reaches a status that should reach MoySklad.
	 *
	 * Bound to `woocommerce_order_status_changed`, which fires for every route
	 * into a status — checkout, payment gateway callback, an admin changing it by
	 * hand — so there is one place to hook rather than three.
	 *
	 * @since 1.1.0
	 * @param int    $order_id Order id.
	 * @param string $from     Previous status.
	 * @param string $to       New status.
	 * @return void
	 */
	public function on_status_change( $order_id, $from, $to ): void {
		if ( ! self::enabled() ) {
			return;
		}

		if ( ! in_array( (string) $to, self::trigger_statuses(), true ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		// Already there. The status can be reached more than once (on-hold →
		// processing → on-hold), and the document is created only once.
		if ( '' !== (string) $order->get_meta( self::META_MS_ID ) ) {
			return;
		}

		$order->update_meta_data( self::META_QUEUED, '1' );
		$order->save();

		// Runs after this request has answered the customer. If the site's
		// loopback cron never fires, the recurring schedule picks the order up
		// instead — the queue is the source of truth, not this event.
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_single_event( time() + 30, self::HOOK );
		}
	}

	/**
	 * Send everything waiting in the queue.
	 *
	 * @since 1.1.0
	 * @return array{sent: int, failed: int, skipped: int}
	 */
	public function process_queue(): array {
		$result = array(
			'sent'    => 0,
			'failed'  => 0,
			'skipped' => 0,
		);

		if ( ! self::enabled() ) {
			return $result;
		}

		$orders = wc_get_orders(
			array(
				'limit'      => self::PER_RUN,
				'orderby'    => 'date',
				'order'      => 'ASC',
				'type'       => 'shop_order',
				'status'     => array_map(
					static function ( $status ) {
						return 'wc-' . $status;
					},
					self::trigger_statuses()
				),
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => self::META_QUEUED,
						'value'   => '1',
						'compare' => '=',
					),
				),
			)
		);

		if ( empty( $orders ) ) {
			return $result;
		}

		$settings = get_option( 'mvweb_pi_moysklad', array() );
		$client   = new MVweb_PI_MoySklad_Client(
			(string) $settings['token'],
			(int) ( $settings['rate_limit'] ?? MVweb_PI_MoySklad_Client::DEFAULT_RATE )
		);

		foreach ( $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			$outcome = $this->send_order( $order, $client, $settings );

			if ( 'sent' === $outcome ) {
				++$result['sent'];
			} elseif ( 'skipped' === $outcome ) {
				++$result['skipped'];
			} else {
				++$result['failed'];
			}
		}

		mvweb_pi_log(
			sprintf(
				/* translators: 1: orders sent, 2: orders that failed, 3: orders skipped */
				__( 'Orders to MoySklad: %1$d sent, %2$d failed, %3$d skipped.', 'mvweb-price-importer' ),
				$result['sent'],
				$result['failed'],
				$result['skipped']
			),
			( $result['failed'] > 0 ) ? 'warning' : 'info'
		);

		return $result;
	}

	/**
	 * Send one order.
	 *
	 * @since 1.1.0
	 * @param WC_Order                 $order    Order to send.
	 * @param MVweb_PI_MoySklad_Client $client   Transport.
	 * @param array                    $settings MoySklad settings.
	 * @return string `sent`, `failed` or `skipped`.
	 */
	public function send_order( WC_Order $order, MVweb_PI_MoySklad_Client $client, array $settings ): string {
		if ( '' !== (string) $order->get_meta( self::META_MS_ID ) ) {
			$order->delete_meta_data( self::META_QUEUED );
			$order->save();
			return 'skipped';
		}

		$attempts = (int) $order->get_meta( self::META_ATTEMPTS );
		if ( $attempts >= self::MAX_ATTEMPTS ) {
			$order->delete_meta_data( self::META_QUEUED );
			$order->save();
			return 'skipped';
		}

		try {
			$created = $this->create_document( $order, $client, $settings );
			$ms_id   = (string) $created['id'];

			$order->update_meta_data( self::META_MS_ID, $ms_id );
			$order->delete_meta_data( self::META_QUEUED );
			$order->delete_meta_data( self::META_ERROR );
			$order->add_order_note(
				sprintf(
					/* translators: %s: MoySklad document number */
					__( 'Sent to MoySklad as order %s.', 'mvweb-price-importer' ),
					sanitize_text_field( (string) ( $created['name'] ?? $ms_id ) )
				)
			);
			$order->save();

			return 'sent';
		} catch ( \Throwable $e ) {
			$message = $client->redact( $e->getMessage() );

			$order->update_meta_data( self::META_ATTEMPTS, (string) ( $attempts + 1 ) );
			$order->update_meta_data( self::META_ERROR, sanitize_text_field( $message ) );

			// Out of attempts: stop retrying, but keep the reason where whoever
			// looks at the order will find it.
			if ( ( $attempts + 1 ) >= self::MAX_ATTEMPTS ) {
				$order->delete_meta_data( self::META_QUEUED );
				$order->add_order_note(
					sprintf(
						/* translators: %s: error message */
						__( 'Could not be sent to MoySklad: %s. No further attempts will be made automatically.', 'mvweb-price-importer' ),
						$message
					)
				);
			}

			$order->save();

			mvweb_pi_log(
				sprintf(
					/* translators: 1: order number, 2: error message */
					__( 'Order %1$s could not be sent to MoySklad: %2$s', 'mvweb-price-importer' ),
					$order->get_order_number(),
					$message
				),
				'error'
			);

			return 'failed';
		}
	}

	/**
	 * Build the document and hand it to MoySklad.
	 *
	 * Everything that can refuse the order lives here, so the caller's job is
	 * only to record what happened. The cheap refusals — a line with no MoySklad
	 * product behind it — come first, before a single request is spent.
	 *
	 * @since 1.1.0
	 * @param WC_Order                 $order    Order to send.
	 * @param MVweb_PI_MoySklad_Client $client   Transport.
	 * @param array                    $settings MoySklad settings.
	 * @return array The created document, with a non-empty `id`.
	 * @throws \RuntimeException When the order cannot be expressed or the API refuses it.
	 */
	private function create_document( WC_Order $order, MVweb_PI_MoySklad_Client $client, array $settings ): array {
		$positions = $this->positions( $order );

		$document = array(
			// The whole idempotency story. Same order, same id, no matter how
			// many times this runs.
			'syncId'       => self::sync_id( $order->get_id() ),
			'name'         => (string) $order->get_order_number(),
			'moment'       => self::moment( $order ),
			'organization' => self::meta_ref( 'organization', (string) $settings['organization'] ),
			'agent'        => self::meta_ref( 'counterparty', $this->counterparty( $order, $client ) ),
			'positions'    => $positions,
			'description'  => $this->description( $order ),
		);

		$address = $order->get_shipping_address_1()
			? $order->get_formatted_shipping_address()
			: $order->get_formatted_billing_address();

		if ( $address ) {
			// Either the string or the structured object, never both — the API
			// ignores the string when the object is present.
			$document['shipmentAddress'] = wp_strip_all_tags( str_replace( '<br/>', ', ', $address ) );
		}

		$created = $client->post( 'entity/customerorder', $document );

		if ( '' === (string) ( $created['id'] ?? '' ) ) {
			throw new \RuntimeException(
				__( 'MoySklad accepted the order but returned no identifier for it.', 'mvweb-price-importer' )
			);
		}

		return $created;
	}

	/**
	 * The order's lines, as MoySklad wants them.
	 *
	 * A line whose product has no MoySklad identifier cannot be expressed here,
	 * and sending the order without it would put a document in the warehouse
	 * that quietly disagrees with what the customer bought. The whole order is
	 * refused instead, with the reason on the order itself.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order.
	 * @return array[]
	 * @throws \RuntimeException When a line cannot be expressed.
	 */
	private function positions( WC_Order $order ): array {
		$positions = array();

		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}

			$product = $item->get_product();
			if ( ! $product ) {
				throw new \RuntimeException(
					sprintf(
						/* translators: %s: order line name */
						__( 'The product behind the line "%s" no longer exists in the shop.', 'mvweb-price-importer' ),
						$item->get_name()
					)
				);
			}

			// Stock, and therefore the MoySklad identifier, lives on the parent
			// when a variation does not manage its own.
			$ms_id = (string) get_post_meta( $product->get_id(), MVweb_PI_Stock_Sync::ID_META, true );
			if ( '' === $ms_id && $product->get_parent_id() ) {
				$ms_id = (string) get_post_meta( $product->get_parent_id(), MVweb_PI_Stock_Sync::ID_META, true );
			}

			if ( '' === $ms_id ) {
				throw new \RuntimeException(
					sprintf(
						/* translators: %s: product name */
						__( '"%s" did not come from MoySklad, so there is nothing to point the order line at.', 'mvweb-price-importer' ),
						$item->get_name()
					)
				);
			}

			$quantity = (float) $item->get_quantity();
			if ( $quantity <= 0 ) {
				continue;
			}

			$positions[] = array(
				'quantity'   => $quantity,
				// Kopecks, and the price of one unit after whatever the line
				// was discounted by — the discount itself is not reported
				// separately, so the two cannot disagree.
				'price'      => (int) round( ( (float) $item->get_total() / $quantity ) * 100 ),
				'assortment' => self::meta_ref( 'product', $ms_id ),
			);
		}

		if ( empty( $positions ) ) {
			throw new \RuntimeException(
				__( 'The order has no lines that MoySklad could be told about.', 'mvweb-price-importer' )
			);
		}

		// The API refuses a document with more than a thousand lines.
		if ( count( $positions ) > 1000 ) {
			throw new \RuntimeException(
				__( 'The order has more than 1000 lines, which is more than MoySklad accepts in one document.', 'mvweb-price-importer' )
			);
		}

		return $positions;
	}

	/**
	 * The MoySklad counterparty this order belongs to, creating one if needed.
	 *
	 * Matched on email first and phone second — the two things a shop actually
	 * has. A new counterparty carries a `syncId` of its own, so a retry that
	 * failed after the counterparty was created but before the order was cannot
	 * leave a second copy of the customer behind.
	 *
	 * @since 1.1.0
	 * @param WC_Order                 $order  Order.
	 * @param MVweb_PI_MoySklad_Client $client Transport.
	 * @return string Counterparty id.
	 * @throws \RuntimeException When the API cannot be read or written.
	 */
	private function counterparty( WC_Order $order, MVweb_PI_MoySklad_Client $client ): string {
		$email = sanitize_email( $order->get_billing_email() );
		$phone = preg_replace( '/[^\d+]/', '', (string) $order->get_billing_phone() );

		$lookups = array(
			'email' => $email,
			'phone' => $phone,
		);

		foreach ( $lookups as $field => $value ) {
			if ( '' === (string) $value ) {
				continue;
			}

			$found = $client->get(
				'entity/counterparty',
				array(
					'filter' => $field . '=' . $value,
					'limit'  => 1,
				)
			);

			$id = (string) ( $found['rows'][0]['id'] ?? '' );
			if ( '' !== $id ) {
				return $id;
			}
		}

		$name = trim( $order->get_formatted_billing_full_name() );
		if ( '' === $name ) {
			$name = '' !== $email ? $email : sprintf(
				/* translators: %s: order number */
				__( 'Customer of order %s', 'mvweb-price-importer' ),
				$order->get_order_number()
			);
		}

		$body = array(
			'name'        => sanitize_text_field( $name ),
			'companyType' => 'individual',
			// Keyed on what identifies the customer, not on the order: the same
			// person ordering twice must land on the same counterparty.
			'syncId'      => self::uuid( 'counterparty|' . ( '' !== $email ? $email : $phone ) ),
		);

		if ( '' !== $email ) {
			$body['email'] = $email;
		}
		if ( '' !== (string) $phone ) {
			$body['phone'] = (string) $phone;
		}

		$created = $client->post( 'entity/counterparty', $body );

		$id = (string) ( $created['id'] ?? '' );
		if ( '' === $id ) {
			throw new \RuntimeException(
				__( 'MoySklad did not return an identifier for the newly created customer.', 'mvweb-price-importer' )
			);
		}

		return $id;
	}

	/**
	 * What goes in the document's comment field.
	 *
	 * Delivery cost lands here rather than as a line of its own: a shipping line
	 * would need a MoySklad service to point at, and inventing one on the
	 * account's behalf is not this plugin's business.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order.
	 * @return string
	 */
	private function description( WC_Order $order ): string {
		$parts = array(
			sprintf(
				/* translators: 1: order number, 2: shop URL */
				__( 'Order %1$s from %2$s', 'mvweb-price-importer' ),
				$order->get_order_number(),
				wp_parse_url( home_url(), PHP_URL_HOST )
			),
		);

		$shipping = (float) $order->get_shipping_total();
		if ( $shipping > 0 ) {
			$parts[] = sprintf(
				/* translators: 1: shipping method name, 2: shipping cost */
				__( 'Delivery: %1$s, %2$s', 'mvweb-price-importer' ),
				$order->get_shipping_method(),
				html_entity_decode( wp_strip_all_tags( wc_price( $shipping, array( 'currency' => $order->get_currency() ) ) ) )
			);
		}

		$note = $order->get_customer_note();
		if ( '' !== $note ) {
			$parts[] = sprintf(
				/* translators: %s: customer's note */
				__( 'Customer note: %s', 'mvweb-price-importer' ),
				$note
			);
		}

		return implode( "\n", $parts );
	}

	/**
	 * When the order was placed, in the format the API expects.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order.
	 * @return string
	 */
	private static function moment( WC_Order $order ): string {
		$date = $order->get_date_created();

		return $date ? $date->format( 'Y-m-d H:i:s' ) : current_time( 'Y-m-d H:i:s' );
	}

	/**
	 * A reference to an entity, in the shape MoySklad reads.
	 *
	 * @since 1.1.0
	 * @param string $type Entity type, e.g. `organization`.
	 * @param string $id   Entity id.
	 * @return array
	 */
	private static function meta_ref( string $type, string $id ): array {
		return array(
			'meta' => array(
				'href'      => MVweb_PI_MoySklad_Client::BASE . 'entity/' . $type . '/' . $id,
				'type'      => $type,
				'mediaType' => 'application/json',
			),
		);
	}

	/**
	 * The identifier that makes sending an order twice harmless.
	 *
	 * @since 1.1.0
	 * @param int $order_id Order id.
	 * @return string
	 */
	private static function sync_id( int $order_id ): string {
		return self::uuid( 'order|' . $order_id );
	}

	/**
	 * A UUID derived from a string, stable for the life of the site.
	 *
	 * Includes the site address, so a staging copy of the database cannot send
	 * documents that collide with the live shop's.
	 *
	 * @since 1.1.0
	 * @param string $seed What the id stands for.
	 * @return string
	 */
	private static function uuid( string $seed ): string {
		$hash = md5( home_url() . '|' . $seed );

		return sprintf(
			'%s-%s-%s-%s-%s',
			substr( $hash, 0, 8 ),
			substr( $hash, 8, 4 ),
			substr( $hash, 12, 4 ),
			substr( $hash, 16, 4 ),
			substr( $hash, 20, 12 )
		);
	}

	/**
	 * Drop everything waiting to be sent, and say so on each order.
	 *
	 * Called when the site changes data source. A queued order is a promise to
	 * send it to a particular MoySklad account, and that promise does not
	 * survive the site being pointed somewhere else: left alone, the marks sit
	 * there dormant while the source is a price list and the queue springs back
	 * to life — possibly months later, possibly against a different account —
	 * the moment MoySklad is selected again.
	 *
	 * Orders already sent keep their document id. Only the intent to send is
	 * withdrawn, and the order says why, because an order that silently never
	 * arrives is the kind of thing nobody notices until stocktaking.
	 *
	 * @since 1.1.0
	 * @return int How many orders were taken out of the queue.
	 */
	public static function abandon_queue(): int {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return 0;
		}

		$orders = wc_get_orders(
			array(
				'limit'      => -1,
				'type'       => 'shop_order',
				'status'     => 'any',
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => self::META_QUEUED,
						'value'   => '1',
						'compare' => '=',
					),
				),
			)
		);

		$dropped = 0;
		foreach ( (array) $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}

			$order->delete_meta_data( self::META_QUEUED );
			$order->add_order_note(
				__( 'Was waiting to be sent to MoySklad, but the site changed its data source. The order was not sent and will not be sent automatically.', 'mvweb-price-importer' )
			);
			$order->save();
			++$dropped;
		}

		return $dropped;
	}

	/**
	 * Schedule or unschedule the queue drain.
	 *
	 * @since 1.1.0
	 * @param string $interval Recurrence key, or 'disabled'.
	 * @return void
	 */
	public static function schedule( string $interval ): void {
		wp_clear_scheduled_hook( self::HOOK );

		if ( 'disabled' === $interval || '' === $interval || ! self::enabled() ) {
			return;
		}

		wp_schedule_event( time(), $interval, self::HOOK );
	}
}
