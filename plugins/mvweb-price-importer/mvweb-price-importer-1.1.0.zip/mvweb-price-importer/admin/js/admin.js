/**
 * Admin JavaScript for MVweb Price Importer
 *
 * Tab navigation, AJAX handlers for download/convert/detect/reset actions.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

(function($) {
	'use strict';

	/**
	 * Tab navigation without page reload.
	 */
	function initTabs() {
		var $links = $('.mvweb-nav .mvweb-nav__link');
		var $contents = $('.mvweb-tab-content');
		var $form = $('.mvweb-settings form');

		function applyTab(tabId) {
			$links.removeClass('mvweb-nav__link--active');
			$links.filter('[data-tab="' + tabId + '"]').addClass('mvweb-nav__link--active');

			$contents.removeClass('active');
			$('#' + tabId).addClass('active');

			$form.toggleClass('mvweb-pi-form--no-submit', tabId === 'help');
		}

		$links.on('click', function(e) {
			e.preventDefault();

			var $this = $(this);
			var tabId = $this.data('tab') || ($this.attr('href') || '').replace('#', '');
			if (!tabId) {
				return;
			}

			applyTab(tabId);

			if (history.pushState) {
				history.pushState(null, null, '#' + tabId);
			}
		});

		var hash = window.location.hash.substring(1);
		if (hash && $('#' + hash).length) {
			applyTab(hash);
		} else {
			var $active = $links.filter('.mvweb-nav__link--active').first();
			if ($active.length) {
				$form.toggleClass('mvweb-pi-form--no-submit', $active.data('tab') === 'help');
			}
		}
	}

	/**
	 * Pull a localized label from the server-provided i18n bag with a fallback.
	 *
	 * @param {string} key      Label key.
	 * @param {string} fallback English fallback used when the bag is missing.
	 * @return {string}
	 */
	function l10n(key, fallback) {
		var bag = (window.mvweb_pi_ajax && mvweb_pi_ajax.i18n) || {};
		return bag[key] || fallback;
	}

	/**
	 * Render a uniform action result: alert with a title and an optional
	 * row of badges. Used by all Actions-row buttons so spacing, wrapping
	 * and tone stay consistent.
	 *
	 * @param {jQuery}  $container Target element.
	 * @param {string}  type       Alert tone: 'success' | 'error' | 'warning' | 'info'.
	 * @param {string}  title      Headline text (already localized, plain text).
	 * @param {Array}   badges     Optional badges: { label, value, tone }.
	 */
	function renderActionResult($container, type, title, badges) {
		var cssClass = 'mvweb-alert mvweb-alert--' + type;
		var html = '<div class="' + cssClass + '">';
		// .mvweb-alert is a flex row (UI Kit). Always wrap content in
		// __body — plugin.css lays that body out as a wrapping row so the
		// title and its badges read as one line ("Feed generated. 14595
		// products"), and any __meta appended later claims a line of its own.
		html += '<div class="mvweb-alert__body">';
		if (title) {
			html += '<div class="mvweb-pi-result__title">' + escapeHtml(title) + '</div>';
		}

		if (badges && badges.length) {
			html += '<div class="mvweb-pi-result__badges">';
			badges.forEach(function(badge) {
				var badgeClass = 'mvweb-badge';
				if (badge.tone) {
					badgeClass += ' mvweb-badge--' + badge.tone;
				}
				html += '<span class="' + badgeClass + '">'
					+ '<span class="mvweb-pi-result__num">' + escapeHtml(String(badge.value)) + '</span> '
					+ escapeHtml(badge.label)
					+ '</span>';
			});
			html += '</div>';
		}

		html += '</div></div>';
		$container.html(html);
	}

	/**
	 * Show a single-line status message (no stats row).
	 *
	 * @param {jQuery} $container Result container.
	 * @param {string} message    Already-localized message text.
	 * @param {string} type       'success' | 'error' | 'warning' | 'info'.
	 */
	function showResult($container, message, type) {
		renderActionResult($container, type || 'info', message, []);
	}

	/**
	 * Resolve the result container for a Main-tab action button.
	 *
	 * Buttons live in a horizontal action row outside any card, so we
	 * look up their result panel by the `data-result` attribute they
	 * carry (each panel has a matching id below the row).
	 *
	 * @param {jQuery} $button Action button.
	 * @return {jQuery} Result container.
	 */
	function resolveResultContainer($button) {
		var resultId = $button.data('result');
		if (resultId) {
			return $('#' + resultId);
		}
		// Fallback for any legacy card-shaped block.
		return $button.closest('.mvweb-card').find('.mvweb-pi-action-result');
	}

	/**
	 * Initialize Main-tab action buttons (download / convert / reset).
	 */
	function initOutputActions() {
		$('.mvweb-pi-action-btn').on('click', function(e) {
			e.preventDefault();

			var $button = $(this);
			var action = $button.data('action');
			var $spinner = $button.find('.mvweb-spinner');
			var $result = resolveResultContainer($button);

			// A button that carries its own warning asks before it acts. The
			// text belongs to the button because only the markup knows what
			// this particular action is about to do.
			var confirmText = $button.data('confirm');
			if (confirmText && !window.confirm(confirmText)) {
				return;
			}

			$button.prop('disabled', true);
			$spinner.addClass('is-active');
			$result.empty();

			$.post(mvweb_pi_ajax.ajax_url, {
				action: action,
				nonce: mvweb_pi_ajax.nonce
			}, function(response) {
				if (response.success) {
					handleActionSuccess(action, response.data, $result);
				} else {
					var errorMsg = typeof response.data === 'string'
						? response.data
						: (response.data && response.data.message ? response.data.message : l10n('unknown_error', 'Unknown error.'));
					showResult($result, errorMsg, 'error');
				}
			}).fail(function() {
				showResult($result, l10n('request_failed', 'Request failed. Please try again.'), 'error');
			}).always(function() {
				$button.prop('disabled', false);
				$spinner.removeClass('is-active');
			});
		});
	}

	/**
	 * Handle successful action response based on action type.
	 *
	 * @param {string} action   AJAX action name.
	 * @param {Object} data     Response data.
	 * @param {jQuery} $result  Result container.
	 */
	function handleActionSuccess(action, data, $result) {
		switch (action) {
			case 'mvweb_pi_download_source':
				handleDownloadResult(data, $result);
				break;

			case 'mvweb_pi_convert_data':
				handleConvertResult(data, $result);
				break;

			case 'mvweb_pi_reset_etags':
			case 'mvweb_pi_rotate_key':
				showResult($result, data, 'success');
				break;

			case 'mvweb_pi_run_import':
				handleImportResult(data, $result);
				break;

			case 'mvweb_pi_retire_undo':
				showResult($result, data.message, 'success');
				// More than one pass may be needed on a large catalogue; the
				// button stays until there is nothing left to put back.
				if (data.left === 0) {
					$('[data-action="mvweb_pi_retire_undo"]').remove();
				}
				break;

			case 'mvweb_pi_moysklad_disconnect':
				showResult($result, data, 'success');
				// The server has just thrown the token away; the half of the
				// tab that says "connected" is now describing something that
				// no longer exists.
				$('.mvweb-pi-moysklad-connected').remove();
				fillPriceTypes({});
				break;

			default:
				// A handler that answers with a plain string is answering in
				// words. Dropping it left the operator looking at an empty
				// green box and guessing whether anything had happened.
				showResult($result, typeof data === 'string' ? data : '', 'success');
		}
	}

	/**
	 * Display download results — one badge per source with its outcome.
	 *
	 * @param {Object} data    Response data with downloaded/errors arrays.
	 * @param {jQuery} $result Result container.
	 */
	function handleDownloadResult(data, $result) {
		var badges = [];
		var hasErrors = data.errors && data.errors.length;

		if (data.downloaded && data.downloaded.length) {
			data.downloaded.forEach(function(item) {
				if ('unchanged' === item.status) {
					badges.push({ label: item.id, value: l10n('unchanged', 'no changes'), tone: 'plain' });
				} else {
					badges.push({
						label: item.id,
						value: item.format.toUpperCase() + ' · ' + item.size,
						tone: 'success'
					});
				}
			});
		}

		if (hasErrors) {
			data.errors.forEach(function(err) {
				badges.push({ label: err.id, value: err.message, tone: 'error' });
			});
		}

		renderActionResult(
			$result,
			hasErrors ? 'warning' : 'success',
			l10n('downloaded', 'Sources downloaded.'),
			badges
		);
	}

	/**
	 * Display convert results.
	 *
	 * @param {Object} data    Response data with product/invalid/duplicate counts.
	 * @param {jQuery} $result Result container.
	 */
	function handleConvertResult(data, $result) {
		var badges = [
			{ label: l10n('products', 'products'), value: data.products, tone: 'success' }
		];
		if (data.invalid > 0) {
			badges.push({ label: l10n('invalid', 'invalid'), value: data.invalid, tone: 'warning' });
		}
		if (data.duplicates > 0) {
			badges.push({ label: l10n('duplicates', 'duplicates'), value: data.duplicates, tone: 'plain' });
		}

		renderActionResult($result, 'success', l10n('converted', 'Sources converted.'), badges);

		if (data.debug_mode && data.checkpoint) {
			$result.find('.mvweb-alert__body').append(
				'<div class="mvweb-pi-result__meta">'
					+ escapeHtml(l10n('checkpoint', 'Checkpoint file:')) + ' '
					+ '<code>' + escapeHtml(data.checkpoint) + '</code>'
				+ '</div>'
			);
		}
		if (data.invalid_file) {
			$result.find('.mvweb-alert__body').append(
				'<div class="mvweb-pi-result__meta">'
					+ escapeHtml(l10n('invalid_file', 'Invalid rows file:')) + ' '
					+ '<code>' + escapeHtml(data.invalid_file) + '</code>'
				+ '</div>'
			);
		}
	}

	/**
	 * Display import results.
	 *
	 * @param {Object} data    Response data with stats or skip message.
	 * @param {jQuery} $result Result container.
	 */
	function handleImportResult(data, $result) {
		if ('skipped' === data.status) {
			showResult($result, data.message, 'warning');
			return;
		}

		var stats = data.stats || {};
		var created = stats.created || 0;
		var updated = stats.updated || 0;
		var skipped = stats.skipped || 0;
		var errors  = stats.errors  || 0;

		// Badges: created and updated always shown (even zero) so the
		// row width stays predictable run-to-run; skipped/errors only
		// when non-zero. Errors switch the whole alert to a warning tone.
		var badges = [
			{ label: l10n('created', 'created'), value: created, tone: 'success' },
			{ label: l10n('updated', 'updated'), value: updated, tone: 'plain' }
		];
		if (skipped > 0) {
			badges.push({ label: l10n('skipped', 'skipped'), value: skipped, tone: 'warning' });
		}
		if (errors > 0) {
			badges.push({ label: l10n('errors',  'errors'),  value: errors,  tone: 'error' });
		}

		renderActionResult(
			$result,
			errors > 0 ? 'warning' : 'success',
			data.message,
			badges
		);

		updateStatsDashboard(stats, data);
	}

	/**
	 * Update the .mvweb-metric cards after an AJAX import.
	 *
	 * We can't reuse the PHP-rendered dashboard because the request that
	 * brought us this stats payload didn't reload the page. So we update
	 * the four metric values in-place — labels stay as the server already
	 * rendered them (already localised), which avoids the previous bug
	 * where the JS injected hard-coded English headers.
	 *
	 * If no dashboard is present yet (first ever import on a fresh page),
	 * fall through to a full reload — PHP will then render the correct
	 * `.mvweb-metrics` grid for us with localised labels.
	 *
	 * @param {Object} stats Import statistics.
	 */
	function updateStatsDashboard(stats) {
		var $dashboard = $('.mvweb-pi-stats-dashboard');
		if (!$dashboard.length) {
			// No metric grid rendered yet — reload so PHP can build it.
			location.reload();
			return;
		}
		$dashboard.find('.mvweb-metric').each(function() {
			var $card  = $(this);
			var label  = $card.find('.mvweb-metric__label').text().toLowerCase();
			var $value = $card.find('.mvweb-metric__value');
			// Match by stable english stat keys, not the localised label —
			// instead compare against the four well-known buckets by index.
			// Cards render in fixed order: created / updated / skipped / errors.
			var idx = $card.index();
			var value;
			if      (idx === 0) value = stats.created || 0;
			else if (idx === 1) value = stats.updated || 0;
			else if (idx === 2) value = stats.skipped || 0;
			else if (idx === 3) value = stats.errors  || 0;
			else                value = null;
			if (value !== null) {
				$value.text(value);
			}
			// Promote errors card to danger styling if non-zero.
			if (idx === 3) {
				$card.toggleClass('mvweb-metric--danger', (stats.errors || 0) > 0);
			}
		});
	}

	/**
	 * Initialize Import tab button.
	 */
	function initImportAction() {
		$('#mvweb-pi-run-import-btn').on('click', function(e) {
			e.preventDefault();

			var $button = $(this);
			var $spinner = $button.find('.mvweb-spinner');
			var $result = $('#mvweb-pi-import-result');
			// Minimum 400ms of visible spinner so a sub-second AJAX response
			// (e.g. ETag-unchanged early exit) does not look like a button
			// click that did nothing.
			var startedAt = Date.now();
			var minVisibleMs = 400;

			$button.prop('disabled', true);
			$spinner.addClass('is-active');
			$result.empty();

			$.post(mvweb_pi_ajax.ajax_url, {
				action: 'mvweb_pi_run_import',
				nonce: mvweb_pi_ajax.nonce
			}, function(response) {
				if (response.success) {
					handleImportResult(response.data, $result);
				} else {
					var errorMsg = typeof response.data === 'string'
						? response.data
						: (response.data && response.data.message ? response.data.message : l10n('unknown_error', 'Unknown error.'));
					showResult($result, errorMsg, 'error');
				}
			}).fail(function(jqXHR, textStatus) {
				// First import of a large catalog (images on every SKU) takes
				// longer than the browser/proxy HTTP timeout. The PHP process
				// keeps running server-side, but the AJAX socket dies first
				// with status === 0 or textStatus === 'timeout'. Show an
				// info banner instead of a red "Request failed" — the latter
				// makes operators think the import crashed when it hasn't.
				var stoppedWaiting = !jqXHR.status || textStatus === 'timeout' || textStatus === 'abort';
				if (stoppedWaiting) {
					renderActionResult(
						$result,
						'info',
						l10n('import_running_title', 'Import is still running in the background'),
						[]
					);
					$result.find('.mvweb-alert__body').append(
						'<div class="mvweb-pi-result__meta">'
						+ escapeHtml(l10n('import_running_body',
							'The browser stopped waiting for a response because images for a large catalog take longer to download than a typical HTTP request allows. The import itself has not stopped — the server continues processing in the background. Wait a few minutes and reload the page to see the final stats.'))
						+ '</div>'
					);
				} else {
					showResult($result, l10n('request_failed', 'Request failed. Please try again.'), 'error');
				}
			}).always(function() {
				var elapsed = Date.now() - startedAt;
				var wait = Math.max(0, minVisibleMs - elapsed);
				setTimeout(function() {
					$button.prop('disabled', false);
					$spinner.removeClass('is-active');
				}, wait);
			});
		});
	}

	/**
	 * Initialize auto-detect columns button on Mapping tab.
	 */
	function initDetectColumns() {
		$('#mvweb-pi-detect-columns').on('click', function(e) {
			e.preventDefault();

			var $button = $(this);
			var $spinner = $('#mvweb-pi-detect-spinner');
			var $status = $('#mvweb-pi-detect-status');

			$button.prop('disabled', true);
			$spinner.addClass('is-active');
			$status.text('');

			$.post(mvweb_pi_ajax.ajax_url, {
				action: 'mvweb_pi_detect_columns',
				nonce: mvweb_pi_ajax.nonce
			}, function(response) {
				if (response.success) {
					updateMappingDropdowns(response.data);
					// Save headers + detected mapping to server.
					saveMappingToServer(response.data);
					var found = response.data.headers.length;
					if (found === 0) {
						// Zero columns is not a success: the file parsed but holds
						// no offers (an empty feed does exactly this), so say that
						// instead of showing a green "0 columns detected".
						$status.html('<span class="mvweb-badge mvweb-badge--warning">' +
							escapeHtml(l10n('no_columns', 'No columns found — the file contains no products.')) +
							'</span>');
					} else {
						$status.html('<span class="mvweb-badge mvweb-badge--success">' +
							found + ' ' + escapeHtml(l10n('columns_detected', 'columns detected')) + '</span>');
					}
				} else {
					$status.html('<span class="mvweb-badge mvweb-badge--error">' +
						escapeHtml(typeof response.data === 'string' ? response.data : 'Detection failed.') +
						'</span>');
				}
			}).fail(function() {
				$status.html('<span class="mvweb-badge mvweb-badge--error">Request failed.</span>');
			}).always(function() {
				$button.prop('disabled', false);
				$spinner.removeClass('is-active');
			});
		});
	}

	/**
	 * Hide source columns that are already taken by another mapping row
	 * so the operator cannot pick the same column twice. Re-runs on every
	 * change of any mapping select and once on load — cheap, O(rows²) but
	 * mapping rows are <15.
	 */
	function refreshMappingDedup() {
		var $selects = $('.mvweb-pi-mapping-select');
		if (!$selects.length) {
			return;
		}

		// Collect currently-picked, non-empty values.
		var taken = {};
		$selects.each(function() {
			var v = $(this).val();
			if (v) {
				taken[v] = true;
			}
		});

		// For each select, hide options claimed by another row;
		// keep the row's own current value visible so the user can see
		// what it points to, and always keep the empty "— Not mapped —".
		$selects.each(function() {
			var $select = $(this);
			var current = $select.val();
			$select.find('option').each(function() {
				var $opt = $(this);
				var val  = $opt.attr('value');
				if (val === '' || val === current) {
					$opt.prop('disabled', false).prop('hidden', false);
				} else {
					var claimed = !!taken[val];
					$opt.prop('disabled', claimed).prop('hidden', claimed);
				}
			});
		});
	}

	/**
	 * Initialise dedup listeners. Called once after DOM ready.
	 */
	function initMappingDedup() {
		// Live re-evaluation on any picker change.
		$(document).on('change', '.mvweb-pi-mapping-select', refreshMappingDedup);
		refreshMappingDedup();
	}

	/**
	 * Update mapping dropdown options with detected headers.
	 *
	 * @param {Object} data Detection result with headers and detected mapping.
	 */
	function updateMappingDropdowns(data) {
		var headers = data.headers || [];
		var detected = data.detected || {};

		$('.mvweb-pi-mapping-select').each(function() {
			var $select = $(this);
			var field = $select.data('field');
			var currentVal = $select.val();

			// Rebuild options.
			var options = '<option value="">' + $select.find('option:first').text() + '</option>';
			headers.forEach(function(header) {
				var selected = '';
				// Auto-select: use detected value if no manual selection exists.
				if (!currentVal && detected[field] === header) {
					selected = ' selected';
				} else if (currentVal === header) {
					selected = ' selected';
				}
				options += '<option value="' + escapeAttr(header) + '"' + selected + '>' +
					escapeHtml(header) + '</option>';
			});

			$select.html(options);
		});

		// After auto-detect re-built the selects, re-apply the dedup
		// rule so options already claimed by another row stay hidden.
		refreshMappingDedup();
	}

	/**
	 * Save detected mapping and headers to server via AJAX.
	 *
	 * @param {Object} data Detection result.
	 */
	function saveMappingToServer(data) {
		$.post(mvweb_pi_ajax.ajax_url, {
			action: 'mvweb_pi_save_mapping',
			nonce: mvweb_pi_ajax.nonce,
			headers: data.headers,
			detected: data.detected
		});
	}

	/**
	 * Escape HTML entities.
	 *
	 * @param {string} str Input string.
	 * @return {string} Escaped string.
	 */
	function escapeHtml(str) {
		var div = document.createElement('div');
		div.appendChild(document.createTextNode(str));
		return div.innerHTML;
	}

	/**
	 * Escape attribute value.
	 *
	 * @param {string} str Input string.
	 * @return {string} Escaped string.
	 */
	function escapeAttr(str) {
		return String(str)
			.replace(/&/g, '&amp;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#39;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;');
	}

	/**
	 * Initialize Feeds tab generate button.
	 */
	function initFeedsAction() {
		$('#mvweb-pi-generate-feeds-btn').on('click', function(e) {
			e.preventDefault();

			var $button = $(this);
			var $spinner = $button.find('.mvweb-spinner');
			var $result = $('#mvweb-pi-feeds-result');

			$button.prop('disabled', true);
			$spinner.addClass('is-active');
			$result.empty();

			runFeedsSlice($result, true, function() {
				$button.prop('disabled', false);
				$spinner.removeClass('is-active');
			});
		});
	}

	/**
	 * Run one slice of feed generation and chain the next one.
	 *
	 * A catalogue of any size outlives a single request, so the server works
	 * for a fixed budget, saves where it got to and answers `done: false`;
	 * we keep asking until it is finished. Only the last answer carries the
	 * generated feeds — until then the file on disk is untouched.
	 *
	 * @param {jQuery}   $result  Result container.
	 * @param {boolean}  restart  Whether to discard an abandoned checkpoint.
	 * @param {Function} onFinish Called once, whatever the outcome.
	 * @param {number}   [left]   Slices still allowed, guarding against a loop
	 *                            that never converges.
	 */
	function runFeedsSlice($result, restart, onFinish, left) {
		var remaining = typeof left === 'number' ? left : 480;
		if (remaining <= 0) {
			showResult($result, l10n('request_failed', 'Request failed. Please try again.'), 'error');
			onFinish();
			return;
		}

		$.post(mvweb_pi_ajax.ajax_url, {
			action: 'mvweb_pi_generate_feeds',
			nonce: mvweb_pi_ajax.nonce,
			restart: restart ? 1 : 0
		}, function(response) {
			if (!response.success) {
				var errorMsg = typeof response.data === 'string'
					? response.data
					: (response.data && response.data.message ? response.data.message : l10n('unknown_error', 'Unknown error.'));
				showResult($result, errorMsg, 'error');
				onFinish();
				return;
			}

			if (response.data.done) {
				handleFeedsResult(response.data, $result);
				onFinish();
				return;
			}

			showFeedsProgress($result, response.data.progress);
			runFeedsSlice($result, false, onFinish, remaining - 1);
		}).fail(function() {
			showResult($result, l10n('request_failed', 'Request failed. Please try again.'), 'error');
			onFinish();
		});
	}

	/**
	 * Show how far the current generation has got.
	 *
	 * @param {jQuery} $result  Result container.
	 * @param {Object} progress Progress payload from the server.
	 */
	function showFeedsProgress($result, progress) {
		if (!progress) {
			return;
		}

		var badges = [{
			label: l10n('products', 'products'),
			value: (progress.scanned || 0) + ' / ' + (progress.total || 0),
			tone: 'plain'
		}];

		if (progress.feeds_total > 1) {
			badges.unshift({
				label: progress.slug || '',
				value: (progress.feeds_done || 0) + 1 + ' / ' + progress.feeds_total,
				tone: 'plain'
			});
		}

		// Generation runs in two passes over the catalogue, and the counter
		// restarts when the second one begins — naming the pass keeps that
		// from reading as progress lost.
		var title = 'collect' === progress.phase
			? l10n('feed_collecting', 'Collecting categories…')
			: l10n('feed_generating', 'Generating feed…');

		renderActionResult($result, 'info', title, badges);
	}

	/**
	 * Display feed generation results.
	 *
	 * @param {Object} data    Response data with feeds array and totals.
	 * @param {jQuery} $result Result container.
	 */
	function handleFeedsResult(data, $result) {
		// One badge per generated feed: "{slug}: N товаров".
		// URLs are intentionally NOT repeated here — the table directly
		// above shows them with click-to-open links, so dragging the
		// full URL into the success banner just wraps to two lines and
		// duplicates info the user can already see.
		var badges = [];
		if (data.feeds && data.feeds.length) {
			data.feeds.forEach(function(feed) {
				badges.push({
					label: feed.slug,
					value: feed.products + ' ' + l10n('products', 'products'),
					tone: 'plain'
				});
			});
		}

		var count = data.count || (data.feeds ? data.feeds.length : 0);
		var title = count === 1
			? l10n('feed_generated',  'Feed generated.')
			: l10n('feeds_generated', 'Feeds generated.');

		renderActionResult($result, 'success', title, badges);

		// Update feeds table with fresh data.
		updateFeedsTable(data.feeds);
	}

	/**
	 * Update the feeds table after generation.
	 *
	 * @param {Array} feeds Array of feed objects.
	 */
	function updateFeedsTable(feeds) {
		// On first generation (no table yet) just reload — PHP will
		// render the full table with all columns and the delete buttons.
		// Building the same markup in JS would just drift from the PHP
		// template on every future change.
		var $table = $('#mvweb-pi-feeds-table');
		if (!$table.length) {
			location.reload();
			return;
		}

		var $tbody = $table.find('tbody');
		$tbody.empty();

		if (!feeds || !feeds.length) {
			return;
		}

		var deleteLabel = l10n('delete', 'Delete');
		feeds.forEach(function(feed) {
			var row = '<tr data-slug="' + escapeAttr(feed.slug) + '">';
			row += '<td><strong>' + escapeHtml(feed.slug) + '</strong></td>';
			row += '<td><a href="' + escapeAttr(feed.url) + '" target="_blank" rel="noopener noreferrer" class="mvweb-pi-feed-url">' +
				escapeHtml(feed.url) + '</a></td>';
			row += '<td>' + new Date().toLocaleString() + '</td>';
			row += '<td><span class="mvweb-badge">' + feed.products + '</span></td>';
			row += '<td>' + escapeHtml(feed.size || '') + '</td>';
			row += '<td class="mvweb-pi-feeds-table__actions">' +
				'<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-pi-delete-feed-btn" ' +
				'data-slug="' + escapeAttr(feed.slug) + '">' +
				escapeHtml(deleteLabel) + '</button></td>';
			row += '</tr>';
			$tbody.append(row);
		});
	}

	/**
	 * Initialise the delete button in the feeds table.
	 * Confirms with the user, then POSTs mvweb_pi_delete_feed and
	 * removes the row on success. If the deletion empties the table,
	 * we reload so PHP can render the proper "No feeds yet" empty state.
	 */
	function initDeleteFeed() {
		var confirmMsg = l10n('confirm_delete_feed', 'Delete this feed file? This cannot be undone.');

		$(document).on('click', '.mvweb-pi-delete-feed-btn', function(e) {
			e.preventDefault();
			var $btn  = $(this);
			var slug  = $btn.data('slug');
			if (!slug) {
				return;
			}
			if (!window.confirm(confirmMsg)) {
				return;
			}

			$btn.prop('disabled', true);

			$.post(mvweb_pi_ajax.ajax_url, {
				action: 'mvweb_pi_delete_feed',
				nonce: mvweb_pi_ajax.nonce,
				slug: slug
			}, function(response) {
				if (!response.success) {
					$btn.prop('disabled', false);
					var msg = typeof response.data === 'string'
						? response.data
						: l10n('unknown_error', 'Unknown error.');
					window.alert(msg);
					return;
				}
				var $row   = $btn.closest('tr');
				var $tbody = $row.closest('tbody');
				$row.remove();

				// If that was the last feed, reload — PHP will render
				// the empty-state placeholder instead of an empty table.
				if ($tbody.find('tr').length === 0) {
					location.reload();
				}
			}).fail(function() {
				$btn.prop('disabled', false);
				window.alert(l10n('request_failed', 'Request failed. Please try again.'));
			});
		});
	}

	/**
	 * Initialize Settings tab — warehouse CRUD.
	 */
	function initWarehouses() {
		var $body = $('#mvweb-pi-warehouses-body');
		var $addBtn = $('#mvweb-pi-add-warehouse');

		if (!$addBtn.length) {
			return;
		}

		// Add warehouse row.
		$addBtn.on('click', function(e) {
			e.preventDefault();

			var index = $body.find('.mvweb-pi-warehouse-row').length;
			var row = buildWarehouseRow(index, {id: '', name: '', url: '', visible: '1', feed_name: ''});
			$body.append(row);
		});

		// Remove warehouse row (delegated).
		$body.on('click', '.mvweb-pi-remove-warehouse', function(e) {
			e.preventDefault();
			$(this).closest('.mvweb-pi-warehouse-row').remove();
			reindexWarehouseRows();
		});
	}

	/**
	 * Build a warehouse table row.
	 *
	 * @param {number} index Row index.
	 * @param {Object} data  Warehouse data.
	 * @return {string} HTML row.
	 */
	function buildWarehouseRow(index, data) {
		var prefix = 'mvweb_pi_settings[warehouses][' + index + ']';
		var checked = (data.visible === '1' || data.visible === true) ? ' checked' : '';

		var row = '<tr class="mvweb-pi-warehouse-row" data-index="' + index + '">';
		row += '<td><input type="text" name="' + prefix + '[id]" class="mvweb-input mvweb-pi-wh-id" value="' + escapeAttr(data.id) + '" placeholder="moscow" required></td>';
		row += '<td><input type="text" name="' + prefix + '[name]" class="mvweb-input mvweb-pi-wh-name" value="' + escapeAttr(data.name) + '" placeholder="Moscow"></td>';
		row += '<td><input type="url" name="' + prefix + '[url]" class="mvweb-input mvweb-pi-wh-url" value="' + escapeAttr(data.url) + '" placeholder="https://"></td>';
		row += '<td><label class="mvweb-toggle"><input type="checkbox" name="' + prefix + '[visible]" value="1"' + checked + '><span class="mvweb-toggle__slider"></span></label></td>';
		row += '<td><input type="text" name="' + prefix + '[feed_name]" class="mvweb-input mvweb-pi-wh-feed" value="' + escapeAttr(data.feed_name) + '" placeholder="Optional"></td>';
		row += '<td><button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-pi-remove-warehouse">&times;</button></td>';
		row += '</tr>';

		return row;
	}

	/**
	 * Reindex warehouse rows after removal.
	 */
	function reindexWarehouseRows() {
		$('#mvweb-pi-warehouses-body .mvweb-pi-warehouse-row').each(function(index) {
			var $row = $(this);
			$row.attr('data-index', index);
			var prefix = 'mvweb_pi_settings[warehouses][' + index + ']';
			$row.find('.mvweb-pi-wh-id').attr('name', prefix + '[id]');
			$row.find('.mvweb-pi-wh-name').attr('name', prefix + '[name]');
			$row.find('.mvweb-pi-wh-url').attr('name', prefix + '[url]');
			$row.find('input[type="checkbox"]').attr('name', prefix + '[visible]');
			$row.find('.mvweb-pi-wh-feed').attr('name', prefix + '[feed_name]');
		});
	}

	/**
	 * Initialize Mapping tab — product tag rules CRUD.
	 */
	function initTagRules() {
		var $body = $('#mvweb-pi-tag-rules-body');
		var $addBtn = $('#mvweb-pi-add-tag-rule');

		if (!$addBtn.length) {
			return;
		}

		// Add rule row.
		$addBtn.on('click', function(e) {
			e.preventDefault();

			var index = $body.find('.mvweb-pi-tag-rule-row').length;
			$body.append(buildTagRuleRow(index));

			// The cloned dropdown carries the donor row's selection — a new
			// rule must start unset.
			$body.find('.mvweb-pi-tag-rule-row').last().find('.mvweb-pi-tag-source').val('');
		});

		// Remove rule row (delegated).
		$body.on('click', '.mvweb-pi-remove-tag-rule', function(e) {
			e.preventDefault();
			$(this).closest('.mvweb-pi-tag-rule-row').remove();
			reindexTagRuleRows();
		});
	}

	/**
	 * Build a tag rule table row.
	 *
	 * The source dropdown is cloned from a select that PHP already rendered
	 * with the detected column headers, so the row needs no data of its own.
	 * The key field stays empty on purpose — PHP mints a fresh key for a new
	 * rule, and cloning an existing key would make two rules fight over one
	 * tag.
	 *
	 * @param {number} index Row index.
	 * @return {string} HTML row.
	 */
	function buildTagRuleRow(index) {
		var prefix = 'mvweb_pi_tag_rules[' + index + ']';
		var $donor = $('#mvweb-pi-tag-rules-body .mvweb-pi-tag-source').first();

		if (!$donor.length) {
			$donor = $('.mvweb-pi-mapping-select').first();
		}

		var options = $donor.length ? $donor.html() : '<option value=""></option>';

		// Placeholders are copied from a row PHP rendered, so they stay in the
		// admin's language instead of being hardcoded here in English.
		var matchHint = $('#mvweb-pi-tag-rules-body .mvweb-pi-tag-match').first().attr('placeholder') || '';
		var labelHint = $('#mvweb-pi-tag-rules-body .mvweb-pi-tag-label').first().attr('placeholder') || '';

		var row = '<tr class="mvweb-pi-tag-rule-row" data-index="' + index + '">';
		row += '<td><select name="' + prefix + '[source]" class="mvweb-select mvweb-pi-tag-source">' + options + '</select>';
		row += '<input type="hidden" name="' + prefix + '[key]" value=""></td>';
		row += '<td><input type="text" name="' + prefix + '[match]" class="mvweb-input mvweb-pi-tag-match" value="" placeholder="' + escapeAttr(matchHint) + '"></td>';
		row += '<td><input type="text" name="' + prefix + '[label]" class="mvweb-input mvweb-pi-tag-label" value="" placeholder="' + escapeAttr(labelHint) + '"></td>';
		row += '<td><button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-pi-remove-tag-rule">&times;</button></td>';
		row += '</tr>';

		return row;
	}

	/**
	 * Reindex tag rule rows after removal.
	 */
	function reindexTagRuleRows() {
		$('#mvweb-pi-tag-rules-body .mvweb-pi-tag-rule-row').each(function(index) {
			var $row = $(this);
			$row.attr('data-index', index);
			var prefix = 'mvweb_pi_tag_rules[' + index + ']';
			$row.find('.mvweb-pi-tag-source').attr('name', prefix + '[source]');
			$row.find('input[type="hidden"]').attr('name', prefix + '[key]');
			$row.find('.mvweb-pi-tag-match').attr('name', prefix + '[match]');
			$row.find('.mvweb-pi-tag-label').attr('name', prefix + '[label]');
		});
	}

	/**
	 * Initialize Log tab — load/filter/clear/paginate.
	 */
	function initLogTab() {
		var $loadBtn    = $('#mvweb-pi-load-log');
		var $clearBtn   = $('#mvweb-pi-clear-log');
		var $spinner    = $('#mvweb-pi-log-spinner');

		if (!$loadBtn.length) {
			return;
		}

		// Load logs on Apply click.
		$loadBtn.on('click', function(e) {
			e.preventDefault();
			loadLogPage(1);
		});

		// Clear logs.
		$clearBtn.on('click', function(e) {
			e.preventDefault();
			if (!confirm('Clear all log entries?')) {
				return;
			}

			$spinner.addClass('is-active');
			$clearBtn.prop('disabled', true);

			$.post(mvweb_pi_ajax.ajax_url, {
				action: 'mvweb_pi_clear_log',
				nonce: mvweb_pi_ajax.nonce
			}, function(response) {
				if (response.success) {
					$('#mvweb-pi-log-body').empty();
					$('#mvweb-pi-log-pagination').empty();
				}
			}).always(function() {
				$spinner.removeClass('is-active');
				$clearBtn.prop('disabled', false);
			});
		});

		// Pagination clicks (delegated).
		$('#mvweb-pi-log-pagination').on('click', 'a', function(e) {
			e.preventDefault();
			var page = $(this).data('page');
			if (page) {
				loadLogPage(page);
			}
		});

		// Auto-load first page on tab activation.
		$('.mvweb-nav .mvweb-nav__link').on('click', function() {
			if ($(this).data('tab') === 'log' && $('#mvweb-pi-log-body').children().length === 0) {
				loadLogPage(1);
			}
		});

		// Initial autoload when the page itself lands on the Log tab — either
		// because PHP rendered it with .active (?tab=log) or because the URL
		// hash points to it. The hash-driven trigger inside initTabs() runs
		// before this handler is registered, so we cannot rely on the click
		// event firing here.
		var logIsActive = $('#log').hasClass('active') || window.location.hash === '#log';
		if (logIsActive && $('#mvweb-pi-log-body').children().length === 0) {
			loadLogPage(1);
		}
	}

	/**
	 * Load a specific log page via AJAX.
	 *
	 * @param {number} page Page number.
	 */
	function loadLogPage(page) {
		var $spinner = $('#mvweb-pi-log-spinner');
		var $tbody   = $('#mvweb-pi-log-body');
		var level    = $('#mvweb-pi-log-level').val();

		$spinner.addClass('is-active');

		$.post(mvweb_pi_ajax.ajax_url, {
			action: 'mvweb_pi_get_log',
			nonce: mvweb_pi_ajax.nonce,
			page: page,
			level: level
		}, function(response) {
			if (!response.success) {
				return;
			}

			var data = response.data;
			$tbody.empty();

			if (!data.items || data.items.length === 0) {
				$tbody.html('<tr><td colspan="4" style="text-align: center;">' +
					escapeHtml('No log entries found.') + '</td></tr>');
				$('#mvweb-pi-log-pagination').empty();
				return;
			}

			data.items.forEach(function(item) {
				var levelClass = '';
				if ('error' === item.level) {
					levelClass = 'mvweb-badge--error';
				} else if ('warning' === item.level) {
					levelClass = 'mvweb-badge--warning';
				} else {
					levelClass = 'mvweb-badge--plain';
				}

				var ctx = '';
				if (item.context && typeof item.context === 'object') {
					var parts = [];
					for (var key in item.context) {
						if (item.context.hasOwnProperty(key)) {
							parts.push(escapeHtml(key) + ': ' + escapeHtml(String(item.context[key])));
						}
					}
					ctx = parts.join(', ');
				}

				var row = '<tr>';
				row += '<td>' + escapeHtml(item.date || '') + '</td>';
				row += '<td><span class="mvweb-badge ' + levelClass + '">' + escapeHtml(item.level || '') + '</span></td>';
				row += '<td>' + escapeHtml(item.message || '') + '</td>';
				row += '<td><small>' + ctx + '</small></td>';
				row += '</tr>';
				$tbody.append(row);
			});

			// Build pagination.
			buildLogPagination(data.page, data.total_pages);
		}).always(function() {
			$spinner.removeClass('is-active');
		});
	}

	/**
	 * Build pagination links for log tab.
	 *
	 * @param {number} current    Current page.
	 * @param {number} totalPages Total pages.
	 */
	function buildLogPagination(current, totalPages) {
		var $pagination = $('#mvweb-pi-log-pagination');
		$pagination.empty();

		if (totalPages <= 1) {
			return;
		}

		// Previous.
		if (current > 1) {
			$pagination.append('<a href="#" data-page="' + (current - 1) + '">&laquo;</a>');
		} else {
			$pagination.append('<span class="mvweb-pagination__disabled">&laquo;</span>');
		}

		// Page numbers (show max 7).
		var start = Math.max(1, current - 3);
		var end = Math.min(totalPages, start + 6);
		start = Math.max(1, end - 6);

		for (var i = start; i <= end; i++) {
			if (i === current) {
				$pagination.append('<span class="current">' + i + '</span>');
			} else {
				$pagination.append('<a href="#" data-page="' + i + '">' + i + '</a>');
			}
		}

		// Next.
		if (current < totalPages) {
			$pagination.append('<a href="#" data-page="' + (current + 1) + '">&raquo;</a>');
		} else {
			$pagination.append('<span class="mvweb-pagination__disabled">&raquo;</span>');
		}
	}

	/**
	 * Categories tab — name filter, select-all, clear-all.
	 *
	 * The list can run to thousands of rows on real catalogs, so the
	 * filter does plain string-contains on the visible name client-side;
	 * much faster than round-tripping each keystroke to the server.
	 */
	/**
	 * Initialize the "Fetch category tree" button.
	 *
	 * Parses the feed's category tree without importing products, then reloads
	 * the page so the server re-renders the tree from the refreshed sidecar.
	 * Lives outside initCategoriesTab() because it must work in the empty state
	 * too — when no tree exists yet there is no .mvweb-pi-cat-tree to bind to.
	 */
	function initFetchTree() {
		var $button = $('#mvweb-pi-fetch-tree-btn');
		if (!$button.length) {
			return;
		}

		$button.on('click', function(e) {
			e.preventDefault();

			var $spinner = $('#mvweb-pi-fetch-tree-spinner');
			var $result  = $('#mvweb-pi-fetch-tree-result');

			$button.prop('disabled', true);
			$spinner.addClass('is-active');
			$result.empty();

			$.post(mvweb_pi_ajax.ajax_url, {
				action: 'mvweb_pi_fetch_tree',
				nonce: mvweb_pi_ajax.nonce
			}, function(response) {
				if (response.success) {
					var count = response.data && response.data.count ? response.data.count : 0;
					showResult(
						$result,
						l10n('tree_fetched', 'Category tree loaded.') + ' (' + count + ')',
						'success'
					);
					// Reload so the server re-renders the tree with checkboxes.
					setTimeout(function() {
						window.location.reload();
					}, 600);
				} else {
					var errorMsg = typeof response.data === 'string'
						? response.data
						: (response.data && response.data.message ? response.data.message : l10n('unknown_error', 'Unknown error.'));
					showResult($result, errorMsg, 'error');
					$button.prop('disabled', false);
					$spinner.removeClass('is-active');
				}
			}).fail(function() {
				showResult($result, l10n('request_failed', 'Request failed. Please try again.'), 'error');
				$button.prop('disabled', false);
				$spinner.removeClass('is-active');
			});
		});
	}

	/**
	 * Initialise every category picker independently.
	 *
	 * There can be more than one picker on the page at once — the source-category
	 * filter on the main tab and the feed-category filter on the feeds tab. Both
	 * live in the same DOM/form, so each picker is scoped to its own
	 * .mvweb-pi-cat-picker wrapper via .find() rather than shared ids; otherwise
	 * one picker's filter/select/clear would reach into the other's rows.
	 */
	function initCategoryPickers() {
		$('.mvweb-pi-cat-picker').each(function() {
			var $picker = $(this);
			var $tree   = $picker.find('.mvweb-pi-cat-tree');
			if (!$tree.length) {
				return;
			}

			var $rows   = $tree.find('.mvweb-pi-cat-row');
			var $filter = $picker.find('.mvweb-pi-cat-filter');

			$filter.on('input', function() {
				var q = $(this).val().toLowerCase().trim();
				if (q === '') {
					$rows.removeClass('is-hidden');
					return;
				}
				$rows.each(function() {
					var name = $(this).find('.mvweb-pi-cat-name').text().toLowerCase();
					$(this).toggleClass('is-hidden', name.indexOf(q) === -1);
				});
			});

			$picker.find('.mvweb-pi-cat-expand-all').on('click', function() {
				$rows.not('.is-hidden').find('input[type="checkbox"]').prop('checked', true);
			});

			$picker.find('.mvweb-pi-cat-clear-all').on('click', function() {
				$rows.find('input[type="checkbox"]').prop('checked', false);
			});
		});
	}

	/**
	 * Connect a MoySklad account.
	 *
	 * None of the three credential fields has a name attribute on purpose —
	 * every tab shares one form, and a named token or password field would be
	 * posted back on every save. They are read from the DOM here, sent once,
	 * and both secrets are emptied as soon as the connection is confirmed: what
	 * the server keeps is the token, and a copy of it sitting in the page adds
	 * nothing but another place to leak from.
	 */
	function initMoySklad() {
		var $button = $('#mvweb-pi-moysklad-connect-btn');
		if (!$button.length) {
			return;
		}

		$button.on('click', function(e) {
			e.preventDefault();

			var $spinner = $button.find('.mvweb-spinner');
			var $result = $('#mvweb-pi-moysklad-result');
			var $password = $('#mvweb-pi-moysklad-password');
			var $token = $('#mvweb-pi-moysklad-token');

			$button.prop('disabled', true);
			$spinner.addClass('is-active');
			$result.empty();

			$.post(mvweb_pi_ajax.ajax_url, {
				action: 'mvweb_pi_moysklad_connect',
				nonce: mvweb_pi_ajax.nonce,
				login: $('#mvweb-pi-moysklad-login').val(),
				password: $password.val(),
				token: $.trim($token.val())
			}, function(response) {
				if (response.success) {
					$password.val('');
					$token.val('');
					fillPriceTypes(response.data.price_types);
					showResult($result, response.data.message, 'success');
				} else {
					showResult($result, typeof response.data === 'string'
						? response.data
						: l10n('unknown_error', 'Unknown error.'), 'error');
				}
			}).fail(function() {
				showResult($result, l10n('request_failed', 'Request failed. Please try again.'), 'error');
			}).always(function() {
				$button.prop('disabled', false);
				$spinner.removeClass('is-active');
			});
		});
	}

	/**
	 * Refill the price-type dropdowns from what MoySklad just reported.
	 *
	 * Keeps whatever was already chosen when the same price type is still on
	 * offer: reconnecting to fix an expired token should not silently unmap
	 * the prices.
	 *
	 * @param {Object} priceTypes Map of id => name.
	 */
	function fillPriceTypes(priceTypes) {
		$('.mvweb-pi-moysklad-price').each(function() {
			var $select = $(this);
			var chosen = $select.val();
			var options = ['<option value="">' + escapeHtml($select.find('option').first().text()) + '</option>'];

			$.each(priceTypes, function(id, name) {
				options.push('<option value="' + escapeAttr(id) + '">' + escapeHtml(name) + '</option>');
			});

			$select.html(options.join(''));
			if (chosen && priceTypes[chosen]) {
				$select.val(chosen);
			}
		});
	}

	/**
	 * Document ready.
	 */
	$(function() {
		initTabs();
		initMoySklad();
		initOutputActions();
		initDetectColumns();
		initMappingDedup();
		initImportAction();
		initFeedsAction();
		initDeleteFeed();
		initWarehouses();
		initTagRules();
		initLogTab();
		initFetchTree();
		initCategoryPickers();
	});

})(jQuery);
