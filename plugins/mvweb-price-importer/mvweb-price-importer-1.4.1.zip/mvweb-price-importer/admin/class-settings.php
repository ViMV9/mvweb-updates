<?php
/**
 * Settings class — settings save logic.
 *
 * Handles validation, sanitization, and persistence of all plugin settings.
 * Extracted from entry point mvweb_pi_settings_page() for SRP compliance.
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Settings
 *
 * Encapsulates settings save logic: nonce verification, sanitization,
 * persistence to wp_options, and cron schedule updates.
 *
 * @since 1.1.0
 */
class MVweb_PI_Settings {

	/**
	 * Handle form submission and save settings.
	 *
	 * Checks nonce and permissions, then delegates to individual
	 * save methods based on submitted data.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function handle_save(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified below via check_admin_referer().
		$switching = isset( $_POST['mvweb_pi_switch_source'] );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified below via check_admin_referer().
		if ( ! isset( $_POST['mvweb_pi_save'] ) && ! $switching ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		check_admin_referer( 'mvweb_pi_settings', 'mvweb_pi_nonce' );

		// Changing the data source has its own button, and it does only that.
		// It used to ride along with "Save changes" — the same button that saves
		// the batch size and the logging level — so an operator adjusting a
		// setting could migrate the catalogue by pressing it. WordPress puts
		// one-off operations on their own submit for this reason.
		if ( $switching ) {
			$this->save_source_mode();
			$this->redirect_back();
		}

		// Save main settings (Settings tab).
		if ( isset( $_POST['mvweb_pi_settings'] ) && is_array( $_POST['mvweb_pi_settings'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized field-by-field in save_main().
			$this->save_main( wp_unslash( $_POST['mvweb_pi_settings'] ) );
		}

		// Save feed settings (Feeds tab).
		$this->save_feeds();

		// Save mapping settings (Mapping tab).
		if ( isset( $_POST['mvweb_pi_mapping'] ) && is_array( $_POST['mvweb_pi_mapping'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized field-by-field in save_mapping().
			$this->save_mapping( wp_unslash( $_POST['mvweb_pi_mapping'] ) );
		}

		// Save product tag rules (Mapping tab). Reads $_POST itself because an
		// emptied repeater posts no array at all — see save_tag_rules().
		$this->save_tag_rules();

		// MoySklad connection options (MoySklad tab).
		$this->save_moysklad();

		$this->redirect_back();
	}

	/**
	 * Post/Redirect/Get back to the settings screen.
	 *
	 * Stashes a one-shot flag in a per-user transient and bounces back as a clean
	 * GET. Without it every browser refresh re-POSTs the form and the "Settings
	 * saved" notice reappears though nobody pressed the button.
	 *
	 * @since 1.1.0
	 * @return never
	 */
	private function redirect_back(): void {
		set_transient(
			$this->saved_flag_key(),
			'1',
			MINUTE_IN_SECONDS
		);

		$redirect = add_query_arg(
			array(
				'page' => 'mvweb-price-importer',
				'tab'  => isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'main', // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab preservation.
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Key for the per-user "settings saved" one-shot transient.
	 *
	 * Per-user so that two admins saving simultaneously do not consume
	 * each other's notice.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public function saved_flag_key(): string {
		return 'mvweb_pi_saved_' . get_current_user_id();
	}

	/**
	 * Consume the one-shot "settings saved" flag, if present.
	 *
	 * Called by the settings page template before settings_errors() so the
	 * green "Settings saved" notice renders exactly once — on the GET that
	 * follows a successful save.
	 *
	 * @since 1.1.0
	 * @return bool True if a notice was queued, false otherwise.
	 */
	public function maybe_queue_saved_notice(): bool {
		$key = $this->saved_flag_key();
		if ( ! get_transient( $key ) ) {
			return false;
		}
		delete_transient( $key );

		add_settings_error(
			'mvweb_pi_messages',
			'mvweb_pi_message',
			__( 'Settings saved.', 'mvweb-price-importer' ),
			'updated'
		);
		return true;
	}

	/**
	 * Render the settings page.
	 *
	 * Queues the post-save "Settings saved" notice (if a save just happened
	 * on the previous request) before including the template, so the notice
	 * renders exactly once on the GET that follows the redirect.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function render(): void {
		$this->maybe_queue_saved_notice();
		$this->maybe_queue_notices();
		include MVWEB_PI_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Bring price list protection in line with the submitted toggle.
	 *
	 * A failure never opens a price list that was already closed: the rule that
	 * was in force stays in force and the switch stays on, because a typo in
	 * the address must not quietly publish the catalogue. It is reported in
	 * red, and a broken import is a loud failure — an exposed price list is a
	 * silent one.
	 *
	 * @since 1.1.0
	 * @param array $settings Settings array, modified in place.
	 * @param array $existing Settings as they were before this save.
	 * @return void
	 */
	private function apply_protection( array &$settings, array $existing ): void {
		$was_enabled = ! empty( $existing['protect_source'] );

		if ( empty( $settings['protect_source'] ) ) {
			if ( $was_enabled && ! MVweb_PI_Protection::disable( $settings ) ) {
				$settings['protect_source'] = true;
				$this->queue_notice(
					__( 'The price list could not be reopened: the rule stays in the .htaccess file because it is not writable. The switch is left on, so the addresses keep their key and the import goes on working.', 'mvweb-price-importer' ),
					'error'
				);
				return;
			}

			if ( $was_enabled ) {
				$this->queue_notice(
					__( 'Price list protection is off — anyone who knows the address can download the file again.', 'mvweb-price-importer' ),
					'warning'
				);
			}
			return;
		}

		// Nothing about the sources changed, so the rule in force already
		// matches them. Re-applying would only spend three live HTTP requests
		// on every unrelated save — a tag rule, a feed name, a batch size.
		if ( $was_enabled && self::sources_unchanged( $existing, $settings ) ) {
			return;
		}

		$key    = MVweb_PI_Protection::get_key();
		$result = MVweb_PI_Protection::enable(
			$settings,
			'' !== $key ? $key : MVweb_PI_Protection::generate_key()
		);

		if ( is_wp_error( $result ) ) {
			$settings['protect_source'] = $was_enabled;
			$message                    = $result->get_error_message();
			if ( $was_enabled ) {
				$message .= ' ' . __( 'The rule that was in force before this save was put back, so the folder it covers stays closed — but the address above is not protected, and the price list at it is public.', 'mvweb-price-importer' );
			}
			$this->queue_notice( $message, 'error' );
			return;
		}

		$this->queue_notice(
			__( 'Price list protection is on. Checked on the live site: without the key the file answers 403, with the key it opens.', 'mvweb-price-importer' ),
			'updated'
		);
	}

	/**
	 * Do both settings sets point at exactly the same price list addresses?
	 *
	 * @since 1.1.0
	 * @param array $existing Settings before the save.
	 * @param array $settings Settings after the save.
	 * @return bool
	 */
	private static function sources_unchanged( array $existing, array $settings ): bool {
		return ( $existing['source_url'] ?? '' ) === ( $settings['source_url'] ?? '' )
			&& wp_json_encode( $existing['warehouses'] ?? array() ) === wp_json_encode( $settings['warehouses'] ?? array() );
	}

	/**
	 * Key for the per-user notices transient.
	 *
	 * @since 1.0.27
	 * @return string
	 */
	private function notice_key(): string {
		return 'mvweb_pi_notices_' . get_current_user_id();
	}

	/**
	 * Remember a notice raised while saving, for the redirect that follows.
	 *
	 * Additive on purpose: one save can raise notices from several sections
	 * (tag rules, price list protection), and a wholesale overwrite would
	 * drop everything but the last one.
	 *
	 * @since 1.1.0
	 * @param string $message Text to show.
	 * @param string $type    Notice type: updated, warning or error.
	 * @return void
	 */
	private function queue_notice( string $message, string $type = 'warning' ): void {
		$key     = $this->notice_key();
		$notices = get_transient( $key );
		if ( ! is_array( $notices ) ) {
			$notices = array();
		}

		$notices[] = array(
			'message' => $message,
			'type'    => $type,
		);

		set_transient( $key, $notices, MINUTE_IN_SECONDS );
	}

	/**
	 * Render notices raised while saving, once.
	 *
	 * Same one-shot pattern as the "Settings saved" notice: they are raised
	 * during the POST but must appear on the GET that follows the redirect.
	 *
	 * @since 1.0.27
	 * @return void
	 */
	private function maybe_queue_notices(): void {
		$key     = $this->notice_key();
		$notices = get_transient( $key );
		if ( ! is_array( $notices ) || empty( $notices ) ) {
			return;
		}
		delete_transient( $key );

		foreach ( $notices as $index => $notice ) {
			$message = is_array( $notice ) ? ( $notice['message'] ?? '' ) : $notice;
			$type    = is_array( $notice ) ? ( $notice['type'] ?? 'warning' ) : 'warning';
			if ( '' === $message ) {
				continue;
			}

			add_settings_error(
				'mvweb_pi_messages',
				'mvweb_pi_notice_' . (int) $index,
				(string) $message,
				(string) $type
			);
		}
	}

	/**
	 * Save main settings (Settings tab).
	 *
	 * Sanitizes source URL, warehouses, cron interval, and batch size.
	 * Updates cron schedule if interval changed.
	 *
	 * @since 1.1.0
	 * @param array $raw Raw POST data for mvweb_pi_settings.
	 * @return void
	 */
	private function save_main( array $raw ): void {
		$existing = get_option( 'mvweb_pi_settings', array() );
		$settings = array();

		// Source URL.
		$settings['source_url'] = isset( $raw['source_url'] )
			? esc_url_raw( $raw['source_url'] )
			: '';

		// Warehouses.
		$settings['warehouses'] = array();
		if ( ! empty( $raw['warehouses'] ) && is_array( $raw['warehouses'] ) ) {
			foreach ( $raw['warehouses'] as $wh_raw ) {
				$wh_id = sanitize_key( $wh_raw['id'] ?? '' );
				if ( empty( $wh_id ) ) {
					continue;
				}
				$settings['warehouses'][] = array(
					'id'        => $wh_id,
					'name'      => sanitize_text_field( $wh_raw['name'] ?? '' ),
					'url'       => esc_url_raw( $wh_raw['url'] ?? '' ),
					'visible'   => isset( $wh_raw['visible'] ) ? '1' : '0',
					'feed_name' => sanitize_text_field( $wh_raw['feed_name'] ?? '' ),
				);
			}
		}

		// Cron interval.
		$allowed_intervals         = array( 'disabled', 'hourly', 'mvweb_pi_6hours', 'mvweb_pi_12hours', 'daily' );
		$settings['cron_interval'] = isset( $raw['cron_interval'] ) && in_array( $raw['cron_interval'], $allowed_intervals, true )
			? $raw['cron_interval']
			: 'daily';

		// Batch size.
		$settings['batch_size'] = isset( $raw['batch_size'] )
			? max( 10, min( 1000, absint( $raw['batch_size'] ) ) )
			: 100;

		// Image import policy. Defaults to `smart` — refreshes photos whose
		// source URL has changed since the previous import, but leaves
		// unchanged photos alone to keep Imagick cost down on large catalogs.
		$allowed_image_modes    = array( 'smart', 'always', 'new_only', 'never' );
		$settings['image_mode'] = isset( $raw['image_mode'] ) && in_array( $raw['image_mode'], $allowed_image_modes, true )
			? $raw['image_mode']
			: 'smart';

		// Verbose/debug logging. When off (default) the JSONL log only
		// shows operator-grade events (downloads, conversions, imports);
		// when on, the importer also writes per-batch and per-source
		// diagnostics that help developers chase a slow or broken run.
		$settings['debug_logging'] = isset( $raw['debug_logging'] ) ? true : false;

		// Stock held by open orders. Stored explicitly from here on, so an
		// operator who switches it off keeps it off; until the first save the
		// key is simply absent and the importer treats that as "on".
		$settings['reserve_stock'] = isset( $raw['reserve_stock'] ) ? true : false;

		// Products with a wholesale price and no retail one.
		$settings['no_retail']       = isset( $raw['no_retail'] ) && is_string( $raw['no_retail'] ) && isset( mvweb_pi_no_retail_modes()[ $raw['no_retail'] ] )
			? (string) $raw['no_retail']
			: 'skip';
		$settings['no_retail_label'] = isset( $raw['no_retail_label'] ) && is_string( $raw['no_retail_label'] ) ? sanitize_text_field( $raw['no_retail_label'] ) : '';

		// Preserve other settings (debug_checkpoint, etc.).
		$settings['debug_checkpoint'] = $existing['debug_checkpoint'] ?? false;

		// Price list protection. Applied before the option is written, because
		// switching it on stamps the access key onto the source URLs and both
		// have to be stored together.
		$settings['protect_source'] = isset( $raw['protect_source'] );
		$this->apply_protection( $settings, $existing );

		update_option( 'mvweb_pi_settings', $settings );

		// Which products a source yields depends on this choice, so what was
		// fetched or converted under the old one must not be imported under the
		// new: the MoySklad dump is dropped, and the price list is taken as
		// changed so the next run converts it again rather than skipping it.
		if ( ( $existing['no_retail'] ?? 'skip' ) !== $settings['no_retail'] ) {
			MVweb_PI_MoySklad_Source::drop_dump();
			( new MVweb_PI_Loader() )->reset_etag();
		}

		// Remove downloaded source files of warehouses that are no longer
		// configured. Keeping them would let a later manual Convert re-merge a
		// removed warehouse's stock into the catalogue, and they accumulate on
		// disk as warehouses come and go. Files of still-configured sources are
		// left untouched.
		$expected  = array_flip( mvweb_pi_expected_source_ids( $settings ) );
		$leftovers = glob( mvweb_pi_get_upload_dir() . 'source-*' );
		foreach ( (array) $leftovers as $file ) {
			if ( preg_match( '/^source-(.+?)-[a-f0-9\-]{36}\.\w+$/', basename( $file ), $m )
				&& ! isset( $expected[ $m[1] ] ) ) {
				wp_delete_file( $file );
			}
		}

		// Excluded categories live in their own option (not nested under
		// mvweb_pi_settings) — they're a separate concern from the import
		// pipeline config and reloading them in the Converter would be a
		// pain if they were buried in the main settings blob.
		// The Categories tab posts an array of external IDs; an absent
		// field means "clear all exclusions".
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce was verified before save_main() was invoked.
		$excluded_raw = isset( $_POST['mvweb_pi_excluded_categories'] ) && is_array( $_POST['mvweb_pi_excluded_categories'] )
			? wp_unslash( $_POST['mvweb_pi_excluded_categories'] )
			: array();
		// phpcs:enable

		// Note: only persist the excluded list when the Categories tab was
		// actually submitted. Otherwise saving on any other tab would wipe
		// the user's exclusion picks. We detect submission by the presence
		// of any hidden marker the tab renders.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see above.
		if ( isset( $_POST['mvweb_pi_categories_submitted'] ) || ! empty( $excluded_raw ) ) {
			$excluded = array();
			foreach ( (array) $excluded_raw as $value ) {
				$id = sanitize_text_field( (string) $value );
				if ( '' !== $id ) {
					$excluded[] = $id;
				}
			}
			$excluded = array_values( array_unique( $excluded ) );
			update_option( 'mvweb_pi_excluded_categories', $excluded, false );

			// Filter mode (exclude blacklist | include whitelist).
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see above.
			$mode = isset( $_POST['mvweb_pi_category_filter_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_pi_category_filter_mode'] ) ) : 'exclude';
			$mode = ( 'include' === $mode ) ? 'include' : 'exclude';
			update_option( 'mvweb_pi_category_filter_mode', $mode, false );

			// Root-flatten list: categories whose own term is skipped while
			// their children are lifted to the top level.
			// phpcs:disable WordPress.Security.NonceVerification.Missing -- see above.
			$flatten_raw = isset( $_POST['mvweb_pi_flatten_roots'] ) && is_array( $_POST['mvweb_pi_flatten_roots'] )
				? wp_unslash( $_POST['mvweb_pi_flatten_roots'] )
				: array();
			// phpcs:enable
			$flatten = array();
			foreach ( (array) $flatten_raw as $value ) {
				$id = sanitize_text_field( (string) $value );
				if ( '' !== $id ) {
					$flatten[] = $id;
				}
			}
			$flatten = array_values( array_unique( $flatten ) );
			update_option( 'mvweb_pi_flatten_roots', $flatten, false );
		}

		// Update cron schedule based on new interval.
		$old_interval = $existing['cron_interval'] ?? 'daily';
		if ( $settings['cron_interval'] !== $old_interval ) {
			wp_clear_scheduled_hook( 'mvweb_pi_cron_import' );
			if ( 'disabled' !== $settings['cron_interval'] ) {
				// Offset the first run by one full interval so the dashboard
				// shows a meaningful "next run" time. wp_schedule_event(time(), …)
				// would put the first occurrence at "now" — the WP-cron tick
				// catches it on the next visit, but the operator UI then
				// reports `Next scheduled import: now`, which looks
				// indistinguishable across hourly/6h/12h/daily and confuses
				// users who expect the interval to be honoured up-front.
				$schedules        = wp_get_schedules();
				$interval_seconds = isset( $schedules[ $settings['cron_interval'] ]['interval'] )
					? (int) $schedules[ $settings['cron_interval'] ]['interval']
					: DAY_IN_SECONDS;
				wp_schedule_event( time() + $interval_seconds, $settings['cron_interval'], 'mvweb_pi_cron_import' );
			}
		}
	}

	/**
	 * Save the MoySklad connection options (MoySklad tab).
	 *
	 * The access token is not among them. It is issued by the Connect button
	 * against a login and password that are never stored and never reach this
	 * method, and it is carried over from the existing option here — a form
	 * field holding a bearer credential would be posted back on every save and
	 * rendered into the page on every load.
	 *
	 * Detected by a hidden marker rather than by the presence of the fields:
	 * every tab lives in the same form, and a select that happens to be absent
	 * must not be read as "the operator cleared it".
	 *
	 * @since 1.1.0
	 * @return void
	 */
	private function save_moysklad(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save() before this runs.
		if ( ! isset( $_POST['mvweb_pi_moysklad_submitted'] ) ) {
			return;
		}

		$raw = isset( $_POST['mvweb_pi_moysklad'] ) && is_array( $_POST['mvweb_pi_moysklad'] )
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized field by field below.
			? wp_unslash( $_POST['mvweb_pi_moysklad'] )
			: array();
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$existing = get_option( 'mvweb_pi_moysklad', array() );
		$existing = is_array( $existing ) ? $existing : array();

		$pick = static function ( string $key, array $allowed, string $default ) use ( $raw ): string {
			$value = isset( $raw[ $key ] ) ? sanitize_key( $raw[ $key ] ) : '';
			return in_array( $value, $allowed, true ) ? $value : $default;
		};

		$settings = array(
			'token'         => (string) ( $existing['token'] ?? '' ),
			'price_types'   => is_array( $existing['price_types'] ?? null ) ? $existing['price_types'] : array(),

			// How many requests fit in three seconds. A plain user token gets
			// 15 today and 11 from December 2026; an application registered
			// with MoySklad as a "solution" gets 45. Guessing high is the one
			// mistake that costs the account an hour of downtime, so the
			// choice is the operator's and the default is the low one.
			'rate_limit'    => max( 1, min( 45, isset( $raw['rate_limit'] ) ? absint( $raw['rate_limit'] ) : MVweb_PI_MoySklad_Client::DEFAULT_RATE ) ),

			'sku_field'     => $pick( 'sku_field', array( 'article', 'code' ), 'article' ),

			// `freeStock` is what is on the shelf less what is already reserved.
			// `quantity` ("available") adds what is still on its way from a
			// supplier on top — measured: five on the shelf and six ordered read
			// as eleven — so it puts goods on sale before they exist. `stock`
			// ignores reservations and sells what MoySklad has promised to
			// somebody else.
			'stock_type'    => $pick( 'stock_type', array( 'quantity', 'stock', 'freeStock' ), 'freeStock' ),

			'images'        => $pick( 'images', array( 'new_only', 'never' ), 'new_only' ),

			// How often stock alone is refreshed between full imports.
			'stock_sync'    => $pick( 'stock_sync', array_keys( MVweb_PI_Stock_Sync::get_interval_choices() ), 'disabled' ),

			// Orders going back the other way.
			'send_orders'   => ! empty( $raw['send_orders'] ),
			'orders_sync'   => $pick( 'orders_sync', array_keys( MVweb_PI_Stock_Sync::get_interval_choices() ), 'mvweb_pi_15min' ),
			'organizations' => is_array( $existing['organizations'] ?? null ) ? $existing['organizations'] : array(),

			// And statuses coming back from there.
			'pull_statuses' => ! empty( $raw['pull_statuses'] ),
			'status_sync'   => $pick( 'status_sync', array_keys( MVweb_PI_Stock_Sync::get_interval_choices() ), 'mvweb_pi_15min' ),
			'lock_status'   => ! empty( $raw['lock_status'] ),
			'order_states'  => is_array( $existing['order_states'] ?? null ) ? $existing['order_states'] : array(),

			// How far back the very first run may reach. Everything after it
			// starts from its own checkpoint, so this only decides how much
			// history is picked up the first time — and therefore how many
			// customers hear about an order they placed a month ago.
			'status_window' => max( 1, min( 365, isset( $raw['status_window'] ) ? absint( $raw['status_window'] ) : 30 ) ),

			// Both read from the account on connecting, never from the form.
			'stores'             => is_array( $existing['stores'] ?? null ) ? $existing['stores'] : array(),
			'product_attributes' => is_array( $existing['product_attributes'] ?? null ) ? $existing['product_attributes'] : array(),
		);

		// Warehouses, statuses, extra fields and organizations are lists read from
		// the account on connecting, and the form carries only the rows that were
		// on the page when it was drawn. A page drawn before a connection posts
		// none of the new rows, and reading that as "every warehouse switched off"
		// wiped the choice. Such a form leaves these choices as they are.
		$stale = ! hash_equals( self::moysklad_lists_hash( $existing ), (string) ( $raw['lists'] ?? '' ) );

		if ( $stale ) {
			foreach ( array( 'stores_excluded', 'stores_counted', 'stores_visible' ) as $key ) {
				$settings[ $key ] = is_array( $existing[ $key ] ?? null ) ? $existing[ $key ] : array();
			}

			if ( isset( $raw['stores_counted'] ) || isset( $raw['status_map'] ) || isset( $raw['attribute_rules'] ) ) {
				$this->queue_notice( __( 'The MoySklad account was re-read after this page was opened, so its warehouses, statuses and extra fields were left as they were. Check them on the MoySklad tab and save again.', 'mvweb-price-importer' ), 'warning' );
			}
		} else {
			$known_stores = array_map( 'strval', array_keys( $settings['stores'] ) );
			$counted      = isset( $raw['stores_counted'] ) && is_array( $raw['stores_counted'] )
				? array_map( 'sanitize_text_field', array_map( 'strval', $raw['stores_counted'] ) )
				: array();
			$shown        = isset( $raw['stores_visible'] ) && is_array( $raw['stores_visible'] )
				? array_map( 'sanitize_text_field', array_map( 'strval', $raw['stores_visible'] ) )
				: array();

			// With every warehouse on, nothing is listed, and a warehouse opened
			// in MoySklad later is counted too. With some switched off, the ones
			// left on are the list — see MVweb_PI_MoySklad_Source::fetch_stock().
			$settings['stores_excluded'] = array_values( array_diff( $known_stores, $counted ) );
			$settings['stores_counted']  = $settings['stores_excluded'] ? array_values( array_intersect( $known_stores, $counted ) ) : array();
			$settings['stores_visible']  = array_values( array_intersect( $known_stores, $shown ) );

			// Counting no warehouse at all is never what anybody means, and it is
			// not harmless: every product would read as zero and the next import
			// would take the whole catalogue off sale.
			if ( ! empty( $known_stores ) && count( $settings['stores_excluded'] ) === count( $known_stores ) ) {
				$settings['stores_excluded'] = is_array( $existing['stores_excluded'] ?? null ) ? $existing['stores_excluded'] : array();
				$settings['stores_counted']  = is_array( $existing['stores_counted'] ?? null ) ? $existing['stores_counted'] : array();
				$this->queue_notice( __( 'At least one warehouse has to be counted in stock. The previous choice of warehouses was kept.', 'mvweb-price-importer' ), 'error' );
			}
		}

		// Which MoySklad state becomes which status here. Kept to states the
		// account reported and statuses this shop has, so neither a renamed
		// state nor a removed status can survive as a rule that silently
		// misfires. `refunded` is refused outright — see
		// MVweb_PI_Orders::FORBIDDEN_STATUS.
		$submitted_map          = isset( $raw['status_map'] ) && is_array( $raw['status_map'] ) ? $raw['status_map'] : array();
		$known_statuses         = array_keys( wc_get_order_statuses() );
		$settings['status_map'] = $stale && is_array( $existing['status_map'] ?? null ) ? $existing['status_map'] : array();
		foreach ( $stale ? array() : array_keys( $settings['order_states'] ) as $state_id ) {
			$status = isset( $submitted_map[ $state_id ] ) ? sanitize_key( (string) $submitted_map[ $state_id ] ) : '';

			if ( '' === $status
				|| MVweb_PI_Orders::FORBIDDEN_STATUS === $status
				|| 'checkout-draft' === $status
				|| ! in_array( 'wc-' . $status, $known_statuses, true )
			) {
				continue;
			}

			$settings['status_map'][ (string) $state_id ] = $status;
		}

		$previous_rules              = is_array( $existing['attribute_rules'] ?? null ) ? $existing['attribute_rules'] : array();
		$settings['attribute_rules'] = $stale ? $previous_rules : $this->attribute_rules(
			isset( $raw['attribute_rules'] ) && is_array( $raw['attribute_rules'] ) ? $raw['attribute_rules'] : array(),
			$settings['product_attributes'],
			$previous_rules
		);

		foreach ( array( 'price_retail', 'price_wholesale', 'price_dealer' ) as $field ) {
			$value = isset( $raw[ $field ] ) ? sanitize_text_field( (string) $raw[ $field ] ) : '';
			// Only ids MoySklad itself reported are accepted, so a stale form
			// cannot point the import at a price type the account dropped.
			$settings[ $field ] = isset( $settings['price_types'][ $value ] ) ? $value : '';
		}

		// Same rule for the organization: only one the account actually reported.
		$organization             = isset( $raw['organization'] ) ? sanitize_text_field( (string) $raw['organization'] ) : '';
		$settings['organization'] = $stale
			? (string) ( $existing['organization'] ?? '' )
			: ( isset( $settings['organizations'][ $organization ] ) ? $organization : '' );

		// Which WooCommerce statuses put an order on its way. Kept to statuses
		// this shop actually has, so a renamed or removed one cannot linger as a
		// trigger nothing will ever match.
		$known                      = array_keys( wc_get_order_statuses() );
		$submitted                  = isset( $raw['order_statuses'] ) && is_array( $raw['order_statuses'] )
			? array_map( 'sanitize_key', $raw['order_statuses'] )
			: array();
		$settings['order_statuses'] = array_values(
			array_filter(
				$submitted,
				static function ( $status ) use ( $known ) {
					return in_array( 'wc-' . $status, $known, true );
				}
			)
		);

		update_option( 'mvweb_pi_moysklad', $settings, false );

		// The dump on disk was built with the previous prices, articles and
		// stock reading. Keeping it would mean the next run imports yesterday's
		// interpretation of today's catalogue.
		if ( $this->moysklad_shape_changed( $existing, $settings ) ) {
			MVweb_PI_MoySklad_Source::drop_dump();
		}

		// Rescheduled when the interval changed, and also when the event is
		// missing while an interval is set — a restored database or a cron table
		// cleared by another plugin gets it back by saving the tab, rather than
		// having to pick a different interval and then pick the right one again.
		//
		// Not on every save: every tab posts this one form, so an unconditional
		// reschedule would push the next run a full interval away each time
		// anything on the settings screen is saved.
		$was = (string) ( $existing['stock_sync'] ?? 'disabled' );
		if ( $was !== $settings['stock_sync'] || false === MVweb_PI_Stock_Sync::get_schedule() ) {
			MVweb_PI_Stock_Sync::schedule( (string) $settings['stock_sync'] );
		}

		// Same reasoning for the order queue, plus one more trigger: switching
		// the sending on or off decides whether the schedule should exist at all.
		$orders_was = (string) ( $existing['orders_sync'] ?? '' );
		if ( $orders_was !== $settings['orders_sync']
			|| ! empty( $existing['send_orders'] ) !== ! empty( $settings['send_orders'] )
			|| false === wp_get_scheduled_event( MVweb_PI_Orders::HOOK )
		) {
			MVweb_PI_Orders::schedule( (string) $settings['orders_sync'] );
		}

		// And the same again for reading states back.
		$status_was = (string) ( $existing['status_sync'] ?? '' );
		if ( $status_was !== $settings['status_sync']
			|| ! empty( $existing['pull_statuses'] ) !== ! empty( $settings['pull_statuses'] )
			|| false === wp_get_scheduled_event( MVweb_PI_Orders::STATUS_HOOK )
		) {
			MVweb_PI_Orders::schedule_status_sync( (string) $settings['status_sync'] );
		}

		// Switching the reading on starts a fresh count. The checkpoint left
		// over from an earlier spell could be months old, and the run that
		// found it would walk every document changed since — mailing customers
		// about orders they have long forgotten. The window setting decides how
		// far the first run reaches instead.
		if ( ! empty( $settings['pull_statuses'] ) && empty( $existing['pull_statuses'] ) ) {
			delete_option( MVweb_PI_Orders::STATUS_SINCE_OPTION );
		}
	}

	/**
	 * What to do with each of the account's product fields.
	 *
	 * Only fields the account reported, and only the use that suits the kind of
	 * field: a flag becomes a tag, a string, a number or a reference becomes an
	 * attribute. Anything else in the form is dropped rather than trusted.
	 *
	 * An attribute is created in WooCommerce here, at the moment it is chosen,
	 * not during the import: creating it needs the attribute taxonomy registered,
	 * which WordPress does once per request on `init` — too late for an import
	 * already running. Chosen again later, the same attribute is reused.
	 *
	 * @since 1.3.0
	 * @param array $submitted Field id => {as, label}, from the form.
	 * @param array $fields    Field id => {name, type}, as the account reported.
	 * @param array $previous  Rules as they were before this save.
	 * @return array<string, array> Field id => rule.
	 */
	private function attribute_rules( array $submitted, array $fields, array $previous ): array {
		$rules = array();

		foreach ( $fields as $field_id => $field ) {
			$field_id = (string) $field_id;
			$choice   = is_array( $submitted[ $field_id ] ?? null ) ? $submitted[ $field_id ] : array();
			$as       = sanitize_key( (string) ( $choice['as'] ?? '' ) );
			$type     = (string) ( $field['type'] ?? '' );
			$name     = (string) ( $field['name'] ?? '' );

			if ( 'tag' === $as && 'boolean' === $type ) {
				$label              = sanitize_text_field( (string) ( $choice['label'] ?? '' ) );
				$rules[ $field_id ] = array(
					'as'    => 'tag',
					'label' => '' !== $label ? $label : $name,
				);
				continue;
			}

			if ( 'attribute' === $as && in_array( $type, array( 'string', 'long', 'double', 'reference' ), true ) ) {
				$taxonomy = $this->ensure_wc_attribute( $name, (string) ( $previous[ $field_id ]['taxonomy'] ?? '' ) );
				if ( '' === $taxonomy ) {
					continue;
				}
				$rules[ $field_id ] = array(
					'as'       => 'attribute',
					'taxonomy' => $taxonomy,
				);
			}
		}

		return $rules;
	}

	/**
	 * Find or create the WooCommerce attribute a MoySklad field fills.
	 *
	 * In this order: the attribute the field already filled, if it still exists;
	 * an attribute the shop already has under the same name — a shop with a
	 * "Brand" attribute of its own wants that one filled, not a second beside
	 * it; a new one. The new one gets a transliterated slug, since the slug is
	 * what appears in the storefront's filter links.
	 *
	 * @since 1.3.0
	 * @param string $label    Attribute name.
	 * @param string $previous Taxonomy the field filled before, or ''.
	 * @return string Attribute taxonomy (`pa_…`), or '' when none could be had.
	 */
	private function ensure_wc_attribute( string $label, string $previous ): string {
		if ( ! function_exists( 'wc_create_attribute' ) ) {
			return '';
		}

		$taxonomy = mvweb_pi_wc_attribute( $label, $previous );
		if ( '' !== $taxonomy ) {
			return $taxonomy;
		}

		$this->queue_notice(
			sprintf(
				/* translators: %s: attribute name */
				__( 'The attribute "%s" could not be created in WooCommerce, so that field is not imported. Create an attribute with this name under Products → Attributes and save this tab again.', 'mvweb-price-importer' ),
				$label
			),
			'error'
		);

		return '';
	}

	/**
	 * Do these two MoySklad settings produce a different catalogue?
	 *
	 * @since 1.1.0
	 * @param array $before Settings before the save.
	 * @param array $after  Settings after the save.
	 * @return bool
	 */
	private function moysklad_shape_changed( array $before, array $after ): bool {
		foreach ( array( 'price_retail', 'price_wholesale', 'price_dealer', 'sku_field', 'stock_type', 'stores_excluded', 'stores_counted', 'attribute_rules' ) as $key ) {
			// Empty and absent are the same choice: an option saved before a key
			// existed must not throw the dump away on its first save.
			$was = empty( $before[ $key ] ) ? null : $before[ $key ];
			$now = empty( $after[ $key ] ) ? null : $after[ $key ];
			if ( $was !== $now ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Fingerprint of the lists read from the MoySklad account.
	 *
	 * Printed into the MoySklad tab and compared on save, so a form drawn
	 * before the account was re-read is recognised as not knowing its rows.
	 *
	 * @since 1.3.1
	 * @param array $ms MoySklad settings.
	 * @return string
	 */
	public static function moysklad_lists_hash( array $ms ): string {
		$lists = array();
		foreach ( array( 'stores', 'order_states', 'product_attributes', 'organizations' ) as $key ) {
			$lists[ $key ] = array_map( 'strval', array_keys( is_array( $ms[ $key ] ?? null ) ? $ms[ $key ] : array() ) );
		}

		return md5( (string) wp_json_encode( $lists ) );
	}

	/**
	 * Switch the site between data sources (Main tab).
	 *
	 * Not a setting but a migration, and it is treated like one. The plugin
	 * assumes throughout that one source describes the whole managed catalogue:
	 * the category map keys WooCommerce terms by that source's external ids, the
	 * tree sidecar mirrors its hierarchy, the category filter ticks its ids, and
	 * the stock-out pass zeroes every managed product the feed no longer carries.
	 * Point the plugin at a different source without clearing that state and the
	 * first run reads ids it has never seen — categories re-created next to their
	 * twins, and in include mode not a single product passing the filter.
	 *
	 * Reached only from its own button, never from "Save changes": an operator
	 * adjusting the batch size must not be able to migrate a catalogue by
	 * pressing the same key. Refused outright while an import is running,
	 * because the state being cleared is what that import is working from.
	 *
	 * Before anything is cleared it takes a snapshot of the outgoing catalogue —
	 * that is the only moment it can. A second later the category map is gone and
	 * nothing tells the old supplier's products from ones somebody added by hand.
	 * See MVweb_PI_Retire.
	 *
	 * Lives in its own option: mvweb_pi_settings is rebuilt from scratch on
	 * every save and would drop a key its whitelist does not know.
	 *
	 * @since 1.1.0
	 * @since 1.1.0 Own button; snapshots the outgoing catalogue.
	 * @return void
	 */
	private function save_source_mode(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save() before this runs.
		if ( ! isset( $_POST['mvweb_pi_source_mode'] ) ) {
			return;
		}

		$submitted = sanitize_key( wp_unslash( $_POST['mvweb_pi_source_mode'] ) );

		// What to do with the catalogue being left behind. `retire` takes it off
		// the shelf once the new source has proved it works; `keep` leaves both
		// catalogues on the storefront, which is what the plugin used to do
		// unconditionally and what produced 1000 products becoming 1699.
		$fate = isset( $_POST['mvweb_pi_old_catalogue'] )
			? sanitize_key( wp_unslash( $_POST['mvweb_pi_old_catalogue'] ) )
			: 'retire';
		$fate = in_array( $fate, array( 'retire', 'keep' ), true ) ? $fate : 'retire';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$modes = mvweb_pi_source_modes();
		if ( ! isset( $modes[ $submitted ] ) ) {
			return;
		}

		$current = mvweb_pi_source_mode();
		if ( $submitted === $current ) {
			$this->queue_notice(
				__( 'That is already this site\'s data source, so nothing was changed.', 'mvweb-price-importer' ),
				'warning'
			);
			return;
		}

		if ( MVweb_PI_Cron::is_locked() ) {
			$this->queue_notice(
				__( 'The data source was left as it was: an import is running right now, and it is working from the very mapping the switch would clear. Try again once it has finished.', 'mvweb-price-importer' ),
				'error'
			);
			return;
		}

		// Taken while the category map still stands — see the note above.
		$survey = MVweb_PI_Retire::capture( $current, $submitted, $fate );

		update_option( 'mvweb_pi_source_mode', $submitted, false );
		mvweb_pi_reset_source_state();

		// Orders still waiting to go to MoySklad. The queue is a promise made to
		// one account and does not survive the site being pointed elsewhere —
		// see MVweb_PI_Orders::abandon_queue().
		$abandoned = MVweb_PI_Orders::abandon_queue();
		if ( $abandoned > 0 ) {
			$this->queue_notice(
				sprintf(
					/* translators: %d: number of orders */
					_n(
						'%d order was waiting to be sent to MoySklad and has been taken out of the queue — it was not sent.',
						'%d orders were waiting to be sent to MoySklad and have been taken out of the queue — they were not sent.',
						$abandoned,
						'mvweb-price-importer'
					),
					$abandoned
				),
				'warning'
			);
		}

		// The stock sync and the order queue only exist for MoySklad, so the
		// switch takes their schedules down or puts them back. Done here rather
		// than in save_moysklad() because that runs first, while the mode is
		// still the old one.
		$ms = get_option( 'mvweb_pi_moysklad', array() );
		$ms = is_array( $ms ) ? $ms : array();
		MVweb_PI_Stock_Sync::schedule( (string) ( $ms['stock_sync'] ?? 'disabled' ) );
		MVweb_PI_Orders::schedule( (string) ( $ms['orders_sync'] ?? 'disabled' ) );
		MVweb_PI_Orders::schedule_status_sync( (string) ( $ms['status_sync'] ?? 'disabled' ) );

		// The status checkpoint describes a spell of watching MoySklad that has
		// just ended. Left behind, the first run after the site comes back
		// would read it as "carry on from here" and mail every customer whose
		// order moved while nobody was watching. Cleared, that run is a first
		// one again: bounded by the window and silent.
		delete_option( MVweb_PI_Orders::STATUS_SINCE_OPTION );

		$this->queue_notice(
			sprintf(
				/* translators: %s: name of the data source now in use */
				__( 'The data source is now "%s". The category mapping, the supplier tree, the category filter, the article snapshot and the statistics have been cleared — the next import builds them again.', 'mvweb-price-importer' ),
				$modes[ $submitted ]
			),
			'updated'
		);

		// What happens to the catalogue that is being left behind, said plainly
		// and now rather than discovered on the storefront later.
		if ( 'retire' === $fate && ! empty( $survey['ids'] ) ) {
			$this->queue_notice(
				sprintf(
					/* translators: 1: products of the previous source, 2: how many of them are in open orders */
					__( 'The previous supplier left %1$d products in the catalogue. They stay on the storefront until the first successful import of the new source, and are then taken off the shelf — except %2$d that appear in open orders, which stay reachable by their address so those orders keep working. Anything the new source carries under the same article is kept. This can be undone from the Main tab.', 'mvweb-price-importer' ),
					count( $survey['ids'] ),
					count( $survey['in_orders'] )
				),
				'warning'
			);
		} elseif ( ! empty( $survey['ids'] ) ) {
			$this->queue_notice(
				sprintf(
					/* translators: %d: products of the previous source */
					__( '%d products of the previous supplier stay in the catalogue, as asked. Until they are dealt with, the storefront shows both assortments at once.', 'mvweb-price-importer' ),
					count( $survey['ids'] )
				),
				'warning'
			);
		}

		if ( ! empty( $survey['manual'] ) ) {
			$this->queue_notice(
				sprintf(
					/* translators: %d: products added by hand */
					__( '%d products in those categories were added by hand rather than imported. They are never touched.', 'mvweb-price-importer' ),
					(int) $survey['manual']
				),
				'updated'
			);
		}

		mvweb_pi_log(
			sprintf(
				/* translators: 1: previous data source, 2: new data source */
				__( 'Data source switched from "%1$s" to "%2$s". Category mapping, feed tree, category filter, known articles, checkpoint and statistics were cleared.', 'mvweb-price-importer' ),
				$modes[ $current ],
				$modes[ $submitted ]
			),
			'warning'
		);
	}

	/**
	 * Save feed settings (Feeds tab).
	 *
	 * Sanitizes company name, currency, and auto-generate toggle.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	private function save_feeds(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
		if ( isset( $_POST['mvweb_pi_feeds_company'] ) ) {
			update_option(
				MVweb_PI_Feeds::OPTION_COMPANY,
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
				sanitize_text_field( wp_unslash( $_POST['mvweb_pi_feeds_company'] ) )
			);
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
		if ( isset( $_POST['mvweb_pi_feeds_currency'] ) ) {
			$allowed_currencies = array( 'RUR', 'USD', 'EUR' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
			$currency_val       = sanitize_text_field( wp_unslash( $_POST['mvweb_pi_feeds_currency'] ) );
			if ( in_array( $currency_val, $allowed_currencies, true ) ) {
				update_option( MVweb_PI_Feeds::OPTION_CURRENCY, $currency_val );
			}
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
		if ( isset( $_POST['mvweb_pi_feeds_slug'] ) ) {
			update_option(
				MVweb_PI_Feeds::OPTION_SLUG,
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
				MVweb_PI_Feeds::sanitize_slug( (string) wp_unslash( $_POST['mvweb_pi_feeds_slug'] ) )
			);
		}

		update_option(
			MVweb_PI_Feeds::OPTION_AUTO_GENERATE,
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
			isset( $_POST['mvweb_pi_feeds_auto_generate'] ) ? '1' : '0'
		);

		// Feed category filter — WooCommerce product_cat term ids (numeric),
		// stored in their own option, fully separate from the parser's
		// source-category filter (`mvweb_pi_excluded_categories`, string ids).
		// Only persist when the Feed Categories block was actually submitted,
		// so saving another tab does not wipe the picks. An empty list means
		// "no filter" — the feed exports every category (backward compatible).
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
		$feed_cats_raw = isset( $_POST['mvweb_pi_feed_excluded_categories'] ) && is_array( $_POST['mvweb_pi_feed_excluded_categories'] )
			? wp_unslash( $_POST['mvweb_pi_feed_excluded_categories'] )
			: array();

		if ( isset( $_POST['mvweb_pi_feed_categories_submitted'] ) || ! empty( $feed_cats_raw ) ) {
			$feed_cats = array();
			foreach ( (array) $feed_cats_raw as $value ) {
				$term_id = absint( $value );
				if ( $term_id > 0 ) {
					$feed_cats[] = $term_id;
				}
			}
			$feed_cats = array_values( array_unique( $feed_cats ) );
			update_option( MVweb_PI_Feeds::OPTION_FEED_EXCLUDED_CATEGORIES, $feed_cats, false );

			$feed_mode = isset( $_POST['mvweb_pi_feed_category_filter_mode'] )
				? sanitize_text_field( wp_unslash( $_POST['mvweb_pi_feed_category_filter_mode'] ) )
				: 'exclude';
			$feed_mode = ( 'include' === $feed_mode ) ? 'include' : 'exclude';
			update_option( MVweb_PI_Feeds::OPTION_FEED_CATEGORY_FILTER_MODE, $feed_mode, false );
		}
		// phpcs:enable
	}

	/**
	 * Save mapping settings (Mapping tab).
	 *
	 * Sanitizes field-to-column mapping and preserves stored headers.
	 *
	 * @since 1.1.0
	 * @param array $raw Raw POST data for mvweb_pi_mapping.
	 * @return void
	 */
	private function save_mapping( array $raw ): void {
		$mapping = array();
		$allowed = array( 'sku', 'name', 'description', 'price', 'sale_price', 'wholesale_price', 'dealer_price', 'stock', 'image', 'gallery', 'category', 'parent_cat', 'barcode' );

		foreach ( $allowed as $field ) {
			$mapping[ $field ] = isset( $raw[ $field ] ) ? sanitize_text_field( $raw[ $field ] ) : '';
		}

		// Preserve stored headers for dropdown repopulation.
		$existing_mapping    = get_option( 'mvweb_pi_mapping', array() );
		$mapping['_headers'] = $existing_mapping['_headers'] ?? array();

		update_option( 'mvweb_pi_mapping', $mapping );
	}

	/**
	 * Save product tag rules (Mapping tab).
	 *
	 * A rule turns a price-list column into a WooCommerce product tag:
	 * "column X holds Y" => tag Z. Stored in its own option rather than inside
	 * mvweb_pi_mapping, whose whitelist in save_mapping() would strip anything
	 * it does not know.
	 *
	 * Submission is detected by the hidden marker, not by the presence of the
	 * rules array: deleting the last rule posts no array at all, and without
	 * the marker that would be indistinguishable from "the tab was never
	 * rendered" — saving from another tab would then resurrect deleted rules.
	 * Mirrors the excluded-categories marker in save_main().
	 *
	 * @since 1.0.27
	 * @return void
	 */
	private function save_tag_rules(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save() before this runs.
		if ( ! isset( $_POST['mvweb_pi_tag_rules_submitted'] ) ) {
			return;
		}

		$raw = isset( $_POST['mvweb_pi_tag_rules'] ) && is_array( $_POST['mvweb_pi_tag_rules'] )
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized field-by-field below.
			? wp_unslash( $_POST['mvweb_pi_tag_rules'] )
			: array();
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$rules    = array();
		$labels   = array();
		$keys     = array();
		$warnings = array();

		foreach ( $raw as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$source = sanitize_text_field( $row['source'] ?? '' );
			$label  = sanitize_text_field( $row['label'] ?? '' );

			// A rule without a source column or without a tag name can't do
			// anything — drop it silently, exactly as an empty warehouse row
			// is dropped in save_main().
			if ( '' === $source || '' === $label ) {
				continue;
			}

			// Two rules pointing at the same tag would fight over one term:
			// each import would rewrite the term's owner key and the loser
			// would recreate its own term on the next run. Keep the first.
			$label_key = mb_strtolower( $label, 'UTF-8' );
			if ( isset( $labels[ $label_key ] ) ) {
				$warnings[] = sprintf(
					/* translators: 1: source column name, 2: tag name */
					__( 'Rule for column "%1$s" was skipped: another rule already assigns the tag "%2$s".', 'mvweb-price-importer' ),
					$source,
					$label
				);
				continue;
			}
			$labels[ $label_key ] = true;

			// The key is what ties a rule to its term, so it must survive
			// edits to the source column, the tag name and the match list.
			// A blank key means a brand-new row; a duplicate means the browser
			// cloned an existing row, and cloning must not clone ownership.
			$key = sanitize_key( $row['key'] ?? '' );
			if ( '' === $key || isset( $keys[ $key ] ) ) {
				$key = 'tag' . substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 10 );
			}
			$keys[ $key ] = true;

			$rules[] = array(
				'key'    => $key,
				'source' => $source,
				'match'  => sanitize_text_field( $row['match'] ?? '' ),
				'label'  => $label,
			);
		}

		update_option( 'mvweb_pi_tag_rules', $rules, false );

		// A tag the shop owner created by hand can carry the same name as a
		// rule. The importer will adopt that term, and from then on it also
		// removes it from products whose price-list row says otherwise — so
		// say it out loud before the first import does it silently.
		foreach ( $rules as $rule ) {
			$term = get_term_by( 'name', $rule['label'], 'product_tag' );
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}
			if ( '' !== (string) get_term_meta( $term->term_id, 'mvweb_pi_tag_key', true ) ) {
				continue;
			}
			$warnings[] = sprintf(
				/* translators: %s: tag name */
				__( 'The tag "%s" already exists and was not created by the importer. From now on this rule manages it — including removing it from products when the price list no longer marks them.', 'mvweb-price-importer' ),
				$rule['label']
			);
		}

		foreach ( $warnings as $warning ) {
			$this->queue_notice( (string) $warning, 'warning' );
		}
	}
}
