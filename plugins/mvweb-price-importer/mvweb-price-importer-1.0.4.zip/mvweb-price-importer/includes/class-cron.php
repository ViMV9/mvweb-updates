<?php
/**
 * Cron class — scheduled import management.
 *
 * Manages wp-cron integration, import scheduling,
 * atomic lock mechanism, and the full import cycle.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Cron
 *
 * Handles automatic import scheduling via wp-cron, CLI, and REST triggers.
 * Uses atomic lock mechanism to prevent parallel imports.
 *
 * @since 1.0.0
 */
class MVweb_PI_Cron {

	/**
	 * Cron hook name.
	 *
	 * @var string
	 */
	const HOOK = 'mvweb_pi_cron_import';

	/**
	 * Lock option name.
	 *
	 * @var string
	 */
	const LOCK_OPTION = 'mvweb_pi_cron_lock';

	/**
	 * Lock TTL in seconds (30 minutes).
	 *
	 * @var int
	 */
	const LOCK_TTL = 1800;

	/**
	 * Wall-clock budget (seconds) for a single non-CLI run.
	 *
	 * Web/AJAX/wp-cron invocations honour this budget by stopping after the
	 * current batch and scheduling a continuation via wp_schedule_single_event.
	 * CLI runs (cron-runner.php, real system cron) ignore it — they have no
	 * max_execution_time worth respecting.
	 *
	 * 50 s leaves headroom under the typical 60 s PHP-FPM / FastCGI cap.
	 *
	 * @var int
	 */
	const WALL_CLOCK_BUDGET = 50;

	/**
	 * Hook name for scheduling a continuation batch.
	 *
	 * Separate from {@see HOOK} so wp_clear_scheduled_hook() on the regular
	 * recurring schedule never accidentally cancels an in-flight continuation.
	 *
	 * @var string
	 */
	const CONTINUE_HOOK = 'mvweb_pi_continue_import';

	/**
	 * Run the full import cycle.
	 *
	 * This method is called by wp-cron, CLI runner, and REST endpoint.
	 * It acquires a lock, downloads sources, converts data,
	 * imports categories and products, then releases the lock.
	 *
	 * @since 1.0.0
	 * @return array{status: string, stats?: array, message: string} Import result.
	 */
	public function run(): array {
		mvweb_pi_log(
			sprintf( 'Import started (sapi=%s).', php_sapi_name() ),
			'debug'
		);

		// Self-heal: if invoked from CLI (system cron or cron-runner.php),
		// proactively clear a stale lock that a previous fatal-aborted run
		// may have left behind. CLI invocations are by definition serial —
		// no concurrent CLI runner can be racing us — so this is safe.
		if ( 'cli' === php_sapi_name() ) {
			delete_option( self::LOCK_OPTION );
			mvweb_pi_log( 'CLI self-heal: lock pre-cleared.', 'debug' );
		}

		// 1. Acquire lock (atomic).
		if ( ! $this->acquire_lock() ) {
			return array(
				'status'  => 'locked',
				'message' => __( 'Import is already running.', 'mvweb-price-importer' ),
			);
		}

		// Belt-and-braces: register a shutdown handler so the lock is
		// released even when a fatal (max_execution_time, OOM, Imagick crash)
		// aborts execution before reaching the finally block below.
		// PHP fatal handlers run after the error, so this is the only way
		// to guarantee lock release short of waiting for the TTL window.
		register_shutdown_function( static function () {
			$err = error_get_last();
			if ( $err && in_array( $err['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR ), true ) ) {
				delete_option( self::LOCK_OPTION );
				if ( function_exists( 'mvweb_pi_log' ) ) {
					mvweb_pi_log(
						sprintf( 'Lock released by shutdown handler after fatal: %s', $err['message'] ?? 'unknown' ),
						'error'
					);
				}
			}
		} );

		// Lift execution-time cap for the importer. CLI usually runs with
		// max_execution_time=0 already; for web/AJAX/cron contexts where
		// the host enforces a wall clock, we want as much headroom as the
		// hosting will give us. Image processing (Imagick resize) on large
		// catalogs blew through the previous hard limit of 600s.
		if ( function_exists( 'set_time_limit' ) ) {
			set_time_limit( 0 );
		}

		try {
			// Check for interrupted import (checkpoint/resume, v1.1).
			$skip_count  = 0;
			$resume_skus = array();
			$progress    = get_option( MVweb_PI_Importer::PROGRESS_OPTION );

			if ( is_array( $progress ) && ! empty( $progress['started_at'] ) ) {
				$age = time() - strtotime( $progress['started_at'] );
				if ( $age < MVweb_PI_Importer::PROGRESS_TTL ) {
					// Recent interrupted import — resume from checkpoint.
					$skip_count  = $progress['processed'] ?? 0;
					$resume_skus = $progress['new_skus'] ?? array();
					mvweb_pi_log(
						sprintf(
							/* translators: %d: number of already-processed products */
							__( 'Resuming interrupted import, skipping %d already-processed products.', 'mvweb-price-importer' ),
							$skip_count
						),
						'info'
					);
				} else {
					// Stale progress record — discard and start fresh.
					delete_option( MVweb_PI_Importer::PROGRESS_OPTION );
				}
			}

			$settings   = get_option( 'mvweb_pi_settings', array() );
			$warehouses = $settings['warehouses'] ?? array();
			$source_url = $settings['source_url'] ?? '';

			// Build sources list.
			$sources = $this->build_sources( $warehouses, $source_url );

			if ( empty( $sources ) ) {
				return array(
					'status'  => 'error',
					'message' => __( 'No source URLs configured.', 'mvweb-price-importer' ),
				);
			}

			// 2–3. Download sources (with ETag check per warehouse).
			$loader      = new MVweb_PI_Loader();
			$upload_dir  = mvweb_pi_get_upload_dir();
			$downloaded  = array();
			$all_skipped = true;

			foreach ( $sources as $source ) {
				$url = $loader->convert_google_sheets_url( $source['url'] );

				// ETag check — skip unchanged files (TZ 2.6).
				$changed = $loader->check_etag( $url, $source['id'] );
				if ( ! $changed ) {
					// Try to use previously downloaded file.
					$existing = glob( $upload_dir . 'source-' . $source['id'] . '-*' );
					if ( ! empty( $existing ) ) {
						$downloaded[ $source['id'] ] = end( $existing );
					}
					continue;
				}

				$all_skipped = false;

				// Clean up old source files for this warehouse.
				$old_files = glob( $upload_dir . 'source-' . $source['id'] . '-*' );
				if ( $old_files ) {
					foreach ( $old_files as $old_file ) {
						wp_delete_file( $old_file );
					}
				}

				// Download.
				do_action( 'mvweb_pi_before_download', $source['id'], $url );

				$format = $loader->detect_format( $url );
				$ext    = ( 'yml' === $format ) ? 'yml' : $format;
				$uuid   = wp_generate_uuid4();
				$dest   = $upload_dir . "source-{$source['id']}-{$uuid}.{$ext}";

				$download_result = $loader->download( $url, $dest );

				if ( is_wp_error( $download_result ) ) {
					mvweb_pi_log(
						sprintf(
							/* translators: 1: warehouse ID, 2: error message */
							__( 'Download failed for warehouse %1$s: %2$s', 'mvweb-price-importer' ),
							$source['id'],
							$download_result->get_error_message()
						),
						'error'
					);
					continue;
				}

				do_action( 'mvweb_pi_after_download', $source['id'], $dest );
				$downloaded[ $source['id'] ] = $dest;
			}

			// If all files unchanged and no downloaded files exist, skip import.
			if ( $all_skipped && empty( $downloaded ) ) {
				mvweb_pi_log( __( 'All sources unchanged. Import skipped.', 'mvweb-price-importer' ), 'info' );
				return array(
					'status'  => 'skipped',
					'message' => __( 'All sources unchanged. Import skipped.', 'mvweb-price-importer' ),
				);
			}

			if ( empty( $downloaded ) ) {
				return array(
					'status'  => 'error',
					'message' => __( 'No source files available for import.', 'mvweb-price-importer' ),
				);
			}

			// 4. Check mapping.
			$mapping  = get_option( 'mvweb_pi_mapping', array() );
			$required = array( 'sku', 'name', 'price', 'stock' );
			$missing  = array();
			foreach ( $required as $field ) {
				if ( empty( $mapping[ $field ] ) ) {
					$missing[] = $field;
				}
			}

			if ( ! empty( $missing ) ) {
				return array(
					'status'  => 'error',
					'message' => sprintf(
						/* translators: %s: comma-separated list of field names */
						__( 'Required fields not mapped: %s.', 'mvweb-price-importer' ),
						implode( ', ', $missing )
					),
				);
			}

			// 4. Convert to unified format.
			$converter = new MVweb_PI_Converter();
			$is_multi  = count( $downloaded ) > 1;

			// Pass 1: Extract categories (lightweight, no full normalization).
			$categories_data    = $converter->categories_only( $downloaded, $mapping );
			$categories_handler = new MVweb_PI_Categories();
			$categories_handler->import( $categories_data );

			// Pass 2: Stream products directly into importer (no buffering).
			if ( $is_multi ) {
				$products = $converter->merge_warehouses( $downloaded, $mapping );
			} else {
				$products = $converter->convert( $downloaded, $mapping );
			}

			// 6. Import products into WooCommerce (with checkpoint/resume support).
			// CLI gets unlimited wall-clock; web/AJAX/wp-cron get a budget
			// and schedule a continuation when it expires.
			$deadline_ts = 'cli' === php_sapi_name() ? 0 : ( time() + self::WALL_CLOCK_BUDGET );

			$importer = new MVweb_PI_Importer();
			$stats    = $importer->run( $products, $skip_count, $resume_skus, $deadline_ts );

			// Importer bailed early because the wall-clock budget expired.
			// Progress is already persisted in mvweb_pi_import_progress; we
			// schedule a continuation 5 s out so the next PHP worker picks
			// up where we left off. The lock is released by `finally` below
			// — acquire_lock() on the next run will succeed because the
			// option is gone.
			if ( ! empty( $stats['incomplete'] ) ) {
				if ( ! wp_next_scheduled( self::CONTINUE_HOOK ) ) {
					wp_schedule_single_event( time() + 5, self::CONTINUE_HOOK );
				}
				mvweb_pi_log(
					sprintf(
						/* translators: %d: number of products processed in this slice */
						__( 'Import slice complete (%d products this run). Continuation scheduled.', 'mvweb-price-importer' ),
						$stats['processed'] ?? 0
					),
					'info'
				);

				return array(
					'status'  => 'continuing',
					'stats'   => $stats,
					'message' => __( 'Import in progress; next slice scheduled.', 'mvweb-price-importer' ),
				);
			}

			// 7. Save stats and log results.
			// Format last_run as a human-readable mysql timestamp (matches
			// class-importer's direct save) so the dashboard does not have
			// to render a unix timestamp.
			$result_stats = array_merge(
				$stats,
				array( 'last_run' => current_time( 'mysql' ) )
			);
			update_option( 'mvweb_pi_import_stats', $result_stats, false );

			mvweb_pi_log(
				sprintf(
					'Import stats persisted: %s.',
					wp_json_encode( array_intersect_key( $result_stats, array_flip( array( 'created', 'updated', 'skipped', 'errors', 'total' ) ) ) )
				),
				'debug'
			);

			mvweb_pi_log(
				sprintf(
					/* translators: 1: created count, 2: updated count, 3: skipped count, 4: error count */
					__( 'Import complete: %1$d created, %2$d updated, %3$d skipped, %4$d errors.', 'mvweb-price-importer' ),
					$stats['created'],
					$stats['updated'],
					$stats['skipped'],
					$stats['errors']
				),
				'info'
			);

			// 8. Generate feeds after import if enabled (TZ 9.4).
			$auto_generate = get_option( MVweb_PI_Feeds::OPTION_AUTO_GENERATE, '1' );
			if ( '1' === $auto_generate ) {
				try {
					$feeds_handler  = new MVweb_PI_Feeds();
					$feeds_results  = $feeds_handler->generate_all();
					$feeds_count    = count( $feeds_results );
					mvweb_pi_log(
						sprintf(
							/* translators: %d: number of feeds generated */
							__( 'Auto-generated %d feed(s) after import.', 'mvweb-price-importer' ),
							$feeds_count
						),
						'info'
					);
				} catch ( \Exception $e ) {
					mvweb_pi_log(
						sprintf(
							/* translators: %s: error message */
							__( 'Feed generation failed: %s', 'mvweb-price-importer' ),
							$e->getMessage()
						),
						'error'
					);
				}
			}

			// 9. Email notification on errors (TZ 10.4).
			if ( $stats['errors'] > 0 ) {
				$this->send_error_email( $stats );
			}

			return array(
				'status'  => 'completed',
				'stats'   => $stats,
				'message' => __( 'Import complete.', 'mvweb-price-importer' ),
			);

		} catch ( \Exception $e ) {
			mvweb_pi_log(
				sprintf(
					/* translators: %s: error message */
					__( 'Import failed: %s', 'mvweb-price-importer' ),
					$e->getMessage()
				),
				'error'
			);

			$this->send_error_email(
				array(
					'errors'  => 1,
					'created' => 0,
					'updated' => 0,
					'message' => $e->getMessage(),
				)
			);

			return array(
				'status'  => 'error',
				'message' => $e->getMessage(),
			);

		} finally {
			$this->release_lock();
		}
	}

	/**
	 * Build sources list from settings.
	 *
	 * @since 1.0.0
	 * @param array  $warehouses Array of warehouse settings.
	 * @param string $source_url Single source URL (non-multiwarehouse mode).
	 * @return array Array of source items with 'id' and 'url' keys.
	 */
	private function build_sources( array $warehouses, string $source_url ): array {
		$sources = array();

		if ( ! empty( $warehouses ) ) {
			foreach ( $warehouses as $wh ) {
				if ( ! empty( $wh['url'] ) ) {
					$sources[] = array(
						'id'  => $wh['id'] ?? sanitize_title( $wh['name'] ?? '' ),
						'url' => $wh['url'],
					);
				}
			}
		} elseif ( ! empty( $source_url ) ) {
			$sources[] = array(
				'id'  => 'default',
				'url' => $source_url,
			);
		}

		return $sources;
	}

	/**
	 * Acquire import lock atomically.
	 *
	 * Strategy borrowed from the previous-generation importer (which
	 * survived production use without lock pile-ups): use add_option()
	 * — implemented as `INSERT ... ON DUPLICATE KEY UPDATE` at MySQL
	 * level — to guarantee mutual exclusion on the very first attempt.
	 * If the row already exists, fall back to a TTL check on its value
	 * and forcibly steal the lock once it crosses the staleness window.
	 *
	 * Why not UPDATE-with-WHERE: it requires the row to exist, and the
	 * stale-recovery path needs a separate query, which reopens a race
	 * window. add_option is single-shot atomic and matches what the
	 * legacy plugin used in production.
	 *
	 * @since 1.0.0
	 * @return bool True if lock acquired, false if another import is running.
	 */
	public function acquire_lock(): bool {
		$now = time();

		// Atomic CAS: succeeds only if the option row didn't exist yet.
		// MySQL upholds uniqueness on option_name, so concurrent callers
		// cannot both win this race.
		$acquired = add_option( self::LOCK_OPTION, (string) $now, '', 'no' );
		if ( $acquired ) {
			mvweb_pi_log( 'Lock acquired (fresh).', 'debug' );
			return true;
		}

		// Row already there — inspect for staleness.
		$current = (int) get_option( self::LOCK_OPTION, 0 );

		// Zero/empty means a previous run released cleanly but the option
		// row was kept. Steal it.
		if ( 0 === $current ) {
			update_option( self::LOCK_OPTION, (string) $now, false );
			mvweb_pi_log( 'Lock acquired (reused empty row).', 'debug' );
			return true;
		}

		// Past TTL: previous run died without releasing. Steal and proceed.
		if ( ( $now - $current ) >= self::LOCK_TTL ) {
			mvweb_pi_log(
				sprintf(
					/* translators: %d: seconds since the stale lock was acquired */
					__( 'Stealing stale import lock (%d seconds old).', 'mvweb-price-importer' ),
					$now - $current
				),
				'warning'
			);
			update_option( self::LOCK_OPTION, (string) $now, false );
			return true;
		}

		// Active lock, not stale — back off.
		return false;
	}

	/**
	 * Release import lock.
	 *
	 * Deletes the option outright (matches legacy importer behaviour).
	 * acquire_lock() relies on add_option() returning false when the row
	 * exists, so leaving a zero-value row behind would force every future
	 * acquisition through the stale-check branch needlessly.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function release_lock(): void {
		delete_option( self::LOCK_OPTION );
		mvweb_pi_log( 'Lock released.', 'debug' );
	}

	/**
	 * Send error notification email to site admin.
	 *
	 * Only sends when import has errors (TZ 10.4).
	 *
	 * @since 1.0.0
	 * @param array $stats Import statistics with 'errors', 'created', 'updated' keys.
	 * @return void
	 */
	private function send_error_email( array $stats ): void {
		$admin_email = get_option( 'admin_email' );
		if ( empty( $admin_email ) ) {
			return;
		}

		$site_name = get_bloginfo( 'name' );

		$subject = sprintf(
			/* translators: %s: site name */
			__( '[%s] Price Import Error', 'mvweb-price-importer' ),
			$site_name
		);

		$body_parts = array();

		if ( ! empty( $stats['message'] ) ) {
			$body_parts[] = $stats['message'];
			$body_parts[] = '';
		}

		$body_parts[] = sprintf(
			/* translators: 1: error count, 2: created count, 3: updated count */
			__( 'Errors: %1$d, Created: %2$d, Updated: %3$d', 'mvweb-price-importer' ),
			$stats['errors'] ?? 0,
			$stats['created'] ?? 0,
			$stats['updated'] ?? 0
		);

		$body_parts[] = '';
		$body_parts[] = sprintf(
			/* translators: %s: admin URL */
			__( 'Check import log: %s', 'mvweb-price-importer' ),
			admin_url( 'admin.php?page=mvweb-price-importer' )
		);

		wp_mail( $admin_email, $subject, implode( "\n", $body_parts ) );
	}

	/**
	 * Register custom cron intervals.
	 *
	 * Adds 'Every 6 hours' and 'Every 12 hours' intervals.
	 * WordPress already provides 'hourly' and 'daily'.
	 *
	 * @since 1.0.0
	 * @param array $schedules Existing cron schedules.
	 * @return array Modified schedules.
	 */
	public static function register_intervals( array $schedules ): array {
		$schedules['mvweb_pi_6hours'] = array(
			'interval' => 6 * HOUR_IN_SECONDS,
			'display'  => esc_html__( 'Every 6 hours', 'mvweb-price-importer' ),
		);

		$schedules['mvweb_pi_12hours'] = array(
			'interval' => 12 * HOUR_IN_SECONDS,
			'display'  => esc_html__( 'Every 12 hours', 'mvweb-price-importer' ),
		);

		return $schedules;
	}

	/**
	 * Schedule or reschedule the cron event.
	 *
	 * Clears existing schedule and sets a new one based on the interval.
	 * Pass 'disabled' to unschedule without rescheduling.
	 *
	 * @since 1.0.0
	 * @param string $interval Cron recurrence key ('hourly', 'mvweb_pi_6hours', 'mvweb_pi_12hours', 'daily', 'disabled').
	 * @return void
	 */
	public static function schedule( string $interval ): void {
		wp_clear_scheduled_hook( self::HOOK );

		if ( 'disabled' !== $interval && ! empty( $interval ) ) {
			wp_schedule_event( time(), $interval, self::HOOK );
		}
	}

	/**
	 * Check if cron is currently scheduled.
	 *
	 * @since 1.0.0
	 * @return string|false Recurrence string if scheduled, false otherwise.
	 */
	public static function get_schedule(): string|false {
		$event = wp_get_scheduled_event( self::HOOK );
		if ( ! $event ) {
			return false;
		}
		return $event->schedule;
	}

	/**
	 * Get next scheduled run timestamp.
	 *
	 * @since 1.0.0
	 * @return int|false Unix timestamp of next run, false if not scheduled.
	 */
	public static function get_next_run(): int|false {
		return wp_next_scheduled( self::HOOK );
	}

	/**
	 * Get available interval choices for settings UI.
	 *
	 * @since 1.0.0
	 * @return array Associative array of interval_key => label.
	 */
	public static function get_interval_choices(): array {
		return array(
			'disabled'         => __( 'Disabled', 'mvweb-price-importer' ),
			'hourly'           => __( 'Every hour', 'mvweb-price-importer' ),
			'mvweb_pi_6hours'  => __( 'Every 6 hours', 'mvweb-price-importer' ),
			'mvweb_pi_12hours' => __( 'Every 12 hours', 'mvweb-price-importer' ),
			'daily'            => __( 'Once daily', 'mvweb-price-importer' ),
		);
	}

	/**
	 * Check if import lock is currently active.
	 *
	 * @since 1.0.0
	 * @return bool True if locked, false if free.
	 */
	public static function is_locked(): bool {
		$lock = (int) get_option( self::LOCK_OPTION, 0 );
		if ( $lock <= 0 ) {
			return false;
		}

		// Treat stale locks as not-locked so callers (status endpoints, UI)
		// don't claim an import is running when it has actually died.
		if ( ( time() - $lock ) >= self::LOCK_TTL ) {
			return false;
		}

		return true;
	}
}
