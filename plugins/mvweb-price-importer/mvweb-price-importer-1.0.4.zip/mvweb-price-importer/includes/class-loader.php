<?php
/**
 * Loader class — file downloading and URL validation.
 *
 * Handles downloading price list files from URLs,
 * Google Sheets URL conversion, SSRF protection,
 * and ETag/Last-Modified change detection.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Loader
 *
 * Downloads price list files from remote URLs with SSRF protection,
 * ETag/Last-Modified caching, Google Sheets URL conversion,
 * and magic bytes verification.
 *
 * @since 1.0.0
 */
class MVweb_PI_Loader {

	/**
	 * Download a file from URL to local destination.
	 *
	 * @since 1.0.0
	 * @param string $url         Remote file URL.
	 * @param string $destination Local file path to save to.
	 * @return true|\WP_Error True on success, WP_Error on failure.
	 */
	public function download( string $url, string $destination ): bool|\WP_Error {
		mvweb_pi_log(
			sprintf( 'Starting download: %s', mvweb_pi_mask_credentials( $url ) ),
			'debug'
		);

		// Validate URL (SSRF protection). Captures the set of IPs the
		// hostname resolved to at validation time so we can detect DNS
		// rebinding after the HTTP request completes.
		$validated_ips = array();
		$valid         = $this->validate_url( $url, $validated_ips );
		if ( is_wp_error( $valid ) ) {
			return $valid;
		}

		mvweb_pi_log(
			sprintf(
				'URL resolved (%d IP[s]): %s',
				count( $validated_ips ),
				implode( ', ', $validated_ips )
			),
			'debug'
		);

		// Ensure destination directory exists.
		$dir = dirname( $destination );
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		/**
		 * Fires before downloading a price list file.
		 *
		 * @since 1.0.0
		 * @param string $url Remote URL being downloaded.
		 */
		do_action( 'mvweb_pi_before_download', $url );

		/** @var int $timeout Download timeout in seconds. */
		$timeout = apply_filters( 'mvweb_pi_download_timeout', 45 );

		$response = wp_remote_get(
			$url,
			array(
				'timeout'     => $timeout,
				'redirection' => 0,
				'stream'      => true,
				'filename'    => $destination,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		// DNS rebinding defense: after the HTTP request, re-resolve the host
		// and ensure the set of IPs intersects with what we approved earlier.
		// If the resolver has switched to a private/reserved IP between the
		// validate_url() check and the wp_remote_get() lookup, refuse to keep
		// the downloaded payload — its contents may have come from an
		// internal host.
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( $host && ! empty( $validated_ips ) ) {
			$current_ips = $this->resolve_host_ips( $host );
			$overlap     = array_intersect( $validated_ips, $current_ips );
			$rebound     = false;
			foreach ( $current_ips as $ip ) {
				if ( $this->is_private_ip( $ip ) ) {
					$rebound = true;
					break;
				}
			}
			if ( $rebound || empty( $overlap ) ) {
				if ( file_exists( $destination ) ) {
					wp_delete_file( $destination );
				}
				return new \WP_Error(
					'ssrf_dns_rebinding',
					__( 'Host IP changed between validation and download. Refusing payload.', 'mvweb-price-importer' )
				);
			}
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			// Clean up partial download.
			if ( file_exists( $destination ) ) {
				wp_delete_file( $destination );
			}
			return new \WP_Error(
				'download_failed',
				/* translators: %d: HTTP response code */
				sprintf( __( 'Download failed: HTTP %d.', 'mvweb-price-importer' ), $code )
			);
		}

		// Check file size limit.
		$settings  = get_option( 'mvweb_pi_settings', array() );
		$max_size  = isset( $settings['max_file_size'] ) ? absint( $settings['max_file_size'] ) : 50;
		$file_size = filesize( $destination );

		if ( $file_size > $max_size * 1024 * 1024 ) {
			wp_delete_file( $destination );
			return new \WP_Error(
				'file_too_large',
				/* translators: %d: maximum file size in MB */
				sprintf( __( 'File exceeds maximum size of %d MB.', 'mvweb-price-importer' ), $max_size )
			);
		}

		// Verify magic bytes.
		$magic_check = $this->verify_magic_bytes( $destination );
		if ( is_wp_error( $magic_check ) ) {
			wp_delete_file( $destination );
			return $magic_check;
		}

		/**
		 * Fires after successfully downloading a price list file.
		 *
		 * @since 1.0.0
		 * @param string $url         Remote URL that was downloaded.
		 * @param string $destination Local file path.
		 */
		do_action( 'mvweb_pi_after_download', $url, $destination );

		mvweb_pi_log(
			sprintf(
				/* translators: 1: file name, 2: file size with unit */
				__( 'Source file downloaded: %1$s (%2$s)', 'mvweb-price-importer' ),
				basename( $destination ),
				size_format( $file_size )
			),
			'info'
		);

		return true;
	}

	/**
	 * Check if remote file has changed using ETag / Last-Modified / Content-Length.
	 *
	 * Sends HEAD request and compares response headers with saved values.
	 * Updates saved values when file has changed.
	 *
	 * @since 1.0.0
	 * @param string $url   Remote file URL.
	 * @param string $wh_id Warehouse ID (for per-warehouse tracking).
	 * @return bool True if file changed (need to download), false if unchanged.
	 */
	public function check_etag( string $url, string $wh_id ): bool {
		// Re-validate the URL even though callers normally vet it — this
		// method is publicly callable and the option could have been
		// modified out-of-band. Failing closed by returning true forces a
		// full download attempt, which will run validate_url() again.
		$valid = $this->validate_url( $url );
		if ( is_wp_error( $valid ) ) {
			return true;
		}

		$response = wp_remote_head(
			$url,
			array(
				'timeout'     => 10,
				'redirection' => 0,
			)
		);

		// On error, assume file changed — download to be safe.
		if ( is_wp_error( $response ) ) {
			return true;
		}

		$etag     = wp_remote_retrieve_header( $response, 'etag' );
		$modified = wp_remote_retrieve_header( $response, 'last-modified' );
		$length   = wp_remote_retrieve_header( $response, 'content-length' );

		// No caching headers available — always download.
		if ( ! $etag && ! $modified && ! $length ) {
			return true;
		}

		$saved_etags = get_option( 'mvweb_pi_last_etags', array() );
		$saved       = $saved_etags[ $wh_id ] ?? array();

		// Compare ETag first (strongest indicator).
		if ( $etag && $etag === ( $saved['etag'] ?? '' ) ) {
			return false;
		}

		// Compare Last-Modified.
		if ( $modified && $modified === ( $saved['modified'] ?? '' ) ) {
			return false;
		}

		// Compare Content-Length as fallback.
		if ( ! $etag && ! $modified && $length && $length === ( $saved['length'] ?? '' ) ) {
			return false;
		}

		// File changed — update saved values.
		$saved_etags[ $wh_id ] = array(
			'etag'     => $etag,
			'modified' => $modified,
			'length'   => $length,
		);
		update_option( 'mvweb_pi_last_etags', $saved_etags, false );

		return true;
	}

	/**
	 * Reset stored ETag/Last-Modified values for a warehouse.
	 *
	 * Forces re-download on next import cycle.
	 *
	 * @since 1.0.0
	 * @param string $wh_id Warehouse ID. Empty string to reset all.
	 * @return void
	 */
	public function reset_etag( string $wh_id = '' ): void {
		if ( '' === $wh_id ) {
			update_option( 'mvweb_pi_last_etags', array(), false );
			return;
		}

		$saved_etags = get_option( 'mvweb_pi_last_etags', array() );
		unset( $saved_etags[ $wh_id ] );
		update_option( 'mvweb_pi_last_etags', $saved_etags, false );
	}

	/**
	 * Validate URL for safety (SSRF protection).
	 *
	 * Checks: scheme (https only by default), no direct IP addresses,
	 * resolves the host via dns_get_record() and refuses any private,
	 * loopback, link-local or reserved IP across all A/AAAA records.
	 *
	 * The resolved IP set is returned via the $resolved_ips out parameter
	 * so callers (download()) can compare against a second lookup after
	 * the HTTP request and detect DNS rebinding.
	 *
	 * @since 1.0.0
	 * @since 1.0.0 Added IPv6 + multi-record resolution and the
	 *              $resolved_ips out parameter for rebinding detection.
	 * @param string  $url          URL to validate.
	 * @param array  &$resolved_ips Output: list of IPs the host resolved to.
	 * @return true|\WP_Error True if valid, WP_Error if not.
	 */
	public function validate_url( string $url, array &$resolved_ips = array() ): bool|\WP_Error {
		$resolved_ips = array();

		$parsed = wp_parse_url( $url );

		if ( ! $parsed || empty( $parsed['scheme'] ) || empty( $parsed['host'] ) ) {
			return new \WP_Error(
				'invalid_url',
				__( 'Invalid URL format.', 'mvweb-price-importer' )
			);
		}

		// 1. Scheme: only https (or http with explicit setting).
		$settings   = get_option( 'mvweb_pi_settings', array() );
		$allow_http = ! empty( $settings['allow_http'] );
		$allowed    = $allow_http ? array( 'https', 'http' ) : array( 'https' );

		if ( ! in_array( $parsed['scheme'], $allowed, true ) ) {
			return new \WP_Error(
				'invalid_scheme',
				__( 'Only HTTPS URLs are allowed.', 'mvweb-price-importer' )
			);
		}

		// 2. No direct IP addresses in host (prevent loopback, RFC1918, link-local).
		$host = $parsed['host'];
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return new \WP_Error(
				'ip_not_allowed',
				__( 'Direct IP addresses are not allowed in URLs.', 'mvweb-price-importer' )
			);
		}

		// 3. Resolve the hostname to all A/AAAA records and reject if any
		// of them lands in a private, reserved or link-local range. A single
		// IP check (the old gethostbyname() behaviour) misses round-robin
		// records that mix public and private IPs, which is a real SSRF
		// bypass on hosts that publish 169.254.169.254 as a secondary A.
		$ips = $this->resolve_host_ips( $host );

		if ( empty( $ips ) ) {
			return new \WP_Error(
				'dns_failed',
				/* translators: %s: hostname */
				sprintf( __( 'DNS resolution failed for host: %s.', 'mvweb-price-importer' ), $host )
			);
		}

		foreach ( $ips as $ip ) {
			if ( $this->is_private_ip( $ip ) ) {
				return new \WP_Error(
					'ssrf_blocked',
					__( 'Host resolves to a private or reserved IP address.', 'mvweb-price-importer' )
				);
			}
		}

		$resolved_ips = $ips;

		/**
		 * Filter URL validation result.
		 *
		 * @since 1.0.0
		 * @param true|WP_Error $result Validation result.
		 * @param string        $url    URL being validated.
		 */
		return apply_filters( 'mvweb_pi_validate_url', true, $url );
	}

	/**
	 * Resolve a hostname to all A and AAAA records.
	 *
	 * Falls back to gethostbynamel()/gethostbyname() when dns_get_record()
	 * is unavailable. Returns an empty array on resolution failure.
	 *
	 * @since 1.0.0
	 * @param string $host Hostname to resolve.
	 * @return string[] List of IP addresses (IPv4 and IPv6).
	 */
	private function resolve_host_ips( string $host ): array {
		$ips = array();

		if ( function_exists( 'dns_get_record' ) ) {
			$records = @dns_get_record( $host, DNS_A | DNS_AAAA ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			if ( is_array( $records ) ) {
				foreach ( $records as $record ) {
					if ( isset( $record['ip'] ) ) {
						$ips[] = $record['ip'];
					} elseif ( isset( $record['ipv6'] ) ) {
						$ips[] = $record['ipv6'];
					}
				}
			}
		}

		if ( empty( $ips ) && function_exists( 'gethostbynamel' ) ) {
			$ipv4 = @gethostbynamel( $host ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			if ( is_array( $ipv4 ) ) {
				$ips = array_merge( $ips, $ipv4 );
			}
		}

		if ( empty( $ips ) ) {
			$single = gethostbyname( $host );
			if ( $single !== $host ) {
				$ips[] = $single;
			}
		}

		return array_values( array_unique( array_filter( $ips ) ) );
	}

	/**
	 * Convert Google Sheets URL to CSV export URL.
	 *
	 * @since 1.0.0
	 * @param string $url Google Sheets URL.
	 * @return string Converted CSV export URL, or original URL if not Google Sheets.
	 */
	public function convert_google_sheets_url( string $url ): string {
		if ( ! str_contains( $url, 'docs.google.com/spreadsheets' ) ) {
			return $url;
		}

		// Extract spreadsheet ID and optional gid.
		$gid = '0';
		if ( preg_match( '/[#&?]gid=(\d+)/', $url, $gid_match ) ) {
			$gid = $gid_match[1];
		}

		// Replace /edit, /view, /pub endings with /export?format=csv&gid=N.
		$url = preg_replace( '/\/(edit|view|pub)([^\/]*)$/', '/export?format=csv&gid=' . $gid, $url );

		// If URL ends without /export, append it.
		if ( ! str_contains( $url, '/export' ) ) {
			$url = rtrim( $url, '/' ) . '/export?format=csv&gid=' . $gid;
		}

		return $url;
	}

	/**
	 * Determine file format from Content-Type header or URL extension.
	 *
	 * @since 1.0.0
	 * @param string $url           Source URL.
	 * @param string $downloaded_to Local file path (for magic bytes check).
	 * @return string File extension: 'csv', 'yml', 'xlsx'.
	 */
	public function detect_format( string $url, string $downloaded_to = '' ): string {
		// Check extension in URL.
		$path = wp_parse_url( $url, PHP_URL_PATH ) ?? '';
		$ext  = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );

		if ( in_array( $ext, array( 'csv', 'yml', 'xml', 'xlsx' ), true ) ) {
			return ( 'xml' === $ext ) ? 'yml' : $ext;
		}

		// Google Sheets converted URLs are always CSV.
		if ( str_contains( $url, 'docs.google.com/spreadsheets' ) ) {
			return 'csv';
		}

		// Check magic bytes of downloaded file.
		if ( $downloaded_to && file_exists( $downloaded_to ) ) {
			$handle = fopen( $downloaded_to, 'rb' );
			if ( $handle ) {
				$header = fread( $handle, 4 );
				fclose( $handle );

				// XLSX: PK ZIP header.
				if ( str_starts_with( $header, 'PK' ) ) {
					return 'xlsx';
				}

				// XML/YML: <?xml header.
				if ( str_starts_with( $header, '<?xm' ) ) {
					return 'yml';
				}

				// UTF-8 BOM + <?xml.
				if ( "\xEF\xBB\xBF" === substr( $header, 0, 3 ) ) {
					// Read more bytes to check for XML after BOM.
					$handle  = fopen( $downloaded_to, 'rb' );
					$header2 = fread( $handle, 7 );
					fclose( $handle );
					if ( str_contains( $header2, '<?xm' ) ) {
						return 'yml';
					}
				}
			}
		}

		// Default to CSV.
		return 'csv';
	}

	/**
	 * Check if IP is in private or reserved range.
	 *
	 * @since 1.0.0
	 * @param string $ip IP address to check.
	 * @return bool True if private/reserved, false if public.
	 */
	private function is_private_ip( string $ip ): bool {
		return ! filter_var(
			$ip,
			FILTER_VALIDATE_IP,
			FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
		);
	}

	/**
	 * Verify file magic bytes match expected format.
	 *
	 * @since 1.0.0
	 * @param string $file Path to downloaded file.
	 * @return true|\WP_Error True if valid, WP_Error if invalid.
	 */
	private function verify_magic_bytes( string $file ): bool|\WP_Error {
		if ( ! file_exists( $file ) || 0 === filesize( $file ) ) {
			return new \WP_Error(
				'empty_file',
				__( 'Downloaded file is empty.', 'mvweb-price-importer' )
			);
		}

		$handle = fopen( $file, 'rb' );
		if ( ! $handle ) {
			return new \WP_Error(
				'file_unreadable',
				__( 'Cannot read downloaded file.', 'mvweb-price-importer' )
			);
		}

		$header = fread( $handle, 8 );
		fclose( $handle );

		$ext = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );

		// XLSX: must start with PK (ZIP format).
		if ( 'xlsx' === $ext && ! str_starts_with( $header, 'PK' ) ) {
			return new \WP_Error(
				'invalid_xlsx',
				__( 'File does not appear to be a valid XLSX (ZIP) file.', 'mvweb-price-importer' )
			);
		}

		// YML/XML: should start with <?xml or BOM + <?xml.
		if ( in_array( $ext, array( 'yml', 'xml' ), true ) ) {
			$is_xml = str_starts_with( $header, '<?xm' )
				|| str_starts_with( $header, "\xEF\xBB\xBF<?xm" )  // UTF-8 BOM
				|| str_starts_with( $header, "\xFF\xFE" )           // UTF-16 LE BOM
				|| str_starts_with( $header, "\xFE\xFF" );          // UTF-16 BE BOM

			if ( ! $is_xml ) {
				return new \WP_Error(
					'invalid_yml',
					__( 'File does not appear to be a valid XML/YML file.', 'mvweb-price-importer' )
				);
			}
		}

		// CSV: basic check — should be text (no binary null bytes in first 8 bytes).
		if ( 'csv' === $ext ) {
			// Allow BOM at start.
			$check = ltrim( $header, "\xEF\xBB\xBF" );
			if ( str_contains( $check, "\x00" ) ) {
				return new \WP_Error(
					'invalid_csv',
					__( 'File does not appear to be a valid text/CSV file.', 'mvweb-price-importer' )
				);
			}
		}

		return true;
	}
}
