<?php
/**
 * Importer class — WooCommerce product import.
 *
 * Creates/updates simple products, manages stock,
 * handles images, and detects missing products.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Importer
 *
 * Imports products into WooCommerce from a generator pipeline.
 * Supports batch processing, image handling, gallery import,
 * and detection of missing (removed) products.
 *
 * @since 1.0.0
 */
class MVweb_PI_Importer {

	/**
	 * Import statistics.
	 *
	 * @since 1.0.0
	 * @var array{created: int, updated: int, skipped: int, errors: int}
	 */
	private array $stats = array(
		'created' => 0,
		'updated' => 0,
		'skipped' => 0,
		'errors'  => 0,
	);

	/**
	 * Category map: external_id => WooCommerce term_id.
	 *
	 * Loaded once from mvweb_pi_category_map option,
	 * populated by MVweb_PI_Categories during import.
	 *
	 * @since 1.0.0
	 * @var array<string, int>|null
	 */
	private ?array $category_map = null;

	/**
	 * Progress option name for checkpoint/resume.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const PROGRESS_OPTION = 'mvweb_pi_import_progress';

	/**
	 * Maximum age (in seconds) for a progress record to be considered resumable.
	 *
	 * @since 1.1.0
	 * @var int
	 */
	const PROGRESS_TTL = 3600;

	/**
	 * Image-import policies (settings.image_mode).
	 *
	 * - `always`   — download/refresh images on every create AND update
	 *                (the original behaviour; safest but slowest).
	 * - `new_only` — download images only when the product is newly created.
	 *                Updates leave existing images alone. This is what the
	 *                legacy importer used and is by far the best default
	 *                for large catalogs: Imagick runs at most once per SKU.
	 * - `never`    — never download images at all (textual catalogs).
	 *
	 * @since 1.0.0
	 */
	private const IMAGE_MODE_ALWAYS   = 'always';
	private const IMAGE_MODE_NEW_ONLY = 'new_only';
	private const IMAGE_MODE_NEVER    = 'never';

	/**
	 * Cached image-import policy for the current run.
	 *
	 * @since 1.0.0
	 * @var string|null
	 */
	private ?string $image_mode = null;

	/**
	 * Run the import process.
	 *
	 * Accepts a generator of normalized product data and processes
	 * them in batches. After all products are processed, zeroes out
	 * stock for products missing from the new price list.
	 *
	 * Supports checkpoint/resume: saves progress after each batch.
	 * On resume, skips already-processed products via $skip_count.
	 *
	 * @since 1.0.0
	 * @since 1.1.0 Added $skip_count and $resume_skus parameters for checkpoint/resume.
	 * @since 1.0.0 Added $deadline_ts for cooperative wall-clock budgeting —
	 *              the cron layer uses it to chop long imports into
	 *              short-lived wp_schedule_single_event chunks on web/AJAX.
	 * @param \Generator $products    Generator yielding normalized product arrays.
	 * @param int        $skip_count  Number of products to skip (for resume after crash).
	 * @param string[]   $resume_skus SKUs already collected before crash (for zero_missing_stock).
	 * @param int        $deadline_ts Unix timestamp at which to stop and persist
	 *                                progress; 0 means "no limit, run to completion".
	 * @return array Import statistics, augmented with `incomplete` => bool when
	 *               the deadline was hit before the generator drained.
	 */
	public function run( \Generator $products, int $skip_count = 0, array $resume_skus = array(), int $deadline_ts = 0 ): array {
		/**
		 * Fires before the import process begins.
		 *
		 * @since 1.0.0
		 */
		do_action( 'mvweb_pi_before_import' );

		// Default batch size: settings value if configured, otherwise 100.
		// Filter `mvweb_pi_batch_size` runs last so it can override both
		// the default and the settings value (TZ public hook contract).
		$settings = get_option( 'mvweb_pi_settings', array() );
		$default  = ! empty( $settings['batch_size'] ) ? absint( $settings['batch_size'] ) : 100;
		/** @var int $batch_size Number of products per batch. */
		$batch_size = (int) apply_filters( 'mvweb_pi_batch_size', $default );
		if ( $batch_size < 1 ) {
			$batch_size = 100;
		}

		$batch          = array();
		$new_skus       = $resume_skus;
		$batch_num      = 0;
		$started_at     = gmdate( 'Y-m-d H:i:s' );
		$skipped_so_far = 0;

		// Restore stats from checkpoint if resuming.
		if ( $skip_count > 0 ) {
			$progress = get_option( self::PROGRESS_OPTION );
			if ( is_array( $progress ) ) {
				$this->stats = array(
					'created' => $progress['created'] ?? 0,
					'updated' => $progress['updated'] ?? 0,
					'skipped' => $progress['skipped'] ?? 0,
					'errors'  => $progress['errors'] ?? 0,
				);
				$started_at = $progress['started_at'] ?? $started_at;
				$batch_num  = $progress['batch_num'] ?? 0;
			}
		}

		foreach ( $products as $product_data ) {
			$new_skus[] = $product_data['sku'];

			// Skip already-processed products on resume.
			if ( $skipped_so_far < $skip_count ) {
				++$skipped_so_far;
				continue;
			}

			$batch[] = $product_data;

			if ( count( $batch ) >= $batch_size ) {
				$this->process_batch( $batch );
				$batch = array();
				++$batch_num;

				// Checkpoint: save progress after each batch.
				$this->save_progress( $new_skus, $started_at, $batch_num );

				mvweb_pi_log(
					sprintf(
						'Batch %d processed (running totals: %d created, %d updated, %d skipped, %d errors).',
						$batch_num,
						$this->stats['created'],
						$this->stats['updated'],
						$this->stats['skipped'],
						$this->stats['errors']
					),
					'debug'
				);

				// Cooperative wall-clock budget: when the caller (web/AJAX)
				// gave us a deadline and we've crossed it, persist what we
				// have and bail. The cron layer reads `incomplete` and
				// schedules a continuation via wp_schedule_single_event().
				// We never bail mid-batch — finishing the current batch
				// guarantees a consistent checkpoint.
				if ( $deadline_ts > 0 && time() >= $deadline_ts ) {
					return array_merge( $this->stats, array(
						'incomplete' => true,
						'processed'  => count( $new_skus ),
					) );
				}
			}
		}

		// Process remaining products.
		if ( ! empty( $batch ) ) {
			$this->process_batch( $batch );
			++$batch_num;
		}

		// At this point the generator has fully drained — the SKU set is complete.
		// Only now is it safe to diff against known_skus and to overwrite known_skus.
		// If the process died inside the loop, save_progress() recorded a partial
		// new_skus but neither zero_missing_stock() nor the known_skus overwrite
		// have run — preserving stock data for products that simply hadn't been
		// streamed yet.
		$final_skus = array_values( array_unique( $new_skus ) );

		// Zero stock for products missing from the new price list (TZ 6.4, 6.5.1).
		$this->zero_missing_stock( $final_skus );

		// Persist total + last_run on the per-instance stats so callers
		// (cron wrapper, REST endpoint, AJAX handler) get a complete
		// payload that survives the array_merge in MVweb_PI_Cron::run().
		$this->stats['total']    = count( $final_skus );
		$this->stats['last_run'] = current_time( 'mysql' );

		// Save import statistics.
		update_option( 'mvweb_pi_import_stats', $this->stats, false );

		// Save known SKUs for next diff (autoload=false). Only the complete,
		// drained SKU set is persisted here; partial sets from interrupted
		// runs remain in the progress option and are recovered on resume.
		update_option( 'mvweb_pi_known_skus', $final_skus, false );

		// Clear progress — import completed successfully.
		delete_option( self::PROGRESS_OPTION );

		/**
		 * Fires after the import process completes.
		 *
		 * @since 1.0.0
		 * @param array $stats Import statistics.
		 */
		do_action( 'mvweb_pi_after_import', $this->stats );

		return $this->stats;
	}

	/**
	 * Save import progress checkpoint.
	 *
	 * Persists current progress to wp_options so the import can be
	 * resumed if the PHP process is interrupted (timeout, OOM, restart).
	 *
	 * @since 1.1.0
	 * @param string[] $new_skus   Accumulated SKUs processed so far.
	 * @param string   $started_at Import start timestamp (GMT).
	 * @param int      $batch_num  Number of completed batches.
	 * @return void
	 */
	private function save_progress( array $new_skus, string $started_at, int $batch_num ): void {
		$processed = $this->stats['created'] + $this->stats['updated']
			+ $this->stats['skipped'] + $this->stats['errors'];

		update_option(
			self::PROGRESS_OPTION,
			array(
				'processed'  => $processed,
				'created'    => $this->stats['created'],
				'updated'    => $this->stats['updated'],
				'skipped'    => $this->stats['skipped'],
				'errors'     => $this->stats['errors'],
				'new_skus'   => $new_skus,
				'started_at' => $started_at,
				'batch_num'  => $batch_num,
			),
			false
		);
	}

	/**
	 * Process a batch of products.
	 *
	 * For each product, determines whether to create or update
	 * based on existing SKU in WooCommerce.
	 *
	 * @since 1.0.0
	 * @param array[] $batch Array of normalized product data.
	 * @return void
	 */
	private function process_batch( array $batch ): void {
		foreach ( $batch as $data ) {
			try {
				$product_id = wc_get_product_id_by_sku( $data['sku'] );

				if ( $product_id ) {
					$this->update_product( $product_id, $data );
					++$this->stats['updated'];
				} else {
					$result = $this->create_product( $data );
					if ( is_wp_error( $result ) ) {
						mvweb_pi_log(
							/* translators: 1: SKU, 2: error message */
							sprintf( __( 'Error creating product %1$s: %2$s', 'mvweb-price-importer' ), $data['sku'], $result->get_error_message() ),
							'error'
						);
						++$this->stats['errors'];
						continue;
					}
					++$this->stats['created'];
				}
			} catch ( \Exception $e ) {
				mvweb_pi_log(
					/* translators: 1: SKU, 2: error message */
					sprintf( __( 'Exception processing product %1$s: %2$s', 'mvweb-price-importer' ), $data['sku'], $e->getMessage() ),
					'error'
				);
				++$this->stats['errors'];
			}
		}
	}

	/**
	 * Create a new WooCommerce simple product.
	 *
	 * @since 1.0.0
	 * @param array $data Normalized product data.
	 * @return int|\WP_Error Product ID on success, WP_Error on failure.
	 */
	private function create_product( array $data ): int|\WP_Error {
		$product = new \WC_Product_Simple();
		$product->set_name( $data['name'] );
		$product->set_sku( $data['sku'] );
		$product->set_regular_price( (string) $data['price'] );

		if ( ! empty( $data['sale_price'] ) && $data['sale_price'] > 0 ) {
			$product->set_sale_price( (string) $data['sale_price'] );
		}

		$product->set_manage_stock( true );
		$product->set_stock_quantity( $data['stock'] );
		$product->set_stock_status( $data['stock'] > 0 ? 'instock' : 'outofstock' );
		$product->set_description( $data['description'] );
		$product->set_status( 'publish' );

		// Category assignment (TZ 6.2).
		if ( ! empty( $data['category_id'] ) ) {
			$term_id = $this->resolve_category( $data['category_id'], $data['parent_cat_id'] ?? '' );
			if ( $term_id ) {
				$product->set_category_ids( array( $term_id ) );
			}
		}

		$product_id = $product->save();

		if ( ! $product_id ) {
			return new \WP_Error(
				'product_save_failed',
				/* translators: %s: product SKU */
				sprintf( __( 'Failed to save product: %s', 'mvweb-price-importer' ), $data['sku'] )
			);
		}

		// Per-warehouse stock meta (TZ 3.3, 16.3).
		if ( ! empty( $data['stocks'] ) && is_array( $data['stocks'] ) ) {
			update_post_meta( $product_id, '_mvweb_pi_stocks', wp_json_encode( $data['stocks'] ) );
		}

		// Barcode meta (TZ 16.3).
		if ( ! empty( $data['barcode'] ) ) {
			update_post_meta( $product_id, '_mvweb_pi_barcode', sanitize_text_field( $data['barcode'] ) );
		}

		// Images: on create we honour every mode except `never`. The first
		// run is the only place Imagick legitimately needs to fire for a
		// brand-new SKU.
		if ( self::IMAGE_MODE_NEVER !== $this->get_image_mode() ) {
			$this->handle_image( $product_id, $data['image'] ?? '' );
			$this->handle_gallery( $product_id, $data['gallery'] ?? array() );
		}

		/**
		 * Fires after a new product is created during import.
		 *
		 * @since 1.0.0
		 * @param int   $product_id WooCommerce product ID.
		 * @param array $data       Normalized product data.
		 */
		do_action( 'mvweb_pi_product_created', $product_id, $data );

		return $product_id;
	}

	/**
	 * Resolve the image-import policy for this run.
	 *
	 * Reads `mvweb_pi_settings.image_mode` once and caches it. Unknown or
	 * legacy values fall back to `new_only` — the same default the legacy
	 * importer used in production.
	 *
	 * @since 1.0.0
	 * @return string One of self::IMAGE_MODE_*.
	 */
	private function get_image_mode(): string {
		if ( null !== $this->image_mode ) {
			return $this->image_mode;
		}

		$settings = get_option( 'mvweb_pi_settings', array() );
		$mode     = $settings['image_mode'] ?? self::IMAGE_MODE_NEW_ONLY;

		if ( ! in_array( $mode, array( self::IMAGE_MODE_ALWAYS, self::IMAGE_MODE_NEW_ONLY, self::IMAGE_MODE_NEVER ), true ) ) {
			$mode = self::IMAGE_MODE_NEW_ONLY;
		}

		$this->image_mode = $mode;
		return $mode;
	}

	/**
	 * Update an existing WooCommerce product.
	 *
	 * Updates all fields: name, price, stock, description, category,
	 * images, and per-warehouse stock meta.
	 *
	 * @since 1.0.0
	 * @param int   $product_id WooCommerce product ID.
	 * @param array $data       Normalized product data.
	 * @return void
	 */
	private function update_product( int $product_id, array $data ): void {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			++$this->stats['errors'];
			return;
		}

		$product->set_name( $data['name'] );
		$product->set_regular_price( (string) $data['price'] );

		if ( ! empty( $data['sale_price'] ) && $data['sale_price'] > 0 ) {
			$product->set_sale_price( (string) $data['sale_price'] );
		} else {
			$product->set_sale_price( '' );
		}

		$product->set_stock_quantity( $data['stock'] );
		$product->set_stock_status( $data['stock'] > 0 ? 'instock' : 'outofstock' );
		$product->set_description( $data['description'] );

		// Category assignment (TZ 6.3).
		if ( ! empty( $data['category_id'] ) ) {
			$term_id = $this->resolve_category( $data['category_id'], $data['parent_cat_id'] ?? '' );
			if ( $term_id ) {
				$product->set_category_ids( array( $term_id ) );
			}
		}

		$product->save();

		// Per-warehouse stock meta (TZ 3.3, 16.3).
		if ( ! empty( $data['stocks'] ) && is_array( $data['stocks'] ) ) {
			update_post_meta( $product_id, '_mvweb_pi_stocks', wp_json_encode( $data['stocks'] ) );
		}

		// Barcode meta.
		if ( ! empty( $data['barcode'] ) ) {
			update_post_meta( $product_id, '_mvweb_pi_barcode', sanitize_text_field( $data['barcode'] ) );
		}

		// Images: on update we only refresh when image_mode === 'always'.
		// `new_only` and `never` skip Imagick entirely on updates — this is
		// the single biggest performance win for repeat imports, because
		// for most products the picture URL hasn't changed anyway and
		// thumbnail regeneration is by far the most expensive step.
		// Note: handle_image() also has a URL-equality short-circuit, so
		// even `always` mode is cheap when nothing changed; the early
		// return here saves the validate_url() + meta-read overhead.
		if ( self::IMAGE_MODE_ALWAYS === $this->get_image_mode() ) {
			$this->handle_image( $product_id, $data['image'] ?? '' );
			$this->handle_gallery( $product_id, $data['gallery'] ?? array() );
		}

		/**
		 * Fires after an existing product is updated during import.
		 *
		 * @since 1.0.0
		 * @param int   $product_id WooCommerce product ID.
		 * @param array $data       Normalized product data.
		 */
		do_action( 'mvweb_pi_product_updated', $product_id, $data );
	}

	/**
	 * Handle featured image for a product.
	 *
	 * Downloads and sets the featured image. If the URL hasn't changed,
	 * skips downloading. If URL changed, removes old image and sets new one.
	 * Only removes images originally uploaded by this plugin.
	 *
	 * @since 1.0.0
	 * @param int    $product_id Product ID.
	 * @param string $image_url  Image URL from the price list.
	 * @return void
	 */
	private function handle_image( int $product_id, string $image_url ): void {
		if ( empty( $image_url ) ) {
			return;
		}

		// Validate image URL (SSRF protection, TZ 2.4).
		$loader = new MVweb_PI_Loader();
		$valid  = $loader->validate_url( $image_url );
		if ( is_wp_error( $valid ) ) {
			mvweb_pi_log(
				/* translators: 1: product ID, 2: error message */
				sprintf( __( 'Image URL validation failed for product %1$d: %2$s', 'mvweb-price-importer' ), $product_id, $valid->get_error_message() ),
				'warning'
			);
			return;
		}

		// Check if image URL has changed (TZ 6.6).
		$saved_url = get_post_meta( $product_id, '_mvweb_pi_image_source', true );
		if ( $saved_url === $image_url ) {
			return;
		}

		// Delete old image if it was uploaded by this plugin (TZ 6.6).
		$old_attach_id = (int) get_post_meta( $product_id, '_mvweb_pi_image_attach_id', true );
		if ( $old_attach_id && get_post_meta( $old_attach_id, '_mvweb_pi_uploaded', true ) ) {
			wp_delete_attachment( $old_attach_id, true );
		}

		// Download and attach new image.
		$attach_id = $this->download_and_attach_image( $image_url, $product_id );
		if ( is_wp_error( $attach_id ) ) {
			// Demoted to debug — broken image URLs are routine in supplier
			// feeds (HTTP 404 on stale photos) and would otherwise flood
			// the log with one warning per missing thumbnail per import.
			mvweb_pi_log(
				/* translators: 1: product ID, 2: error message */
				sprintf( __( 'Image download failed for product %1$d: %2$s', 'mvweb-price-importer' ), $product_id, $attach_id->get_error_message() ),
				'debug'
			);
			return;
		}

		set_post_thumbnail( $product_id, $attach_id );
		update_post_meta( $product_id, '_mvweb_pi_image_source', $image_url );
		update_post_meta( $product_id, '_mvweb_pi_image_attach_id', $attach_id );

		// Mark as uploaded by plugin — private key, hidden from REST API (TZ 6.6, 16.5).
		update_post_meta( $attach_id, '_mvweb_pi_uploaded', 1 );
	}

	/**
	 * Handle gallery images for a product.
	 *
	 * Downloads gallery images, deduplicates against the previously imported
	 * set (stored in meta `_mvweb_pi_gallery_sources`), and assigns the
	 * resulting attachment IDs as the product's gallery. Validates each URL
	 * for SSRF protection.
	 *
	 * @since 1.0.0
	 * @since 1.0.0 Added URL-based dedup to prevent attachment duplication
	 *              on repeated imports.
	 * @param int      $product_id Product ID.
	 * @param string[] $gallery    Array of gallery image URLs.
	 * @return void
	 */
	private function handle_gallery( int $product_id, array $gallery ): void {
		if ( empty( $gallery ) ) {
			return;
		}

		$loader = new MVweb_PI_Loader();

		// Previously stored mapping: url => attach_id.
		$saved_sources = get_post_meta( $product_id, '_mvweb_pi_gallery_sources', true );
		if ( ! is_array( $saved_sources ) ) {
			$saved_sources = array();
		}

		$new_sources    = array();
		$attachment_ids = array();
		$seen_urls      = array();

		foreach ( $gallery as $image_url ) {
			if ( empty( $image_url ) || isset( $seen_urls[ $image_url ] ) ) {
				continue;
			}
			$seen_urls[ $image_url ] = true;

			// Reuse existing attachment if the URL was imported previously
			// and the attachment still exists.
			if ( isset( $saved_sources[ $image_url ] ) ) {
				$existing_id = (int) $saved_sources[ $image_url ];
				if ( $existing_id > 0 && 'attachment' === get_post_type( $existing_id ) ) {
					$attachment_ids[]            = $existing_id;
					$new_sources[ $image_url ]  = $existing_id;
					continue;
				}
			}

			// Validate URL (SSRF protection, TZ 2.4).
			$valid = $loader->validate_url( $image_url );
			if ( is_wp_error( $valid ) ) {
				continue;
			}

			$attach_id = $this->download_and_attach_image( $image_url, $product_id );
			if ( is_wp_error( $attach_id ) ) {
				continue;
			}

			// Mark as uploaded by plugin (TZ 16.5).
			update_post_meta( $attach_id, '_mvweb_pi_uploaded', 1 );

			$attachment_ids[]          = $attach_id;
			$new_sources[ $image_url ] = $attach_id;
		}

		// Delete attachments that are no longer in the gallery
		// (only ones uploaded by this plugin).
		$stale_urls = array_diff_key( $saved_sources, $new_sources );
		foreach ( $stale_urls as $stale_id ) {
			$stale_id = (int) $stale_id;
			if ( $stale_id > 0 && get_post_meta( $stale_id, '_mvweb_pi_uploaded', true ) ) {
				wp_delete_attachment( $stale_id, true );
			}
		}

		// Persist the new mapping for the next import.
		if ( ! empty( $new_sources ) ) {
			update_post_meta( $product_id, '_mvweb_pi_gallery_sources', $new_sources );
		} else {
			delete_post_meta( $product_id, '_mvweb_pi_gallery_sources' );
		}

		if ( ! empty( $attachment_ids ) ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				$product->set_gallery_image_ids( $attachment_ids );
				$product->save();
			}
		}
	}

	/**
	 * Download an image from URL and attach it to a product.
	 *
	 * Uses the plugin loader (SSRF-protected, no redirect following)
	 * to download to a temp file, then runs the file through the
	 * WordPress sideload pipeline to create the attachment. This is
	 * deliberately not `media_sideload_image()` — that helper performs
	 * its own HTTP request which follows redirects and would bypass
	 * SSRF protection (TZ 16.x security fix).
	 *
	 * @since 1.0.0
	 * @since 1.0.0 Replaced media_sideload_image() with a hardened pipeline.
	 * @param string $url        Image URL to download.
	 * @param int    $product_id Product ID to attach to.
	 * @return int|\WP_Error Attachment ID on success, WP_Error on failure.
	 */
	private function download_and_attach_image( string $url, int $product_id ): int|\WP_Error {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// Download via the SSRF-protected loader to a temp file under uploads/pricelists/.
		$loader   = new MVweb_PI_Loader();
		$path     = wp_parse_url( $url, PHP_URL_PATH ) ?? '';
		$basename = sanitize_file_name( wp_basename( $path ) );
		if ( '' === $basename ) {
			$basename = 'image-' . wp_generate_uuid4() . '.jpg';
		}
		$tmp_name = mvweb_pi_get_upload_dir() . 'img-' . wp_generate_uuid4() . '-' . $basename;

		$result = $loader->download( $url, $tmp_name );
		if ( is_wp_error( $result ) ) {
			if ( file_exists( $tmp_name ) ) {
				wp_delete_file( $tmp_name );
			}
			return $result;
		}

		// Sideload the local file into the media library — no HTTP request,
		// no redirect-following, no second SSRF surface.
		$file_array = array(
			'name'     => $basename,
			'tmp_name' => $tmp_name,
		);

		$overrides = array(
			'test_form' => false,
			'test_size' => true,
		);

		$sideload = wp_handle_sideload( $file_array, $overrides );

		if ( isset( $sideload['error'] ) ) {
			if ( file_exists( $tmp_name ) ) {
				wp_delete_file( $tmp_name );
			}
			return new \WP_Error( 'image_sideload_failed', $sideload['error'] );
		}

		// Create the attachment post.
		$attachment = array(
			'post_mime_type' => $sideload['type'],
			'post_title'     => preg_replace( '/\.[^.]+$/', '', $basename ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		);

		$attach_id = wp_insert_attachment( $attachment, $sideload['file'], $product_id );
		if ( is_wp_error( $attach_id ) || 0 === $attach_id ) {
			return new \WP_Error( 'attachment_insert_failed', __( 'Failed to insert attachment.', 'mvweb-price-importer' ) );
		}

		$metadata = wp_generate_attachment_metadata( $attach_id, $sideload['file'] );
		wp_update_attachment_metadata( $attach_id, $metadata );

		return $attach_id;
	}

	/**
	 * Zero out stock for products missing from the new price list.
	 *
	 * Compares the new set of SKUs with the previously known set.
	 * Products present in the old set but absent in the new set
	 * get their stock set to 0 and status set to 'outofstock'.
	 * Products are NOT deleted or unpublished (TZ 6.4).
	 *
	 * @since 1.0.0
	 * @param string[] $new_skus Array of SKUs from the current import.
	 * @return void
	 */
	private function zero_missing_stock( array $new_skus ): void {
		$known_skus = get_option( 'mvweb_pi_known_skus', array() );

		// On first import, no known SKUs — nothing to zero out.
		if ( empty( $known_skus ) ) {
			return;
		}

		$missing = array_diff( $known_skus, $new_skus );

		foreach ( $missing as $sku ) {
			$product_id = wc_get_product_id_by_sku( $sku );
			if ( ! $product_id ) {
				continue;
			}

			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}

			$product->set_stock_quantity( 0 );
			$product->set_stock_status( 'outofstock' );
			$product->save();

			// Zero per-warehouse stocks.
			$stocks = get_post_meta( $product_id, '_mvweb_pi_stocks', true );
			if ( $stocks ) {
				$decoded = json_decode( $stocks, true );
				if ( is_array( $decoded ) ) {
					$zeroed = array_map( function () {
						return 0;
					}, $decoded );
					update_post_meta( $product_id, '_mvweb_pi_stocks', wp_json_encode( $zeroed ) );
				}
			}

			mvweb_pi_log(
				/* translators: %s: product SKU */
				sprintf( __( 'Stock zeroed for missing product: %s', 'mvweb-price-importer' ), $sku ),
				'info'
			);
		}

		if ( ! empty( $missing ) ) {
			mvweb_pi_log(
				/* translators: %d: number of products */
				sprintf( __( 'Zeroed stock for %d missing products.', 'mvweb-price-importer' ), count( $missing ) ),
				'info'
			);
		}
	}

	/**
	 * Resolve external category ID to WooCommerce term_id.
	 *
	 * Checks the category map option for a cached mapping.
	 * Falls back to searching by name if MVweb_PI_Categories
	 * is not yet implemented (Stage 5).
	 *
	 * @since 1.0.0
	 * @param string $external_id     External category ID from the price list.
	 * @param string $parent_ext_id   External parent category ID (optional).
	 * @return int Term ID or 0 if not found.
	 */
	private function resolve_category( string $external_id, string $parent_ext_id = '' ): int {
		if ( empty( $external_id ) ) {
			return 0;
		}

		// Load category map once (populated by MVweb_PI_Categories).
		if ( null === $this->category_map ) {
			$this->category_map = get_option( 'mvweb_pi_category_map', array() );
			if ( ! is_array( $this->category_map ) ) {
				$this->category_map = array();
			}
		}

		if ( isset( $this->category_map[ $external_id ] ) ) {
			return absint( $this->category_map[ $external_id ] );
		}

		return 0;
	}

	/**
	 * Get current import statistics.
	 *
	 * @since 1.0.0
	 * @return array{created: int, updated: int, skipped: int, errors: int}
	 */
	public function get_stats(): array {
		return $this->stats;
	}
}
