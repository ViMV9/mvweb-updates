<?php
/**
 * Categories class — WooCommerce category import.
 *
 * Imports categories with hierarchy support, handles duplicates,
 * and maps external IDs to WooCommerce term_ids.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Categories
 *
 * Handles importing product categories from price lists into WooCommerce.
 * Supports hierarchical categories, external ID mapping via term meta,
 * duplicate name handling, and cache optimization for bulk operations.
 *
 * @since 1.0.0
 */
class MVweb_PI_Categories {

	/**
	 * In-memory cache: external_id => WooCommerce term_id.
	 *
	 * Populated during import to avoid repeated DB queries.
	 *
	 * @since 1.0.0
	 * @var array<string, int>
	 */
	private array $cache = array();

	/**
	 * Import categories from product data.
	 *
	 * Extracts unique categories from products, sorts by hierarchy depth
	 * (parents first), creates/maps terms, and persists the mapping
	 * to wp_options for use by the Importer class.
	 *
	 * Uses wp_suspend_cache_invalidation() to prevent hundreds of
	 * clean_term_cache() calls during bulk creation (TZ 7.4).
	 *
	 * @since 1.0.0
	 * @param array[] $categories Array of category arrays with keys: id, name, parent_id.
	 * @return void
	 */
	public function import( array $categories ): void {
		if ( empty( $categories ) ) {
			return;
		}

		// Pre-load existing category map from DB.
		$this->load_cache();

		// Optimize: suspend cache invalidation during bulk operations (TZ 7.4).
		wp_suspend_cache_invalidation( true );

		// Sort categories: parents before children.
		// Categories without parent_id come first, then by parent_id presence.
		usort( $categories, function ( $a, $b ) {
			$a_has_parent = ! empty( $a['parent_id'] );
			$b_has_parent = ! empty( $b['parent_id'] );

			if ( $a_has_parent === $b_has_parent ) {
				return 0;
			}

			return $a_has_parent ? 1 : -1;
		} );

		$created = 0;
		$mapped  = 0;

		// Sidecar: id => [name, parent_id]. Used by the Settings UI to draw
		// the "Excluded categories" tree, and by the converter to walk the
		// parent chain when filtering products. Kept separate from
		// $this->cache (which is id => term_id) so existing consumers don't
		// have to change shape.
		$meta = get_option( 'mvweb_pi_category_meta', array() );
		if ( ! is_array( $meta ) ) {
			$meta = array();
		}

		foreach ( $categories as $cat ) {
			if ( empty( $cat['id'] ) || empty( $cat['name'] ) ) {
				continue;
			}

			$term_id = $this->get_or_create( $cat );
			if ( $term_id > 0 ) {
				if ( isset( $this->cache[ $cat['id'] ] ) ) {
					++$mapped;
				} else {
					++$created;
				}
			}

			// Refresh sidecar for every category seen this run — keeps the
			// tree in sync if the supplier renames/restructures categories.
			$meta[ (string) $cat['id'] ] = array(
				'name'      => (string) $cat['name'],
				'parent_id' => isset( $cat['parent_id'] ) ? (string) $cat['parent_id'] : '',
			);
		}

		update_option( 'mvweb_pi_category_meta', $meta, false );

		// Restore cache invalidation and flush only the product_cat terms we
		// touched, not the entire object cache. The original wp_cache_flush()
		// invalidated caches of every other plugin on the site and caused
		// noticeable load spikes on busy stores.
		wp_suspend_cache_invalidation( false );
		if ( ! empty( $this->cache ) ) {
			clean_term_cache( array_values( $this->cache ), 'product_cat' );
		}

		// Persist the full mapping to wp_options for Importer::resolve_category().
		$this->save_cache();

		if ( $created > 0 || $mapped > 0 ) {
			mvweb_pi_log(
				sprintf(
					/* translators: 1: number of categories processed, 2: number created */
					__( 'Categories import: %1$d processed, %2$d created.', 'mvweb-price-importer' ),
					count( $categories ),
					$created
				),
				'info'
			);
		}
	}

	/**
	 * Get or create a WooCommerce product category from external data.
	 *
	 * Lookup order:
	 * 1. In-memory cache (fastest).
	 * 2. Term meta mvweb_pi_external_id (previously imported).
	 * 3. Create new term (with duplicate name handling, TZ 7.2).
	 *
	 * @since 1.0.0
	 * @param array $cat Category data with keys: id, name, parent_id.
	 * @return int WooCommerce term_id, or 0 on failure.
	 */
	public function get_or_create( array $cat ): int {
		$external_id = (string) $cat['id'];

		// 1. Check in-memory cache.
		if ( isset( $this->cache[ $external_id ] ) ) {
			return $this->cache[ $external_id ];
		}

		// 2. Check term meta for previously imported category.
		$existing = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'meta_key'   => 'mvweb_pi_external_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value' => $external_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'hide_empty' => false,
				'fields'     => 'ids',
				'number'     => 1,
			)
		);

		if ( ! empty( $existing ) && ! is_wp_error( $existing ) ) {
			$this->cache[ $external_id ] = $existing[0];
			return $existing[0];
		}

		// 3. Resolve parent term_id (if parent already processed).
		$parent_term_id = 0;
		if ( ! empty( $cat['parent_id'] ) ) {
			$parent_term_id = $this->cache[ (string) $cat['parent_id'] ] ?? 0;
		}

		// 4. Create new term.
		// sanitize_text_field() encodes ampersands as &amp; — fine for HTML
		// output, but supplier feeds use raw "Tom & Jerry" and we want that
		// to read identically in the admin. Decode HTML entities after the
		// XSS pass; all tags have already been stripped.
		$name   = sanitize_text_field( $cat['name'] );
		$name   = html_entity_decode( $name, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$result = wp_insert_term(
			$name,
			'product_cat',
			array( 'parent' => $parent_term_id )
		);

		if ( is_wp_error( $result ) ) {
			// Duplicate name — bind to existing term (TZ 7.2).
			if ( 'term_exists' === $result->get_error_code() ) {
				$term_id = (int) $result->get_error_data();

				// If existing term has same parent — reuse it directly.
				// If different parent (name collision with different hierarchy) —
				// try creating with unique slug (TZ 7.2).
				$existing_term = get_term( $term_id, 'product_cat' );
				if ( $existing_term && (int) $existing_term->parent !== $parent_term_id && $parent_term_id > 0 ) {
					$unique_slug = sanitize_title( $name ) . '-' . substr( md5( $external_id ), 0, 6 );
					$retry       = wp_insert_term(
						$name,
						'product_cat',
						array(
							'parent' => $parent_term_id,
							'slug'   => $unique_slug,
						)
					);

					if ( ! is_wp_error( $retry ) ) {
						$term_id = (int) $retry['term_id'];
					}
					// If retry also fails, use the original $term_id.
				}

				update_term_meta( $term_id, 'mvweb_pi_external_id', $external_id );
				$this->cache[ $external_id ] = $term_id;
				return $term_id;
			}

			// Other error — log and return 0.
			mvweb_pi_log(
				sprintf(
					/* translators: 1: category name, 2: error message */
					__( 'Failed to create category "%1$s": %2$s', 'mvweb-price-importer' ),
					$name,
					$result->get_error_message()
				),
				'error'
			);
			return 0;
		}

		$term_id = (int) $result['term_id'];
		update_term_meta( $term_id, 'mvweb_pi_external_id', $external_id );
		$this->cache[ $external_id ] = $term_id;

		return $term_id;
	}

	/**
	 * Get WooCommerce term_id by external category ID.
	 *
	 * Used by the Importer class to resolve category assignments.
	 *
	 * @since 1.0.0
	 * @param string $external_id External category ID from the price list.
	 * @return int Term ID or 0 if not mapped.
	 */
	public function get_term_id( string $external_id ): int {
		return $this->cache[ $external_id ] ?? 0;
	}

	/**
	 * Load category map from wp_options into in-memory cache.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function load_cache(): void {
		$saved = get_option( 'mvweb_pi_category_map', array() );
		if ( is_array( $saved ) ) {
			$this->cache = array_map( 'absint', $saved );
		}
	}

	/**
	 * Persist in-memory cache to wp_options.
	 *
	 * Used by Importer::resolve_category() via mvweb_pi_category_map.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function save_cache(): void {
		update_option( 'mvweb_pi_category_map', $this->cache );
	}
}
