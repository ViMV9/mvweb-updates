<?php
/**
 * Main tab — all-in-one operator panel.
 *
 * Source, schedule, excluded categories, action buttons, and statistics
 * live on a single page so day-to-day operators do not have to chase
 * tabs. Field mapping, log, feeds, and help remain on their own tabs
 * because they are configured rarely or referenced read-only.
 *
 * Uses MVweb Admin UI Kit (slate palette, Yoast-style layout).
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings      = get_option( 'mvweb_pi_settings', array() );
$source_url    = $settings['source_url'] ?? '';
$warehouses    = $settings['warehouses'] ?? array();
$cron_interval = $settings['cron_interval'] ?? 'daily';
$batch_size    = absint( $settings['batch_size'] ?? 100 );
$image_mode    = $settings['image_mode'] ?? 'new_only';
$debug_logging = ! empty( $settings['debug_logging'] );

$mapping     = get_option( 'mvweb_pi_mapping', array() );
$has_mapping = ! empty( $mapping['sku'] ) && ! empty( $mapping['name'] ) && ! empty( $mapping['price'] ) && ! empty( $mapping['stock'] );
$has_sources = ! empty( $source_url ) || ! empty( $warehouses );
$stats       = get_option( 'mvweb_pi_import_stats', array() );
$known_skus  = get_option( 'mvweb_pi_known_skus', array() );

$meta_raw = get_option( 'mvweb_pi_category_meta', array() );
$meta     = is_array( $meta_raw ) ? $meta_raw : array();

$excluded_raw = get_option( 'mvweb_pi_excluded_categories', array() );
$excluded     = array();
if ( is_array( $excluded_raw ) ) {
	foreach ( $excluded_raw as $id ) {
		$excluded[ (string) $id ] = true;
	}
}

$children_by_parent = array( '' => array() );
foreach ( $meta as $id => $row ) {
	$parent = (string) ( $row['parent_id'] ?? '' );
	if ( '' !== $parent && ! isset( $meta[ $parent ] ) ) {
		$parent = '';
	}
	$children_by_parent[ $parent ][] = (string) $id;
}

$sort_by_name = static function ( array $ids ) use ( $meta ): array {
	usort( $ids, static function ( $a, $b ) use ( $meta ) {
		return strnatcasecmp(
			(string) ( $meta[ $a ]['name'] ?? $a ),
			(string) ( $meta[ $b ]['name'] ?? $b )
		);
	} );
	return $ids;
};
foreach ( $children_by_parent as $parent_id => $list ) {
	$children_by_parent[ $parent_id ] = $sort_by_name( $list );
}

$render = function ( string $parent_id, int $depth = 0 ) use ( &$render, $children_by_parent, $meta, $excluded ) {
	if ( empty( $children_by_parent[ $parent_id ] ) ) {
		return;
	}
	foreach ( $children_by_parent[ $parent_id ] as $id ) {
		$row     = $meta[ $id ] ?? array();
		$name    = (string) ( $row['name'] ?? $id );
		$checked = isset( $excluded[ $id ] );
		?>
		<li class="mvweb-pi-cat-row" style="--depth: <?php echo (int) $depth; ?>;">
			<label class="mvweb-pi-cat-label">
				<input type="checkbox"
					   name="mvweb_pi_excluded_categories[]"
					   value="<?php echo esc_attr( $id ); ?>"
					   <?php checked( $checked ); ?>>
				<span class="mvweb-pi-cat-name"><?php echo esc_html( $name ); ?></span>
				<span class="mvweb-pi-cat-id"><code><?php echo esc_html( $id ); ?></code></span>
			</label>
		</li>
		<?php
		$render( $id, $depth + 1 );
	}
};

$cron_options = array(
	'disabled'         => __( 'Disabled', 'mvweb-price-importer' ),
	'hourly'           => __( 'Every hour', 'mvweb-price-importer' ),
	'mvweb_pi_6hours'  => __( 'Every 6 hours', 'mvweb-price-importer' ),
	'mvweb_pi_12hours' => __( 'Every 12 hours', 'mvweb-price-importer' ),
	'daily'            => __( 'Once daily', 'mvweb-price-importer' ),
);

$image_mode_options = array(
	'new_only' => __( 'Only for new products (recommended)', 'mvweb-price-importer' ),
	'always'   => __( 'Always — refresh on every import', 'mvweb-price-importer' ),
	'never'    => __( 'Never — skip image import', 'mvweb-price-importer' ),
);
?>

<div class="mvweb-pi-tab-main">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Source', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Enter a single source URL or configure multiple warehouses below. Google Sheets links are auto-converted to CSV export.', 'mvweb-price-importer' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_source_url" class="mvweb-form-row__label">
				<?php esc_html_e( 'Source URL', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="url"
					   id="mvweb_pi_source_url"
					   name="mvweb_pi_settings[source_url]"
					   class="mvweb-input"
					   value="<?php echo esc_attr( $source_url ); ?>"
					   placeholder="https://example.com/pricelist.csv">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Used when warehouses are not configured. Supports CSV, YML, XLSX, and Google Sheets URLs.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-pi-subblock">
			<div class="mvweb-pi-subblock__title"><?php esc_html_e( 'Warehouses', 'mvweb-price-importer' ); ?></div>
			<p class="mvweb-pi-subblock__sub">
				<?php esc_html_e( 'Configure multiple warehouses for multi-source import. When warehouses are set, the single Source URL above is ignored.', 'mvweb-price-importer' ); ?>
			</p>

			<div class="mvweb-table-wrap">
				<table class="mvweb-table" id="mvweb-pi-warehouses">
					<thead>
						<tr>
							<th><?php esc_html_e( 'ID', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'Name', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'URL', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'Visible', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'Feed Name', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'Actions', 'mvweb-price-importer' ); ?></th>
						</tr>
					</thead>
					<tbody id="mvweb-pi-warehouses-body">
						<?php if ( ! empty( $warehouses ) ) : ?>
							<?php foreach ( $warehouses as $index => $wh ) : ?>
								<tr class="mvweb-pi-warehouse-row" data-index="<?php echo esc_attr( absint( $index ) ); ?>">
									<td>
										<input type="text"
											   name="mvweb_pi_settings[warehouses][<?php echo esc_attr( absint( $index ) ); ?>][id]"
											   class="mvweb-input mvweb-pi-wh-id"
											   value="<?php echo esc_attr( $wh['id'] ?? '' ); ?>"
											   placeholder="moscow"
											   required>
									</td>
									<td>
										<input type="text"
											   name="mvweb_pi_settings[warehouses][<?php echo esc_attr( absint( $index ) ); ?>][name]"
											   class="mvweb-input mvweb-pi-wh-name"
											   value="<?php echo esc_attr( $wh['name'] ?? '' ); ?>"
											   placeholder="<?php esc_attr_e( 'Moscow', 'mvweb-price-importer' ); ?>">
									</td>
									<td>
										<input type="url"
											   name="mvweb_pi_settings[warehouses][<?php echo esc_attr( absint( $index ) ); ?>][url]"
											   class="mvweb-input mvweb-pi-wh-url"
											   value="<?php echo esc_attr( $wh['url'] ?? '' ); ?>"
											   placeholder="https://">
									</td>
									<td>
										<label class="mvweb-toggle">
											<input type="checkbox"
												   name="mvweb_pi_settings[warehouses][<?php echo esc_attr( absint( $index ) ); ?>][visible]"
												   value="1"
												   <?php checked( $wh['visible'] ?? '1', '1' ); ?>>
											<span class="mvweb-toggle__slider"></span>
										</label>
									</td>
									<td>
										<input type="text"
											   name="mvweb_pi_settings[warehouses][<?php echo esc_attr( absint( $index ) ); ?>][feed_name]"
											   class="mvweb-input mvweb-pi-wh-feed"
											   value="<?php echo esc_attr( $wh['feed_name'] ?? '' ); ?>"
											   placeholder="<?php esc_attr_e( 'Optional', 'mvweb-price-importer' ); ?>">
									</td>
									<td>
										<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-pi-remove-warehouse">
											&times;
										</button>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>

			<div class="mvweb-pi-warehouse-actions">
				<button type="button" class="mvweb-btn mvweb-btn--secondary" id="mvweb-pi-add-warehouse">
					+ <?php esc_html_e( 'Add Warehouse', 'mvweb-price-importer' ); ?>
				</button>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Import Schedule', 'mvweb-price-importer' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_cron_interval" class="mvweb-form-row__label">
				<?php esc_html_e( 'Auto-import Interval', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_cron_interval"
						name="mvweb_pi_settings[cron_interval]"
						class="mvweb-select">
					<?php foreach ( $cron_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>"
							<?php selected( $cron_interval, $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'How often to automatically check for price list updates and run import.', 'mvweb-price-importer' ); ?>
				</p>

				<?php
				$server_now = wp_date( 'H:i' );
				$next       = ( 'disabled' !== $cron_interval ) ? wp_next_scheduled( 'mvweb_pi_cron_import' ) : 0;
				?>
				<p class="mvweb-pi-schedule-status">
					<?php
					printf(
						/* translators: %s: server-local time, e.g. "08:00" */
						esc_html__( 'Server time %s', 'mvweb-price-importer' ),
						'<strong>' . esc_html( $server_now ) . '</strong>'
					);
					?>
					<span class="mvweb-pi-schedule-status__sep">|</span>
					<?php if ( $next ) : ?>
						<?php
						printf(
							/* translators: %s: server-local time, e.g. "08:48" */
							esc_html__( 'Next import at %s', 'mvweb-price-importer' ),
							'<strong>' . esc_html( wp_date( 'H:i', $next ) ) . '</strong>'
						);
						?>
					<?php else : ?>
						<span class="mvweb-pi-schedule-status__muted"><?php esc_html_e( 'Auto-import disabled', 'mvweb-price-importer' ); ?></span>
					<?php endif; ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_batch_size" class="mvweb-form-row__label">
				<?php esc_html_e( 'Batch Size', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
					   id="mvweb_pi_batch_size"
					   name="mvweb_pi_settings[batch_size]"
					   class="mvweb-input mvweb-pi-input--narrow"
					   value="<?php echo esc_attr( absint( $batch_size ) ); ?>"
					   min="10"
					   max="1000"
					   step="10">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Number of products to process per batch during import (default: 100).', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_image_mode" class="mvweb-form-row__label">
				<?php esc_html_e( 'Image Import', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_image_mode"
						name="mvweb_pi_settings[image_mode]"
						class="mvweb-select">
					<?php foreach ( $image_mode_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>"
							<?php selected( $image_mode, $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Thumbnail regeneration is the most expensive part of an import. "Only for new products" downloads images once when each SKU is first created, then leaves them alone — recommended for catalogs over a few hundred items.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_debug_logging" class="mvweb-form-row__label">
				<?php esc_html_e( 'Verbose logging', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							   id="mvweb_pi_debug_logging"
							   name="mvweb_pi_settings[debug_logging]"
							   value="1"
							   <?php checked( $debug_logging ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Record additional debug-level events in the log', 'mvweb-price-importer' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Default off — the log shows only operator-grade events (downloads, conversions, imports, errors). Turn this on when troubleshooting a slow or broken import: the plugin will also record per-batch progress, per-source download details, and HTTP-404 image misses.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Excluded Categories', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Tick any category whose products should be skipped during import. Excluding a parent automatically excludes every category nested under it.', 'mvweb-price-importer' ); ?>
		</p>

		<input type="hidden" name="mvweb_pi_categories_submitted" value="1">

		<?php if ( empty( $meta ) ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'No categories have been imported yet. Run an import once to populate this list, then come back to pick exclusions.', 'mvweb-price-importer' ); ?>
				</div>
			</div>
		<?php else : ?>
			<div class="mvweb-pi-cat-toolbar">
				<input type="search"
					   id="mvweb-pi-cat-filter"
					   class="mvweb-input mvweb-pi-cat-filter"
					   placeholder="<?php esc_attr_e( 'Filter categories by name…', 'mvweb-price-importer' ); ?>">
				<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm" id="mvweb-pi-cat-expand-all">
					<?php esc_html_e( 'Select all', 'mvweb-price-importer' ); ?>
				</button>
				<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm" id="mvweb-pi-cat-clear-all">
					<?php esc_html_e( 'Clear selection', 'mvweb-price-importer' ); ?>
				</button>
				<span class="mvweb-pi-cat-count">
					<?php
					printf(
						/* translators: 1: number of excluded categories, 2: total number of categories */
						esc_html__( '%1$d of %2$d excluded', 'mvweb-price-importer' ),
						count( $excluded ),
						count( $meta )
					);
					?>
				</span>
			</div>

			<ul class="mvweb-pi-cat-tree">
				<?php $render( '', 0 ); ?>
			</ul>
		<?php endif; ?>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Actions', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Manual operations: run a full import, download fresh price files, convert with the configured mapping, or reset change-detection hashes.', 'mvweb-price-importer' ); ?>
		</p>

		<?php if ( ! $has_sources ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'No source URL configured. Add a source URL or warehouse above before running actions.', 'mvweb-price-importer' ); ?>
				</div>
			</div>
		<?php elseif ( ! $has_mapping ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'Field mapping is not configured. Set up mapping in the Mapping tab before running an import.', 'mvweb-price-importer' ); ?>
				</div>
			</div>
		<?php endif; ?>

		<div class="mvweb-pi-main-actions">
			<button type="button"
					class="mvweb-btn mvweb-btn--primary mvweb-pi-import-btn"
					id="mvweb-pi-run-import-btn"
					<?php echo ( ! $has_sources || ! $has_mapping ) ? 'disabled' : ''; ?>>
				<?php esc_html_e( 'Import Now', 'mvweb-price-importer' ); ?>
				<span class="mvweb-spinner" id="mvweb-pi-import-spinner"></span>
			</button>

			<button type="button"
					class="mvweb-btn mvweb-btn--secondary mvweb-pi-action-btn"
					id="mvweb-pi-download-btn"
					data-action="mvweb_pi_download_source"
					data-result="mvweb-pi-download-result"
					<?php echo ! $has_sources ? 'disabled' : ''; ?>>
				<?php esc_html_e( 'Download', 'mvweb-price-importer' ); ?>
				<span class="mvweb-spinner" id="mvweb-pi-download-spinner"></span>
			</button>

			<button type="button"
					class="mvweb-btn mvweb-btn--secondary mvweb-pi-action-btn"
					id="mvweb-pi-convert-btn"
					data-action="mvweb_pi_convert_data"
					data-result="mvweb-pi-convert-result">
				<?php esc_html_e( 'Convert', 'mvweb-price-importer' ); ?>
				<span class="mvweb-spinner" id="mvweb-pi-convert-spinner"></span>
			</button>

			<button type="button"
					class="mvweb-btn mvweb-btn--ghost mvweb-pi-action-btn"
					id="mvweb-pi-reset-btn"
					data-action="mvweb_pi_reset_etags"
					data-result="mvweb-pi-reset-result">
				<?php esc_html_e( 'Reset Hash', 'mvweb-price-importer' ); ?>
				<span class="mvweb-spinner" id="mvweb-pi-reset-spinner"></span>
			</button>
		</div>

		<div class="mvweb-pi-action-result" id="mvweb-pi-import-result"></div>
		<div class="mvweb-pi-action-result" id="mvweb-pi-download-result"></div>
		<div class="mvweb-pi-action-result" id="mvweb-pi-convert-result"></div>
		<div class="mvweb-pi-action-result" id="mvweb-pi-reset-result"></div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Import Statistics', 'mvweb-price-importer' ); ?></div>
		</div>

		<?php if ( ! empty( $stats['last_run'] ) ) : ?>
			<p class="mvweb-block__sub">
				<?php
				printf(
					/* translators: %s: timestamp of the last import */
					esc_html__( 'Last import: %s', 'mvweb-price-importer' ),
					'<strong>' . esc_html( (string) $stats['last_run'] ) . '</strong>'
				);
				?>
			</p>

			<?php $errors = absint( $stats['errors'] ?? 0 ); ?>
			<div class="mvweb-pi-stats-dashboard">
				<div class="mvweb-metric mvweb-metric--success">
					<span class="mvweb-metric__label"><?php esc_html_e( 'Created', 'mvweb-price-importer' ); ?></span>
					<span class="mvweb-metric__value"><?php echo esc_html( (string) absint( $stats['created'] ?? 0 ) ); ?></span>
				</div>
				<div class="mvweb-metric">
					<span class="mvweb-metric__label"><?php esc_html_e( 'Updated', 'mvweb-price-importer' ); ?></span>
					<span class="mvweb-metric__value"><?php echo esc_html( (string) absint( $stats['updated'] ?? 0 ) ); ?></span>
				</div>
				<div class="mvweb-metric">
					<span class="mvweb-metric__label"><?php esc_html_e( 'Skipped', 'mvweb-price-importer' ); ?></span>
					<span class="mvweb-metric__value"><?php echo esc_html( (string) absint( $stats['skipped'] ?? 0 ) ); ?></span>
				</div>
				<div class="mvweb-metric <?php echo $errors > 0 ? 'mvweb-metric--danger' : ''; ?>">
					<span class="mvweb-metric__label"><?php esc_html_e( 'Errors', 'mvweb-price-importer' ); ?></span>
					<span class="mvweb-metric__value"><?php echo esc_html( (string) $errors ); ?></span>
				</div>
			</div>

			<p class="mvweb-block__sub mvweb-pi-stats-footer">
				<?php
				printf(
					/* translators: 1: total products in source, 2: count of known SKUs */
					esc_html__( 'Total in price list: %1$d · Known SKUs: %2$d', 'mvweb-price-importer' ),
					absint( $stats['total'] ?? 0 ),
					count( $known_skus )
				);
				?>
			</p>
		<?php else : ?>
			<p class="mvweb-block__sub">
				<?php esc_html_e( 'No import has been run yet.', 'mvweb-price-importer' ); ?>
			</p>
		<?php endif; ?>
	</div>

</div>
