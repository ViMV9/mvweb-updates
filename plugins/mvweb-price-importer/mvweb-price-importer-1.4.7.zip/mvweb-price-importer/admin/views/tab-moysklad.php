<?php
/**
 * MoySklad tab — connection and what to take from it.
 *
 * Uses MVweb Admin UI Kit (slate palette, Yoast-style layout).
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$ms          = get_option( 'mvweb_pi_moysklad', array() );
$ms          = is_array( $ms ) ? $ms : array();
$connected   = '' !== (string) ( $ms['token'] ?? '' );
$price_types = is_array( $ms['price_types'] ?? null ) ? $ms['price_types'] : array();
$ms_active   = ( 'moysklad' === mvweb_pi_source_mode() );

$rate_options = array(
	11 => __( '11 — personal token, from December 2026', 'mvweb-price-importer' ),
	15 => __( '15 — personal token, until December 2026', 'mvweb-price-importer' ),
	45 => __( '45 — token of an application registered with MoySklad', 'mvweb-price-importer' ),
);

// "Free" leads because "Available" also counts goods still on their way from a
// supplier: measured against a live account, five on the shelf and six ordered
// read as eleven for sale.
$stock_options = array(
	'freeStock' => __( 'Free — on the shelf, less what is reserved (recommended)', 'mvweb-price-importer' ),
	'quantity'  => __( 'Available — the same, plus goods still on their way from a supplier', 'mvweb-price-importer' ),
	'stock'     => __( 'Physical — everything on the shelf, reservations ignored', 'mvweb-price-importer' ),
);

$sku_options = array(
	'article' => __( 'Article', 'mvweb-price-importer' ),
	'code'    => __( 'Code', 'mvweb-price-importer' ),
);

$image_options = array(
	'smart'    => __( 'Smart — also refresh photos changed in MoySklad', 'mvweb-price-importer' ),
	'new_only' => __( 'For new products only (recommended)', 'mvweb-price-importer' ),
	'never'    => __( 'Never', 'mvweb-price-importer' ),
);

$price_fields = array(
	'price_retail'    => array(
		'label' => __( 'Retail price', 'mvweb-price-importer' ),
		'desc'  => __( 'The price the shop sells at. A product whose chosen price type is not filled in is left out of the import — it would otherwise land in the catalogue at no price at all.', 'mvweb-price-importer' ),
	),
	'price_wholesale' => array(
		'label' => __( 'Wholesale price', 'mvweb-price-importer' ),
		'desc'  => __( 'Optional. Stored in its own product field and never shown as the shop price — the theme decides what to do with it.', 'mvweb-price-importer' ),
	),
	'price_dealer'    => array(
		'label' => __( 'Dealer price', 'mvweb-price-importer' ),
		'desc'  => __( 'Optional. Second B2B tier, stored and treated exactly like the wholesale price.', 'mvweb-price-importer' ),
	),
);

$selected_stock = (string) ( $ms['stock_type'] ?? 'freeStock' );

$ms_stores       = is_array( $ms['stores'] ?? null ) ? $ms['stores'] : array();
$stores_excluded = array_map( 'strval', (array) ( $ms['stores_excluded'] ?? array() ) );
$stores_counted  = array_map( 'strval', (array) ( $ms['stores_counted'] ?? array() ) );
$stores_visible  = array_map( 'strval', (array) ( $ms['stores_visible'] ?? array() ) );

$ms_fields       = is_array( $ms['product_attributes'] ?? null ) ? $ms['product_attributes'] : array();
$attribute_rules = is_array( $ms['attribute_rules'] ?? null ) ? $ms['attribute_rules'] : array();
$field_kinds     = array(
	'boolean'   => __( 'Flag', 'mvweb-price-importer' ),
	'string'    => __( 'String', 'mvweb-price-importer' ),
	'text'      => __( 'Text', 'mvweb-price-importer' ),
	'long'      => __( 'Whole number', 'mvweb-price-importer' ),
	'double'    => __( 'Decimal number', 'mvweb-price-importer' ),
	'time'      => __( 'Date', 'mvweb-price-importer' ),
	'link'      => __( 'Link', 'mvweb-price-importer' ),
	'file'      => __( 'File', 'mvweb-price-importer' ),
	'reference' => __( 'List', 'mvweb-price-importer' ),
);
$selected_sku   = (string) ( $ms['sku_field'] ?? 'article' );
$selected_image = (string) ( $ms['images'] ?? 'new_only' );
$selected_rate  = (int) ( $ms['rate_limit'] ?? MVweb_PI_MoySklad_Client::DEFAULT_RATE );

$organizations  = is_array( $ms['organizations'] ?? null ) ? $ms['organizations'] : array();
$send_orders    = ! empty( $ms['send_orders'] );
$organization   = (string) ( $ms['organization'] ?? '' );
$order_statuses = is_array( $ms['order_statuses'] ?? null ) ? $ms['order_statuses'] : array( 'processing' );
$orders_sync    = (string) ( $ms['orders_sync'] ?? 'mvweb_pi_15min' );
$orders_next    = wp_next_scheduled( MVweb_PI_Orders::HOOK );

$wc_statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();

$order_states  = is_array( $ms['order_states'] ?? null ) ? $ms['order_states'] : array();
$status_map    = is_array( $ms['status_map'] ?? null ) ? $ms['status_map'] : array();
$pull_statuses = ! empty( $ms['pull_statuses'] );
$status_sync   = (string) ( $ms['status_sync'] ?? 'mvweb_pi_15min' );
$status_window = (int) ( $ms['status_window'] ?? 30 );
$lock_status   = ! empty( $ms['lock_status'] );
$status_next   = MVweb_PI_Orders::get_status_next_run();
$status_last   = get_option( MVweb_PI_Orders::STATUS_LAST_OPTION, array() );
$status_last   = is_array( $status_last ) ? $status_last : array();

// Everything the shop has, less the two nobody should be able to pick here.
// `refunded` books a refund and mails the customer about it; `checkout-draft`
// is the placeholder the block checkout gives an order nobody has placed yet,
// and an order moved into it disappears from the customer's account.
$status_choices = $wc_statuses;
unset( $status_choices[ 'wc-' . MVweb_PI_Orders::FORBIDDEN_STATUS ], $status_choices['wc-checkout-draft'] );

$sync_options  = MVweb_PI_Stock_Sync::get_interval_choices();
$selected_sync = (string) ( $ms['stock_sync'] ?? 'disabled' );
$sync_next     = MVweb_PI_Stock_Sync::get_next_run();
$sync_last     = get_option( MVweb_PI_Stock_Sync::LAST_RUN_OPTION, array() );
$sync_last     = is_array( $sync_last ) ? $sync_last : array();
?>

<div class="mvweb-pi-tab-moysklad">

	<input type="hidden" name="mvweb_pi_moysklad_submitted" value="1">
	<input type="hidden" name="mvweb_pi_moysklad[lists]" value="<?php echo esc_attr( MVweb_PI_Settings::moysklad_lists_hash( $ms ) ); ?>">

	<?php
	$ms_sources = array(
		array( __( 'Name, description', 'mvweb-price-importer' ), __( 'Product name and description', 'mvweb-price-importer' ) ),
		array( __( 'Article or code — chosen under Catalogue', 'mvweb-price-importer' ), __( 'SKU', 'mvweb-price-importer' ) ),
		array( __( 'Price types — chosen under Prices', 'mvweb-price-importer' ), __( 'Regular, wholesale and dealer price', 'mvweb-price-importer' ) ),
		array( __( 'Stock of the warehouses switched on under Catalogue', 'mvweb-price-importer' ), __( 'Stock quantity', 'mvweb-price-importer' ) ),
		array( __( 'Product groups', 'mvweb-price-importer' ), __( 'Categories — which ones to import is set in the Category Filter on the Main tab', 'mvweb-price-importer' ) ),
		array( __( 'Photos', 'mvweb-price-importer' ), __( 'Product image and gallery', 'mvweb-price-importer' ) ),
		array( __( 'Modifications and their characteristics', 'mvweb-price-importer' ), __( 'Variations and attributes of a variable product', 'mvweb-price-importer' ) ),
		array( __( 'Weight, barcode, GTIN', 'mvweb-price-importer' ), __( 'Weight and the GTIN field; the barcode also helps find a product that is already in the shop', 'mvweb-price-importer' ) ),
		array( __( 'Extra fields — chosen under Extra product fields', 'mvweb-price-importer' ), __( 'Product tags and attributes', 'mvweb-price-importer' ) ),
	);
	?>
	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'What comes from where', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'MoySklad fields are fixed, so there is no column mapping to set up. Below is what fills what; the choices that remain are on this tab. The import schedule and the category filter are shared with the price list and live on the Main tab.', 'mvweb-price-importer' ); ?>
		</p>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'In MoySklad', 'mvweb-price-importer' ); ?></th>
						<th scope="col"><?php esc_html_e( 'In WooCommerce', 'mvweb-price-importer' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $ms_sources as $ms_source ) : ?>
						<tr>
							<td><?php echo esc_html( $ms_source[0] ); ?></td>
							<td><?php echo esc_html( $ms_source[1] ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Connection', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Two ways in: paste a token issued in MoySklad, or let it issue one in exchange for a login and password. Either way only the token is kept — the login and password are used once and not stored.', 'mvweb-price-importer' ); ?>
		</p>

		<?php if ( ! $ms_active ) : ?>
			<div class="mvweb-alert mvweb-alert--info">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'MoySklad is not this site\'s data source right now, so nothing here affects the catalogue. Set the connection up first, then switch the source on the Main tab — that way the shop is never left without a working source.', 'mvweb-price-importer' ); ?>
				</div>
			</div>
		<?php endif; ?>

		<?php if ( $connected ) : ?>
			<div class="mvweb-alert mvweb-alert--success mvweb-pi-moysklad-connected">
				<div class="mvweb-alert__body">
					<?php
					printf(
						/* translators: %d: number of price types */
						esc_html__( 'Connected. MoySklad reported %d price types.', 'mvweb-price-importer' ),
						count( $price_types )
					);
					?>
				</div>
			</div>

			<div class="mvweb-pi-main-actions mvweb-pi-moysklad-connected">
				<button type="button"
						class="mvweb-btn mvweb-btn--ghost mvweb-pi-action-btn"
						id="mvweb-pi-moysklad-disconnect-btn"
						data-action="mvweb_pi_moysklad_disconnect"
						data-result="mvweb-pi-moysklad-result">
					<?php esc_html_e( 'Disconnect', 'mvweb-price-importer' ); ?>
					<span class="mvweb-spinner"></span>
				</button>
			</div>
		<?php endif; ?>

		<div class="mvweb-form-row">
			<label for="mvweb-pi-moysklad-token" class="mvweb-form-row__label">
				<?php esc_html_e( 'Access token', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php
				// None of the three fields below carries a name attribute, and
				// that is deliberate. Every tab shares one form, so a named
				// field here would be posted back on every save of every tab —
				// a token travelling with a change of batch size. They are read
				// by the Connect button and sent on their own.
				?>
				<input type="password" id="mvweb-pi-moysklad-token" class="mvweb-input" autocomplete="off"<?php echo $connected ? ' placeholder="••••••••••••"' : ''; ?>>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'The safer way in. Create it in MoySklad under the user menu → Settings → Tokens. With a token filled in, the login and password below are not needed.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-pi-moysklad-login" class="mvweb-form-row__label">
				<?php esc_html_e( 'Login', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb-pi-moysklad-login" class="mvweb-input" autocomplete="off">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'The other way: MoySklad issues the token itself in exchange for a login and password. Leave these empty if a token is pasted above.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-pi-moysklad-password" class="mvweb-form-row__label">
				<?php esc_html_e( 'Password', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="password" id="mvweb-pi-moysklad-password" class="mvweb-input" autocomplete="new-password">
				<div class="mvweb-pi-main-actions">
					<button type="button"
							class="mvweb-btn mvweb-btn--primary"
							id="mvweb-pi-moysklad-connect-btn">
						<?php echo $connected ? esc_html__( 'Reconnect', 'mvweb-price-importer' ) : esc_html__( 'Connect', 'mvweb-price-importer' ); ?>
						<span class="mvweb-spinner"></span>
					</button>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Whichever way is used, a separate MoySklad user with read access is safer than the owner account.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-pi-action-result" id="mvweb-pi-moysklad-result"></div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Prices', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Which MoySklad price type becomes which price here. The list comes from the account and refreshes when you connect.', 'mvweb-price-importer' ); ?>
		</p>

		<?php if ( empty( $price_types ) ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'No price types yet — connect an account above and they will appear here.', 'mvweb-price-importer' ); ?>
				</div>
			</div>
		<?php endif; ?>

		<?php foreach ( $price_fields as $field => $meta ) : ?>
			<div class="mvweb-form-row">
				<label for="mvweb_pi_<?php echo esc_attr( $field ); ?>" class="mvweb-form-row__label">
					<?php echo esc_html( $meta['label'] ); ?>
				</label>
				<div class="mvweb-form-row__field">
					<select id="mvweb_pi_<?php echo esc_attr( $field ); ?>"
							name="mvweb_pi_moysklad[<?php echo esc_attr( $field ); ?>]"
							class="mvweb-select mvweb-pi-moysklad-price">
						<option value=""><?php esc_html_e( '— not used —', 'mvweb-price-importer' ); ?></option>
						<?php foreach ( $price_types as $type_id => $type_name ) : ?>
							<option value="<?php echo esc_attr( $type_id ); ?>"
								<?php selected( (string) ( $ms[ $field ] ?? '' ), (string) $type_id ); ?>>
								<?php echo esc_html( $type_name ); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<p class="mvweb-form-row__desc"><?php echo esc_html( $meta['desc'] ); ?></p>
				</div>
			</div>
		<?php endforeach; ?>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Catalogue', 'mvweb-price-importer' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_ms_sku_field" class="mvweb-form-row__label">
				<?php esc_html_e( 'Match products by', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_ms_sku_field" name="mvweb_pi_moysklad[sku_field]" class="mvweb-select">
					<?php foreach ( $sku_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $selected_sku, $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Becomes the product article in WooCommerce, and every later import matches on it.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_ms_stock_type" class="mvweb-form-row__label">
				<?php esc_html_e( 'Stock figure', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_ms_stock_type" name="mvweb_pi_moysklad[stock_type]" class="mvweb-select">
					<?php foreach ( $stock_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $selected_stock, $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( '"Available" puts goods on sale before they arrive — choose it only for a shop that knowingly sells to order. "Free" and "Available" already have MoySklad\'s own reservations taken out, but orders placed here are not among them. Keep "Goods in open orders" on the Main tab switched on.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Warehouses', 'mvweb-price-importer' ); ?></span>
			<div class="mvweb-form-row__field">
				<?php if ( empty( $ms_stores ) ) : ?>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'No warehouses yet — connect an account above, or press Reconnect with the fields left empty to re-read it, and reload the page.', 'mvweb-price-importer' ); ?>
					</p>
				<?php else : ?>
					<div class="mvweb-table-wrap">
						<table class="mvweb-table">
							<thead>
								<tr>
									<th scope="col"><?php esc_html_e( 'Warehouse in MoySklad', 'mvweb-price-importer' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Count in stock', 'mvweb-price-importer' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Show on the product page', 'mvweb-price-importer' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $ms_stores as $store_id => $store_name ) : ?>
									<tr>
										<td><?php echo esc_html( $store_name ); ?></td>
										<td>
											<label class="mvweb-toggle">
												<input type="checkbox"
														name="mvweb_pi_moysklad[stores_counted][]"
														value="<?php echo esc_attr( (string) $store_id ); ?>"
														aria-label="<?php echo esc_attr( sprintf( /* translators: %s: warehouse name */ __( 'Count %s in stock', 'mvweb-price-importer' ), $store_name ) ); ?>"
														<?php checked( $stores_counted ? in_array( (string) $store_id, $stores_counted, true ) : ! in_array( (string) $store_id, $stores_excluded, true ) ); ?>>
												<span class="mvweb-toggle__slider"></span>
											</label>
										</td>
										<td>
											<label class="mvweb-toggle">
												<input type="checkbox"
														name="mvweb_pi_moysklad[stores_visible][]"
														value="<?php echo esc_attr( (string) $store_id ); ?>"
														aria-label="<?php echo esc_attr( sprintf( /* translators: %s: warehouse name */ __( 'Show %s on the product page', 'mvweb-price-importer' ), $store_name ) ); ?>"
														<?php checked( in_array( (string) $store_id, $stores_visible, true ) ); ?>>
												<span class="mvweb-toggle__slider"></span>
											</label>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				<?php endif; ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'The stock a product is sold from is the sum over the warehouses counted here. A reservation MoySklad holds without a warehouse is always taken off that sum. While every warehouse is counted, one opened in MoySklad later is counted too; once some are switched off, only the ones switched on here are counted, and a new warehouse stays out until it is switched on. Shown warehouses add their own figures under the stock line on the product page.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_ms_images" class="mvweb-form-row__label">
				<?php esc_html_e( 'Product photos', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_ms_images" name="mvweb_pi_moysklad[images]" class="mvweb-select">
					<?php foreach ( $image_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $selected_image, $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'A product gets its photos when it first appears; after that the media library is the master copy. "Smart" also checks the photos of every product on each import and downloads the ones added or replaced in MoySklad since — MoySklad then becomes the master copy: a main photo changed by hand on the site is put back. A photo deleted in MoySklad does not reliably disappear from the site — it stays when nothing comes in its place. The catalogue is read in pages of a hundred instead of a thousand, about ten times the requests: roughly a minute more per ten thousand products. For a catalogue of several thousand products run the import from the server\'s cron, not the site\'s own: reading it then takes longer than a web request is usually allowed to last.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_ms_rate" class="mvweb-form-row__label">
				<?php esc_html_e( 'Requests per 3 seconds', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_ms_rate" name="mvweb_pi_moysklad[rate_limit]" class="mvweb-select">
					<?php foreach ( $rate_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( (string) $value ); ?>" <?php selected( $selected_rate, $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Set this to what the account actually allows, and no higher: MoySklad cuts off an account that keeps overshooting, and only its support can turn it back on.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Extra product fields', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'The fields the account adds to its products. A flag can become a product tag — "Hit", "New" — and a string, number or list field can become a product attribute, shown on the product page and usable in the storefront filters. Nothing is taken until it is chosen here.', 'mvweb-price-importer' ); ?>
		</p>

		<?php if ( empty( $ms_fields ) ) : ?>
			<div class="mvweb-alert mvweb-alert--info">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'No extra fields yet. If the account has some, press Reconnect above with the fields left empty, then reload the page.', 'mvweb-price-importer' ); ?>
				</div>
			</div>
		<?php else : ?>
			<div class="mvweb-table-wrap">
				<table class="mvweb-table">
					<thead>
						<tr>
							<th scope="col"><?php esc_html_e( 'Field in MoySklad', 'mvweb-price-importer' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Kind', 'mvweb-price-importer' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Use it as', 'mvweb-price-importer' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Tag name', 'mvweb-price-importer' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php
						foreach ( $ms_fields as $field_id => $field ) :
							$field_id   = (string) $field_id;
							$field_type = (string) ( $field['type'] ?? '' );
							$field_rule = is_array( $attribute_rules[ $field_id ] ?? null ) ? $attribute_rules[ $field_id ] : array();
							$field_as   = (string) ( $field_rule['as'] ?? '' );
							$choices    = array( '' => __( '— not imported —', 'mvweb-price-importer' ) );
							if ( 'boolean' === $field_type ) {
								$choices['tag'] = __( 'Product tag', 'mvweb-price-importer' );
							} elseif ( in_array( $field_type, array( 'string', 'long', 'double', 'reference' ), true ) ) {
								$choices['attribute'] = __( 'Product attribute', 'mvweb-price-importer' );
							}
							?>
							<tr>
								<td><?php echo esc_html( (string) ( $field['name'] ?? $field_id ) ); ?></td>
								<td><?php echo esc_html( $field_kinds[ $field_type ] ?? $field_type ); ?></td>
								<td>
									<?php if ( count( $choices ) > 1 ) : ?>
										<select name="mvweb_pi_moysklad[attribute_rules][<?php echo esc_attr( $field_id ); ?>][as]"
												class="mvweb-select"
												aria-label="<?php echo esc_attr( sprintf( /* translators: %s: field name */ __( 'How to use %s', 'mvweb-price-importer' ), (string) ( $field['name'] ?? '' ) ) ); ?>">
											<?php foreach ( $choices as $value => $label ) : ?>
												<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $field_as, $value ); ?>><?php echo esc_html( $label ); ?></option>
											<?php endforeach; ?>
										</select>
									<?php else : ?>
										<?php esc_html_e( 'Not supported yet', 'mvweb-price-importer' ); ?>
									<?php endif; ?>
								</td>
								<td>
									<?php if ( 'boolean' === $field_type ) : ?>
										<input type="text"
												name="mvweb_pi_moysklad[attribute_rules][<?php echo esc_attr( $field_id ); ?>][label]"
												class="mvweb-input"
												value="<?php echo esc_attr( (string) ( $field_rule['label'] ?? '' ) ); ?>"
												placeholder="<?php echo esc_attr( (string) ( $field['name'] ?? '' ) ); ?>"
												aria-label="<?php echo esc_attr( sprintf( /* translators: %s: field name */ __( 'Tag name for %s', 'mvweb-price-importer' ), (string) ( $field['name'] ?? '' ) ) ); ?>">
									<?php else : ?>
										—
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<div class="mvweb-alert mvweb-alert--info">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'A field left empty in MoySklad counts as empty here: unticking "Hit" there takes the tag off the product, clearing a value removes the attribute. Tags and attributes added in WooCommerce by hand are never touched. An attribute is created in WooCommerce when it is chosen and saved; if the shop already has an attribute with the same name, that one is filled instead — and on imported products its values then come from MoySklad only, replacing any typed in by hand. Changes reach the products on the next full import.', 'mvweb-price-importer' ); ?>
				</div>
			</div>
		<?php endif; ?>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Stock refresh', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Between full imports: one request that updates nothing but the stock figure, so something selling out does not stay on sale here until the next import.', 'mvweb-price-importer' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_ms_stock_sync" class="mvweb-form-row__label">
				<?php esc_html_e( 'Refresh stock', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_ms_stock_sync" name="mvweb_pi_moysklad[stock_sync]" class="mvweb-select">
					<?php foreach ( $sync_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $selected_sync, $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Products missing from the report are left exactly as they are — this never takes anything off sale and never touches categories.', 'mvweb-price-importer' ); ?>
				</p>
				<?php if ( ! $ms_active && 'disabled' !== $selected_sync ) : ?>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'Saved, but not running: the site does not import from MoySklad right now. It starts on its own once the source is switched over.', 'mvweb-price-importer' ); ?>
					</p>
				<?php endif; ?>
			</div>
		</div>

		<?php if ( $sync_next || ! empty( $sync_last['time'] ) ) : ?>
			<div class="mvweb-alert mvweb-alert--info">
				<div class="mvweb-alert__body">
					<?php
					if ( $sync_next ) {
						printf(
							/* translators: %s: human-readable time until the next run, e.g. "12 mins" */
							esc_html__( 'Next refresh in %s.', 'mvweb-price-importer' ),
							esc_html( human_time_diff( time(), (int) $sync_next ) )
						);
					}

					if ( ! empty( $sync_last['time'] ) ) {
						echo $sync_next ? ' ' : '';
						printf(
							/* translators: 1: time since the last run, 2: products whose stock changed, 3: products matched */
							esc_html__( 'Last one %1$s ago: %2$d products updated out of %3$d matched.', 'mvweb-price-importer' ),
							esc_html( human_time_diff( (int) $sync_last['time'], time() ) ),
							(int) ( $sync_last['updated'] ?? 0 ),
							(int) ( $sync_last['matched'] ?? 0 )
						);
					}
					?>
				</div>
			</div>
		<?php endif; ?>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Orders to MoySklad', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'An order that reaches one of the chosen statuses goes across as a customer order. Until then MoySklad never learns that anything was sold here.', 'mvweb-price-importer' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb_pi_ms_send_orders">
				<?php esc_html_e( 'Send orders', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
								id="mvweb_pi_ms_send_orders"
								name="mvweb_pi_moysklad[send_orders]"
								value="1"
								<?php checked( $send_orders ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Send orders placed on this site to MoySklad', 'mvweb-price-importer' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Sending happens in the background, so a slow warehouse never holds up a checkout. An order is never sent twice, and orders placed before this was switched on are not sent at all.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_ms_organization" class="mvweb-form-row__label">
				<?php esc_html_e( 'Organization', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_ms_organization" name="mvweb_pi_moysklad[organization]" class="mvweb-select">
					<option value=""><?php esc_html_e( '— not chosen —', 'mvweb-price-importer' ); ?></option>
					<?php foreach ( $organizations as $org_id => $org_name ) : ?>
						<option value="<?php echo esc_attr( $org_id ); ?>" <?php selected( $organization, (string) $org_id ); ?>>
							<?php echo esc_html( $org_name ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Which legal entity the orders belong to. MoySklad refuses an order without one.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Send when the order becomes', 'mvweb-price-importer' ); ?></span>
			<div class="mvweb-form-row__field">
				<div class="mvweb-pi-status-list">
					<?php foreach ( $wc_statuses as $status_key => $status_label ) : ?>
						<?php $bare = substr( (string) $status_key, 3 ); ?>
						<label class="mvweb-check">
							<input type="checkbox"
									name="mvweb_pi_moysklad[order_statuses][]"
									value="<?php echo esc_attr( $bare ); ?>"
									<?php checked( in_array( $bare, $order_statuses, true ) ); ?>>
							<?php echo esc_html( $status_label ); ?>
						</label>
					<?php endforeach; ?>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'One status is usually enough — the one that means the shop has accepted the order.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_ms_orders_sync" class="mvweb-form-row__label">
				<?php esc_html_e( 'Check the queue', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_ms_orders_sync" name="mvweb_pi_moysklad[orders_sync]" class="mvweb-select">
					<?php foreach ( $sync_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $orders_sync, $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Picks up the orders that did not get through on their first try.', 'mvweb-price-importer' ); ?>
				</p>
				<?php if ( $orders_next ) : ?>
					<p class="mvweb-form-row__desc">
						<?php
						printf(
							/* translators: %s: human-readable time until the next run */
							esc_html__( 'Next check in %s.', 'mvweb-price-importer' ),
							esc_html( human_time_diff( time(), (int) $orders_next ) )
						);
						?>
					</p>
				<?php endif; ?>
			</div>
		</div>

		<?php if ( $send_orders && in_array( $selected_stock, array( 'quantity', 'freeStock' ), true ) ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'Worth checking now that orders go across: the stock figure chosen above already has MoySklad\'s own reservations taken out, and the orders this site sends may now be among them. If they are, the "Goods in open orders" switch on the Main tab subtracts the same orders a second time and the shop will look emptier than it is. Compare one product\'s stock here against MoySklad after an order goes through — if the two disagree by exactly the ordered quantity, turn that switch off.', 'mvweb-price-importer' ); ?>
				</div>
			</div>
		<?php endif; ?>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Statuses from MoySklad', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'The other half of the exchange: the manager moves the document in MoySklad and the order here follows. Nothing needs doing in this admin at all.', 'mvweb-price-importer' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb_pi_ms_pull_statuses">
				<?php esc_html_e( 'Follow MoySklad', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
								id="mvweb_pi_ms_pull_statuses"
								name="mvweb_pi_moysklad[pull_statuses]"
								value="1"
								<?php checked( $pull_statuses ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Take the order status from the state of its document in MoySklad', 'mvweb-price-importer' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Only orders this site sent across are affected — anything typed into MoySklad by hand is none of the shop\'s business. A status change here does everything it normally does: the customer is emailed and stock moves.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Which state means what', 'mvweb-price-importer' ); ?></span>
			<div class="mvweb-form-row__field">
				<?php if ( empty( $order_states ) ) : ?>
					<div class="mvweb-alert mvweb-alert--warning">
						<div class="mvweb-alert__body">
							<?php esc_html_e( 'No states yet — connect an account above and the list this account actually uses will appear here.', 'mvweb-price-importer' ); ?>
						</div>
					</div>
				<?php else : ?>
					<div class="mvweb-table-wrap">
						<table class="mvweb-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'State in MoySklad', 'mvweb-price-importer' ); ?></th>
									<th><?php esc_html_e( 'Order status here', 'mvweb-price-importer' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $order_states as $state_id => $state_name ) : ?>
									<tr>
										<th scope="row"><?php echo esc_html( $state_name ); ?></th>
										<td>
											<select name="mvweb_pi_moysklad[status_map][<?php echo esc_attr( $state_id ); ?>]" class="mvweb-select">
												<option value=""><?php esc_html_e( '— leave the order alone —', 'mvweb-price-importer' ); ?></option>
												<?php foreach ( $status_choices as $status_key => $status_label ) : ?>
													<?php $bare = substr( (string) $status_key, 3 ); ?>
													<option value="<?php echo esc_attr( $bare ); ?>"
														<?php selected( (string) ( $status_map[ $state_id ] ?? '' ), $bare ); ?>>
														<?php echo esc_html( $status_label ); ?>
													</option>
												<?php endforeach; ?>
											</select>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				<?php endif; ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Leave the state a new document starts in unmatched — that is the state an order arrives in from this site, and matching it would send the order back where it just came from. "Refunded" is not offered: it books a refund and emails the customer without returning either the goods or the money.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_ms_status_sync" class="mvweb-form-row__label">
				<?php esc_html_e( 'How often', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_ms_status_sync" name="mvweb_pi_moysklad[status_sync]" class="mvweb-select">
					<?php foreach ( $sync_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $status_sync, $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'MoySklad is asked only for documents that changed since the last check, so a shop of any size normally costs one request per turn.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_ms_status_window" class="mvweb-form-row__label">
				<?php esc_html_e( 'How far back to start', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
						id="mvweb_pi_ms_status_window"
						name="mvweb_pi_moysklad[status_window]"
						class="mvweb-input mvweb-pi-input--narrow"
						min="1"
						max="365"
						step="1"
						value="<?php echo esc_attr( (string) $status_window ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Days. Matters once, on the very first check: orders older than this keep the status they have, so switching this on does not mail a year of customers at once. Every check after that carries on from where the last one stopped.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb_pi_ms_lock_status">
				<?php esc_html_e( 'Hold the status here', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
								id="mvweb_pi_ms_lock_status"
								name="mvweb_pi_moysklad[lock_status]"
								value="1"
								<?php checked( $lock_status ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Do not let the status be changed on the order screen', 'mvweb-price-importer' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'A change made here would stand for a few minutes and then be corrected by the next check, which looks like the site losing it. Everything else on the order screen still saves as usual, and a shop manager can still override the status through a confirmation step on the order itself.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-pi-main-actions">
			<button type="button"
					class="mvweb-btn mvweb-btn--ghost mvweb-pi-action-btn"
					data-action="mvweb_pi_status_sync"
					data-result="mvweb-pi-status-sync-result">
				<?php esc_html_e( 'Check now', 'mvweb-price-importer' ); ?>
				<span class="mvweb-spinner"></span>
			</button>
		</div>
		<div class="mvweb-pi-action-result" id="mvweb-pi-status-sync-result"></div>

		<?php if ( $status_next || ! empty( $status_last['time'] ) ) : ?>
			<div class="mvweb-alert mvweb-alert--info">
				<div class="mvweb-alert__body">
					<?php
					if ( $status_next ) {
						printf(
							/* translators: %s: human-readable time until the next run */
							esc_html__( 'Next check in %s.', 'mvweb-price-importer' ),
							esc_html( human_time_diff( time(), (int) $status_next ) )
						);
					}

					if ( ! empty( $status_last['time'] ) ) {
						echo $status_next ? ' ' : '';
						printf(
							/* translators: 1: time since the last check, 2: documents examined, 3: order statuses changed */
							esc_html__( 'Last one %1$s ago: %2$d documents examined, %3$d statuses changed.', 'mvweb-price-importer' ),
							esc_html( human_time_diff( (int) $status_last['time'], time() ) ),
							(int) ( $status_last['seen'] ?? 0 ),
							(int) ( $status_last['changed'] ?? 0 )
						);
					}
					?>
				</div>
			</div>
		<?php endif; ?>

		<?php if ( $pull_statuses && ! $ms_active ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'Saved, but not running: the site does not import from MoySklad right now. It starts on its own once the source is switched over.', 'mvweb-price-importer' ); ?>
				</div>
			</div>
		<?php endif; ?>
	</div>

</div>
