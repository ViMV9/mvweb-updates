<?php
/**
 * Converter class — unified format conversion.
 *
 * Converts parsed data into a unified format via generator pipeline.
 * Handles multi-warehouse SKU merging, row validation, and optional
 * checkpoint files for debugging.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Converter
 *
 * @since 1.0.0
 */
class MVweb_PI_Converter {

	/**
	 * Invalid rows collected during conversion.
	 *
	 * @since 1.0.0
	 * @var array[]
	 */
	private array $invalid_rows = array();

	/**
	 * Duplicate SKU warnings collected during conversion.
	 *
	 * @since 1.0.0
	 * @var string[]
	 */
	private array $duplicate_skus = array();

	/**
	 * Resolved excluded-categories set: external_id => true.
	 *
	 * Built lazily on first use from `mvweb_pi_excluded_categories` (the
	 * user's direct picks) plus every descendant resolved through the
	 * `mvweb_pi_category_meta` parent map. Storing the closure once
	 * avoids re-walking the parent chain for every row.
	 *
	 * @since 1.0.0
	 * @var array<string, true>|null
	 */
	private ?array $excluded_set = null;

	/**
	 * Category filter mode: 'exclude' (blacklist) or 'include' (whitelist).
	 *
	 * In 'exclude' mode the ticked categories (and their descendants) are
	 * dropped from the feed. In 'include' mode only the ticked branches are
	 * kept and everything else is dropped. Loaded lazily alongside the set.
	 *
	 * @since 1.1.0
	 * @var string|null
	 */
	private ?string $filter_mode = null;

	/**
	 * Lazily-loaded category parent map (id => ['parent_id' => ...]).
	 *
	 * Cached per-instance so the parent-chain walk in is_category_excluded()
	 * doesn't re-read the mvweb_pi_category_meta option once per product —
	 * on a large feed without a persistent object cache that was one DB hit
	 * per row.
	 *
	 * @since 1.0.9
	 * @var array<string, array>|null
	 */
	private ?array $category_meta = null;

	/**
	 * Convert parsed data into unified product format (single source).
	 *
	 * Generator pipeline — processes rows one at a time without loading
	 * the entire file into memory.
	 *
	 * @since 1.0.0
	 * @param array<string, string> $source_files Map of warehouse_id => file_path.
	 * @param array<string, string> $mapping      Map of field_name => column_header.
	 * @return \Generator<int, array> Normalized product data.
	 */
	public function convert( array $source_files, array $mapping ): \Generator {
		$seen_skus = array();

		foreach ( $source_files as $wh_id => $file_path ) {
			$parser = MVweb_PI_Parser::create( $file_path );

			foreach ( $parser->rows() as $raw_row ) {
				$product = $this->normalize( $raw_row, $mapping, $wh_id );

				if ( null === $product ) {
					continue;
				}

				$sku = $product['sku'];

				// Duplicate SKU in same file: use first occurrence (TZ 5.2).
				if ( isset( $seen_skus[ $sku ] ) ) {
					$this->duplicate_skus[] = $sku;
					mvweb_pi_log(
						/* translators: %s: product SKU */
						sprintf( __( 'Duplicate SKU skipped: %s', 'mvweb-price-importer' ), $sku ),
						'warning'
					);
					continue;
				}
				$seen_skus[ $sku ] = true;

				yield $product;
			}
		}
	}

	/**
	 * Merge data from multiple warehouses by SKU.
	 *
	 * Mode 1: Separate files per warehouse.
	 * Merges by SKU: price from first warehouse, stocks summed.
	 *
	 * Note: For large catalogs (10,000+ products) $merged can be
	 * significant. The runtime memory check below aborts before the
	 * process OOMs on shared hosting.
	 *
	 * @since 1.0.0
	 * @since 1.0.0 Added per-row memory budget check to prevent OOM on
	 *              constrained hosting.
	 * @param array<string, string> $source_files Map of warehouse_id => file_path.
	 * @param array<string, string> $mapping      Map of field_name => column_header.
	 * @return \Generator<int, array> Merged product data.
	 */
	public function merge_warehouses( array $source_files, array $mapping ): \Generator {
		$merged       = array();
		$seen_in_wh   = array();
		$memory_limit = $this->parse_memory_limit( ini_get( 'memory_limit' ) );
		// When memory_limit is -1 (unlimited) parse_memory_limit() returns 0
		// and the merge would have no ceiling at all — a pathological feed
		// could exhaust the box's physical RAM. Fall back to a fixed 512 MB
		// budget so the guard below always has something to enforce.
		if ( $memory_limit <= 0 ) {
			$memory_limit = 512 * 1024 * 1024;
		}
		// Stop accumulating when usage exceeds 80% of the limit. Leaves
		// headroom for the import phase that runs immediately afterwards.
		$soft_cap     = (int) ( $memory_limit * 0.8 );
		$check_every  = 250;
		$row_count    = 0;
		$bailed       = false;

		foreach ( $source_files as $wh_id => $file_path ) {
			if ( $bailed ) {
				break;
			}

			$parser = MVweb_PI_Parser::create( $file_path );

			foreach ( $parser->rows() as $raw_row ) {
				++$row_count;

				if ( $soft_cap > 0 && 0 === $row_count % $check_every ) {
					if ( memory_get_usage( true ) > $soft_cap ) {
						mvweb_pi_log(
							sprintf(
								/* translators: 1: SKUs merged so far, 2: memory limit in MB */
								__( 'Multi-warehouse merge aborted: memory budget exhausted after %1$d unique SKUs (PHP memory_limit %2$d MB). Increase memory_limit or split warehouses into separate imports.', 'mvweb-price-importer' ),
								count( $merged ),
								(int) ( $memory_limit / 1024 / 1024 )
							),
							'error'
						);
						$bailed = true;
						break;
					}
				}

				$product = $this->normalize( $raw_row, $mapping, $wh_id );
				if ( null === $product ) {
					continue;
				}

				$sku = $product['sku'];

				// Duplicate SKU within the same warehouse file: keep the first
				// occurrence (price, name and stock) and log it, mirroring the
				// single-source convert() rule. Without this the second row would
				// silently overwrite this warehouse's stock with its own value.
				$seen_key = $wh_id . '|' . $sku;
				if ( isset( $seen_in_wh[ $seen_key ] ) ) {
					$this->duplicate_skus[] = $sku;
					mvweb_pi_log(
						sprintf(
							/* translators: 1: product SKU, 2: warehouse id */
							__( 'Duplicate SKU %1$s skipped in warehouse %2$s (first occurrence kept).', 'mvweb-price-importer' ),
							$sku,
							$wh_id
						),
						'warning'
					);
					continue;
				}
				$seen_in_wh[ $seen_key ] = true;

				if ( ! isset( $merged[ $sku ] ) ) {
					$merged[ $sku ]           = $product;
					$merged[ $sku ]['stocks'] = array();
				}

				// Per-warehouse stock.
				$merged[ $sku ]['stocks'][ $wh_id ] = $product['stock'];

				// Total stock = sum across warehouses (TZ 3.3).
				$merged[ $sku ]['stock'] = array_sum( $merged[ $sku ]['stocks'] );
			}
		}

		foreach ( $merged as $product ) {
			yield $product;
		}
	}

	/**
	 * Parse the PHP memory_limit ini value into bytes.
	 *
	 * Returns 0 when the limit is unlimited (-1) or unparseable.
	 *
	 * @since 1.0.0
	 * @param string $value Raw memory_limit value (e.g. "256M", "1G").
	 * @return int Memory limit in bytes, or 0 if unlimited/unknown.
	 */
	private function parse_memory_limit( string $value ): int {
		$value = trim( $value );
		if ( '' === $value || '-1' === $value ) {
			return 0;
		}

		$unit   = strtolower( substr( $value, -1 ) );
		$number = (int) $value;

		return match ( $unit ) {
			'g'     => $number * 1024 * 1024 * 1024,
			'm'     => $number * 1024 * 1024,
			'k'     => $number * 1024,
			default => $number,
		};
	}

	/**
	 * Extract unique categories from a source file (lightweight first pass).
	 *
	 * Reads only category-related columns from the file without full
	 * product normalization. For YML files, categories are already
	 * pre-parsed in the <categories> block — use Parser_YML::get_categories() instead.
	 *
	 * @since 1.1.0
	 * @param array<string, string> $source_files Map of warehouse_id => file_path.
	 * @param array<string, string> $mapping      Map of field_name => column_header.
	 * @return array[] Array of category arrays with keys: id, name, parent_id.
	 */
	public function categories_only( array $source_files, array $mapping ): array {
		$categories = array();
		$seen       = array();

		foreach ( $source_files as $file_path ) {
			$parser = MVweb_PI_Parser::create( $file_path );

			// YML parser has pre-parsed categories — use them directly.
			if ( $parser instanceof MVweb_PI_Parser_YML ) {
				$yml_cats = $parser->get_categories();
				foreach ( $yml_cats as $cat ) {
					$cat_id = (string) $cat['id'];
					if ( isset( $seen[ $cat_id ] ) ) {
						continue;
					}
					$seen[ $cat_id ] = true;
					$categories[]    = array(
						'id'        => $cat_id,
						'name'      => mvweb_pi_clean_text( (string) $cat['name'] ),
						'parent_id' => $cat['parentId'] ?? '',
					);
				}
				continue;
			}

			// CSV/XLSX: lightweight pass — read only category columns.
			$cat_col        = $mapping['category'] ?? '';
			$parent_cat_col = $mapping['parent_cat'] ?? '';

			if ( '' === $cat_col ) {
				continue;
			}

			foreach ( $parser->rows() as $raw_row ) {
				$cat_id = trim( (string) ( $raw_row[ $cat_col ] ?? '' ) );
				if ( '' === $cat_id ) {
					continue;
				}

				// Hierarchical path ("/Apple/iPhone/Проклейки"): register every
				// level as its own category with a path-as-id and parent links, so
				// a supplier that ships nested categories as a slash-path builds a
				// real tree instead of one flat category named after the whole path.
				// A plain id (no "/") keeps the original flat behaviour untouched.
				if ( str_contains( $cat_id, '/' ) ) {
					foreach ( $this->expand_category_path( $cat_id ) as $level ) {
						if ( isset( $seen[ $level['id'] ] ) ) {
							continue;
						}
						$seen[ $level['id'] ] = true;
						$categories[]         = $level;
					}
					continue;
				}

				if ( isset( $seen[ $cat_id ] ) ) {
					continue;
				}

				$seen[ $cat_id ] = true;

				$cat_name = $cat_id;
				// For CSV, category_name is typically the same column value.
				if ( isset( $raw_row['category_name'] ) ) {
					$cat_name = trim( (string) $raw_row['category_name'] );
				}

				$parent_id   = '' !== $parent_cat_col ? trim( (string) ( $raw_row[ $parent_cat_col ] ?? '' ) ) : '';
				$parent_name = $parent_id;
				if ( isset( $raw_row['parent_category_name'] ) ) {
					$parent_name = trim( (string) $raw_row['parent_category_name'] );
				}

				$categories[] = array(
					'id'        => sanitize_text_field( $cat_id ),
					'name'      => mvweb_pi_clean_text( $cat_name ),
					'parent_id' => sanitize_text_field( $parent_id ),
				);

				// Register parent category if not yet seen.
				if ( '' !== $parent_id && ! isset( $seen[ $parent_id ] ) ) {
					$seen[ $parent_id ] = true;
					$categories[]       = array(
						'id'        => sanitize_text_field( $parent_id ),
						'name'      => mvweb_pi_clean_text( $parent_name ),
						'parent_id' => '',
					);
				}
			}
		}

		return $categories;
	}

	/**
	 * Split a hierarchical category path into level records.
	 *
	 * "/Apple/iPhone/Проклейки" → three categories, each keyed by its own path
	 * ("/Apple", "/Apple/iPhone", "/Apple/iPhone/Проклейки") with the leaf
	 * segment as the display name and the parent path as parent_id. The path is
	 * the stable external id — it can't collide with a supplier's plain
	 * numeric/text ids, which never start with "/". normalize() canonicalises
	 * a product's category value the same way, so the product lands on the leaf.
	 *
	 * @since 1.0.0
	 * @param string $path Slash-separated category path.
	 * @return array<int, array{id: string, name: string, parent_id: string}>
	 */
	private function expand_category_path( string $path ): array {
		$segments = array_values(
			array_filter(
				array_map( 'trim', explode( '/', $path ) ),
				static function ( $segment ) {
					return '' !== $segment;
				}
			)
		);

		$levels = array();
		$parent = '';
		$acc    = '';
		foreach ( $segments as $segment ) {
			$acc     .= '/' . $segment;
			$levels[] = array(
				'id'        => sanitize_text_field( $acc ),
				'name'      => mvweb_pi_clean_text( $segment ),
				'parent_id' => sanitize_text_field( $parent ),
			);
			$parent = $acc;
		}

		return $levels;
	}

	/**
	 * Write checkpoint file (optional debug mode).
	 *
	 * Saves converted products to a CSV file for debugging
	 * and resumable import on batch failure.
	 *
	 * @since 1.0.0
	 * @param \Generator $products    Product generator.
	 * @param string     $destination Directory to write to.
	 * @return string Path to the created checkpoint file.
	 */
	public function save_checkpoint( \Generator $products, string $destination ): string {
		$uuid   = wp_generate_uuid4();
		$file   = $destination . "final_products-{$uuid}.csv";
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- checkpoint is debug-only file.
		$handle = fopen( $file, 'w' );

		if ( false === $handle ) {
			throw new \RuntimeException(
				sprintf( 'Cannot open checkpoint file for writing: %s', $file )
			);
		}

		$headers = null;

		foreach ( $products as $product ) {
			if ( null === $headers ) {
				$headers = array_keys( $product );
				// Convert stocks array to JSON for CSV.
				fputcsv( $handle, $headers );
			}

			$row = $product;
			// Serialize complex fields for CSV storage.
			if ( isset( $row['stocks'] ) && is_array( $row['stocks'] ) ) {
				$row['stocks'] = wp_json_encode( $row['stocks'] );
			}
			if ( isset( $row['gallery'] ) && is_array( $row['gallery'] ) ) {
				$row['gallery'] = implode( ',', $row['gallery'] );
			}

			fputcsv( $handle, $row );
		}

		fclose( $handle );
		return $file;
	}

	/**
	 * Write invalid rows to file (debug mode).
	 *
	 * @since 1.0.0
	 * @param string $destination Directory to write to.
	 * @return string Path to the created file, or empty string if no invalid rows.
	 */
	public function save_invalid_rows( string $destination ): string {
		if ( empty( $this->invalid_rows ) ) {
			return '';
		}

		$uuid   = wp_generate_uuid4();
		$file   = $destination . "invalid_rows-{$uuid}.csv";
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- debug-only file.
		$handle = fopen( $file, 'w' );

		if ( false === $handle ) {
			return '';
		}

		// Header row.
		fputcsv( $handle, array( 'reason', 'raw_data' ) );

		foreach ( $this->invalid_rows as $invalid ) {
			fputcsv(
				$handle,
				array(
					$invalid['reason'],
					wp_json_encode( $invalid['data'], JSON_UNESCAPED_UNICODE ),
				)
			);
		}

		fclose( $handle );
		return $file;
	}

	/**
	 * Get invalid rows collected during conversion.
	 *
	 * @since 1.0.0
	 * @return array[]
	 */
	public function get_invalid_rows(): array {
		return $this->invalid_rows;
	}

	/**
	 * Get duplicate SKUs found during conversion.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	public function get_duplicate_skus(): array {
		return $this->duplicate_skus;
	}

	/**
	 * Normalize a raw row from parser into unified product format.
	 *
	 * @since 1.0.0
	 * @param array  $raw     Raw row data from parser.
	 * @param array  $mapping Field mapping configuration.
	 * @param string $wh_id   Warehouse identifier.
	 * @return array|null Normalized product data, or null if invalid.
	 */
	private function normalize( array $raw, array $mapping, string $wh_id ): ?array {
		// Get mapped value helper.
		$get = function ( string $field ) use ( $raw, $mapping ): string {
			$column = $mapping[ $field ] ?? '';
			if ( '' === $column ) {
				return '';
			}
			return trim( (string) ( $raw[ $column ] ?? '' ) );
		};

		// Validate required fields (TZ 5.2).
		$sku = $get( 'sku' );
		if ( '' === $sku ) {
			// Empty SKU — can't be matched or tracked, so it's dropped. Record it
			// in invalid_rows so the operator sees a feed where the SKU column is
			// unmapped or an offer lost its id, instead of products silently
			// vanishing from the catalogue with no trace.
			$this->invalid_rows[] = array(
				'reason' => 'empty_sku',
				'data'   => $raw,
			);
			return null;
		}

		$price_raw = $get( 'price' );
		$price     = $this->parse_price( $price_raw );
		if ( null === $price || $price < 0 ) {
			$this->invalid_rows[] = array(
				'reason' => 'invalid_price',
				'data'   => $raw,
			);
			return null;
		}

		// Sale price handling.
		$sale_price_raw = $get( 'sale_price' );
		$sale_price     = '' !== $sale_price_raw ? $this->parse_price( $sale_price_raw ) : null;
		if ( null !== $sale_price && $sale_price <= 0 ) {
			$sale_price = null;
		}

		// Wholesale price: optional, stored on its own product meta. Kept fully
		// independent of the retail/sale price so it never influences what the
		// storefront charges. A missing or non-positive value means "not
		// supplied" and leaves any existing wholesale price untouched on update.
		$wholesale_raw   = $get( 'wholesale_price' );
		$wholesale_price = '' !== $wholesale_raw ? $this->parse_price( $wholesale_raw ) : null;
		if ( null !== $wholesale_price && $wholesale_price <= 0 ) {
			$wholesale_price = null;
		}

		// Stock: parse as integer, default 0.
		$stock = absint( $get( 'stock' ) );

		// Category: resolve name from raw data (YML provides category_name).
		$category_id   = sanitize_text_field( $get( 'category' ) );
		$category_name = trim( (string) ( $raw['category_name'] ?? '' ) );

		// Hierarchical path category ("/Apple/iPhone/Проклейки"): canonicalise the
		// id to the same leaf path expand_category_path() builds for the tree, and
		// default the display name to the leaf segment (not the whole path). A
		// plain id without "/" is untouched, so flat CSV/YML feeds are unchanged.
		if ( str_contains( $category_id, '/' ) ) {
			$segments = array_values(
				array_filter(
					array_map( 'trim', explode( '/', $category_id ) ),
					static function ( $segment ) {
						return '' !== $segment;
					}
				)
			);
			if ( ! empty( $segments ) ) {
				$category_id = '/' . implode( '/', $segments );
				if ( '' === $category_name ) {
					$category_name = end( $segments );
				}
			} else {
				// Path with no real segments ("/", "///"): no category to attach to
				// (categories_only() registers nothing for it either), so drop it
				// rather than leave the product pointing at a phantom id.
				$category_id = '';
			}
		}

		if ( '' === $category_name ) {
			$category_name = $category_id; // Fallback: use ID as name (CSV).
		}

		// Skip products belonging to user-excluded categories (or any of
		// their descendants). Done here, before any product fields touch
		// the DB, so an excluded category produces zero side effects. The
		// empty-category_id case is handled inside is_category_excluded():
		// in include mode a product with no category belongs to no ticked
		// branch and must be dropped; in exclude mode it is kept.
		if ( $this->is_category_excluded( $category_id ) ) {
			return null;
		}

		$parent_cat_id   = sanitize_text_field( $get( 'parent_cat' ) );
		$parent_cat_name = trim( (string) ( $raw['parent_category_name'] ?? '' ) );
		if ( '' === $parent_cat_name ) {
			$parent_cat_name = $parent_cat_id;
		}

		// Gallery: prefer the mapped column, but fall back to the raw
		// "gallery" key. The YML parser auto-splits multiple <picture>
		// tags into picture[0] → image + the rest → "gallery", so the
		// admin has no separate column to map. Without this fallback,
		// galleries from YML feeds were silently dropped.
		$gallery_raw = $get( 'gallery' );
		if ( '' === $gallery_raw ) {
			$gallery_raw = trim( (string) ( $raw['gallery'] ?? '' ) );
		}

		return array(
			// SKU and barcode stay byte-for-byte as supplied: they are matching
			// keys, and normalising them would stop us finding products already
			// imported under the raw value and create duplicates instead.
			'sku'             => sanitize_text_field( $sku ),
			'name'            => mvweb_pi_clean_text( $get( 'name' ) ),
			'description'     => mvweb_pi_clean_text( $get( 'description' ), true ),
			'price'           => $price,
			'sale_price'      => $sale_price,
			'wholesale_price' => $wholesale_price,
			'stock'           => $stock,
			'image'           => esc_url_raw( $get( 'image' ) ),
			'gallery'         => $this->parse_gallery( $gallery_raw ),
			'category_id'     => $category_id,
			'category_name'   => mvweb_pi_clean_text( $category_name ),
			'parent_cat_id'   => $parent_cat_id,
			'parent_cat_name' => mvweb_pi_clean_text( $parent_cat_name ),
			'barcode'         => sanitize_text_field( $get( 'barcode' ) ),
			'warehouse'       => $wh_id,
			'stocks'          => array( $wh_id => $stock ),
		);
	}

	/**
	 * Parse price string into float.
	 *
	 * Handles comma/dot decimal separators, spaces as thousand separators.
	 *
	 * @since 1.0.0
	 * @param string $value Raw price string.
	 * @return float|null Parsed price or null if not numeric.
	 */
	private function parse_price( string $value ): ?float {
		if ( '' === $value ) {
			return null;
		}

		// Remove currency symbols and whitespace.
		$value = preg_replace( '/[^\d.,\-]/', '', $value );

		// Handle comma as decimal separator (e.g. "1 234,56").
		if ( str_contains( $value, ',' ) && str_contains( $value, '.' ) ) {
			// Both present: assume last one is decimal separator.
			$last_comma = strrpos( $value, ',' );
			$last_dot   = strrpos( $value, '.' );
			if ( $last_comma > $last_dot ) {
				// Comma is decimal: "1.234,56" → "1234.56".
				$value = str_replace( '.', '', $value );
				$value = str_replace( ',', '.', $value );
			} else {
				// Dot is decimal: "1,234.56" → "1234.56".
				$value = str_replace( ',', '', $value );
			}
		} elseif ( str_contains( $value, ',' ) ) {
			// Only comma: could be decimal or thousand.
			// If one comma and digits after it are 1-2, treat as decimal.
			if ( preg_match( '/,(\d{1,2})$/', $value ) ) {
				$value = str_replace( ',', '.', $value );
			} else {
				$value = str_replace( ',', '', $value );
			}
		}

		if ( ! is_numeric( $value ) ) {
			return null;
		}

		return (float) $value;
	}

	/**
	 * Parse gallery URLs from a string.
	 *
	 * Supports comma-separated, semicolon-separated, and newline-separated URLs.
	 *
	 * @since 1.0.0
	 * @param string $value Raw gallery string.
	 * @return string[] Array of sanitized URLs.
	 */
	private function parse_gallery( string $value ): array {
		if ( '' === $value ) {
			return array();
		}

		// Split by comma, semicolon, or newline.
		$urls = preg_split( '/[,;\n]+/', $value );
		$urls = array_map( 'trim', $urls );
		$urls = array_filter( $urls );
		$urls = array_map( 'esc_url_raw', $urls );
		$urls = array_filter( $urls );

		return array_values( $urls );
	}

	/**
	 * Check whether a category (or any of its ancestors) is on the user's
	 * exclusion list.
	 *
	 * Walks the parent chain in `mvweb_pi_category_meta` so that excluding
	 * a top-level category implicitly excludes every nested category and
	 * the user doesn't have to tick each child manually. The resolved set
	 * is memoised on the instance — `normalize()` runs millions of times
	 * across a large catalog, so re-walking on every call is unaffordable.
	 *
	 * Guarded against malformed parent loops with a depth cap of 32 — far
	 * deeper than any real category tree.
	 *
	 * @since 1.0.0
	 * @since 1.1.0 Honours the include/exclude filter mode.
	 * @param string $category_id External category id from the price list.
	 * @return bool True if the product in this category must be dropped.
	 */
	private function is_category_excluded( string $category_id ): bool {
		if ( null === $this->excluded_set ) {
			$this->excluded_set = $this->build_excluded_closure();
		}

		if ( null === $this->filter_mode ) {
			$mode              = get_option( 'mvweb_pi_category_filter_mode', 'exclude' );
			$this->filter_mode = ( 'include' === $mode ) ? 'include' : 'exclude';
		}

		// No ticked categories: in exclude mode nothing is dropped; in include
		// mode an empty whitelist would wipe the whole catalogue, which is never
		// what the operator means — treat it as "no filter" too.
		if ( empty( $this->excluded_set ) ) {
			return false;
		}

		if ( null === $this->category_meta ) {
			$meta                = get_option( 'mvweb_pi_category_meta', array() );
			$this->category_meta = is_array( $meta ) ? $meta : array();
		}

		// Walk up the parent chain: does this category sit under any ticked one?
		$in_set  = false;
		$current = $category_id;
		$depth   = 0;

		while ( '' !== $current && $depth < 32 ) {
			if ( isset( $this->excluded_set[ $current ] ) ) {
				$in_set = true;
				break;
			}
			$current = (string) ( $this->category_meta[ $current ]['parent_id'] ?? '' );
			++$depth;
		}

		// exclude mode: drop when under a ticked branch.
		// include mode: drop when NOT under a ticked branch.
		return ( 'include' === $this->filter_mode ) ? ! $in_set : $in_set;
	}

	/**
	 * Build the resolved excluded-categories set.
	 *
	 * Takes the raw list from `mvweb_pi_excluded_categories` (only the
	 * categories the user explicitly ticked) and returns them keyed by
	 * external_id => true for O(1) lookup. Descendant resolution happens
	 * at lookup time in {@see is_category_excluded()} — we walk *upward*
	 * from each product's category, which is cheap and avoids precomputing
	 * the full closure when most categories are not excluded.
	 *
	 * @since 1.0.0
	 * @return array<string, true>
	 */
	private function build_excluded_closure(): array {
		$raw = get_option( 'mvweb_pi_excluded_categories', array() );
		if ( ! is_array( $raw ) || empty( $raw ) ) {
			return array();
		}

		$set = array();
		foreach ( $raw as $id ) {
			$id = (string) $id;
			if ( '' !== $id ) {
				$set[ $id ] = true;
			}
		}

		return $set;
	}
}
