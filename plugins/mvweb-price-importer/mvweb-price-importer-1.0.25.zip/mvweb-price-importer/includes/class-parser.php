<?php
/**
 * Parser factory — Strategy pattern for file format parsers.
 *
 * Creates appropriate parser instance based on file format.
 * Provides auto-detection of columns for field mapping.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Parser
 *
 * Factory class that creates the appropriate parser based on file format
 * and provides column auto-detection for field mapping.
 *
 * @since 1.0.0
 */
class MVweb_PI_Parser {

	/**
	 * Create a parser instance for the given file.
	 *
	 * @since 1.0.0
	 * @param string $file_path Path to the file to parse.
	 * @return MVweb_PI_Parser_CSV|MVweb_PI_Parser_YML|MVweb_PI_Parser_XLSX Parser instance.
	 * @throws \InvalidArgumentException If file format is not supported.
	 */
	public static function create( string $file_path ): MVweb_PI_Parser_CSV|MVweb_PI_Parser_YML|MVweb_PI_Parser_XLSX|MVweb_PI_Parser_XLS {
		$ext = strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );

		return match ( $ext ) {
			'csv', 'txt' => new MVweb_PI_Parser_CSV( $file_path ),
			'yml', 'xml' => new MVweb_PI_Parser_YML( $file_path ),
			'xlsx'       => new MVweb_PI_Parser_XLSX( $file_path ),
			'xls'        => new MVweb_PI_Parser_XLS( $file_path ),
			default      => throw new \InvalidArgumentException(
				/* translators: %s: file extension */
				sprintf( __( 'Unsupported file format: %s', 'mvweb-price-importer' ), $ext )
			),
		};
	}

	/**
	 * Auto-detect columns in a file for field mapping.
	 *
	 * Scans file headers and matches them against known keywords
	 * in English and Russian for automatic mapping suggestions.
	 *
	 * @since 1.0.0
	 * @param string $file_path Path to the file to scan.
	 * @return array{headers: string[], detected: array<string, string>} Headers and detected mapping.
	 */
	public static function detect_columns( string $file_path ): array {
		$parser  = self::create( $file_path );
		$headers = $parser->get_headers();

		// Keywords for each WooCommerce field (EN + RU).
		$keywords = array(
			// Order matters: the first keyword that matches a column wins, so a
			// dedicated code column is picked before the generic offer id. In
			// YML the `id` attribute of <offer> doubles as the article number
			// when the supplier ships no vendorCode, but whenever a real code
			// column exists it must take precedence.
			'sku'         => array( 'sku', 'артикул', 'vendorcode', 'vendor_code', 'article', 'код товара', 'код', 'code', 'id' ),
			'name'        => array( 'name', 'наименование', 'название', 'title', 'товар', 'product', 'offer' ),
			'description' => array( 'description', 'описание', 'desc', 'text' ),
			'price'       => array( 'price', 'цена', 'стоимость', 'розничная', 'retail', 'cost' ),
			'sale_price'  => array( 'sale_price', 'old_price', 'oldprice', 'старая цена', 'скидка', 'акция', 'sale', 'discount' ),
			'wholesale_price' => array( 'wholesale', 'wholesale_price', 'optovaya', 'opt_price', 'price_opt', 'opt_cena', 'опт', 'оптовая', 'оптовая цена', 'опт. цена', 'опт цена', 'b2b' ),
			'stock'       => array( 'stock', 'остаток', 'количество', 'qty', 'quantity', 'наличие', 'count', 'amount' ),
			'image'       => array( 'image', 'фото', 'картинка', 'picture', 'img', 'изображение', 'изображения', 'photo', 'thumbnail' ),
			'gallery'     => array( 'gallery', 'галерея', 'images', 'фотографии', 'pictures', 'дополнительные фото' ),
			'category'    => array( 'category', 'категория', 'cat', 'group', 'группа', 'раздел', 'categoryid' ),
			'parent_cat'  => array( 'parent_category', 'родительская категория', 'parent_cat', 'parentid', 'parent' ),
			'barcode'     => array( 'barcode', 'штрих-код', 'штрихкод', 'ean', 'upc', 'gtin', 'isbn' ),
		);

		// Two-pass matching, exact before substring. Several price fields share
		// the substring «цена» (price/цена, sale_price/старая цена,
		// wholesale_price/оптовая цена), so a pure substring scan could source
		// the retail price from a wholesale/old-price column whenever it sits
		// first in the file — a costly mis-map. Pass 1 locks in exact header
		// matches; pass 2 fills the rest by substring. A header claimed by one
		// field can't be reclaimed by another, so each column maps once.
		$detected = array();
		$claimed  = array();

		// Compare against a normalised header, but always map to the ORIGINAL
		// one: the saved mapping stores the exact header and rows are read as
		// $raw[$column], so cleaning the header itself would break every mapping
		// already saved on a live site. A column titled «Розничная<nbsp>цена»
		// only matches once the invisible characters are out of the way.
		$normalised = array();
		foreach ( $headers as $header ) {
			$normalised[ $header ] = mb_strtolower( trim( mvweb_pi_clean_text( (string) $header ) ) );
		}

		// Pass 1 — exact match, keywords in priority order. The keyword loop is
		// the outer one on purpose: it makes the FIRST keyword of a field win,
		// so «vendorCode» beats the generic «id» no matter which of them comes
		// first in the file.
		foreach ( $keywords as $field => $words ) {
			foreach ( $words as $word ) {
				foreach ( $headers as $header ) {
					if ( isset( $claimed[ $header ] ) ) {
						continue;
					}
					if ( $word === ( $normalised[ $header ] ?? '' ) ) {
						$detected[ $field ] = $header;
						$claimed[ $header ] = true;
						break 2;
					}
				}
			}
		}

		// Pass 2 — substring, only for fields still unmapped and free headers.
		foreach ( $keywords as $field => $words ) {
			if ( isset( $detected[ $field ] ) ) {
				continue;
			}
			foreach ( $words as $word ) {
				foreach ( $headers as $header ) {
					if ( isset( $claimed[ $header ] ) ) {
						continue;
					}
					if ( str_contains( $normalised[ $header ] ?? '', $word ) ) {
						$detected[ $field ] = $header;
						$claimed[ $header ] = true;
						break 2;
					}
				}
			}
		}

		return array(
			'headers'  => $headers,
			'detected' => $detected,
		);
	}
}
