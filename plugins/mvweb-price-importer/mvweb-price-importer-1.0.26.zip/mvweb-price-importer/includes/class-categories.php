<?php
/**
 * Categories class — WooCommerce category import.
 *
 * Imports categories with hierarchy support, handles duplicates,
 * and maps external IDs to WooCommerce term_ids.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Categories
 *
 * Handles importing product categories from price lists into WooCommerce.
 * Supports hierarchical categories, external ID mapping via term meta,
 * duplicate name handling, and cache optimization for bulk operations.
 *
 * @since 1.0.0
 */
class MVweb_PI_Categories {

	/**
	 * In-memory cache: external_id => WooCommerce term_id.
	 *
	 * Populated during import to avoid repeated DB queries.
	 *
	 * @since 1.0.0
	 * @var array<string, int>
	 */
	private array $cache = array();

	/**
	 * Import categories from product data.
	 *
	 * Extracts unique categories from products, sorts by hierarchy depth
	 * (parents first), creates/maps terms, and persists the mapping
	 * to wp_options for use by the Importer class.
	 *
	 * Uses wp_suspend_cache_invalidation() to prevent hundreds of
	 * clean_term_cache() calls during bulk creation (TZ 7.4).
	 *
	 * @since 1.0.0
	 * @param array[] $categories Array of category arrays with keys: id, name, parent_id.
	 * @return void
	 */
	public function import( array $categories ): void {
		if ( empty( $categories ) ) {
			return;
		}

		// Persist the FULL feed tree to the sidecar first, before any filtering.
		// `mvweb_pi_category_meta` is the id => [name, parent_id] map the
		// converter walks UP to decide whether a product's category sits under a
		// ticked branch — and that walk must see every ancestor, including ones
		// in un-ticked branches. It also feeds the Settings UI tree and the
		// root-flatten lookup. If we stored only the filtered subset here, the
		// parent chain would break for any category outside the ticked branches
		// and the product filter would misclassify rows. So the sidecar always
		// holds the whole tree; the include/exclude filter below only governs
		// which terms get CREATED, never what the tree map contains.
		$this->persist_full_tree( $categories );

		// Category filter (include/exclude): drop categories that fall outside
		// the ticked branches before any term is created, so the catalogue never
		// gets empty wrapper terms from un-ticked branches of the feed. This only
		// affects term creation — the full tree is already in the sidecar above.
		$categories = $this->apply_category_filter( $categories );
		if ( empty( $categories ) ) {
			return;
		}

		// Root-flatten: categories the operator marked to "lift children to the
		// top". The category itself is never created as a term; its direct
		// children become top-level (parent_id cleared) while the rest of the
		// branch keeps its internal hierarchy. Used to import only the contents
		// of a wrapper category (e.g. "Для выгрузки") without that wrapper
		// showing up in the catalogue.
		$categories = $this->apply_root_flatten( $categories );

		// Pre-load existing category map from DB.
		$this->load_cache();

		// Optimize: suspend cache invalidation during bulk operations (TZ 7.4).
		wp_suspend_cache_invalidation( true );

		// Build a topological order so every parent is created before its
		// children. The previous approach was a single usort() that only
		// distinguished "no parent" vs "has parent" — fine for a 2-level
		// tree, but on a 3+ level tree (the ns60.ru supplier has 320
		// categories ~3 levels deep) a level-3 child could still appear
		// before its level-2 parent, get inserted as a root, then collide
		// with same-named siblings further down the feed via term_exists
		// and ultimately drop most categories with "missing_parent" errors.
		$by_id = array();
		foreach ( $categories as $cat ) {
			if ( ! empty( $cat['id'] ) ) {
				$by_id[ (string) $cat['id'] ] = $cat;
			}
		}
		usort( $categories, function ( $a, $b ) use ( $by_id ) {
			$depth_a = $this->resolve_depth( $a, $by_id, array() );
			$depth_b = $this->resolve_depth( $b, $by_id, array() );
			if ( $depth_a === $depth_b ) {
				return 0;
			}
			return $depth_a < $depth_b ? -1 : 1;
		} );

		// Sidecar (mvweb_pi_category_meta) was already written with the full
		// feed tree by persist_full_tree() above — we do not touch it again
		// here, so the filtered term-creation loop below can't shrink it.

		// Multi-pass: keep walking the unprocessed queue until either every
		// category is in cache or a full pass made no progress. WordPress's
		// object cache and our in-memory $this->cache can briefly disagree
		// across consecutive wp_insert_term() calls inside the same request
		// (parent rows pending in the persistent cache), and one pass over
		// a deep tree is enough to lose a handful of late children to
		// "missing_parent". A second pass picks them up once every parent
		// in the cache map points at a row that's already flushed to DB.
		$created = 0;
		$mapped  = 0;
		$pending = $categories;
		for ( $pass = 0; $pass < 5 && ! empty( $pending ); $pass++ ) {
			$next        = array();
			$pass_change = false;
			foreach ( $pending as $cat ) {
				if ( empty( $cat['id'] ) || empty( $cat['name'] ) ) {
					continue;
				}

				$was_cached = isset( $this->cache[ $cat['id'] ] );
				$term_id    = $this->get_or_create( $cat );

				if ( $term_id > 0 ) {
					if ( $was_cached ) {
						if ( 0 === $pass ) {
							++$mapped;
						}
					} else {
						++$created;
						$pass_change = true;
					}

					// Sidecar already holds the full tree (persist_full_tree);
					// nothing to refresh per-term here.
					continue;
				}

				// Failed this round — push to the next pass.
				$next[] = $cat;
			}

			// Promote the still-unprocessed queue before the no-progress
			// break: when every category resolved this pass (e.g. a re-import
			// where all 320 are already cached), $next is empty and $pending
			// must reflect that, otherwise the "could not be imported" log
			// below fires on a queue that was actually fully processed.
			$pending = $next;
			if ( ! $pass_change ) {
				break;
			}
		}

		// Surface any categories the multi-pass loop couldn't import.
		// Without this they'd be silently dropped — the symptom downstream
		// would be products with category_id pointing nowhere. Logging
		// makes the operator aware that the supplier feed has either a
		// real WP-side error other than missing_parent (out-of-memory,
		// taxonomy-locked, etc.) or a structural problem we can't fix
		// here, and lets them decide whether to investigate or accept.
		if ( ! empty( $pending ) ) {
			$names = array();
			foreach ( $pending as $cat ) {
				$names[] = (string) ( $cat['name'] ?? $cat['id'] ?? '?' );
			}
			mvweb_pi_log(
				sprintf(
					/* translators: 1: count of unprocessed categories, 2: sample of names */
					__( '%1$d categories could not be imported after the multi-pass loop. First few: %2$s', 'mvweb-price-importer' ),
					count( $pending ),
					implode( ', ', array_slice( $names, 0, 10 ) )
				),
				'error'
			);
		}

		// Sidecar (mvweb_pi_category_meta) is persisted by persist_full_tree()
		// at the top of import(); no write here.

		// Restore cache invalidation and flush only the product_cat terms we
		// touched, not the entire object cache. The original wp_cache_flush()
		// invalidated caches of every other plugin on the site and caused
		// noticeable load spikes on busy stores.
		wp_suspend_cache_invalidation( false );
		if ( ! empty( $this->cache ) ) {
			clean_term_cache( array_values( $this->cache ), 'product_cat' );
		}

		// Persist the full mapping to wp_options for Importer::resolve_category().
		$this->save_cache();

		if ( $created > 0 || $mapped > 0 ) {
			mvweb_pi_log(
				sprintf(
					/* translators: 1: number of categories processed, 2: number created */
					__( 'Categories import: %1$d processed, %2$d created.', 'mvweb-price-importer' ),
					count( $categories ),
					$created
				),
				'info'
			);
		}
	}

	/**
	 * Persist the full feed category tree to the mvweb_pi_category_meta sidecar.
	 *
	 * Stores every category from the feed as id => [name, parent_id], regardless
	 * of the include/exclude filter. The converter walks this map UP from a
	 * product's category to decide whether it sits under a ticked branch, so the
	 * map must contain the complete ancestry — including branches that won't get
	 * terms created. The Settings UI tree and root-flatten lookup read it too.
	 *
	 * @since 1.0.16
	 * @param array[] $categories Full feed categories with keys: id, name, parent_id.
	 * @return void
	 */
	private function persist_full_tree( array $categories ): void {
		$meta = array();
		foreach ( $categories as $cat ) {
			$id = isset( $cat['id'] ) ? (string) $cat['id'] : '';
			if ( '' === $id ) {
				continue;
			}
			$meta[ $id ] = array(
				'name'      => isset( $cat['name'] ) ? (string) $cat['name'] : $id,
				'parent_id' => isset( $cat['parent_id'] ) ? (string) $cat['parent_id'] : '',
			);
		}

		if ( ! empty( $meta ) ) {
			update_option( 'mvweb_pi_category_meta', $meta, false );
		}
	}

	/**
	 * Drop categories that fall outside the configured include/exclude filter.
	 *
	 * Walks each category's parent chain (built from the feed itself, so it
	 * works before mvweb_pi_category_meta is written) and keeps or drops the
	 * whole branch consistently with the per-product filter in the converter:
	 *
	 * - exclude mode: drop a category if it sits under any ticked branch.
	 * - include mode: drop a category unless it sits under a ticked branch.
	 *
	 * Empty ticked set means "no filter" — return the tree untouched, mirroring
	 * the converter so an empty whitelist never wipes the catalogue.
	 *
	 * @since 1.0.16
	 * @param array[] $categories Feed categories with keys: id, name, parent_id.
	 * @return array[] Filtered categories.
	 */
	private function apply_category_filter( array $categories ): array {
		$raw = get_option( 'mvweb_pi_excluded_categories', array() );
		if ( ! is_array( $raw ) || empty( $raw ) ) {
			return $categories;
		}

		$ticked = array();
		foreach ( $raw as $id ) {
			$id = (string) $id;
			if ( '' !== $id ) {
				$ticked[ $id ] = true;
			}
		}
		if ( empty( $ticked ) ) {
			return $categories;
		}

		$mode    = get_option( 'mvweb_pi_category_filter_mode', 'exclude' );
		$include = ( 'include' === $mode );

		$parent_of = array();
		foreach ( $categories as $cat ) {
			$id = isset( $cat['id'] ) ? (string) $cat['id'] : '';
			if ( '' !== $id ) {
				$parent_of[ $id ] = isset( $cat['parent_id'] ) ? (string) $cat['parent_id'] : '';
			}
		}

		$result = array();
		foreach ( $categories as $cat ) {
			$id = isset( $cat['id'] ) ? (string) $cat['id'] : '';

			$in_set  = false;
			$current = $id;
			$depth   = 0;
			while ( '' !== $current && $depth < 32 ) {
				if ( isset( $ticked[ $current ] ) ) {
					$in_set = true;
					break;
				}
				$current = $parent_of[ $current ] ?? '';
				++$depth;
			}

			$drop = $include ? ! $in_set : $in_set;
			if ( ! $drop ) {
				$result[] = $cat;
			}
		}

		return $result;
	}

	/**
	 * Apply the root-flatten rule to the category list.
	 *
	 * For every external id in `mvweb_pi_flatten_roots`: drop the category
	 * itself from the list (so no term is created for it) and clear the
	 * parent_id of its direct children (so they become top-level). The rest
	 * of each branch keeps its hierarchy because only the direct children
	 * pointed at the flattened category.
	 *
	 * @since 1.1.0
	 * @param array[] $categories Category arrays with keys: id, name, parent_id.
	 * @return array[] The transformed list.
	 */
	private function apply_root_flatten( array $categories ): array {
		$roots = get_option( 'mvweb_pi_flatten_roots', array() );
		if ( ! is_array( $roots ) || empty( $roots ) ) {
			return $categories;
		}

		$flatten = array();
		foreach ( $roots as $id ) {
			$id = (string) $id;
			if ( '' !== $id ) {
				$flatten[ $id ] = true;
			}
		}

		if ( empty( $flatten ) ) {
			return $categories;
		}

		$result = array();
		foreach ( $categories as $cat ) {
			$id = isset( $cat['id'] ) ? (string) $cat['id'] : '';

			// Skip the flattened category itself — it must not become a term.
			if ( '' !== $id && isset( $flatten[ $id ] ) ) {
				continue;
			}

			// Direct children of a flattened category become top-level.
			$parent_id = isset( $cat['parent_id'] ) ? (string) $cat['parent_id'] : '';
			if ( '' !== $parent_id && isset( $flatten[ $parent_id ] ) ) {
				$cat['parent_id'] = '';
			}

			$result[] = $cat;
		}

		return $result;
	}

	/**
	 * Get or create a WooCommerce product category from external data.
	 *
	 * Lookup order:
	 * 1. In-memory cache (fastest).
	 * 2. Term meta mvweb_pi_external_id (previously imported).
	 * 3. Create new term (with duplicate name handling, TZ 7.2).
	 *
	 * @since 1.0.0
	 * @param array $cat Category data with keys: id, name, parent_id.
	 * @return int WooCommerce term_id, or 0 on failure.
	 */
	public function get_or_create( array $cat ): int {
		$external_id = (string) $cat['id'];

		// Resolve parent term_id once up-front so both the cache-hit and
		// the create paths can use it (cache hit needs it to detect a
		// supplier moving a category to a new parent).
		$parent_term_id = 0;
		if ( ! empty( $cat['parent_id'] ) ) {
			$parent_term_id = $this->cache[ (string) $cat['parent_id'] ] ?? 0;
		}

		// Decode before sanitising, never the other way round: sanitising an
		// still-encoded string filters nothing, and decoding afterwards would
		// put back whatever the encoding was hiding.
		$name = mvweb_pi_clean_text( (string) $cat['name'] );

		// 1. Check in-memory cache. Validate that the cached term still
		// exists in wp_term_taxonomy — after a manual DB cleanup, sync
		// from a fresh dump, or DROP/TRUNCATE on terms while the option
		// survives, the cache can hold ids that point to deleted terms.
		// Use term_exists() instead of get_term() so we don't pay the
		// full term hydration cost on the hot path.
		if ( isset( $this->cache[ $external_id ] ) ) {
			$cached_id = (int) $this->cache[ $external_id ];
			if ( $cached_id > 0 && term_exists( $cached_id, 'product_cat' ) ) {
				$this->sync_term_attributes( $cached_id, $name, $parent_term_id );
				return $cached_id;
			}
			// Stale — drop and fall through to recreate.
			unset( $this->cache[ $external_id ] );
		}

		// 2. Check term meta for previously imported category.
		$existing = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'meta_key'   => 'mvweb_pi_external_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value' => $external_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'hide_empty' => false,
				'fields'     => 'ids',
				'number'     => 1,
			)
		);

		if ( ! empty( $existing ) && ! is_wp_error( $existing ) ) {
			$this->cache[ $external_id ] = $existing[0];
			$this->sync_term_attributes( (int) $existing[0], $name, $parent_term_id );
			return $existing[0];
		}

		// 3. Create new term with a short, readable, transliterated slug.
		//
		// A supplier feed routinely lists the same leaf name ("15 Pro") under
		// many branches. WordPress requires a globally-unique product_cat slug,
		// so if we leave the slug empty it auto-appends the whole parent path to
		// deduplicate; with Cyrillic parents that url-encoded slug overflows the
		// 200-char slug column and the insert dies with db_insert_error, losing
		// the leaf. We instead transliterate the name to a clean ASCII slug
		// ("15-pro") and, on collision, prefix it with the parent slug
		// ("frontalnaya-kamera-15-pro") — readable, SEO-friendly, and short.
		$base = $this->build_slug( $name );
		$slug = $base;
		if ( term_exists( $slug, 'product_cat' ) ) {
			$parent_slug = '';
			if ( $parent_term_id > 0 ) {
				$pterm = get_term( $parent_term_id, 'product_cat' );
				if ( $pterm && ! is_wp_error( $pterm ) ) {
					$parent_slug = $pterm->slug;
				}
			}
			$slug = '' !== $parent_slug ? $parent_slug . '-' . $base : $base . '-' . substr( md5( $external_id ), 0, 6 );
			$slug = mb_substr( $slug, 0, 190 );
		}
		$result = wp_insert_term(
			$name,
			'product_cat',
			array(
				'parent' => $parent_term_id,
				'slug'   => $slug,
			)
		);

		if ( is_wp_error( $result ) ) {
			// term_exists here means a previous import already created our own
			// term (same slug, derived from the same external_id) — reuse it.
			if ( 'term_exists' === $result->get_error_code() ) {
				$term_id = (int) $result->get_error_data();
				if ( $term_id > 0 ) {
					update_term_meta( $term_id, 'mvweb_pi_external_id', $external_id );
					$this->cache[ $external_id ] = $term_id;
					return $term_id;
				}
				return 0;
			}

			// Other error — log and return 0.
			mvweb_pi_log(
				sprintf(
					/* translators: 1: category name, 2: error message */
					__( 'Failed to create category "%1$s": %2$s', 'mvweb-price-importer' ),
					$name,
					$result->get_error_message()
				),
				'error'
			);
			return 0;
		}

		$term_id = (int) $result['term_id'];
		update_term_meta( $term_id, 'mvweb_pi_external_id', $external_id );
		$this->cache[ $external_id ] = $term_id;

		return $term_id;
	}

	/**
	 * Build a clean, transliterated, SEO-friendly slug from a category name.
	 *
	 * sanitize_title() leaves Cyrillic url-encoded ("ф" -> "%d1%84") on hosts
	 * without a transliteration filter, which bloats slugs past the 200-char
	 * column. We transliterate Russian to ASCII first so the slug is short and
	 * readable ("Фронтальная камера" -> "frontalnaya-kamera"), then hand off to
	 * sanitize_title() for the final normalisation.
	 *
	 * @since 1.1.0
	 * @param string $name Category name.
	 * @return string ASCII slug, or 'cat' if the name has no slug-able chars.
	 */
	private function build_slug( string $name ): string {
		$map = array(
			'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd',
			'е' => 'e', 'ё' => 'e', 'ж' => 'zh', 'з' => 'z', 'и' => 'i',
			'й' => 'y', 'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n',
			'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't',
			'у' => 'u', 'ф' => 'f', 'х' => 'h', 'ц' => 'c', 'ч' => 'ch',
			'ш' => 'sh', 'щ' => 'sch', 'ъ' => '', 'ы' => 'y', 'ь' => '',
			'э' => 'e', 'ю' => 'yu', 'я' => 'ya',
		);
		$name = strtr( mb_strtolower( $name, 'UTF-8' ), $map );
		$slug = sanitize_title( $name );
		// Keep base slugs well under the 200-char slug column; the collision
		// path may still prepend a parent slug on top of this.
		$slug = mb_substr( $slug, 0, 150 );

		return '' === $slug ? 'cat' : $slug;
	}

	/**
	 * Get WooCommerce term_id by external category ID.
	 *
	 * Used by the Importer class to resolve category assignments.
	 *
	 * @since 1.0.0
	 * @param string $external_id External category ID from the price list.
	 * @return int Term ID or 0 if not mapped.
	 */
	public function get_term_id( string $external_id ): int {
		return $this->cache[ $external_id ] ?? 0;
	}

	/**
	 * Load category map from wp_options into in-memory cache.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function load_cache(): void {
		$saved = get_option( 'mvweb_pi_category_map', array() );
		if ( is_array( $saved ) ) {
			$this->cache = array_map( 'absint', $saved );
		}
	}

	/**
	 * Persist in-memory cache to wp_options.
	 *
	 * Used by Importer::resolve_category() via mvweb_pi_category_map.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function save_cache(): void {
		// `autoload = false` keeps the map out of every bootstrap query:
		// on a 320-category supplier the serialised array is tens of KB,
		// and the option is only ever read inside an import / category
		// lookup — never on a public request.
		update_option( 'mvweb_pi_category_map', $this->cache, false );
	}

	/**
	 * Compute a category's depth in the supplier tree.
	 *
	 * Categories without a parent are depth 0, their direct children are
	 * depth 1, and so on. Parent ids that point outside the current feed
	 * snapshot (a supplier-side orphan) collapse the node to depth 0 so
	 * it still imports as a root rather than getting stuck waiting for a
	 * parent that will never arrive. The recursion is guarded against
	 * cycles in the feed via the `$visited` set; once a loop is detected
	 * the offending node falls back to depth 0.
	 *
	 * Used by `import()` to topologically sort the feed snapshot so
	 * `wp_insert_term()` always sees its parent in cache.
	 *
	 * @since 1.0.8
	 * @param array              $cat     Category row from the parser.
	 * @param array<string,array> $by_id  Lookup `external_id => row` for every category in the snapshot.
	 * @param array<string,bool> $visited Set of ids already crossed on this branch (cycle guard).
	 * @return int Depth (0-based).
	 */
	private function resolve_depth( array $cat, array $by_id, array $visited ): int {
		$parent_id = isset( $cat['parent_id'] ) ? (string) $cat['parent_id'] : '';
		if ( '' === $parent_id || ! isset( $by_id[ $parent_id ] ) ) {
			return 0;
		}
		$self_id = isset( $cat['id'] ) ? (string) $cat['id'] : '';
		if ( '' !== $self_id ) {
			if ( isset( $visited[ $self_id ] ) ) {
				return 0;
			}
			$visited[ $self_id ] = true;
		}
		return 1 + $this->resolve_depth( $by_id[ $parent_id ], $by_id, $visited );
	}

	/**
	 * Sync an existing term's name and parent with the supplier feed.
	 *
	 * Suppliers occasionally move a category under a different parent
	 * without changing the external id; the term must follow that change so
	 * the catalogue hierarchy stays in step with the feed (parent is keyed by
	 * id, not name, so this never fights a local rename).
	 *
	 * The category NAME is intentionally NOT synced here: it is set once by
	 * `wp_insert_term()` when the category is first created and then left
	 * alone, so an operator who renames a category on their own site (while
	 * the supplier feed keeps the original label) keeps that rename across
	 * imports. The external-id binding still prevents duplicates regardless
	 * of the displayed name.
	 *
	 * The one exception is leftover encoding damage in the stored name. A
	 * category created before text normalisation existed keeps its `&quot;` and
	 * non-breaking spaces forever, because the name is never re-synced. So the
	 * stored name is compared against its OWN cleaned form — not against the
	 * feed — and rewritten only when cleaning actually changes something. A
	 * deliberate local rename survives untouched; only the mangling goes away.
	 *
	 * @since 1.0.7
	 * @since 1.1.0 Stops overwriting the name on re-import — only parent is synced.
	 * @since 1.0.25 Repairs encoding damage left in an existing name.
	 * @since 1.0.26 Compares on the stored side of `pre_term_name`, so a name
	 *               WordPress keeps encoded is no longer rewritten every import.
	 * @param int    $term_id        Existing product_cat term id.
	 * @param string $expected_name  Cleaned feed name (unused; kept for signature stability).
	 * @param int    $expected_parent Resolved feed parent term id (0 = top).
	 * @return void
	 */
	private function sync_term_attributes( int $term_id, string $expected_name, int $expected_parent ): void {
		unset( $expected_name );

		if ( $term_id <= 0 ) {
			return;
		}
		$term = get_term( $term_id, 'product_cat' );
		if ( ! $term || is_wp_error( $term ) ) {
			return;
		}

		$updates = array();

		if ( (int) $term->parent !== $expected_parent ) {
			$updates['parent'] = $expected_parent;
		}

		// Ask the only question that matters: would saving the cleaned name change
		// what is already in the table? WordPress encodes a name on its way in
		// (`pre_term_name` runs _wp_specialchars), so the comparison has to happen
		// on the stored side of that filter — otherwise names WordPress keeps
		// encoded on purpose ("Тайд &amp; Ко", "Провод &lt;5мм") look different
		// from their cleaned form on every run and get rewritten forever.
		//
		// The filter expects slashed input and returns slashed output (kses round-
		// trips through addslashes), so the value is slashed going in and unslashed
		// coming out — otherwise a name holding a double quote («10.1"») comes back
		// with a stray backslash and never matches what is stored.
		$stored  = (string) $term->name;
		$cleaned = mvweb_pi_clean_text( $stored );
		$as_saved = wp_unslash( apply_filters( 'pre_term_name', wp_slash( $cleaned ), 'product_cat' ) );
		if ( '' !== $cleaned && $as_saved !== $stored ) {
			$updates['name'] = $cleaned;
		}

		if ( ! empty( $updates ) ) {
			wp_update_term( $term_id, 'product_cat', $updates );
		}
	}
}
