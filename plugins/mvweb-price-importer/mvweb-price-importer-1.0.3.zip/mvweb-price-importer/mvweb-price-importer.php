<?php
/**
 * Plugin Name:       MVweb Price Importer
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-price-importer
 * Description:       Automatic import of products from external price lists into WooCommerce.
 * Version:           1.0.3
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Requires Plugins:  woocommerce
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-price-importer
 * Domain Path:       /languages
 *
 * @package mvweb_pi
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_PI_VERSION' ) ) {
	return;
}

/**
 * Plugin version.
 */
define( 'MVWEB_PI_VERSION', '1.0.3' );

/**
 * Plugin directory path.
 */
define( 'MVWEB_PI_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Plugin directory URL.
 */
define( 'MVWEB_PI_URL', plugin_dir_url( __FILE__ ) );

/**
 * Plugin basename.
 */
define( 'MVWEB_PI_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_PI_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_PI_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_PI_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
// Do NOT rely on get_instance() at end of class file — OPcache may skip it.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_PI_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_PI_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-price-importer' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-price-importer'] = array(
		'name'         => 'MVweb Price Importer',
		'description'  => __( 'Automatic import of products from external price lists.', 'mvweb-price-importer' ),
		'url'          => 'https://mvweb.ru/plugins/mvweb-price-importer',
		'settings_url' => 'admin.php?page=mvweb-price-importer',
		'textdomain'   => 'mvweb-price-importer',
	);
	return $plugins;
} );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-price-importer',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_pi_load_textdomain' );

/**
 * Register plugin submenu under MVweb Hub.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_register_menu() {
	$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

	add_submenu_page(
		$parent_slug,
		__( 'MVweb Price Importer', 'mvweb-price-importer' ),
		__( 'Price Importer', 'mvweb-price-importer' ),
		'manage_options',
		'mvweb-price-importer',
		'mvweb_pi_settings_page'
	);
}
add_action( 'admin_menu', 'mvweb_pi_register_menu' );

/**
 * Plugin settings page callback.
 *
 * Delegates to MVweb_PI_Admin for settings handling and rendering.
 *
 * @since 1.0.0
 * @since 1.1.0 Refactored to delegate to MVweb_PI_Admin/MVweb_PI_Settings.
 * @return void
 */
function mvweb_pi_settings_page() {
	$admin = new MVweb_PI_Admin();
	$admin->settings_page();
}

/**
 * Enqueue admin styles and scripts.
 *
 * @since 1.0.0
 * @param string $hook Current admin page hook.
 * @return void
 */
function mvweb_pi_admin_enqueue( $hook ) {
	if ( false === strpos( $hook, 'mvweb-price-importer' ) ) {
		return;
	}

	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	// Cache buster: prefer the bundle's mtime so a re-uploaded build
	// is picked up by browsers without bumping MVWEB_PI_VERSION.
	$asset_ver = static function ( string $relative_path ) {
		$absolute = MVWEB_PI_PATH . $relative_path;
		$mtime    = @filemtime( $absolute );
		return $mtime ? (string) $mtime : MVWEB_PI_VERSION;
	};

	wp_enqueue_style(
		'mvweb-pi-admin',
		MVWEB_PI_URL . 'admin/css/admin' . $suffix . '.css',
		array(),
		$asset_ver( 'admin/css/admin' . $suffix . '.css' )
	);

	wp_enqueue_style(
		'mvweb-pi-plugin',
		MVWEB_PI_URL . 'admin/css/plugin' . $suffix . '.css',
		array( 'mvweb-pi-admin' ),
		$asset_ver( 'admin/css/plugin' . $suffix . '.css' )
	);

	wp_enqueue_script(
		'mvweb-pi-admin',
		MVWEB_PI_URL . 'admin/js/admin' . $suffix . '.js',
		array( 'jquery' ),
		$asset_ver( 'admin/js/admin' . $suffix . '.js' ),
		true
	);

	wp_localize_script(
		'mvweb-pi-admin',
		'mvweb_pi_ajax',
		array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'mvweb_pi_ajax' ),
			'i18n'     => array(
				'created'         => __( 'created', 'mvweb-price-importer' ),
				'updated'         => __( 'updated', 'mvweb-price-importer' ),
				'skipped'         => __( 'skipped', 'mvweb-price-importer' ),
				'errors'          => __( 'errors', 'mvweb-price-importer' ),
				'products'        => __( 'products', 'mvweb-price-importer' ),
				'invalid'         => __( 'invalid', 'mvweb-price-importer' ),
				'duplicates'      => __( 'duplicates', 'mvweb-price-importer' ),
				'unchanged'       => __( 'no changes', 'mvweb-price-importer' ),
				'downloaded'      => __( 'Sources downloaded.', 'mvweb-price-importer' ),
				'converted'       => __( 'Sources converted.', 'mvweb-price-importer' ),
				'feed_generated'  => __( 'Feed generated.', 'mvweb-price-importer' ),
				'feeds_generated' => __( 'Feeds generated.', 'mvweb-price-importer' ),
				'delete'          => __( 'Delete', 'mvweb-price-importer' ),
				'confirm_delete_feed' => __( 'Delete this feed file? This cannot be undone.', 'mvweb-price-importer' ),
				'invalid_file'    => __( 'Invalid rows file:', 'mvweb-price-importer' ),
				'checkpoint'      => __( 'Checkpoint file:', 'mvweb-price-importer' ),
				'request_failed'  => __( 'Request failed. Please try again.', 'mvweb-price-importer' ),
				'unknown_error'   => __( 'Unknown error.', 'mvweb-price-importer' ),
			),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'mvweb_pi_admin_enqueue' );

/**
 * Create protected upload directory for pricelists.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_create_upload_dir() {
	$upload_dir  = wp_upload_dir();
	$pricelists  = $upload_dir['basedir'] . '/pricelists/';
	$feeds_dir   = $pricelists . 'feeds/';

	wp_mkdir_p( $pricelists );
	wp_mkdir_p( $feeds_dir );

	// index.php — prevent directory listing.
	$index_content = "<?php\n// Silence is golden.\n";
	if ( ! file_exists( $pricelists . 'index.php' ) ) {
		file_put_contents( $pricelists . 'index.php', $index_content );
	}
	if ( ! file_exists( $feeds_dir . 'index.php' ) ) {
		file_put_contents( $feeds_dir . 'index.php', $index_content );
	}

	// .htaccess — deny direct access to pricelists (not feeds).
	$htaccess = $pricelists . '.htaccess';
	if ( ! file_exists( $htaccess ) ) {
		$rules  = "# Protect pricelists directory\n";
		$rules .= "<IfModule mod_authz_core.c>\n";
		$rules .= "    Require all denied\n";
		$rules .= "</IfModule>\n";
		$rules .= "<IfModule !mod_authz_core.c>\n";
		$rules .= "    Order deny,allow\n";
		$rules .= "    Deny from all\n";
		$rules .= "</IfModule>\n";
		file_put_contents( $htaccess, $rules );
	}

	// feeds/ must override the parent deny — Apache .htaccess cascades
	// into subdirectories, so without an explicit allow here the YML
	// feeds are unreachable on the public side even though they are
	// intentionally meant to be served (e.g. for Yandex.Market).
	$feeds_htaccess = $feeds_dir . '.htaccess';
	if ( ! file_exists( $feeds_htaccess ) ) {
		$rules  = "# Allow public access to generated feeds\n";
		$rules .= "<IfModule mod_authz_core.c>\n";
		$rules .= "    Require all granted\n";
		$rules .= "</IfModule>\n";
		$rules .= "<IfModule !mod_authz_core.c>\n";
		$rules .= "    Order allow,deny\n";
		$rules .= "    Allow from all\n";
		$rules .= "</IfModule>\n";
		file_put_contents( $feeds_htaccess, $rules );
	}
}

/**
 * Plugin activation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_activate() {
	// Check WooCommerce dependency.
	if ( ! class_exists( 'WooCommerce' ) ) {
		deactivate_plugins( plugin_basename( __FILE__ ) );
		wp_die(
			esc_html__( 'MVweb Price Importer requires WooCommerce 8.0+ to be installed and active.', 'mvweb-price-importer' ),
			esc_html__( 'Plugin Activation Error', 'mvweb-price-importer' ),
			array( 'back_link' => true )
		);
	}

	// Create protected upload directory.
	mvweb_pi_create_upload_dir();

	// Initialize service options (autoload=no).
	// NOTE: mvweb_pi_cron_lock is deliberately NOT pre-created — it must
	// not exist until a real import starts, otherwise acquire_lock()'s
	// add_option() race-free path can never fire on first run.
	add_option( 'mvweb_pi_last_etags', array(), '', 'no' );
	add_option( 'mvweb_pi_import_stats', array(), '', 'no' );
	add_option( 'mvweb_pi_known_skus', array(), '', 'no' );
}
register_activation_hook( __FILE__, 'mvweb_pi_activate' );

/**
 * Plugin deactivation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_deactivate() {
	wp_clear_scheduled_hook( 'mvweb_pi_cron_import' );
	wp_clear_scheduled_hook( 'mvweb_pi_continue_import' );
	delete_option( 'mvweb_pi_cron_lock' );
}
register_deactivation_hook( __FILE__, 'mvweb_pi_deactivate' );

// Include additional files.
require_once MVWEB_PI_PATH . 'includes/helpers.php';

// Stage 10: Logger (JSONL file logging).
require_once MVWEB_PI_PATH . 'includes/class-logger.php';

// Stage 2: Loader and Parsers.
require_once MVWEB_PI_PATH . 'includes/class-loader.php';
require_once MVWEB_PI_PATH . 'includes/class-parser-csv.php';
require_once MVWEB_PI_PATH . 'includes/class-parser-yml.php';
require_once MVWEB_PI_PATH . 'includes/class-parser-xlsx.php';
require_once MVWEB_PI_PATH . 'includes/class-parser.php';

// Stage 3: Converter.
require_once MVWEB_PI_PATH . 'includes/class-converter.php';

// Stage 4: Importer.
require_once MVWEB_PI_PATH . 'includes/class-importer.php';

// Stage 5: Categories.
require_once MVWEB_PI_PATH . 'includes/class-categories.php';

// Stage 6: Cron and REST.
require_once MVWEB_PI_PATH . 'includes/class-cron.php';
require_once MVWEB_PI_PATH . 'includes/class-rest.php';

// Stage 7: Feeds.
require_once MVWEB_PI_PATH . 'includes/class-feeds.php';

// Admin: Settings and Admin classes.
require_once MVWEB_PI_PATH . 'admin/class-settings.php';
require_once MVWEB_PI_PATH . 'admin/class-admin.php';

// Stage 9: Frontend UI (per-warehouse stock display).
require_once MVWEB_PI_PATH . 'includes/class-ui.php';

// Initialize frontend UI (Stage 9: per-warehouse stock display).
new MVweb_PI_UI();

// Register custom cron intervals (TZ 8.4).
add_filter( 'cron_schedules', array( 'MVweb_PI_Cron', 'register_intervals' ) );

// Bind cron hook to import runner.
add_action( 'mvweb_pi_cron_import', function () {
	$cron = new MVweb_PI_Cron();
	$cron->run();
} );

// Continuation hook — scheduled by the importer when a web/AJAX/wp-cron run
// hits its wall-clock budget. Same handler, picks up via the resume path.
add_action( MVweb_PI_Cron::CONTINUE_HOOK, function () {
	$cron = new MVweb_PI_Cron();
	$cron->run();
} );

// Register REST API routes (TZ 8.1).
add_action( 'rest_api_init', function () {
	$rest = new MVweb_PI_REST();
	$rest->register_routes();
} );

// ───────────────────────────────────────────────
// Settings save handler
// ───────────────────────────────────────────────

/**
 * AJAX handler: detect columns from a downloaded source file.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_detect_columns() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$settings = get_option( 'mvweb_pi_settings', array() );
	$url      = $settings['source_url'] ?? '';

	if ( empty( $url ) ) {
		wp_send_json_error( __( 'No source URL configured.', 'mvweb-price-importer' ) );
	}

	$loader = new MVweb_PI_Loader();

	// Convert Google Sheets URL if needed.
	$url = $loader->convert_google_sheets_url( $url );

	// Re-validate the URL even though it was sanitized on save — the option
	// could have been mutated out-of-band and validate_url() also covers
	// SSRF/scheme/IP checks that sanitize_text_field cannot perform.
	$valid = $loader->validate_url( $url );
	if ( is_wp_error( $valid ) ) {
		wp_send_json_error( $valid->get_error_message() );
	}

	// Determine format and file extension.
	$format = $loader->detect_format( $url );
	$ext    = ( 'yml' === $format ) ? 'yml' : $format;

	// Download to temp file with UUID name.
	$upload_dir  = mvweb_pi_get_upload_dir();
	$uuid        = wp_generate_uuid4();
	$destination = $upload_dir . "detect-{$uuid}.{$ext}";

	$result = $loader->download( $url, $destination );

	if ( is_wp_error( $result ) ) {
		wp_send_json_error( $result->get_error_message() );
	}

	// Detect columns.
	try {
		$detected = MVweb_PI_Parser::detect_columns( $destination );
		wp_send_json_success( $detected );
	} catch ( \Exception $e ) {
		wp_send_json_error( $e->getMessage() );
	} finally {
		// Clean up temp file.
		if ( file_exists( $destination ) ) {
			wp_delete_file( $destination );
		}
	}
}
add_action( 'wp_ajax_mvweb_pi_detect_columns', 'mvweb_pi_ajax_detect_columns' );

/**
 * AJAX handler: download source file(s) from configured URL(s).
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_download_source() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$settings   = get_option( 'mvweb_pi_settings', array() );
	$warehouses = $settings['warehouses'] ?? array();
	$source_url = $settings['source_url'] ?? '';

	// Build list of URLs to download.
	$sources = array();
	if ( ! empty( $warehouses ) ) {
		foreach ( $warehouses as $wh ) {
			if ( ! empty( $wh['url'] ) ) {
				$sources[] = array(
					'id'  => $wh['id'] ?? sanitize_title( $wh['name'] ?? '' ),
					'url' => $wh['url'],
				);
			}
		}
	} elseif ( ! empty( $source_url ) ) {
		$sources[] = array(
			'id'  => 'default',
			'url' => $source_url,
		);
	}

	if ( empty( $sources ) ) {
		wp_send_json_error( __( 'No source URLs configured.', 'mvweb-price-importer' ) );
	}

	$loader     = new MVweb_PI_Loader();
	$upload_dir = mvweb_pi_get_upload_dir();
	$results    = array();
	$errors     = array();

	foreach ( $sources as $source ) {
		$url = $loader->convert_google_sheets_url( $source['url'] );

		// Check ETag — skip if unchanged.
		$changed = $loader->check_etag( $url, $source['id'] );
		if ( ! $changed ) {
			$results[] = array(
				'id'      => $source['id'],
				'status'  => 'unchanged',
				'message' => __( 'File unchanged (ETag match).', 'mvweb-price-importer' ),
			);
			continue;
		}

		// Determine format.
		$format = $loader->detect_format( $url );
		$ext    = ( 'yml' === $format ) ? 'yml' : $format;
		$uuid   = wp_generate_uuid4();
		$dest   = $upload_dir . "source-{$source['id']}-{$uuid}.{$ext}";

		$download_result = $loader->download( $url, $dest );
		if ( is_wp_error( $download_result ) ) {
			$errors[] = array(
				'id'      => $source['id'],
				'message' => $download_result->get_error_message(),
			);
		} else {
			$results[] = array(
				'id'     => $source['id'],
				'status' => 'downloaded',
				'file'   => basename( $dest ),
				'format' => $format,
				'size'   => size_format( filesize( $dest ) ),
			);
		}
	}

	if ( ! empty( $errors ) && empty( $results ) ) {
		wp_send_json_error( $errors );
	}

	wp_send_json_success(
		array(
			'downloaded' => $results,
			'errors'     => $errors,
		)
	);
}
add_action( 'wp_ajax_mvweb_pi_download_source', 'mvweb_pi_ajax_download_source' );

/**
 * AJAX handler: convert downloaded sources into unified format.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_convert_data() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$mapping = get_option( 'mvweb_pi_mapping', array() );

	// Check required fields are mapped.
	$required = array( 'sku', 'name', 'price', 'stock' );
	$missing  = array();
	foreach ( $required as $field ) {
		if ( empty( $mapping[ $field ] ) ) {
			$missing[] = $field;
		}
	}
	if ( ! empty( $missing ) ) {
		wp_send_json_error(
			/* translators: %s: comma-separated list of field names */
			sprintf(
				__( 'Required fields not mapped: %s. Configure mapping in the Mapping tab.', 'mvweb-price-importer' ),
				implode( ', ', $missing )
			)
		);
	}

	// Find downloaded source files.
	$upload_dir   = mvweb_pi_get_upload_dir();
	$source_files = glob( $upload_dir . 'source-*' );

	if ( empty( $source_files ) ) {
		wp_send_json_error( __( 'No downloaded source files found. Download sources first in the Output tab.', 'mvweb-price-importer' ) );
	}

	// Build warehouse_id => file_path map.
	$sources = array();
	foreach ( $source_files as $file ) {
		$basename = basename( $file );
		// Extract warehouse ID from filename: source-{wh_id}-{uuid}.{ext}
		if ( preg_match( '/^source-(.+?)-[a-f0-9\-]{36}\.\w+$/', $basename, $matches ) ) {
			$sources[ $matches[1] ] = $file;
		}
	}

	if ( empty( $sources ) ) {
		wp_send_json_error( __( 'Could not identify source files. Please re-download.', 'mvweb-price-importer' ) );
	}

	try {
		$converter  = new MVweb_PI_Converter();
		$is_multi   = count( $sources ) > 1;
		$settings   = get_option( 'mvweb_pi_settings', array() );
		$debug_mode = ! empty( $settings['debug_checkpoint'] );

		// Choose single-source or multi-warehouse pipeline.
		if ( $is_multi ) {
			$products = $converter->merge_warehouses( $sources, $mapping );
		} else {
			$products = $converter->convert( $sources, $mapping );
		}

		// In debug mode, write checkpoint file; otherwise, consume generator to count.
		$count = 0;
		if ( $debug_mode ) {
			$checkpoint = $converter->save_checkpoint( $products, $upload_dir );
			// Count lines in checkpoint (subtract header).
			$file_obj = new \SplFileObject( $checkpoint, 'r' );
			$file_obj->seek( PHP_INT_MAX );
			$count = max( 0, $file_obj->key() - 1 );
		} else {
			foreach ( $products as $product ) {
				++$count;
			}
		}

		$invalid_count = count( $converter->get_invalid_rows() );
		$dupes_count   = count( $converter->get_duplicate_skus() );

		// Save invalid rows if debug mode.
		$invalid_file = '';
		if ( $debug_mode && $invalid_count > 0 ) {
			$invalid_file = basename( $converter->save_invalid_rows( $upload_dir ) );
		}

		$response = array(
			'products'       => $count,
			'invalid'        => $invalid_count,
			'duplicates'     => $dupes_count,
			'debug_mode'     => $debug_mode,
			'checkpoint'     => $debug_mode && isset( $checkpoint ) ? basename( $checkpoint ) : '',
			'invalid_file'   => $invalid_file,
		);

		// Operator-grade summary — counterpart to the "Source file
		// downloaded" line so the log shows the full pipeline.
		mvweb_pi_log(
			sprintf(
				/* translators: 1: number of valid products, 2: invalid count, 3: duplicate count */
				__( 'Source converted: %1$d products parsed (%2$d invalid, %3$d duplicates).', 'mvweb-price-importer' ),
				$count,
				$invalid_count,
				$dupes_count
			),
			'info'
		);

		wp_send_json_success( $response );

	} catch ( \Exception $e ) {
		wp_send_json_error( $e->getMessage() );
	}
}
add_action( 'wp_ajax_mvweb_pi_convert_data', 'mvweb_pi_ajax_convert_data' );

/**
 * AJAX handler: reset ETag/Last-Modified to force re-download.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_reset_etags() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$loader = new MVweb_PI_Loader();
	$loader->reset_etag( '' ); // Reset all warehouses.

	wp_send_json_success( __( 'ETag/hash reset. Files will be re-downloaded on next import.', 'mvweb-price-importer' ) );
}
add_action( 'wp_ajax_mvweb_pi_reset_etags', 'mvweb_pi_ajax_reset_etags' );

/**
 * AJAX handler: save mapping from auto-detect and persist headers.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_save_mapping() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$headers  = isset( $_POST['headers'] ) && is_array( $_POST['headers'] )
		? array_map( 'sanitize_text_field', wp_unslash( $_POST['headers'] ) )
		: array();

	$detected = isset( $_POST['detected'] ) && is_array( $_POST['detected'] )
		? array_map( 'sanitize_text_field', wp_unslash( $_POST['detected'] ) )
		: array();

	// Merge with existing mapping (keep manual overrides).
	$existing = get_option( 'mvweb_pi_mapping', array() );
	$mapping  = array_merge( $existing, $detected );

	// Store headers for dropdown repopulation.
	$mapping['_headers'] = $headers;

	update_option( 'mvweb_pi_mapping', $mapping );

	wp_send_json_success( __( 'Mapping saved.', 'mvweb-price-importer' ) );
}
add_action( 'wp_ajax_mvweb_pi_save_mapping', 'mvweb_pi_ajax_save_mapping' );

/**
 * AJAX handler: run full import cycle.
 *
 * Delegates to MVweb_PI_Cron::run() which handles the full import pipeline
 * including lock acquisition, download, conversion, and import.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_run_import() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$cron   = new MVweb_PI_Cron();
	$result = $cron->run();

	if ( in_array( $result['status'], array( 'completed', 'skipped' ), true ) ) {
		wp_send_json_success( $result );
	}

	wp_send_json_error( $result['message'] );
}
add_action( 'wp_ajax_mvweb_pi_run_import', 'mvweb_pi_ajax_run_import' );

/**
 * AJAX handler: get import progress for real-time polling.
 *
 * Returns current checkpoint data so the admin UI can display
 * a progress bar during long-running imports.
 *
 * @since 1.1.0
 * @return void
 */
function mvweb_pi_ajax_import_progress() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$progress = get_option( MVweb_PI_Importer::PROGRESS_OPTION, array() );
	wp_send_json_success( $progress );
}
add_action( 'wp_ajax_mvweb_pi_import_progress', 'mvweb_pi_ajax_import_progress' );

/**
 * AJAX handler: generate all YML feeds.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_generate_feeds() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	try {
		$feeds   = new MVweb_PI_Feeds();
		$results = $feeds->generate_all();

		$summary = array();
		$total   = 0;
		foreach ( $results as $key => $result ) {
			$summary[] = array(
				'slug'     => $key,
				'url'      => $result['url'],
				'products' => $result['products'],
			);
			$total += $result['products'];
		}

		wp_send_json_success(
			array(
				'feeds' => $summary,
				'total' => $total,
				'count' => count( $summary ),
			)
		);
	} catch ( \Exception $e ) {
		wp_send_json_error( $e->getMessage() );
	}
}
add_action( 'wp_ajax_mvweb_pi_generate_feeds', 'mvweb_pi_ajax_generate_feeds' );

/**
 * AJAX handler: delete a single generated feed file by slug.
 *
 * @since 1.0.3
 * @return void
 */
function mvweb_pi_ajax_delete_feed() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified above.
	$slug = isset( $_POST['slug'] ) ? sanitize_text_field( wp_unslash( $_POST['slug'] ) ) : '';
	if ( '' === $slug ) {
		wp_send_json_error( __( 'Feed slug is required.', 'mvweb-price-importer' ) );
	}

	$feeds   = new MVweb_PI_Feeds();
	$deleted = $feeds->delete( $slug );

	if ( ! $deleted ) {
		wp_send_json_error( __( 'Feed file not found or could not be deleted.', 'mvweb-price-importer' ) );
	}

	mvweb_pi_log(
		sprintf(
			/* translators: %s: feed slug */
			__( 'Feed file deleted: %s.', 'mvweb-price-importer' ),
			$slug
		),
		'info'
	);

	wp_send_json_success(
		array(
			'slug'    => $slug,
			'message' => __( 'Feed deleted.', 'mvweb-price-importer' ),
		)
	);
}
add_action( 'wp_ajax_mvweb_pi_delete_feed', 'mvweb_pi_ajax_delete_feed' );

/**
 * AJAX handler: get log entries with pagination and filtering.
 *
 * Delegates to MVweb_PI_Logger::get_page() for JSONL reading (TZ 10.2).
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_get_log() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$page  = isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1;
	$level = isset( $_POST['level'] ) ? sanitize_key( $_POST['level'] ) : '';

	$logger = MVweb_PI_Logger::get_instance();
	$result = $logger->get_page( $page, MVweb_PI_Logger::PER_PAGE, $level );

	wp_send_json_success( $result );
}
add_action( 'wp_ajax_mvweb_pi_get_log', 'mvweb_pi_ajax_get_log' );

/**
 * AJAX handler: clear the log file.
 *
 * Delegates to MVweb_PI_Logger::clear() for safe cleanup.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_clear_log() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$logger = MVweb_PI_Logger::get_instance();
	$logger->clear();

	wp_send_json_success( __( 'Log cleared.', 'mvweb-price-importer' ) );
}
add_action( 'wp_ajax_mvweb_pi_clear_log', 'mvweb_pi_ajax_clear_log' );
