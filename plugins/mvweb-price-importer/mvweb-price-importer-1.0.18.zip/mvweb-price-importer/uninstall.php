<?php
/**
 * Uninstall MVweb Price Importer
 *
 * Fired when the plugin is uninstalled.
 * Removes all options, post meta, term meta, attachment meta,
 * cron schedules, and uploaded files.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Delete all plugin options.
$options = array(
	'mvweb_pi_settings',
	'mvweb_pi_mapping',
	'mvweb_pi_output',
	'mvweb_pi_category_map',
	'mvweb_pi_feeds_company',
	'mvweb_pi_feeds_currency',
	'mvweb_pi_feeds_auto_generate',
	'mvweb_pi_cron_lock',
	'mvweb_pi_last_etags',
	'mvweb_pi_import_stats',
	'mvweb_pi_import_progress',
	'mvweb_pi_known_skus',
);

foreach ( $options as $option ) {
	delete_option( $option );
}

// Clean up product meta.
global $wpdb;
$meta_keys = array(
	'_mvweb_pi_stocks',
	'_mvweb_pi_image_source',
	'_mvweb_pi_image_attach_id',
	'_mvweb_pi_gallery_sources',
	'_mvweb_pi_barcode',
);
foreach ( $meta_keys as $key ) {
	$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => $key ), array( '%s' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
}

// Clean up attachment meta.
$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => '_mvweb_pi_uploaded' ), array( '%s' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key

// Clean up term meta.
$wpdb->delete( $wpdb->termmeta, array( 'meta_key' => 'mvweb_pi_external_id' ), array( '%s' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key

// Clear cron schedule.
wp_clear_scheduled_hook( 'mvweb_pi_cron_import' );
wp_clear_scheduled_hook( 'mvweb_pi_continue_import' );

// Delete uploaded files (pricelists directory).
$upload_dir     = wp_upload_dir();
$pricelists_dir = $upload_dir['basedir'] . '/pricelists/';

if ( is_dir( $pricelists_dir ) ) {
	// Recursive directory removal.
	$iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $pricelists_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);

	foreach ( $iterator as $item ) {
		if ( $item->isDir() ) {
			rmdir( $item->getPathname() );
		} else {
			unlink( $item->getPathname() );
		}
	}

	rmdir( $pricelists_dir );
}

// For multisite, clean up each site. Each iteration is wrapped in
// try/finally so a failure inside one site's cleanup still restores the
// global blog context and lets the loop continue for the remaining sites.
if ( is_multisite() ) {
	$sites = get_sites();
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );

		try {
			foreach ( $options as $option ) {
				delete_option( $option );
			}

			foreach ( $meta_keys as $key ) {
				$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => $key ), array( '%s' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			}
			$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => '_mvweb_pi_uploaded' ), array( '%s' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			$wpdb->delete( $wpdb->termmeta, array( 'meta_key' => 'mvweb_pi_external_id' ), array( '%s' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key

			wp_clear_scheduled_hook( 'mvweb_pi_cron_import' );

			$ms_upload_dir     = wp_upload_dir();
			$ms_pricelists_dir = $ms_upload_dir['basedir'] . '/pricelists/';
			if ( is_dir( $ms_pricelists_dir ) ) {
				$ms_iterator = new RecursiveIteratorIterator(
					new RecursiveDirectoryIterator( $ms_pricelists_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
					RecursiveIteratorIterator::CHILD_FIRST
				);
				foreach ( $ms_iterator as $item ) {
					if ( $item->isDir() ) {
						rmdir( $item->getPathname() );
					} else {
						unlink( $item->getPathname() );
					}
				}
				rmdir( $ms_pricelists_dir );
			}
		} finally {
			restore_current_blog();
		}
	}
}

// Clear any cached data.
wp_cache_flush();
