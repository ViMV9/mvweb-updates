<?php
/**
 * CLI cron runner for system cron integration.
 *
 * Usage: php cron-runner.php
 * Add to crontab: 0 * /6 * * * php /path/to/wp-content/plugins/mvweb-price-importer/cron-runner.php
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Only allow CLI execution (TZ 13.1).
if ( 'cli' !== php_sapi_name() ) {
	http_response_code( 403 );
	exit( 'This script can only be run from the command line.' );
}

// Bootstrap WordPress.
// Plugin path: wp-content/plugins/mvweb-price-importer/cron-runner.php
// wp-load.php: ../../../../wp-load.php
$wp_load = dirname( __FILE__, 4 ) . '/wp-load.php';

if ( ! file_exists( $wp_load ) ) {
	// Try alternative path for non-standard installations.
	$wp_load = dirname( __FILE__, 5 ) . '/wp-load.php';
}

if ( ! file_exists( $wp_load ) ) {
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	fwrite( STDERR, "Error: wp-load.php not found. Tried:\n" );
	fwrite( STDERR, '  ' . dirname( __FILE__, 4 ) . "/wp-load.php\n" );
	fwrite( STDERR, '  ' . dirname( __FILE__, 5 ) . "/wp-load.php\n" );
	exit( 1 );
}

// Define DOING_CRON to prevent wp-cron from running.
if ( ! defined( 'DOING_CRON' ) ) {
	define( 'DOING_CRON', true );
}

require_once $wp_load;

// Verify plugin is active.
if ( ! defined( 'MVWEB_PI_VERSION' ) ) {
	fwrite( STDERR, "Error: MVweb Price Importer is not active.\n" );
	exit( 1 );
}

// Run import.
$cron   = new MVweb_PI_Cron();
$result = $cron->run();

// Output result.
$status = $result['status'] ?? 'unknown';
$message = $result['message'] ?? '';

if ( 'completed' === $status ) {
	$stats = $result['stats'] ?? array();
	fwrite(
		STDOUT,
		sprintf(
			"Import completed: %d created, %d updated, %d skipped, %d errors.\n",
			$stats['created'] ?? 0,
			$stats['updated'] ?? 0,
			$stats['skipped'] ?? 0,
			$stats['errors'] ?? 0
		)
	);
	exit( 0 );
}

if ( 'skipped' === $status ) {
	fwrite( STDOUT, "Import skipped: sources unchanged.\n" );
	exit( 0 );
}

if ( 'locked' === $status ) {
	fwrite( STDERR, "Import skipped: another import is running.\n" );
	exit( 2 );
}

// Error.
fwrite( STDERR, "Import failed: {$message}\n" );
exit( 1 );
