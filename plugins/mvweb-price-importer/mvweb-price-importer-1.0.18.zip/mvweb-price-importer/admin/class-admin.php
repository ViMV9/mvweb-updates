<?php
/**
 * Admin class — admin page orchestration.
 *
 * Coordinates settings handling and admin-specific functionality.
 *
 * @package mvweb_pi
 * @since   1.0.0
 * @since   1.1.0 Implemented with Settings delegation.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Admin
 *
 * Orchestrates admin functionality: delegates settings save to
 * MVweb_PI_Settings and manages admin page rendering.
 *
 * @since 1.0.0
 * @since 1.1.0 Fully implemented.
 */
class MVweb_PI_Admin {

	/**
	 * Settings handler instance.
	 *
	 * @since 1.1.0
	 * @var MVweb_PI_Settings
	 */
	private MVweb_PI_Settings $settings;

	/**
	 * Constructor.
	 *
	 * @since 1.1.0
	 */
	public function __construct() {
		$this->settings = new MVweb_PI_Settings();
	}

	/**
	 * Handle settings page request.
	 *
	 * Processes form submission (if any) and renders the page.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function settings_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$this->settings->handle_save();
		$this->settings->render();
	}
}
