<?php
/**
 * Feeds tab template.
 *
 * YML feed settings, feed list table, and generation controls.
 * Settings (company, currency) are saved via the main form POST.
 * Feed generation is handled via AJAX.
 *
 * Uses MVweb Admin UI Kit (slate palette, Yoast-style layout).
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$feeds_handler  = new MVweb_PI_Feeds();
$company        = $feeds_handler->get_company();
$currency       = $feeds_handler->get_currency();
$feed_slug_raw  = (string) get_option( MVweb_PI_Feeds::OPTION_SLUG, '' );
$auto_generate  = get_option( MVweb_PI_Feeds::OPTION_AUTO_GENERATE, '1' );
$feed_list      = $feeds_handler->get_feed_list();

$currency_options = array(
	'RUR' => __( 'RUR — Russian Ruble', 'mvweb-price-importer' ),
	'USD' => __( 'USD — US Dollar', 'mvweb-price-importer' ),
	'EUR' => __( 'EUR — Euro', 'mvweb-price-importer' ),
);

// Count feeds the operator will get on the next generation:
// always one general feed, plus one per configured warehouse with an id.
$settings_for_feeds = get_option( 'mvweb_pi_settings', array() );
$feed_total         = 1;
foreach ( ( $settings_for_feeds['warehouses'] ?? array() ) as $wh ) {
	if ( ! empty( $wh['id'] ) ) {
		++$feed_total;
	}
}
$generate_btn_label = $feed_total > 1
	? __( 'Generate All Feeds', 'mvweb-price-importer' )
	: __( 'Generate Feed', 'mvweb-price-importer' );
?>

<div class="mvweb-pi-tab-feeds">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Feed Settings', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Configure YML feed parameters for Yandex.Market. Feeds include only products with stock > 0.', 'mvweb-price-importer' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_feeds_company" class="mvweb-form-row__label">
				<?php esc_html_e( 'Company Name', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
					   id="mvweb_pi_feeds_company"
					   name="mvweb_pi_feeds_company"
					   class="mvweb-input"
					   value="<?php echo esc_attr( $company ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Company name displayed in the YML feed header.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_feeds_slug" class="mvweb-form-row__label">
				<?php esc_html_e( 'Feed Slug', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
					   id="mvweb_pi_feeds_slug"
					   name="mvweb_pi_feeds_slug"
					   class="mvweb-input"
					   value="<?php echo esc_attr( $feed_slug_raw ); ?>"
					   pattern="[a-z0-9-]+"
					   placeholder="<?php echo esc_attr( MVweb_PI_Feeds::DEFAULT_SLUG ); ?>"
					   title="<?php esc_attr_e( 'Allowed: lowercase Latin letters, digits and hyphens.', 'mvweb-price-importer' ); ?>">
				<p class="mvweb-form-row__desc">
					<?php
					printf(
						/* translators: %s: example feed URL */
						esc_html__( 'Filename suffix for the feed: products-feed-{slug}.yml. Allowed characters: a–z, 0–9, hyphen. Example: %s', 'mvweb-price-importer' ),
						'<code>' . esc_html( mvweb_pi_get_feeds_url() . 'products-feed-poisk123.yml' ) . '</code>'
					);
					?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_feeds_currency" class="mvweb-form-row__label">
				<?php esc_html_e( 'Currency', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_feeds_currency"
						name="mvweb_pi_feeds_currency"
						class="mvweb-select">
					<?php foreach ( $currency_options as $code => $label ) : ?>
						<option value="<?php echo esc_attr( $code ); ?>"
							<?php selected( $currency, $code ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_feeds_auto_generate" class="mvweb-form-row__label">
				<?php esc_html_e( 'Auto-generate', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							   id="mvweb_pi_feeds_auto_generate"
							   name="mvweb_pi_feeds_auto_generate"
							   value="1"
							   <?php checked( $auto_generate, '1' ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Regenerate feeds automatically after each successful import', 'mvweb-price-importer' ); ?></span>
				</div>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Generated Feeds', 'mvweb-price-importer' ); ?></div>
		</div>

		<?php if ( ! empty( $feed_list ) ) : ?>
			<div class="mvweb-table-wrap">
				<table class="mvweb-table" id="mvweb-pi-feeds-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Feed', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'URL', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'Last Generated', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'Products', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'Size', 'mvweb-price-importer' ); ?></th>
							<th class="mvweb-pi-feeds-table__actions-col"><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'mvweb-price-importer' ); ?></span></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $feed_list as $feed ) : ?>
							<tr data-slug="<?php echo esc_attr( $feed['slug'] ); ?>">
								<td>
									<strong><?php echo esc_html( $feed['slug'] ); ?></strong>
								</td>
								<td>
									<a href="<?php echo esc_url( $feed['url'] ); ?>"
									   target="_blank"
									   rel="noopener noreferrer"
									   class="mvweb-pi-feed-url">
										<?php echo esc_html( $feed['url'] ); ?>
									</a>
								</td>
								<td>
									<?php
									echo esc_html(
										wp_date(
											get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
											$feed['modified']
										)
									);
									?>
								</td>
								<td>
									<span class="mvweb-badge"><?php echo esc_html( (string) $feed['products'] ); ?></span>
								</td>
								<td>
									<?php echo esc_html( $feed['size'] ); ?>
								</td>
								<td class="mvweb-pi-feeds-table__actions">
									<button type="button"
											class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-pi-delete-feed-btn"
											data-slug="<?php echo esc_attr( $feed['slug'] ); ?>"
											aria-label="<?php
												/* translators: %s: feed slug */
												echo esc_attr( sprintf( __( 'Delete feed %s', 'mvweb-price-importer' ), $feed['slug'] ) );
											?>">
										<?php esc_html_e( 'Delete', 'mvweb-price-importer' ); ?>
									</button>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php else : ?>
			<div class="mvweb-empty">
				<div class="mvweb-empty__icon">&#128230;</div>
				<div class="mvweb-empty__title"><?php esc_html_e( 'No feeds generated yet', 'mvweb-price-importer' ); ?></div>
				<div class="mvweb-empty__text"><?php esc_html_e( 'Click the button below to generate YML feeds.', 'mvweb-price-importer' ); ?></div>
			</div>
		<?php endif; ?>

		<div class="mvweb-pi-feeds-actions">
			<button type="button"
					class="mvweb-btn mvweb-btn--primary"
					id="mvweb-pi-generate-feeds-btn">
				<?php echo esc_html( $generate_btn_label ); ?>
				<span class="mvweb-spinner" id="mvweb-pi-feeds-spinner"></span>
			</button>
			<div class="mvweb-pi-action-result" id="mvweb-pi-feeds-result"></div>
		</div>
	</div>

</div>
