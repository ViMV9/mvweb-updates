<?php
/**
 * Admin settings page template.
 *
 * Uses MVweb Admin UI Kit (slate palette, Yoast-style layout with left sidebar).
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'main'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.

$tabs = array(
	'main'    => array(
		'label' => __( 'Main', 'mvweb-price-importer' ),
		'count' => null,
		'icon'  => 'grid',
	),
	'mapping' => array(
		'label' => __( 'Mapping', 'mvweb-price-importer' ),
		'count' => null,
		'icon'  => 'mapping',
	),
	'log'     => array(
		'label' => __( 'Log', 'mvweb-price-importer' ),
		'count' => null,
		'icon'  => 'log',
	),
	'feeds'   => array(
		'label' => __( 'Feeds', 'mvweb-price-importer' ),
		'count' => null,
		'icon'  => 'feeds',
	),
	'help'    => array(
		'label' => __( 'Help', 'mvweb-price-importer' ),
		'count' => null,
		'icon'  => 'help',
	),
);

$icons = array(
	'grid'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'mapping' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>',
	'log'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>',
	'feeds'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11a9 9 0 0 1 9 9"/><path d="M4 4a16 16 0 0 1 16 16"/><circle cx="5" cy="19" r="1"/></svg>',
	'help'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">PI</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Price Importer', 'mvweb-price-importer' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_PI_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $tabs as $tab_id => $tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $tab_id ); ?>"
						class="mvweb-nav__link <?php echo $current_tab === $tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						data-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo $icons[ $tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $tab['label'] ); ?>
						<?php if ( null !== $tab['count'] ) : ?>
							<span class="mvweb-nav__badge"><?php echo esc_html( (string) $tab['count'] ); ?></span>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors( 'mvweb_pi_messages' ); ?>

		<form method="post" action="">
			<?php wp_nonce_field( 'mvweb_pi_settings', 'mvweb_pi_nonce' ); ?>

			<div id="main" class="mvweb-tab-content <?php echo 'main' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_PI_PATH . 'admin/views/tab-main.php'; ?>
			</div>

			<div id="mapping" class="mvweb-tab-content <?php echo 'mapping' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_PI_PATH . 'admin/views/tab-mapping.php'; ?>
			</div>

			<div id="log" class="mvweb-tab-content <?php echo 'log' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_PI_PATH . 'admin/views/tab-log.php'; ?>
			</div>

			<div id="feeds" class="mvweb-tab-content <?php echo 'feeds' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_PI_PATH . 'admin/views/tab-feeds.php'; ?>
			</div>

			<div id="help" class="mvweb-tab-content <?php echo 'help' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_PI_PATH . 'admin/views/tab-help.php'; ?>
			</div>

			<div class="mvweb-submit mvweb-pi-submit">
				<button type="submit" name="mvweb_pi_save" class="mvweb-btn mvweb-btn--primary">
					<?php esc_html_e( 'Save Changes', 'mvweb-price-importer' ); ?>
				</button>
				<span class="mvweb-submit__hint"><kbd>⌘ S</kbd></span>
			</div>
		</form>

	</main>
</div>
