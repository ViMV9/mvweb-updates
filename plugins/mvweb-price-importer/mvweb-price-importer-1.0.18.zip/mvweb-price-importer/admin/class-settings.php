<?php
/**
 * Settings class — settings save logic.
 *
 * Handles validation, sanitization, and persistence of all plugin settings.
 * Extracted from entry point mvweb_pi_settings_page() for SRP compliance.
 *
 * @package mvweb_pi
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Settings
 *
 * Encapsulates settings save logic: nonce verification, sanitization,
 * persistence to wp_options, and cron schedule updates.
 *
 * @since 1.1.0
 */
class MVweb_PI_Settings {

	/**
	 * Handle form submission and save settings.
	 *
	 * Checks nonce and permissions, then delegates to individual
	 * save methods based on submitted data.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function handle_save(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified below via check_admin_referer().
		if ( ! isset( $_POST['mvweb_pi_save'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		check_admin_referer( 'mvweb_pi_settings', 'mvweb_pi_nonce' );

		// Save main settings (Settings tab).
		if ( isset( $_POST['mvweb_pi_settings'] ) && is_array( $_POST['mvweb_pi_settings'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized field-by-field in save_main().
			$this->save_main( wp_unslash( $_POST['mvweb_pi_settings'] ) );
		}

		// Save feed settings (Feeds tab).
		$this->save_feeds();

		// Save mapping settings (Mapping tab).
		if ( isset( $_POST['mvweb_pi_mapping'] ) && is_array( $_POST['mvweb_pi_mapping'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized field-by-field in save_mapping().
			$this->save_mapping( wp_unslash( $_POST['mvweb_pi_mapping'] ) );
		}

		// Post/Redirect/Get: stash a one-shot flag in a per-user transient and
		// bounce back to the settings page as a clean GET. Without this, every
		// browser refresh re-POSTs the form and the "Settings saved" notice
		// reappears even though the user did not press the button.
		set_transient(
			$this->saved_flag_key(),
			'1',
			MINUTE_IN_SECONDS
		);

		$redirect = add_query_arg(
			array(
				'page' => 'mvweb-price-importer',
				'tab'  => isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'main', // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab preservation.
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Key for the per-user "settings saved" one-shot transient.
	 *
	 * Per-user so that two admins saving simultaneously do not consume
	 * each other's notice.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public function saved_flag_key(): string {
		return 'mvweb_pi_saved_' . get_current_user_id();
	}

	/**
	 * Consume the one-shot "settings saved" flag, if present.
	 *
	 * Called by the settings page template before settings_errors() so the
	 * green "Settings saved" notice renders exactly once — on the GET that
	 * follows a successful save.
	 *
	 * @since 1.1.0
	 * @return bool True if a notice was queued, false otherwise.
	 */
	public function maybe_queue_saved_notice(): bool {
		$key = $this->saved_flag_key();
		if ( ! get_transient( $key ) ) {
			return false;
		}
		delete_transient( $key );

		add_settings_error(
			'mvweb_pi_messages',
			'mvweb_pi_message',
			__( 'Settings saved.', 'mvweb-price-importer' ),
			'updated'
		);
		return true;
	}

	/**
	 * Render the settings page.
	 *
	 * Queues the post-save "Settings saved" notice (if a save just happened
	 * on the previous request) before including the template, so the notice
	 * renders exactly once on the GET that follows the redirect.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function render(): void {
		$this->maybe_queue_saved_notice();
		include MVWEB_PI_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Save main settings (Settings tab).
	 *
	 * Sanitizes source URL, warehouses, cron interval, and batch size.
	 * Updates cron schedule if interval changed.
	 *
	 * @since 1.1.0
	 * @param array $raw Raw POST data for mvweb_pi_settings.
	 * @return void
	 */
	private function save_main( array $raw ): void {
		$existing = get_option( 'mvweb_pi_settings', array() );
		$settings = array();

		// Source URL.
		$settings['source_url'] = isset( $raw['source_url'] )
			? esc_url_raw( $raw['source_url'] )
			: '';

		// Warehouses.
		$settings['warehouses'] = array();
		if ( ! empty( $raw['warehouses'] ) && is_array( $raw['warehouses'] ) ) {
			foreach ( $raw['warehouses'] as $wh_raw ) {
				$wh_id = sanitize_key( $wh_raw['id'] ?? '' );
				if ( empty( $wh_id ) ) {
					continue;
				}
				$settings['warehouses'][] = array(
					'id'        => $wh_id,
					'name'      => sanitize_text_field( $wh_raw['name'] ?? '' ),
					'url'       => esc_url_raw( $wh_raw['url'] ?? '' ),
					'visible'   => isset( $wh_raw['visible'] ) ? '1' : '0',
					'feed_name' => sanitize_text_field( $wh_raw['feed_name'] ?? '' ),
				);
			}
		}

		// Cron interval.
		$allowed_intervals         = array( 'disabled', 'hourly', 'mvweb_pi_6hours', 'mvweb_pi_12hours', 'daily' );
		$settings['cron_interval'] = isset( $raw['cron_interval'] ) && in_array( $raw['cron_interval'], $allowed_intervals, true )
			? $raw['cron_interval']
			: 'daily';

		// Batch size.
		$settings['batch_size'] = isset( $raw['batch_size'] )
			? max( 10, min( 1000, absint( $raw['batch_size'] ) ) )
			: 100;

		// Image import policy. Defaults to `smart` — refreshes photos whose
		// source URL has changed since the previous import, but leaves
		// unchanged photos alone to keep Imagick cost down on large catalogs.
		$allowed_image_modes    = array( 'smart', 'always', 'new_only', 'never' );
		$settings['image_mode'] = isset( $raw['image_mode'] ) && in_array( $raw['image_mode'], $allowed_image_modes, true )
			? $raw['image_mode']
			: 'smart';

		// Verbose/debug logging. When off (default) the JSONL log only
		// shows operator-grade events (downloads, conversions, imports);
		// when on, the importer also writes per-batch and per-source
		// diagnostics that help developers chase a slow or broken run.
		$settings['debug_logging'] = isset( $raw['debug_logging'] ) ? true : false;

		// Preserve other settings (debug_checkpoint, etc.).
		$settings['debug_checkpoint'] = $existing['debug_checkpoint'] ?? false;

		update_option( 'mvweb_pi_settings', $settings );

		// Excluded categories live in their own option (not nested under
		// mvweb_pi_settings) — they're a separate concern from the import
		// pipeline config and reloading them in the Converter would be a
		// pain if they were buried in the main settings blob.
		// The Categories tab posts an array of external IDs; an absent
		// field means "clear all exclusions".
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce was verified before save_main() was invoked.
		$excluded_raw = isset( $_POST['mvweb_pi_excluded_categories'] ) && is_array( $_POST['mvweb_pi_excluded_categories'] )
			? wp_unslash( $_POST['mvweb_pi_excluded_categories'] )
			: array();
		// phpcs:enable

		// Note: only persist the excluded list when the Categories tab was
		// actually submitted. Otherwise saving on any other tab would wipe
		// the user's exclusion picks. We detect submission by the presence
		// of any hidden marker the tab renders.
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see above.
		if ( isset( $_POST['mvweb_pi_categories_submitted'] ) || ! empty( $excluded_raw ) ) {
			$excluded = array();
			foreach ( (array) $excluded_raw as $value ) {
				$id = sanitize_text_field( (string) $value );
				if ( '' !== $id ) {
					$excluded[] = $id;
				}
			}
			$excluded = array_values( array_unique( $excluded ) );
			update_option( 'mvweb_pi_excluded_categories', $excluded, false );

			// Filter mode (exclude blacklist | include whitelist).
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see above.
			$mode = isset( $_POST['mvweb_pi_category_filter_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_pi_category_filter_mode'] ) ) : 'exclude';
			$mode = ( 'include' === $mode ) ? 'include' : 'exclude';
			update_option( 'mvweb_pi_category_filter_mode', $mode, false );

			// Root-flatten list: categories whose own term is skipped while
			// their children are lifted to the top level.
			// phpcs:disable WordPress.Security.NonceVerification.Missing -- see above.
			$flatten_raw = isset( $_POST['mvweb_pi_flatten_roots'] ) && is_array( $_POST['mvweb_pi_flatten_roots'] )
				? wp_unslash( $_POST['mvweb_pi_flatten_roots'] )
				: array();
			// phpcs:enable
			$flatten = array();
			foreach ( (array) $flatten_raw as $value ) {
				$id = sanitize_text_field( (string) $value );
				if ( '' !== $id ) {
					$flatten[] = $id;
				}
			}
			$flatten = array_values( array_unique( $flatten ) );
			update_option( 'mvweb_pi_flatten_roots', $flatten, false );
		}

		// Update cron schedule based on new interval.
		$old_interval = $existing['cron_interval'] ?? 'daily';
		if ( $settings['cron_interval'] !== $old_interval ) {
			wp_clear_scheduled_hook( 'mvweb_pi_cron_import' );
			if ( 'disabled' !== $settings['cron_interval'] ) {
				// Offset the first run by one full interval so the dashboard
				// shows a meaningful "next run" time. wp_schedule_event(time(), …)
				// would put the first occurrence at "now" — the WP-cron tick
				// catches it on the next visit, but the operator UI then
				// reports `Next scheduled import: now`, which looks
				// indistinguishable across hourly/6h/12h/daily and confuses
				// users who expect the interval to be honoured up-front.
				$schedules        = wp_get_schedules();
				$interval_seconds = isset( $schedules[ $settings['cron_interval'] ]['interval'] )
					? (int) $schedules[ $settings['cron_interval'] ]['interval']
					: DAY_IN_SECONDS;
				wp_schedule_event( time() + $interval_seconds, $settings['cron_interval'], 'mvweb_pi_cron_import' );
			}
		}
	}

	/**
	 * Save feed settings (Feeds tab).
	 *
	 * Sanitizes company name, currency, and auto-generate toggle.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	private function save_feeds(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
		if ( isset( $_POST['mvweb_pi_feeds_company'] ) ) {
			update_option(
				MVweb_PI_Feeds::OPTION_COMPANY,
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
				sanitize_text_field( wp_unslash( $_POST['mvweb_pi_feeds_company'] ) )
			);
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
		if ( isset( $_POST['mvweb_pi_feeds_currency'] ) ) {
			$allowed_currencies = array( 'RUR', 'USD', 'EUR' );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
			$currency_val       = sanitize_text_field( wp_unslash( $_POST['mvweb_pi_feeds_currency'] ) );
			if ( in_array( $currency_val, $allowed_currencies, true ) ) {
				update_option( MVweb_PI_Feeds::OPTION_CURRENCY, $currency_val );
			}
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
		if ( isset( $_POST['mvweb_pi_feeds_slug'] ) ) {
			update_option(
				MVweb_PI_Feeds::OPTION_SLUG,
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
				MVweb_PI_Feeds::sanitize_slug( (string) wp_unslash( $_POST['mvweb_pi_feeds_slug'] ) )
			);
		}

		update_option(
			MVweb_PI_Feeds::OPTION_AUTO_GENERATE,
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified in handle_save().
			isset( $_POST['mvweb_pi_feeds_auto_generate'] ) ? '1' : '0'
		);
	}

	/**
	 * Save mapping settings (Mapping tab).
	 *
	 * Sanitizes field-to-column mapping and preserves stored headers.
	 *
	 * @since 1.1.0
	 * @param array $raw Raw POST data for mvweb_pi_mapping.
	 * @return void
	 */
	private function save_mapping( array $raw ): void {
		$mapping = array();
		$allowed = array( 'sku', 'name', 'description', 'price', 'sale_price', 'stock', 'image', 'gallery', 'category', 'parent_cat', 'barcode' );

		foreach ( $allowed as $field ) {
			$mapping[ $field ] = isset( $raw[ $field ] ) ? sanitize_text_field( $raw[ $field ] ) : '';
		}

		// Preserve stored headers for dropdown repopulation.
		$existing_mapping    = get_option( 'mvweb_pi_mapping', array() );
		$mapping['_headers'] = $existing_mapping['_headers'] ?? array();

		update_option( 'mvweb_pi_mapping', $mapping );
	}
}
