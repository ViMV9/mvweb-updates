<?php
/**
 * Parser factory — Strategy pattern for file format parsers.
 *
 * Creates appropriate parser instance based on file format.
 * Provides auto-detection of columns for field mapping.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Parser
 *
 * Factory class that creates the appropriate parser based on file format
 * and provides column auto-detection for field mapping.
 *
 * @since 1.0.0
 */
class MVweb_PI_Parser {

	/**
	 * Create a parser instance for the given file.
	 *
	 * @since 1.0.0
	 * @param string $file_path Path to the file to parse.
	 * @return MVweb_PI_Parser_CSV|MVweb_PI_Parser_YML|MVweb_PI_Parser_XLSX Parser instance.
	 * @throws \InvalidArgumentException If file format is not supported.
	 */
	public static function create( string $file_path ): MVweb_PI_Parser_CSV|MVweb_PI_Parser_YML|MVweb_PI_Parser_XLSX {
		$ext = strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );

		return match ( $ext ) {
			'csv', 'txt' => new MVweb_PI_Parser_CSV( $file_path ),
			'yml', 'xml' => new MVweb_PI_Parser_YML( $file_path ),
			'xlsx'       => new MVweb_PI_Parser_XLSX( $file_path ),
			default      => throw new \InvalidArgumentException(
				/* translators: %s: file extension */
				sprintf( __( 'Unsupported file format: %s', 'mvweb-price-importer' ), $ext )
			),
		};
	}

	/**
	 * Auto-detect columns in a file for field mapping.
	 *
	 * Scans file headers and matches them against known keywords
	 * in English and Russian for automatic mapping suggestions.
	 *
	 * @since 1.0.0
	 * @param string $file_path Path to the file to scan.
	 * @return array{headers: string[], detected: array<string, string>} Headers and detected mapping.
	 */
	public static function detect_columns( string $file_path ): array {
		$parser  = self::create( $file_path );
		$headers = $parser->get_headers();

		// Keywords for each WooCommerce field (EN + RU).
		$keywords = array(
			'sku'         => array( 'sku', 'артикул', 'article', 'код', 'код товара', 'code', 'id', 'vendor_code', 'vendorcode' ),
			'name'        => array( 'name', 'наименование', 'название', 'title', 'товар', 'product', 'offer' ),
			'description' => array( 'description', 'описание', 'desc', 'text' ),
			'price'       => array( 'price', 'цена', 'стоимость', 'розничная', 'retail', 'cost' ),
			'sale_price'  => array( 'sale_price', 'old_price', 'oldprice', 'старая цена', 'скидка', 'акция', 'sale', 'discount' ),
			'stock'       => array( 'stock', 'остаток', 'количество', 'qty', 'quantity', 'наличие', 'count', 'amount' ),
			'image'       => array( 'image', 'фото', 'картинка', 'picture', 'img', 'изображение', 'photo', 'thumbnail' ),
			'gallery'     => array( 'gallery', 'галерея', 'images', 'фотографии', 'pictures', 'дополнительные фото' ),
			'category'    => array( 'category', 'категория', 'cat', 'group', 'группа', 'раздел', 'categoryid' ),
			'parent_cat'  => array( 'parent_category', 'родительская категория', 'parent_cat', 'parentid', 'parent' ),
			'barcode'     => array( 'barcode', 'штрих-код', 'штрихкод', 'ean', 'upc', 'gtin', 'isbn' ),
		);

		$detected = array();
		foreach ( $keywords as $field => $words ) {
			foreach ( $headers as $header ) {
				$header_lower = mb_strtolower( trim( $header ) );
				foreach ( $words as $word ) {
					if ( $header_lower === $word || str_contains( $header_lower, $word ) ) {
						$detected[ $field ] = $header;
						break 2;
					}
				}
			}
		}

		return array(
			'headers'  => $headers,
			'detected' => $detected,
		);
	}
}
