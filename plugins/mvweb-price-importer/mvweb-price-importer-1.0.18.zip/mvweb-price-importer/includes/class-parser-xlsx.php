<?php
/**
 * XLSX Parser — Excel file parsing via SimpleXLSX.
 *
 * Lightweight parsing with row limit protection (50,000 rows).
 * Uses Shuchkin\SimpleXLSX library (~100 KB, bundled in lib/).
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load SimpleXLSX library.
if ( ! class_exists( 'Shuchkin\SimpleXLSX' ) ) {
	require_once MVWEB_PI_PATH . 'lib/SimpleXLSX.php';
}

/**
 * Class MVweb_PI_Parser_XLSX
 *
 * Parses XLSX files using SimpleXLSX with row limit protection.
 *
 * @since 1.0.0
 */
class MVweb_PI_Parser_XLSX {

	/**
	 * Maximum rows to parse (ZIP-bomb protection).
	 *
	 * @var int
	 */
	const MAX_ROWS = 50000;

	/**
	 * Maximum uncompressed size of any single XLSX inner XML entry (250 MB).
	 *
	 * ZIP-bomb defense: SimpleXLSX::parse() loads the worksheet XML fully
	 * into memory before yielding rows. A 1 MB XLSX can decompress to
	 * gigabytes if crafted maliciously. We refuse to open the file when
	 * any inner entry's uncompressed size exceeds this bound.
	 *
	 * @var int
	 */
	const MAX_UNCOMPRESSED_BYTES = 250 * 1024 * 1024;

	/**
	 * Path to the XLSX file.
	 *
	 * @var string
	 */
	private string $file_path;

	/**
	 * Parsed XLSX instance.
	 *
	 * @var \Shuchkin\SimpleXLSX|null
	 */
	private ?\Shuchkin\SimpleXLSX $xlsx = null;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 * @param string $file_path Path to XLSX file.
	 */
	public function __construct( string $file_path ) {
		$this->file_path = $file_path;
	}

	/**
	 * Get headers (first row of the XLSX file).
	 *
	 * @since 1.0.0
	 * @return string[] Array of column header names.
	 */
	public function get_headers(): array {
		$xlsx = $this->get_xlsx();
		if ( ! $xlsx ) {
			return array();
		}

		$rows = $xlsx->rows( 0 );
		if ( empty( $rows ) || empty( $rows[0] ) ) {
			return array();
		}

		return array_map( 'trim', array_map( 'strval', $rows[0] ) );
	}

	/**
	 * Stream XLSX rows as a generator.
	 *
	 * Yields associative arrays (header => value) for each data row.
	 * Stops at MAX_ROWS to protect against ZIP-bomb attacks.
	 *
	 * @since 1.0.0
	 * @return \Generator<int, array<string, string>> Yields rows as header => value arrays.
	 */
	public function rows(): \Generator {
		$xlsx = $this->get_xlsx();
		if ( ! $xlsx ) {
			return;
		}

		// SimpleXLSX has no streaming API — rows(0) materialises the whole
		// sheet in memory at once (unlike the YML/CSV parsers which stream).
		// MAX_ROWS below bounds iteration but not this peak; for very large
		// spreadsheets prefer CSV/YML. Acceptable here as XLSX feeds are rare.
		$all_rows = $xlsx->rows( 0 );
		if ( empty( $all_rows ) ) {
			mvweb_pi_log( 'XLSX sheet is empty — no rows to import.', 'warning' );
			return;
		}

		$headers      = array_map( 'trim', array_map( 'strval', array_shift( $all_rows ) ) );
		$header_count = count( $headers );
		$count        = 0;

		if ( empty( $all_rows ) ) {
			mvweb_pi_log( 'XLSX sheet has a header row but no data rows.', 'warning' );
			return;
		}

		foreach ( $all_rows as $row ) {
			if ( ++$count > self::MAX_ROWS ) {
				mvweb_pi_log(
					sprintf( 'XLSX row limit reached (%d rows). Stopping.', self::MAX_ROWS ),
					'warning'
				);
				break;
			}

			// Skip empty rows.
			$row = array_map( 'strval', $row );
			if ( $this->is_empty_row( $row ) ) {
				continue;
			}

			// Pad or trim row to match header count.
			$row_count = count( $row );
			if ( $row_count < $header_count ) {
				$row = array_pad( $row, $header_count, '' );
			} elseif ( $row_count > $header_count ) {
				$row = array_slice( $row, 0, $header_count );
			}

			yield array_combine( $headers, $row );
		}
	}

	/**
	 * Get or create the SimpleXLSX instance.
	 *
	 * @since 1.0.0
	 * @return \Shuchkin\SimpleXLSX|null XLSX instance or null on error.
	 */
	private function get_xlsx(): ?\Shuchkin\SimpleXLSX {
		if ( null !== $this->xlsx ) {
			return $this->xlsx;
		}

		// ZIP-bomb defense: inspect uncompressed entry sizes via ZipArchive
		// before handing the file to SimpleXLSX (which buffers the worksheet
		// XML in memory). Refuses files that would decompress past the cap.
		if ( ! $this->is_zip_safe() ) {
			return null;
		}

		$this->xlsx = \Shuchkin\SimpleXLSX::parse( $this->file_path );

		if ( ! $this->xlsx ) {
			mvweb_pi_log(
				/* translators: %s: parser error message */
				sprintf( __( 'XLSX parse error: %s', 'mvweb-price-importer' ), \Shuchkin\SimpleXLSX::parseError() ),
				'error'
			);
			return null;
		}

		return $this->xlsx;
	}

	/**
	 * Verify that no entry inside the XLSX (a ZIP archive) decompresses
	 * past MAX_UNCOMPRESSED_BYTES.
	 *
	 * Returns true when the file is safe to parse or when ZipArchive is
	 * unavailable (in which case we fall back to SimpleXLSX's own row-level
	 * MAX_ROWS guard).
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	private function is_zip_safe(): bool {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return true;
		}

		$zip = new \ZipArchive();
		if ( true !== $zip->open( $this->file_path, \ZipArchive::RDONLY ) ) {
			mvweb_pi_log(
				__( 'XLSX rejected: file is not a valid ZIP archive.', 'mvweb-price-importer' ),
				'error'
			);
			return false;
		}

		$total = 0;
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$stat = $zip->statIndex( $i );
			if ( ! is_array( $stat ) ) {
				continue;
			}
			$size   = (int) ( $stat['size'] ?? 0 );
			$total += $size;
			if ( $size > self::MAX_UNCOMPRESSED_BYTES || $total > self::MAX_UNCOMPRESSED_BYTES ) {
				$zip->close();
				mvweb_pi_log(
					sprintf(
						/* translators: 1: entry name, 2: limit in MB */
						__( 'XLSX rejected: entry "%1$s" exceeds uncompressed limit (%2$d MB). Possible ZIP-bomb.', 'mvweb-price-importer' ),
						$stat['name'] ?? '?',
						(int) ( self::MAX_UNCOMPRESSED_BYTES / 1024 / 1024 )
					),
					'error'
				);
				return false;
			}
		}

		$zip->close();
		return true;
	}

	/**
	 * Check if a row is empty (all cells blank).
	 *
	 * @since 1.0.0
	 * @param array $row Row values.
	 * @return bool True if all cells are empty.
	 */
	private function is_empty_row( array $row ): bool {
		foreach ( $row as $cell ) {
			if ( '' !== trim( $cell ) ) {
				return false;
			}
		}
		return true;
	}
}
