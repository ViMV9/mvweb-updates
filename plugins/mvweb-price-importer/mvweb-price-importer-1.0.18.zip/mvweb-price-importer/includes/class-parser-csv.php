<?php
/**
 * CSV Parser — streaming CSV parsing with auto-detection.
 *
 * Supports auto-delimiter detection (semicolon, comma, tab),
 * auto-encoding detection (UTF-8, Windows-1251), and BOM handling.
 * Uses SplFileObject for memory-efficient streaming.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Parser_CSV
 *
 * Streaming CSV parser with automatic delimiter and encoding detection.
 *
 * @since 1.0.0
 */
class MVweb_PI_Parser_CSV {

	/**
	 * Path to the CSV file.
	 *
	 * @var string
	 */
	private string $file_path;

	/**
	 * Detected CSV delimiter.
	 *
	 * @var string
	 */
	private string $delimiter = ';';

	/**
	 * Detected file encoding.
	 *
	 * @var string
	 */
	private string $encoding = 'UTF-8';

	/**
	 * Whether file has UTF-8 BOM.
	 *
	 * @var bool
	 */
	private bool $has_bom = false;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 * @param string $file_path Path to CSV file.
	 */
	public function __construct( string $file_path ) {
		$this->file_path = $file_path;
		$this->detect_bom();
		$this->detect_encoding();
		$this->detect_delimiter();
	}

	/**
	 * Get CSV headers (first row).
	 *
	 * @since 1.0.0
	 * @return string[] Array of column header names.
	 */
	public function get_headers(): array {
		$file = new \SplFileObject( $this->file_path, 'r' );
		$file->setFlags( \SplFileObject::READ_CSV );
		$file->setCsvControl( $this->delimiter );

		$headers = $file->current();
		$file    = null;

		if ( ! is_array( $headers ) ) {
			return array();
		}

		// Convert encoding if needed.
		$headers = $this->convert_row_encoding( $headers );

		// Strip the BOM from the first header. ltrim() with a byte mask would
		// chew off any leading byte that happens to be 0xEF/0xBB/0xBF, not just
		// the 3-byte BOM sequence; remove exactly the prefix instead.
		if ( $this->has_bom && isset( $headers[0] ) && str_starts_with( $headers[0], "\xEF\xBB\xBF" ) ) {
			$headers[0] = substr( $headers[0], 3 );
		}

		// Trim whitespace from all headers.
		return array_map( 'trim', $headers );
	}

	/**
	 * Stream CSV rows as a generator.
	 *
	 * Yields associative arrays (header => value) for each data row.
	 * Does not load entire file into memory.
	 *
	 * @since 1.0.0
	 * @return \Generator<int, array<string, string>> Yields rows as header => value arrays.
	 */
	public function rows(): \Generator {
		$headers = $this->get_headers();
		if ( empty( $headers ) ) {
			return;
		}

		$header_count = count( $headers );

		$file = new \SplFileObject( $this->file_path, 'r' );
		$file->setFlags(
			\SplFileObject::READ_CSV
			| \SplFileObject::SKIP_EMPTY
			| \SplFileObject::DROP_NEW_LINE
		);
		$file->setCsvControl( $this->delimiter );

		// finally releases the SplFileObject (closing its descriptor) even if
		// the import loop throws while we're paused on a yield — otherwise the
		// handle would linger until GC, which adds up across long CLI batches.
		try {
			$is_first = true;
			foreach ( $file as $row ) {
				// Skip header row.
				if ( $is_first ) {
					$is_first = false;
					continue;
				}

				// Skip truly empty rows.
				if ( ! is_array( $row ) || ( 1 === count( $row ) && null === $row[0] ) ) {
					continue;
				}

				// Convert encoding.
				$row = $this->convert_row_encoding( $row );

				// Pad or trim row to match header count.
				$row_count = count( $row );
				if ( $row_count < $header_count ) {
					$row = array_pad( $row, $header_count, '' );
				} elseif ( $row_count > $header_count ) {
					$row = array_slice( $row, 0, $header_count );
				}

				yield array_combine( $headers, $row );
			}
		} finally {
			$file = null;
		}
	}

	/**
	 * Get detected delimiter.
	 *
	 * @since 1.0.0
	 * @return string The detected delimiter character.
	 */
	public function get_delimiter(): string {
		return $this->delimiter;
	}

	/**
	 * Get detected encoding.
	 *
	 * @since 1.0.0
	 * @return string The detected encoding name.
	 */
	public function get_encoding(): string {
		return $this->encoding;
	}

	/**
	 * Detect UTF-8 BOM at the start of the file.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function detect_bom(): void {
		$handle = fopen( $this->file_path, 'rb' );
		if ( ! $handle ) {
			return;
		}

		$bom = fread( $handle, 3 );
		fclose( $handle );

		$this->has_bom = ( "\xEF\xBB\xBF" === $bom );
	}

	/**
	 * Detect file encoding (UTF-8 or Windows-1251).
	 *
	 * Reads first 8KB and checks for encoding markers.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function detect_encoding(): void {
		$sample = file_get_contents( $this->file_path, false, null, 0, 8192 );
		if ( false === $sample ) {
			return;
		}

		// Strip BOM for detection.
		if ( $this->has_bom ) {
			$sample = substr( $sample, 3 );
		}

		// Try mb_detect_encoding with strict mode.
		$detected = mb_detect_encoding( $sample, array( 'UTF-8', 'Windows-1251', 'ISO-8859-1' ), true );

		if ( $detected && 'UTF-8' !== $detected ) {
			$this->encoding = $detected;
		}
	}

	/**
	 * Detect CSV delimiter by analyzing first few lines.
	 *
	 * Tests semicolon, comma, and tab delimiters.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function detect_delimiter(): void {
		$sample = file_get_contents( $this->file_path, false, null, 0, 8192 );
		if ( false === $sample ) {
			return;
		}

		// Strip BOM.
		if ( $this->has_bom ) {
			$sample = substr( $sample, 3 );
		}

		// Convert encoding for proper analysis.
		if ( 'UTF-8' !== $this->encoding ) {
			$converted = iconv( $this->encoding, 'UTF-8//IGNORE', $sample );
			if ( false !== $converted ) {
				$sample = $converted;
			}
		}

		// Get first 5 lines.
		$lines = explode( "\n", $sample );
		$lines = array_slice( $lines, 0, 5 );

		$delimiters = array( ';', ',', "\t" );
		$scores     = array();

		foreach ( $delimiters as $delim ) {
			$counts = array();
			foreach ( $lines as $line ) {
				$line = trim( $line );
				if ( '' === $line ) {
					continue;
				}
				$counts[] = substr_count( $line, $delim );
			}

			if ( empty( $counts ) ) {
				$scores[ $delim ] = 0;
				continue;
			}

			// Score: prefer delimiter that gives consistent non-zero count across lines.
			$min   = min( $counts );
			$max   = max( $counts );
			$total = array_sum( $counts );

			// Consistency bonus: if all lines have the same count, it's likely the delimiter.
			$consistency = ( $min === $max && $min > 0 ) ? 100 : 0;
			$scores[ $delim ] = $total + $consistency;
		}

		// Pick delimiter with highest score.
		arsort( $scores );
		$best = key( $scores );

		if ( $best && $scores[ $best ] > 0 ) {
			$this->delimiter = $best;
		}
	}

	/**
	 * Convert a row from detected encoding to UTF-8.
	 *
	 * @since 1.0.0
	 * @param array $row CSV row values.
	 * @return array Converted row values.
	 */
	private function convert_row_encoding( array $row ): array {
		if ( 'UTF-8' === $this->encoding ) {
			return $row;
		}

		return array_map(
			function ( $value ) {
				if ( ! is_string( $value ) || '' === $value ) {
					return $value;
				}
				$converted = iconv( $this->encoding, 'UTF-8//IGNORE', $value );
				return ( false !== $converted ) ? $converted : $value;
			},
			$row
		);
	}
}
