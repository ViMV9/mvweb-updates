<?php
/**
 * CLI feeds runner for system cron integration.
 *
 * Regenerates YML feeds (general + per-warehouse) independently of import.
 * Schedule it separately in crontab when you want feeds refreshed on a
 * different cadence than the import itself — e.g. import once a day,
 * feeds every hour.
 *
 * Usage: php feeds-cron-runner.php
 * Add to crontab: 0 * * * * php /path/to/wp-content/plugins/mvweb-price-importer/feeds-cron-runner.php
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Only allow CLI execution.
if ( 'cli' !== php_sapi_name() ) {
	http_response_code( 403 );
	exit( 'This script can only be run from the command line.' );
}

// Bootstrap WordPress.
// Plugin path: wp-content/plugins/mvweb-price-importer/feeds-cron-runner.php
// wp-load.php: ../../../../wp-load.php
$wp_load = dirname( __FILE__, 4 ) . '/wp-load.php';

if ( ! file_exists( $wp_load ) ) {
	// Try alternative path for non-standard installations.
	$wp_load = dirname( __FILE__, 5 ) . '/wp-load.php';
}

if ( ! file_exists( $wp_load ) ) {
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	fwrite( STDERR, "Error: wp-load.php not found. Tried:\n" );
	fwrite( STDERR, '  ' . dirname( __FILE__, 4 ) . "/wp-load.php\n" );
	fwrite( STDERR, '  ' . dirname( __FILE__, 5 ) . "/wp-load.php\n" );
	exit( 1 );
}

if ( ! defined( 'DOING_CRON' ) ) {
	define( 'DOING_CRON', true );
}

require_once $wp_load;

// Verify plugin is active.
if ( ! defined( 'MVWEB_PI_VERSION' ) ) {
	fwrite( STDERR, "Error: MVweb Price Importer is not active.\n" );
	exit( 1 );
}

if ( function_exists( 'set_time_limit' ) ) {
	set_time_limit( 0 );
}

try {
	$feeds_handler = new MVweb_PI_Feeds();
	$results       = $feeds_handler->generate_all();

	$total_products = 0;
	foreach ( $results as $feed ) {
		$total_products += (int) ( $feed['products'] ?? 0 );
	}

	fwrite(
		STDOUT,
		sprintf(
			"Feeds generated: %d file(s), %d total products.\n",
			count( $results ),
			$total_products
		)
	);

	exit( 0 );

} catch ( \Throwable $e ) {
	fwrite( STDERR, sprintf( "Feed generation failed: %s\n", $e->getMessage() ) );
	exit( 1 );
}
