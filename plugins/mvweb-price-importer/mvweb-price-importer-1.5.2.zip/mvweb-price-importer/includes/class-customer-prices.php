<?php
/**
 * Customer prices — the price type of a customer's MoySklad counterparty.
 *
 * A counterparty in MoySklad can carry a price type in its "Prices" field. A
 * customer on the site whose account email is that counterparty's email buys
 * at that type, once they have confirmed the email.
 *
 * Confirmation is WooCommerce's own (11.0+): the link from its "Confirm email
 * address" message, setting or resetting the password, or the checkbox in the
 * user profile. The plugin keeps no token and sends no email of its own. A
 * WooCommerce registration logs the new customer in straight away without
 * asking whether the address is theirs, so without that confirmation anybody
 * could register under a wholesale customer's email and buy at their prices.
 *
 * Customers and counterparties are matched once an hour by one read of the
 * counterparty list, never per registration: nothing a visitor does reaches
 * the API, and nothing in the timing of a sign-up tells whether an email
 * belongs to a wholesale customer.
 *
 * @package mvweb_pi
 * @since   1.5.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Customer_Prices
 *
 * @since 1.5.0
 */
class MVweb_PI_Customer_Prices {

	/**
	 * Cron hook of the hourly match.
	 *
	 * @since 1.5.0
	 * @var string
	 */
	const HOOK = 'mvweb_pi_customer_prices_sync';

	/**
	 * User option holding the link: counterparty id, price type id, email.
	 *
	 * Per site, like WooCommerce's own confirmation: two sites of a network
	 * can be connected to two different MoySklad accounts.
	 *
	 * @since 1.5.0
	 * @var string
	 */
	const LINK_META = '_mvweb_pi_customer';

	/**
	 * Where the result of the last match is kept, for the settings screen.
	 *
	 * @since 1.5.0
	 * @var string
	 */
	const LAST_RUN_OPTION = 'mvweb_pi_customer_prices_last';

	/**
	 * Counterparties per page — the API's maximum.
	 *
	 * @since 1.5.0
	 * @var int
	 */
	const PAGE = 1000;

	/**
	 * Session key remembering the price type the cart totals were worked out at.
	 *
	 * @since 1.5.0
	 * @var string
	 */
	const SESSION_KEY = 'mvweb_pi_price_type';

	/**
	 * Order meta: the counterparty whose price type the order was placed at.
	 *
	 * @since 1.5.0
	 * @var string
	 */
	const ORDER_AGENT_META = '_mvweb_pi_ms_agent';

	/**
	 * Order meta: the name of that price type.
	 *
	 * @since 1.5.0
	 * @var string
	 */
	const ORDER_TYPE_META = '_mvweb_pi_price_type';

	/**
	 * Hook everything up.
	 *
	 * @since 1.5.0
	 * @return void
	 */
	public static function register(): void {
		add_action( self::HOOK, array( __CLASS__, 'sync' ) );
		add_action( 'admin_init', array( __CLASS__, 'schedule' ) );
		add_action( 'woocommerce_customer_email_verified', array( __CLASS__, 'on_verified' ) );
		add_filter( 'woocommerce_customer_email_verification_should_show_prompt', array( __CLASS__, 'show_prompt' ), 10, 2 );

		foreach ( array( 'woocommerce_product_get_', 'woocommerce_product_variation_get_', 'woocommerce_variation_prices_' ) as $prefix ) {
			add_filter( $prefix . 'price', array( __CLASS__, 'filter_price' ), 10, 2 );
			add_filter( $prefix . 'regular_price', array( __CLASS__, 'filter_regular_price' ), 10, 2 );
			add_filter( $prefix . 'sale_price', array( __CLASS__, 'filter_sale_price' ), 10, 2 );
		}
		add_filter( 'woocommerce_get_variation_prices_hash', array( __CLASS__, 'variation_prices_hash' ) );
		add_filter( 'woocommerce_variation_is_visible', array( __CLASS__, 'variation_visible' ), 10, 2 );
		add_filter( 'woocommerce_empty_price_html', array( __CLASS__, 'on_request_html' ), 10, 2 );
		add_filter( 'woocommerce_variable_empty_price_html', array( __CLASS__, 'on_request_html' ), 10, 2 );
		add_action( 'woocommerce_cart_loaded_from_session', array( __CLASS__, 'refresh_cart' ) );
		add_action( 'woocommerce_checkout_create_order', array( __CLASS__, 'stamp_order' ) );
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( __CLASS__, 'stamp_order' ) );
		add_action( 'woocommerce_new_order', array( __CLASS__, 'stamp_new_order' ), 10, 2 );
		add_action( 'woocommerce_account_dashboard', array( __CLASS__, 'account_line' ) );
		add_action( 'show_user_profile', array( __CLASS__, 'profile_block' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'profile_block' ) );
	}

	/**
	 * Keep the hourly match scheduled exactly while the feature is on.
	 *
	 * Checked on every admin request rather than only on saving the settings,
	 * so a site that switched source or lost its schedule comes right by
	 * itself; the storefront pays nothing for it, since both the switch and
	 * the setting happen in the admin.
	 *
	 * @since 1.5.0
	 * @return void
	 */
	public static function schedule(): void {
		$next = wp_next_scheduled( self::HOOK );

		if ( mvweb_pi_customer_prices_enabled() ) {
			if ( ! $next ) {
				wp_schedule_event( time() + MINUTE_IN_SECONDS, 'hourly', self::HOOK );
			}
		} elseif ( $next ) {
			wp_unschedule_hook( self::HOOK );
		}
	}

	/**
	 * Match customers to counterparties.
	 *
	 * Reads every counterparty — archived ones are left out by the API — and
	 * links each user whose account email is the email of a counterparty with
	 * a price type. The type is stored whether or not it is allowed on the
	 * settings screen: that is checked when the price is worked out, so a
	 * change there takes effect at once.
	 *
	 * Nothing is unlinked on a failed or empty read. Either would otherwise
	 * drop every wholesale customer back to retail until the next good one.
	 *
	 * @since 1.5.0
	 * @return void
	 */
	public static function sync(): void {
		if ( ! mvweb_pi_customer_prices_enabled() ) {
			return;
		}

		$ms    = get_option( 'mvweb_pi_moysklad', array() );
		$token = is_array( $ms ) ? (string) ( $ms['token'] ?? '' ) : '';
		if ( '' === $token ) {
			return;
		}

		try {
			$rows = self::fetch_counterparties( new MVweb_PI_MoySklad_Client( $token, (int) ( $ms['rate_limit'] ?? MVweb_PI_MoySklad_Client::DEFAULT_RATE ) ) );
		} catch ( \RuntimeException $e ) {
			self::finish( 'error', $e->getMessage() );
			return;
		}

		$linked = self::linked_users();
		if ( empty( $rows ) && ! empty( $linked ) ) {
			self::finish( 'error', __( 'Customer prices: MoySklad returned no counterparties, so the customer links were left as they were.', 'mvweb-price-importer' ) );
			return;
		}

		$by_email  = self::typed_by_email( $rows );
		$conflicts = array();
		$keep      = array();

		foreach ( $by_email as $email => $candidates ) {
			if ( count( array_unique( array_column( $candidates, 'type' ) ) ) > 1 ) {
				$conflicts[] = $email;
				continue;
			}

			$user = get_user_by( 'email', $email );
			if ( ! $user instanceof \WP_User || strtolower( $user->user_email ) !== $email ) {
				continue;
			}

			$link = array(
				'counterparty' => (string) $candidates[0]['id'],
				'type'         => (string) $candidates[0]['type'],
				'email'        => $email,
			);

			// A new link drops the account's application passwords: one made by
			// whoever registered under this email before its owner confirmed it
			// would otherwise read the owner's prices, whichever came first.
			if ( ! in_array( $user->ID, $linked, true ) && class_exists( 'WP_Application_Passwords' ) ) {
				WP_Application_Passwords::delete_all_application_passwords( $user->ID );
			}

			update_user_option( $user->ID, self::LINK_META, $link );
			$keep[ $user->ID ] = true;
		}

		$unlinked = 0;
		foreach ( $linked as $user_id ) {
			if ( ! isset( $keep[ $user_id ] ) ) {
				delete_user_option( $user_id, self::LINK_META );
				++$unlinked;
			}
		}

		if ( ! empty( $conflicts ) ) {
			mvweb_pi_log(
				sprintf(
					/* translators: %s: email addresses */
					__( 'Customer prices: these emails belong to several MoySklad counterparties with different price types, so they were not linked: %s', 'mvweb-price-importer' ),
					implode( ', ', array_slice( $conflicts, 0, 20 ) )
				),
				'warning'
			);
		}

		self::finish(
			'ok',
			sprintf(
				/* translators: 1: linked customers, 2: unlinked customers, 3: counterparties read */
				__( 'Customer prices: %1$d customers linked, %2$d unlinked, %3$d counterparties read.', 'mvweb-price-importer' ),
				count( $keep ),
				$unlinked,
				count( $rows )
			)
		);
	}

	/**
	 * Read the whole counterparty list.
	 *
	 * There is no filter for "a price type is set" (`priceType!=` is refused
	 * with 412), so the list is read whole; a thousand counterparties are one
	 * request. A page without rows, or a list shorter than the size the API
	 * reported, is a failed read: taken for the end of the list it would
	 * unlink every customer on the pages that never arrived.
	 *
	 * @since 1.5.0
	 * @param MVweb_PI_MoySklad_Client $client API client.
	 * @return array[] Counterparty rows.
	 * @throws \RuntimeException When the API cannot be read in full.
	 */
	private static function fetch_counterparties( MVweb_PI_MoySklad_Client $client ): array {
		$rows   = array();
		$offset = 0;
		$size   = 0;

		do {
			$page = $client->get(
				'entity/counterparty',
				array(
					'limit'  => self::PAGE,
					'offset' => $offset,
				)
			);

			if ( ! isset( $page['rows'] ) || ! is_array( $page['rows'] ) ) {
				throw new \RuntimeException( __( 'Customer prices: MoySklad sent a page of counterparties that could not be read.', 'mvweb-price-importer' ) );
			}

			$size    = (int) ( $page['meta']['size'] ?? 0 );
			$rows    = array_merge( $rows, $page['rows'] );
			$offset += self::PAGE;
		} while ( self::PAGE === count( $page['rows'] ) );

		if ( count( $rows ) < $size ) {
			throw new \RuntimeException( __( 'Customer prices: MoySklad sent fewer counterparties than it reported.', 'mvweb-price-importer' ) );
		}

		return $rows;
	}

	/**
	 * Counterparties with a price type and an email, grouped by email.
	 *
	 * @since 1.5.0
	 * @param array[] $rows Counterparty rows.
	 * @return array<string, array<int, array{id: string, type: string}>>
	 */
	private static function typed_by_email( array $rows ): array {
		$by_email = array();

		foreach ( $rows as $row ) {
			$email = strtolower( trim( (string) ( $row['email'] ?? '' ) ) );
			$type  = (string) ( $row['priceType']['id'] ?? '' );

			if ( '' === $email || '' === $type || ! empty( $row['archived'] ) || ! is_email( $email ) ) {
				continue;
			}

			$by_email[ $email ][] = array(
				'id'   => (string) ( $row['id'] ?? '' ),
				'type' => $type,
			);
		}

		return $by_email;
	}

	/**
	 * Ids of the users that carry a link now.
	 *
	 * @since 1.5.0
	 * @return int[]
	 */
	private static function linked_users(): array {
		global $wpdb;

		return array_map(
			'intval',
			get_users(
				array(
					'meta_key' => $wpdb->get_blog_prefix() . self::LINK_META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
					'fields'   => 'ID',
					'number'   => -1,
				)
			)
		);
	}

	/**
	 * Record the outcome of a match, and log a failure.
	 *
	 * @since 1.5.0
	 * @param string $status  'ok' or 'error'.
	 * @param string $message What happened.
	 * @return void
	 */
	private static function finish( string $status, string $message ): void {
		update_option(
			self::LAST_RUN_OPTION,
			array(
				'time'    => time(),
				'status'  => $status,
				'message' => $message,
			),
			false
		);

		mvweb_pi_log( $message, 'ok' === $status ? 'info' : 'error' );
	}

	/**
	 * Whether WooCommerce has confirmed the user's current account email.
	 *
	 * Asked of WooCommerce's own service. Its classes are internal, so when it
	 * is missing or changes shape the answer is "no" and the customer pays
	 * retail — the safe side to be wrong on.
	 *
	 * @since 1.5.0
	 * @param int $user_id User id.
	 * @return bool
	 */
	public static function email_verified( int $user_id ): bool {
		$service = 'Automattic\\WooCommerce\\Internal\\CustomerEmailVerification\\EmailVerificationService';
		if ( $user_id <= 0 || ! class_exists( $service ) || ! function_exists( 'wc_get_container' ) ) {
			return false;
		}

		try {
			$instance = wc_get_container()->get( $service );
		} catch ( \Throwable $e ) {
			return false;
		}

		return method_exists( $instance, 'is_verified' ) && true === $instance->is_verified( $user_id );
	}

	/**
	 * The price type a user buys at, or null.
	 *
	 * Null unless the feature is on, the user is linked, WooCommerce has
	 * confirmed the very email the link was made for, and the type is allowed
	 * on the settings screen.
	 *
	 * @since 1.5.0
	 * @param int $user_id User id; the current user when 0.
	 * @return array{id: string, name: string}|null
	 */
	public static function price_type( int $user_id = 0 ): ?array {
		static $cache = array();

		$user_id = $user_id > 0 ? $user_id : get_current_user_id();
		if ( $user_id <= 0 ) {
			return null;
		}
		if ( array_key_exists( $user_id, $cache ) ) {
			return $cache[ $user_id ];
		}

		$cache[ $user_id ] = null;

		if ( ! mvweb_pi_customer_prices_enabled() ) {
			return null;
		}

		$link = get_user_option( self::LINK_META, $user_id );
		$user = get_userdata( $user_id );
		if ( ! is_array( $link ) || ! $user instanceof \WP_User || strtolower( $user->user_email ) !== (string) ( $link['email'] ?? '' ) ) {
			return null;
		}

		$type = (string) ( $link['type'] ?? '' );
		if ( '' === $type || ! in_array( $type, mvweb_pi_customer_price_types(), true ) || ! self::email_verified( $user_id ) ) {
			return null;
		}

		$ms    = get_option( 'mvweb_pi_moysklad', array() );
		$names = is_array( $ms ) && is_array( $ms['price_types'] ?? null ) ? $ms['price_types'] : array();

		$cache[ $user_id ] = array(
			'id'   => $type,
			'name' => (string) ( $names[ $type ] ?? '' ),
		);

		return $cache[ $user_id ];
	}

	/**
	 * Whether the current customer's own prices apply to this request.
	 *
	 * On the storefront, in the Store API and in the REST routes a theme or
	 * plugin serves the customer's own browser — favourites, a one-click order.
	 * Never in the admin, its AJAX included: quick edit reads the prices it
	 * writes back, and a manager adding a line to an order would get their own
	 * type. Never in the routes the shop is managed through, WooCommerce's and
	 * WordPress's own, nor in a REST request without the session's nonce, which
	 * is an integration signed in with a key or an application password.
	 *
	 * @since 1.5.0
	 * @since 1.5.2 REST routes outside WooCommerce and WordPress count as the storefront.
	 * @return bool
	 */
	public static function applies(): bool {
		static $storefront = null;

		if ( null === $storefront ) {
			if ( is_admin() || ! function_exists( 'WC' ) ) {
				$storefront = false;
			} elseif ( ! WC()->is_rest_api_request() || WC()->is_store_api_request() ) {
				$storefront = true;
			} else {
				// Asked before the route is parsed: not yet, and not remembered.
				$route = isset( $GLOBALS['wp'] ) ? (string) ( $GLOBALS['wp']->query_vars['rest_route'] ?? '' ) : '';
				if ( '' === $route ) {
					return false;
				}

				$referer    = (string) wp_get_raw_referer();
				$storefront = ( isset( $_SERVER['HTTP_X_WP_NONCE'] ) || isset( $_REQUEST['_wpnonce'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- presence only; the REST API checks it.
					&& ! preg_match( '#^/(wc/|wc-|wp/|wp-|mvweb-pi/|batch/)#i', $route )
					&& false === strpos( $referer, (string) wp_parse_url( admin_url(), PHP_URL_PATH ) );
			}
		}

		return $storefront && null !== self::price_type();
	}

	/**
	 * The customer's price for a product property, or null to leave it alone.
	 *
	 * Left alone: a product the importer has not written price types for yet
	 * (made by hand, not imported since), and a property already set during
	 * this request, such as a cart price set by a quantity discount. A missing
	 * price of the type is an empty one, which WooCommerce does not sell. The
	 * sale price is always empty: the customer's type is the price.
	 *
	 * @since 1.5.0
	 * @param mixed  $product Product or variation.
	 * @param string $prop    'price', 'regular_price' or 'sale_price'.
	 * @return string|null
	 */
	private static function own_price( $product, string $prop ): ?string {
		if ( ! $product instanceof \WC_Product || ! self::applies() || array_key_exists( $prop, $product->get_changes() ) ) {
			return null;
		}

		$prices = get_post_meta( $product->get_id(), '_mvweb_pi_prices', true );
		if ( ! is_array( $prices ) ) {
			return null;
		}

		if ( 'sale_price' === $prop ) {
			return '';
		}

		return (string) ( $prices[ self::price_type()['id'] ] ?? '' );
	}

	/**
	 * Price filter.
	 *
	 * @since 1.5.0
	 * @param mixed $price   Price.
	 * @param mixed $product Product or variation.
	 * @return mixed
	 */
	public static function filter_price( $price, $product ) {
		return self::own_price( $product, 'price' ) ?? $price;
	}

	/**
	 * Regular price filter.
	 *
	 * @since 1.5.0
	 * @param mixed $price   Regular price.
	 * @param mixed $product Product or variation.
	 * @return mixed
	 */
	public static function filter_regular_price( $price, $product ) {
		return self::own_price( $product, 'regular_price' ) ?? $price;
	}

	/**
	 * Sale price filter.
	 *
	 * @since 1.5.0
	 * @param mixed $price   Sale price.
	 * @param mixed $product Product or variation.
	 * @return mixed
	 */
	public static function filter_sale_price( $price, $product ) {
		return self::own_price( $product, 'sale_price' ) ?? $price;
	}

	/**
	 * Keep the cached variation prices of each price type apart.
	 *
	 * @since 1.5.0
	 * @param array $hash Data the cache key is made of.
	 * @return array
	 */
	public static function variation_prices_hash( $hash ) {
		if ( self::applies() ) {
			$hash['mvweb_pi_price_type'] = self::price_type()['id'];
		}

		return $hash;
	}

	/**
	 * Show a variation without a price of the customer's type.
	 *
	 * WooCommerce hides a variation without a price as "unavailable". Shown,
	 * it reads "Price on request" and still cannot be bought.
	 *
	 * @since 1.5.0
	 * @param bool $visible      Whether WooCommerce would show it.
	 * @param int  $variation_id Variation id.
	 * @return bool
	 */
	public static function variation_visible( $visible, $variation_id ): bool {
		if ( $visible ) {
			return true;
		}

		return self::applies()
			&& 'publish' === get_post_status( (int) $variation_id )
			&& is_array( get_post_meta( (int) $variation_id, '_mvweb_pi_prices', true ) );
	}

	/**
	 * "Price on request" where the customer's type has no price.
	 *
	 * Only on imported products: a simple product or variation carries the
	 * price types itself, a variable product the MoySklad id.
	 *
	 * @since 1.5.0
	 * @param string $html    Empty price HTML.
	 * @param mixed  $product Product, variation or variable product.
	 * @return string
	 */
	public static function on_request_html( $html, $product ) {
		if ( ! $product instanceof \WC_Product || ! self::applies() ) {
			return $html;
		}
		$imported = $product->is_type( 'variable' )
			? '' !== (string) get_post_meta( $product->get_id(), MVweb_PI_Stock_Sync::ID_META, true )
			: is_array( get_post_meta( $product->get_id(), '_mvweb_pi_prices', true ) );
		if ( ! $imported ) {
			return $html;
		}

		return '<span class="mvweb-pi-price-on-request">' . esc_html__( 'Price on request', 'mvweb-price-importer' ) . '</span>';
	}

	/**
	 * Work the cart totals out again once the customer's price type changes.
	 *
	 * WooCommerce keeps the totals in the session and the mini cart shows them
	 * as kept, while the line prices are read afresh: after a link appears or
	 * goes, the total would disagree with the lines until the next change to
	 * the cart. Lines without a price of the new type are already removed by
	 * WooCommerce, as products that cannot be bought.
	 *
	 * @since 1.5.0
	 * @param WC_Cart $cart Cart.
	 * @return void
	 */
	public static function refresh_cart( $cart ): void {
		if ( ! $cart instanceof \WC_Cart || ! WC()->session || is_admin() ) {
			return;
		}

		$type = self::applies() ? self::price_type()['id'] : '';
		if ( (string) WC()->session->get( self::SESSION_KEY, '' ) === $type ) {
			return;
		}

		WC()->session->set( self::SESSION_KEY, $type );
		if ( ! $cart->is_empty() ) {
			$cart->calculate_totals();
		}
	}

	/**
	 * Note on the order the counterparty and price type it is placed at.
	 *
	 * Taken at checkout, from the classic form and the Store API alike, so
	 * the order goes to MoySklad under the customer it was priced for, however
	 * the link changes before it is sent. The Store API updates the same draft
	 * order on every attempt, hence the clearing.
	 *
	 * @since 1.5.0
	 * @param WC_Order $order Order being placed.
	 * @return void
	 */
	public static function stamp_order( $order ): void {
		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		$link = self::applies() ? get_user_option( self::LINK_META, get_current_user_id() ) : false;
		if ( ! is_array( $link ) || '' === (string) ( $link['counterparty'] ?? '' ) ) {
			$order->delete_meta_data( self::ORDER_AGENT_META );
			$order->delete_meta_data( self::ORDER_TYPE_META );
			return;
		}

		$order->update_meta_data( self::ORDER_AGENT_META, (string) $link['counterparty'] );
		$order->update_meta_data( self::ORDER_TYPE_META, self::price_type()['name'] );
	}

	/**
	 * The same note on an order made outside the checkout.
	 *
	 * A theme's one-click order is created in its own REST route, priced for
	 * the signed-in customer, and passes neither checkout hook. Only an order
	 * of that customer, and one the checkout has not noted already.
	 *
	 * @since 1.5.2
	 * @param int           $order_id Order id.
	 * @param WC_Order|null $order    Order just created.
	 * @return void
	 */
	public static function stamp_new_order( $order_id, $order = null ): void {
		if ( ! $order instanceof \WC_Order || ! self::applies()
			|| $order->get_customer_id() !== get_current_user_id()
			|| '' !== (string) $order->get_meta( self::ORDER_AGENT_META ) ) {
			return;
		}

		self::stamp_order( $order );
		$order->save_meta_data();
	}

	/**
	 * "Your price type" on the My Account dashboard.
	 *
	 * Only to a customer the type applies to: telling an unconfirmed account
	 * that its email has a type would tell whoever registered under it too.
	 *
	 * @since 1.5.0
	 * @return void
	 */
	public static function account_line(): void {
		$type = self::price_type();
		if ( null === $type || '' === $type['name'] ) {
			return;
		}

		printf(
			'<p class="mvweb-pi-account-price-type">%s <strong>%s</strong></p>',
			esc_html__( 'Your price type:', 'mvweb-price-importer' ),
			esc_html( $type['name'] )
		);
	}

	/**
	 * The customer's price type and why it does or does not apply, in the
	 * user profile.
	 *
	 * For shop managers only, and read-only: the type comes from MoySklad, and
	 * the email is confirmed with WooCommerce's own checkbox on the same
	 * screen.
	 *
	 * @since 1.5.0
	 * @param WP_User $user User being edited.
	 * @return void
	 */
	public static function profile_block( $user ): void {
		if ( ! $user instanceof \WP_User || ! mvweb_pi_customer_prices_enabled() || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$link  = get_user_option( self::LINK_META, $user->ID );
		$ms    = get_option( 'mvweb_pi_moysklad', array() );
		$names = is_array( $ms ) && is_array( $ms['price_types'] ?? null ) ? $ms['price_types'] : array();
		$type  = is_array( $link ) ? (string) ( $link['type'] ?? '' ) : '';

		if ( '' === $type ) {
			$status = __( 'Not linked: no MoySklad counterparty with a price type has this email. Links are refreshed every hour.', 'mvweb-price-importer' );
		} elseif ( strtolower( $user->user_email ) !== (string) ( $link['email'] ?? '' ) ) {
			$status = __( 'Not applied: the account email has changed since the link was made. The next hourly match brings it up to date.', 'mvweb-price-importer' );
		} elseif ( ! in_array( $type, mvweb_pi_customer_price_types(), true ) ) {
			$status = __( 'Not applied: this price type is switched off on the MoySklad tab.', 'mvweb-price-importer' );
		} elseif ( ! self::email_verified( $user->ID ) ) {
			$status = __( 'Not applied: the customer has not confirmed their email yet. It can be confirmed with the WooCommerce checkbox on this screen.', 'mvweb-price-importer' );
		} else {
			$status = __( 'Applies: the customer sees and buys at this price type.', 'mvweb-price-importer' );
		}
		?>
		<h2><?php esc_html_e( 'MoySklad price type', 'mvweb-price-importer' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Price type', 'mvweb-price-importer' ); ?></th>
				<td><?php echo esc_html( '' !== $type ? (string) ( $names[ $type ] ?? $type ) : '—' ); ?></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Status', 'mvweb-price-importer' ); ?></th>
				<td><?php echo esc_html( $status ); ?></td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Close the doors a confirmation leaves open.
	 *
	 * Application passwords outlive a password reset, so one created by
	 * whoever registered under the customer's email would keep reading their
	 * prices. From the customer's own session the other sessions are closed;
	 * from an administrator's checkbox every session of the customer is,
	 * since the one still open may belong to whoever registered under the
	 * email. A password reset has closed them already.
	 *
	 * @since 1.5.0
	 * @param int $user_id User id.
	 * @return void
	 */
	public static function on_verified( $user_id ): void {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 || ! mvweb_pi_customer_prices_enabled() ) {
			return;
		}

		if ( class_exists( 'WP_Application_Passwords' ) ) {
			WP_Application_Passwords::delete_all_application_passwords( $user_id );
		}

		if ( get_current_user_id() === $user_id ) {
			wp_destroy_other_sessions();
		} else {
			WP_Session_Tokens::get_instance( $user_id )->destroy_all();
		}
	}

	/**
	 * Offer every unconfirmed customer WooCommerce's "confirm your email".
	 *
	 * WooCommerce shows it only on shops that allow guest checkout. The same
	 * prompt for everybody tells nobody whether their email is a wholesale
	 * one. WooCommerce asks only about unconfirmed accounts. Left alone: an
	 * account still on a generated password, whose set-password link confirms
	 * the email too, and a shop that switched the confirmation email off — the
	 * button would report a link that never leaves.
	 *
	 * @since 1.5.0
	 * @param bool $show    Whether WooCommerce would show it.
	 * @param int  $user_id User id.
	 * @return bool
	 */
	public static function show_prompt( $show, $user_id ): bool {
		if ( $show || ! mvweb_pi_customer_prices_enabled() ) {
			return (bool) $show;
		}

		$email = get_option( 'woocommerce_customer_verify_email_settings', array() );
		if ( 'yes' !== ( is_array( $email ) ? ( $email['enabled'] ?? 'yes' ) : 'yes' ) ) {
			return false;
		}

		return ! get_user_option( 'default_password_nag', (int) $user_id );
	}
}

/**
 * The price type the current or given customer buys at.
 *
 * For themes: `array( 'id' => …, 'name' => 'Опт 1' )` when the customer gets a
 * price type of their own, null otherwise — including when the feature is off
 * or the customer has not confirmed their email.
 *
 * @since 1.5.0
 * @param int $user_id User id; the current user when 0.
 * @return array{id: string, name: string}|null
 */
function mvweb_pi_customer_price_type( int $user_id = 0 ): ?array {
	return MVweb_PI_Customer_Prices::price_type( $user_id );
}
