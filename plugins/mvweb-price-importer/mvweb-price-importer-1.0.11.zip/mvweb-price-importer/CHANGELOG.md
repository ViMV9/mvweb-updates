# Changelog

All notable changes to MVweb Price Importer will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.11] - 2026-06-04

### Fixed
- **Stock-out now covers every duplicate copy of a SKU, not just one.** The catalog can hold several products sharing one SKU — duplicates left behind by an older plugin build that failed to dedupe. Both stock paths previously resolved a SKU to a single product (`process_batch()` via `resolve_existing_skus()` → one lookup id; `zero_missing_stock()` via `wc_get_product_id_by_sku()` → one lookup row), so when a SKU had duplicates only one copy ever got its stock updated and the rest stayed "in stock" — including SKUs that were already sold out or dropped from the feed. Both paths now resolve a SKU to *every* live product carrying it through a single `_sku` postmeta query (new `resolve_all_ids_by_skus()`, batched — one SELECT per import batch / per missing-SKU set, not per row), excluding trashed posts. For a SKU present in the feed, the canonical (lowest-id) copy is updated and the extra duplicates are forced out of stock (zeroing is unconditional, so a duplicate is never left in stock even if the canonical update bails); for a SKU dropped from the feed, all copies are zeroed. Stock-out is centralised in a new `zero_out_product()` helper shared by both paths so they apply identical semantics. The plugin still never deletes products — clearing the duplicate rows themselves stays a manual catalog tidy.

## [1.0.10] - 2026-05-31

### Fixed
- **The MVweb Hub page is fully translated regardless of which plugins are installed.** The shared `MVweb_Menu` derived its textdomain from the first known MVweb plugin constant it found, so the hub's own strings only showed up translated if that particular plugin happened to ship the full hub catalogue in its `.po`. On a site with several MVweb plugins the hub could come out half-English (e.g. the studio blurb, section headers and "active"/"inactive" badges). The hub now owns a dedicated `mvweb-hub` textdomain with its own bundled `mvweb-hub-{locale}.mo` (shipped inside `includes/languages/`), loaded independently of any plugin, so the hub reads correctly for any combination of installed MVweb plugins.

### Changed
- **The outgoing YML feed now lists only non-empty category chains.** `write_categories()` previously emitted every `product_cat` term (`hide_empty => false`), so a feed for a supplier with hundreds of categories but only a handful of in-stock products carried hundreds of empty branches. It now collects the categories that actually carry feed-eligible products (same gate as the offers: published, in stock for the warehouse context, with a usable price), walks each one's parent chain up to the root, and writes only that minimal connected set. Empty leaf categories are dropped; empty parents that sit above a non-empty child are kept so no `parentId` ever points at a category missing from the feed. On the ns60.ru feed (320 categories, 2 in-stock products) the category block shrank from 320 entries to the 5 that form the two product chains.

## [1.0.9] - 2026-05-31

### Fixed
- **Re-importing the same feed no longer creates duplicate products.** `create_product()` writes products with a low-level `wp_insert_post()` + `update_post_meta()` path that bypasses `WC_Product->save()` for speed, so the `wc_product_meta_lookup` row WooCommerce normally maintains was never written. `process_batch()` resolves "does this SKU already exist?" through `resolve_existing_skus()`, which queried only that (always-empty) lookup table, so every run re-created the same SKUs as fresh duplicates — on a 1400-SKU feed that doubled the catalogue on the second import. `wc_get_product_id_by_sku()` is no help because in modern WooCommerce it reads the same empty table. Fixed in two layers: `process_batch()` now seeds the lookup row via WooCommerce's native `WC_Product_Data_Store_CPT::update_lookup_table()` (reached through reflection since it's `protected`; this also derives the full column set so it survives WC schema upgrades, and a direct call would fatal) after every create/update, and `resolve_existing_skus()` falls back to a direct `_sku` post-meta lookup for any SKU the lookup table missed so an already-damaged install de-duplicates on the very next run.
- **Generated YML feeds are written atomically.** `MVweb_PI_Feeds::generate()` opened the public feed file directly with `XMLWriter::openUri()`, which truncates the target to zero bytes the instant it opens. Any failure mid-generation (OOM, timeout, fatal — and feeds are generated at the tail of an import when memory is already near the limit) left a half-written, invalid feed served live to aggregators until the next success. The writer now targets a PID-suffixed temp file and `rename()`s it onto the public path only once the document is complete; the rename is atomic on the same filesystem, so readers only ever see the previous complete feed or the new complete feed. The PID suffix also stops two concurrent generators (the auto-run after import vs. the admin "Generate" button vs. `feeds-cron-runner.php`, none of which shared a lock) from clobbering each other's file.
- **Empty / zero prices no longer produce invalid offers in the feed.** `write_single_offer()` emitted `<price></price>` for a product whose regular and sale price were both empty or zero — Yandex.Market rejects such an offer and can bounce the whole feed. The offer is now skipped entirely (and not counted) when it has no usable price; the offer count reflects only the offers actually written.
- **Category names and product titles with `&`, `<`, `>` are no longer over-escaped in the feed.** WordPress stores term names and post titles with entity-encoded specials (`&` saved as `&amp;`). Passing that raw string to `XMLWriter` escaped the ampersand a second time, emitting `&amp;amp;`, so an aggregator showed "Phones &amp; Tablets". Category, name and description text now passes through a decode helper before `XMLWriter`, which then escapes exactly once.
- **`zero_missing_stock()` refuses to wipe the catalogue on a truncated feed.** The product generator drains to the end even when the supplier returned HTTP 200 with a physically truncated body or a temporarily near-empty feed (e.g. 10 offers instead of 1400). `array_diff(known, new)` would then zero stock on hundreds of live products, which vanish from the outgoing feed on the next regeneration. A ratio guard (filterable via `mvweb_pi_zero_stock_min_ratio`, default 0.5) now skips zeroing — with a warning — whenever the new feed has fewer than half the SKUs known last run.
- **A poison-pill product can no longer wedge the importer forever.** Checkpoint/resume skips the first `processed` products, but if the row right after that boundary triggers a real fatal/OOM (not a catchable per-row `Exception`), every resume died at the same offset and the import never advanced. The cron layer now tracks how many times it resumed at an unchanged `processed`; after three dead resumes it discards the checkpoint, logs an error naming the offset, and starts fresh.
- **Lock stealing is now race-free.** The stale-lock branch of `acquire_lock()` did a `get_option()` + `update_option()`, a TOCTOU window in which two runners that both saw the same stale lock would both steal it and run in parallel. The steal is now a single conditional `UPDATE ... WHERE option_value = <exact value read>`, so MySQL serialises the writers and only one gets `rows_affected === 1`.
- **CLI self-heal no longer kills a live web import.** The CLI entry point unconditionally `delete_option()`-ed the lock before acquiring, which would wipe the lock of a web/AJAX import running at that moment (admin "Run import" while the system cron fires). It now clears the lock only when it is genuinely stale (older than `LOCK_TTL`).
- **A trashed product is no longer updated in place instead of resurfacing.** `update_product()` accepted a product whose `post_status` was `trash` (its lookup row survives trashing), burying the SKU in the bin. It now bails on a trashed post so `process_batch()` re-creates the SKU as a published product.
- **`handle_image()` re-imports a deleted thumbnail.** A matching cached source URL short-circuited the image step without checking the attachment still existed; deleting the image from the media library by hand pinned the product to a missing picture forever. It now verifies the cached attachment exists and is still the product thumbnail before skipping.
- **ETag freshness check no longer skips updated feeds.** `check_etag()` returned "unchanged" if *either* the ETag *or* the Last-Modified matched. A server that changed the content (new ETag) but kept the same Last-Modified would have its updated price list skipped. When an ETag is present the decision is now made solely on it (the strongest validator); Last-Modified and Content-Length are fallbacks only.
- **CSV BOM is stripped precisely.** Both the parser and the magic-byte check used `ltrim($s, "\xEF\xBB\xBF")`, which removes any leading byte matching those three, not just the BOM sequence. They now strip exactly the 3-byte prefix.
- **HTML error pages served as CSV are rejected.** A source URL that answered 200 with an HTML error page (instead of the CSV) passed the null-byte magic check and reached the CSV parser as garbage. The check now also rejects content starting with `<!doctype`, `<html` or `<?xml`.
- **Multi-warehouse merge keeps its OOM guard under an unlimited memory_limit.** When `memory_limit` is `-1`, `parse_memory_limit()` returned 0 and the merge accumulated with no ceiling at all. It now falls back to a fixed 512 MB budget so the guard always has something to enforce.
- **XLSX parser logs empty sheets.** A sheet with no rows (or only a header) silently produced zero products with no signal to the operator; both cases are now logged at warning level. (The whole-sheet-in-memory limitation of SimpleXLSX is documented in-code; YML/CSV remain the streaming paths.)

### Performance
- **The object cache is flushed between import batches.** On a CLI run with no persistent cache, every `get_post_meta()` / `update_object_term_cache()` a batch primed stayed in a PHP array for the rest of the process, the main driver of RSS growth across a 1400-SKU import. Flushing per batch keeps memory flat (~620 MB peak on 1413 products) instead of climbing.
- **The excluded-categories parent map is read once per import, not once per product.** `is_category_excluded()` called `get_option('mvweb_pi_category_meta')` on every row while walking the parent chain; the map is now cached on the converter instance.

### Reliability
- **Streaming parsers release their file handle on a mid-stream exception.** The YML (`XMLReader`) and CSV (`SplFileObject`) generators close their resource in a `finally` block, so an exception thrown by the import loop while paused on a `yield` no longer leaks the descriptor until GC.
- **A pending continuation batch is cleared when scheduling is disabled.** `MVweb_PI_Cron::schedule('disabled')` previously left a queued `CONTINUE_HOOK` event that kept firing after the operator turned the schedule off; it is now cleared alongside the main hook.
- **ETag-cached source files are reused by modification time.** The reuse path picked the source file via `end(glob(...))`, which is lexicographic, not newest-last, so a UUID-suffixed leftover could be chosen; it now sorts by `filemtime()` and takes the most recent.

### Added
- **Offer `available` reflects real stock status.** The feed hard-coded `available="true"`; a product kept in catalogue but set out of stock now advertises `available="false"`.

## [1.0.8] - 2026-05-31

### Fixed
- **Deep category trees no longer drop most of the tree with `missing_parent` errors.** `MVweb_PI_Categories::import()` used a single `usort()` that only distinguished "no parent" vs "has parent", which works for a two-level tree but fails on 3+ levels: a level-3 child could still appear before its level-2 parent, get inserted as a root, then collide with same-named siblings further down the feed via `term_exists`, and ultimately drop most categories with "Родительского элемента не существует" / "missing_parent". On the ns60.ru supplier (320 categories, ~3 levels, many same-named siblings under different vendors) the symptom was a log full of `154` create-failures and "Импорт категорий: 320 обработано, 0 создано" — every product then landed in WooCommerce with zero `product_cat` links. Replaced the sort with a proper topological order (`resolve_depth()` walks the parent chain through the feed snapshot, guarded against cycles) and wrapped the create loop in a multi-pass driver: it re-tries every category that returned 0 on the previous pass and stops as soon as a full pass made no progress (max 5 passes). Categories that still fail after the loop are now logged at error level with their names instead of being dropped silently, so the operator sees what the feed couldn't import.

### Performance
- **`mvweb_pi_category_map` option is no longer autoloaded.** On a 320-category supplier the serialised map is tens of KB and was being pulled into every WordPress bootstrap via `wp_load_alloptions()` even though it's only ever read during an import or category lookup. Switched `update_option()` to pass `$autoload = false`. Existing installs get the flag flipped the next time `MVweb_PI_Categories::save_cache()` runs (every import).

### Fixed
- **Categories silently lost when the cached map points at deleted terms.** Both `MVweb_PI_Categories::get_or_create()` and `Importer::resolve_category()` returned an id straight from the `mvweb_pi_category_map` option without checking that the term still existed. If `wp_terms`/`wp_term_taxonomy` got cleared (manual DB sync, fresh-dump import, a sloppy WooCommerce reset) while the option survived, every category lookup returned a stale term_id, `wp_set_object_terms()` no-op'd because that taxonomy row was gone, and products landed in WooCommerce without a single `product_cat` link. The legacy importer log shows up as "Categories: 50 processed, 0 created" — meaning every category went through the "already mapped" branch and none of them mapped to anything real. Both code paths now validate the cached id with `term_exists($id, 'product_cat')` before returning, drop the stale entry, and fall through to recreate (categories) / refresh from the option (importer).

### Added
- **Category name and parent are synced to the feed on every import.** `MVweb_PI_Categories::get_or_create()` previously returned a cached term id without checking whether the supplier had renamed the category ("Headphones" → "Audio") or moved it under a new parent — the term stayed pinned to its original name and position forever. New `sync_term_attributes()` is now called on every cache hit and on every term-meta match, and pushes the feed-side name/parent through `wp_update_term()` only on a real diff so an unchanged taxonomy still costs nothing.
- **Products follow the supplier when categories move.** `update_product()` used to append the feed term in `wp_set_object_terms( ..., true )` mode, which left the product attached to *both* the old and the new category whenever a supplier moved an SKU between branches. The importer now remembers which term it assigned on the previous run in `_mvweb_pi_feed_cat_term_id`, removes that specific term when the feed category changes, and re-runs the assignment in replace mode — manual categories added through the admin UI or other integrations are preserved.
- **Excluded categories also clean up products that already shipped under them.** When the operator newly ticks a category in the "Excluded categories" UI, the converter starts dropping its rows from the next import (existing behaviour), but every product the plugin had previously created under that branch stayed in WooCommerce indefinitely. A new `Importer::reconcile_excluded_categories()` runs once at the start of every full import: it walks the `mvweb_pi_category_meta` parent map to compute the full descendant closure of every excluded id, force-deletes every product attached to those terms (`wp_delete_post( $id, true )` so the SKU is free for future re-import), deletes the now-orphan term, prunes the corresponding entries from `mvweb_pi_category_map` and `mvweb_pi_known_skus`, and logs the totals. Idempotent — re-running after everything is clean does nothing.

## [1.0.6] - 2026-05-29

### Fixed
- **`mvweb_pi_after_import` no longer crashes the run with a `Call to protected method` fatal.** The lookup-table refresh closure called `WC_Product_Data_Store_CPT::update_lookup_table()` directly, but that method is `protected` on its base class `WC_Data_Store_WP` — instantiating the store doesn't make protected methods callable from a closure in global scope, and PHP threw a fatal at the very end of every successful run (the import data was already persisted, but the shutdown handler logged the error and `mvweb_pi_known_skus` was not updated). The refresh block is removed; `wc_product_meta_lookup` now goes stale until WC writes a product through its normal path or `wp wc tool run regenerate_product_lookup_tables` is run once. Catalog filters and sort-by-price degrade gracefully (last value wins on next product save) — the legacy `mvweb-price-converter` lived without that refresh for years, so this matches established behaviour rather than introducing regression.
- **`process_batch()` falls back to `create_product()` when the lookup id is stale.** A SKU resolved via `wc_product_meta_lookup` could point to a post that no longer exists (DB cleanup, another importer crashing mid-run, manual delete) — the old code called `update_product()` regardless, which silently bumped `errors` AND `updated` for the same row (both counters grew by 100 on a 100-row batch). `update_product()` now returns `bool` and `process_batch()` treats a `false` return as "not actually updateable, create it instead" so the row reaches the database and the counters reflect what actually happened.

### Removed
- **Deferred thumbnail worker removed.** The background `MVweb_PI_Thumbs_Worker`, the `thumbs-cron-runner.php` CLI entry point, the `mvweb_pi_thumbs_tick` WP-cron event, the `mvweb_pi_defer_thumbnails` filter, the `_mvweb_pi_thumbs_pending` / `_mvweb_pi_thumbs_attempts` postmeta keys, the `mvweb_pi_after_batch` hook, and the related Help-tab block / FAQ entry have been dropped. An empirical run on the same Beget VDS with the same supplier feed showed the legacy `mvweb-price-converter` (which generates every thumbnail synchronously inside `media_handle_sideload()`) reaches ~5 SKU per 30 s with full thumbnails — the same order of magnitude as this importer would hit on the synchronous path. Adding a second cron, a lock-aware worker, and a queue meta key bought no observable speedup over what the host can already do, so the simpler synchronous code is back: `download_and_attach_image()` calls `wp_generate_attachment_metadata()` inline.

### Added
- **New "Smart" image import mode, now the default.** Downloads new photos on product creation and on subsequent imports refreshes only the photos whose source URL changed in the feed. Covers the common supplier case where catalog photos occasionally get replaced without paying Imagick cost for unchanged rows. Existing `new_only` / `always` / `never` modes stay available.
- **Gallery updates on existing products.** `handle_gallery()` now runs during product updates (not only on creation) under both `smart` and `always` modes, so additional `<picture>` entries that appeared in the feed after the first import are downloaded, dedup'd by URL, and assigned as WooCommerce gallery images. Previously, galleries were only built for newly-created SKUs.

### Changed
- **`image_mode` default is now `smart` (was `new_only`).** Existing installs keep their saved setting; new installs and any unknown stored values fall back to `smart`. The Image Import field label and the help blurb on the main tab were rewritten to describe all four modes.

### Fixed
- **Gallery re-import skips its `$product->save()` when nothing changed.** The previous code always wrote `_mvweb_pi_gallery_sources` and called `set_gallery_image_ids()` even when the feed's gallery URLs and order were identical to the last import — a measurable cost on large catalogs under `always`/`smart` modes. Now compared with ordered equality and short-circuited.
- **AJAX timeouts on long-running imports no longer show a misleading "Request failed" error.** When the browser stops waiting because image downloads outlast the HTTP request budget, the result panel now displays an info-toned message explaining the import continues server-side. Only genuine server failures (HTTP 5xx, network rejection with a real status code) still surface as red errors.
- **Per-image debug spam removed from the import log.** Each downloaded picture used to write three lines into `mvweb_pi.log` ("Starting download", "URL resolved", "Source file downloaded"), producing 4000+ entries on a full catalog refresh and burying useful events. The loader now only emits these lines for top-level price-list sources; image downloads are silent in the log on success.
- **YML galleries were silently dropped because the operator had no column to map.** YML feeds carry every product photo as repeated `<picture>` tags — there is no separate "gallery" element in the spec — but the converter only read `gallery` through the user-defined mapping. Since the mapping dropdown could not expose a non-existent column, `gallery` was always empty and `handle_gallery()` exited on its first guard. The converter now falls back to the parser-provided `gallery` key when no column is mapped, so extra `<picture>` entries reach the gallery as intended. The Mapping tab also locks the Gallery row on YML sources with an "Auto — split from `<picture>`" placeholder so the missing dropdown stops looking like a misconfiguration.

### Performance
- **In-process DNS cache for the loader.** Each image download triggered two synchronous `dns_get_record()` calls (validate + DNS-rebinding check); on a 1400-product YML feed pulling from one CDN that meant ~7000 redundant resolver round-trips per import, which dominated wall-clock time on Beget's VDS. The loader now caches resolved IPs per host on a static property so the second-through-Nth fetch from the same host skips DNS entirely.
- **Image-only fast path: 15 s timeout, no rebinding re-check.** Product photos use a 15 s `wp_remote_get` timeout (vs 45 s for price lists) and skip the post-download DNS-rebinding verification. The rebinding check is meaningful for the one big price-list download per source, but running it on every product photo gave no real security gain once the parent URL was validated and added measurable per-image overhead. Filter `mvweb_pi_download_timeout` still applies and now sees a default of 15 for images / 45 for price-list sources.
- **Skip `$product->save()` when no field on the WooCommerce object actually changed.** Previously `update_product()` always finished with a `save()` even when the incoming feed row matched what was already in the database — and on a 1400-product feed where 99 % of rows don't move between imports, that meant 1400 round-trips through `WC_Product->save()` (lookup-table rewrite, dozens of hooks, post cache flush) per cycle. The updater now compares name / price / sale price / stock / status / description / category against the live product, calls the relevant setter only on real diffs, and skips `save()` entirely when nothing changed.
- **Import raises `memory_limit` to 512 MB.** Imagick keeps a large RSS while resizing big supplier photos; Beget's default 256 MB cgroup limit was killing long CLI runs with SIGBUS somewhere mid-catalog. The legacy `mvweb-price-converter` did the same on the same host and ran cleanly. Filterable via `mvweb_pi_import_memory_limit`.
- **WC transient invalidation batched into a single post-import sweep.** Calling `wc_delete_product_transients()` after every `create_product()` / `update_product()` was issuing 3–5 `wp_options` operations per call — ~5 600 extra DB writes across a 1 400-SKU import. The call moved into the `mvweb_pi_after_import` handler and runs once per touched ID at the end of the run; reads in the same request still see the meta we wrote because the touched IDs are flushed before the next request boundary.
- **Per-batch postmeta + term cache priming.** `process_batch()` now resolves every SKU in the batch to its existing product ID through one `WHERE sku IN (…)` query against `wc_product_meta_lookup` (new private `resolve_existing_skus()`), then primes the postmeta and term caches for those IDs with `update_meta_cache()` / `update_object_term_cache()`. `update_product()`'s six `get_post_meta()` diff reads now hit cache instead of issuing six cold SELECTs per row on a CLI runner.
- **`save_progress()` persists `touched_ids`.** The checkpoint omitted the touched-IDs list, so after a wall-clock-budgeted resume the `mvweb_pi_after_import` handler only saw IDs from the resumed segment — the lookup-table and transient flush for products touched earlier in the same run were silently dropped. Now the field is written and rehydrated alongside `created`/`updated`/`skipped`/`errors`.
- **`filemtime()` warning silencer replaced with a real check.** The admin-assets cache-buster used `@filemtime(...)` which both swallows the PHP warning *and* violates WPCS's `NoSilencedErrors` rule; switched to `file_exists()` + `filemtime()` so a genuinely missing asset is handled deterministically.
- **Gallery write no longer round-trips through `WC_Product->save()`.** `handle_gallery()` previously closed by constructing a `WC_Product`, calling `set_gallery_image_ids()` and `save()` — re-introducing the same expensive path the low-level product creation/update code carefully avoided. It now writes `_product_image_gallery` directly via `update_post_meta()`, which is the meta key WC reads via `WC_Product_Data_Store_CPT::read_product_data()`.
- **`wc_product_meta_lookup` refresh uses the correct API.** The first attempt called `wc_update_product_lookup_tables($id)`, but that function takes a list of columns, not an ID — so on every import the lookup table was silently never refreshed for the touched products. Replaced with `WC_Product_Data_Store_CPT::update_lookup_table($id, 'wc_product_meta_lookup')`, the canonical per-row primitive, and scoped to the SKUs actually touched on this run (tracked via a new `stats.touched_ids` array) instead of the full `mvweb_pi_known_skus` history.
- **WC product cache invalidated after direct postmeta writes.** Direct `update_post_meta()` doesn't notify WC's transient cache (`wc_get_product` reads, `_transient_wc_product_*`), so the next reader in the same request — admin list table, REST endpoint, theme template — would see stale values. Both `create_product()` and `update_product()` now call `wc_delete_product_transients()` after their meta writes.
- **Required WC product flags written on create.** `wp_insert_post`-based creation was missing `_virtual`, `_downloadable`, `_tax_status`, `_tax_class`, `_visibility`, `_featured`, `_backorders`, `_sold_individually`, and the `product_visibility` taxonomy. WC admin renders the row with broken icons without them and some queries can drop the product entirely; we now write the same defaults `WC_Product_Simple::save()` would.
- **Category assignment switched to append mode.** `wp_set_object_terms( ..., 'product_cat', false )` was *replacing* every term every import, so any manual category attached out-of-band (admin UI, other integration) was wiped on the next run. Both create and update paths now append (`true`) and the update path additionally short-circuits when the feed term is already attached.
- **Low-level product creation and update — no `WC_Product->save()`.** Both `create_product()` and `update_product()` now write products through `wp_insert_post()` / `wp_update_post()` and direct `update_post_meta()` calls (mirroring what the legacy `mvweb-price-converter` plugin did before us), instead of going through the WC data store. `WC_Product->save()` cost 200–300 ms per row on Beget's VDS because of its full hook fan-out, lookup-table rewrite and post-cache flush — on a catalog where 99 % of rows don't change between imports, that was several wasted minutes per import. The update path additionally compares each meta value to the live one and writes only on a real diff. Trade-off: `wc_product_meta_lookup` is no longer updated synchronously per product; instead the bootstrap hooks `WC_Product_Data_Store_CPT::update_lookup_table()` for every touched SKU into `mvweb_pi_after_import` so catalog filters / sort-by-price stay in sync at the end of each run.

## [1.0.5] - 2026-05-21

### Changed
- **Settings page no longer duplicates the plugin name and tagline.** The `.mvweb-main__header` block (`<h1>` + intro paragraph) was a visual repeat of `.mvweb-sidebar__brand`, which already shows the plugin name and version at the top of the left rail. Removing it gives the actual settings sections (`.mvweb-block`) more vertical room and matches the updated `_boilerplate/plugin-template` reference.
- **Help tab no longer renders the decorative `.mvweb-statusbar` footer.** The "IDE"-style status line at the bottom of the Help tab (`mvweb-price-importer · UTF-8 · vX.Y.Z · MVweb UI Kit`) carried no functional information — the version is already visible in the sidebar brand, the slug and UI Kit label were noise. Dropped to match the boilerplate.
- **Top padding on the settings shell restored.** `.wrap.mvweb-settings` was flush against the WordPress admin bar after the header block was removed; `margin-top: 20px` was added in `admin.css` for breathing room.
- **Bundled `MVweb_Menu` updated to v2.2.0.** The Hub page (`admin.php?page=mvweb-hub`) was rewritten on top of the current UI Kit (`.mvweb-hero`, `.mvweb-card` plugin cards with two-letter icons, `.mvweb-badge` status pills) and now serves admin CSS from the first installed MVweb plugin instead of inlining a duplicate stylesheet.

### Added
- **Brand logo asset (`images/mv-logo-violet.png`) bundled with the plugin.** The Hub hero looks for `images/mv-logo-violet.png` in the first installed MVweb plugin and renders it as the actual brand mark; the textual "MV" placeholder remains only as a fallback. Bundling the file here ensures the real logo appears whenever this plugin is installed.

## [1.0.4] - 2026-05-21

### Fixed
- **YML feed offers now include `<count>` with the available stock.** Generated feeds (`?page=mvweb-price-importer#feeds`) previously emitted only `available="true"` and dropped the actual quantity — so any consumer expecting a numeric stock value (Yandex.Market, marketplace pipelines, custom integrations) saw products as "in stock" without knowing how many. The general feed now writes the total WooCommerce `stock_quantity`, and per-warehouse feeds write the warehouse-specific value from `_mvweb_pi_stocks`. The element is placed right after `<currencyId>` and is omitted when stock is zero.

## [1.0.3] - 2026-05-20

### Added
- **Feed slug option (Feeds tab → "Feed Slug").** Lets the operator pick the filename suffix for generated feeds — e.g. `poisk123` → `products-feed-poisk123.yml`. Per-warehouse feeds become `products-feed-{slug}-{warehouse}.yml`. Validated server-side against `/^[a-z0-9-]+$/`; empty value falls back to `all` so existing `products-feed-all.yml` URLs keep working without intervention.
- **Per-row Delete button in the Generated Feeds table.** Removes a single feed file by slug via the new `mvweb_pi_delete_feed` AJAX endpoint (nonce + `manage_options` + slug allowlist; row is taken out in-place, the page reloads to the empty state when the last feed is deleted). Useful when an old slug becomes obsolete after renaming the feed.
- **Mapping deduplication.** When a source column is picked in one mapping row, it's hidden from the other rows' dropdowns so the operator can't pick the same column twice by accident. Re-applies after auto-detect rebuilds the selects.
- **Help tab FAQ entries for the Actions row.** Three new collapsibles describe what the Download, Convert, and Reset Hash buttons actually do and when to reach for each — including the "Reset Hash button resets the HTTP fingerprint, not a content hash" clarification.

### Changed
- **Unified Actions result layout.** Title and badges are now wrapped into `.mvweb-alert__body` so the badges row sits at a stable left edge regardless of headline length — no more horizontal jumps between Import / Download / Convert / Reset blocks. Server-side `'Import complete: %d created, …'` headline simplified to `'Import complete.'`; counts are shown only as badges to remove duplication. All badge labels and headlines now go through a localized i18n bag prepared via `wp_localize_script`.
- **Generate Feeds button label is dynamic.** Reads "Generate Feed" when only the general feed will be produced, "Generate All Feeds" when warehouses add additional feeds. The feed-generation result banner uses the same single-headline + badges layout as the rest of the Actions row.
- **Help tab follows the boilerplate structure.** Removed the locally-invented Features block that diverged from `_boilerplate/plugin-template`. Added a `__sub` introductory line to the FAQ block so the first collapsible no longer touches the title.
- **Plugin description and Hub card description are now translatable.** "Import products and pricing from feeds." and "Automatic import of products from external price lists." were rendered in English regardless of locale — both wrapped in `__()` and added to `ru_RU.po`/`.mo`.

### Fixed
- **Double border under each FAQ collapse.** The plugin's own `.mvweb-faq` rule duplicated the border already drawn by UI Kit's `.mvweb-faq summary`. Dropped the redundant outer rule, leaving a single border as the kit intended.
- **System cron commands block was not translated.** Three msgids (`System cron commands`, `Import cron`, `Feeds cron (optional)`) existed in the template without colon but only the legacy "with colon" variants lived in `ru_RU.po`. Added the matching translations.
- **Long cron command lines escaped the warning alert.** `.mvweb-alert` is a flex row; without `min-width: 0` on `.mvweb-alert__body` the inner `<pre>` would stretch the alert past its parent. Added a min-width override plus `max-width: 100%` on `.mvweb-codeblock` so the existing `overflow-x: auto` actually engages.
- **JS feeds table re-render was a column short.** After `Generate Feeds`, the AJAX path used to repaint the table with 4 columns while PHP had rendered 6 — losing the Size and Actions columns. The JS now either appends rows that match the PHP shape (including the Delete button) or reloads the page when no table exists yet.

## [1.0.2] - 2026-05-20

### Changed
- **Migrated admin UI to the current MVweb boilerplate (slate Yoast-style UI Kit).** Replaced legacy Classic Clean `admin.css` with the slate palette + Yoast-style layout from `_boilerplate/plugin-template`. Settings page now uses `.mvweb-main` shell with `.mvweb-main__header` and `.mvweb-tabs__tab`/`.mvweb-tabs__tab--active`. All five tab partials (Main, Mapping, Log, Feeds, Help) were rewritten under the new component vocabulary: `.mvweb-block` + `.mvweb-block__head` for sections, `.mvweb-form-row` for fields (was `.form-table`), `.mvweb-input`/`.mvweb-select` (was `regular-text`), `.mvweb-alert` (was `.mvweb-notice`), `.mvweb-faq` (was `.mvweb-details`), `.mvweb-toggle` for boolean switches, `.mvweb-empty` for blank states, `.mvweb-statusbar` for the Help footer. Behavior unchanged — only markup and styles.
- **`admin.js` selectors aligned with the new tab vocabulary.** Tab navigation now targets `.mvweb-tabs__tab`/`.mvweb-tabs__tab--active`; AJAX result banners render `.mvweb-alert mvweb-alert--{success|error|warning|info}` instead of the retired `.mvweb-notice` variants. Warehouse row builder emits `.mvweb-input` for the URL cell so it matches the rest of the table.
- **`plugin.css` rewritten** as a thin layer of plugin-specific styles (`.mvweb-pi-*`) plus utilities the boilerplate UI Kit deliberately leaves to the plugin: `.mvweb-tab-content` show/hide, `.mvweb-spinner.is-active` reveal, `.mvweb-pi-stats-dashboard` metric grid, `.mvweb-pi-cat-tree`/`.mvweb-pi-cat-row` category picker, `.mvweb-pi-subblock` heading, `.mvweb-pi-schedule-status` line, responsive collapse at ≤960px.
- **Settings shell widened to 1280px** so the new two-column layout breathes on large monitors. The page header no longer carries the version badge — the meta slot is used for a short tagline.
- **`helpers.php`** declares `strict_types=1` to match boilerplate.
- **`package.json`** adds the `build:locale` script alias so `npm run build:locale` works alongside `build:js` / `build:css` / `build` — matches the new boilerplate scripts surface.

## [1.0.1] - 2026-05-19

### Added
- **Separate CLI runner for feeds (`feeds-cron-runner.php`).** Lets you schedule feed regeneration independently of import via system cron — useful when the price source updates rarely (e.g. daily) but you want feeds rebuilt on a tighter cadence to keep `<yml_catalog date>` fresh. Calls `MVweb_PI_Feeds::generate_all()` directly without going through the import pipeline.
- **Help tab coverage for the feeds cron.** New Step 7 in Quick Start, a dedicated FAQ entry ("How do feeds get updated, and do I need a separate cron for them?"), and a second crontab template alongside the import one in the Note block at the bottom.

### Fixed
- **"Settings saved" notice reappeared on every refresh.** The settings form posted to itself and rendered the success notice in the same request, so Safari (and other browsers that re-submit POSTs without prompting) replayed the save on every Cmd+R. Switched to a proper Post/Redirect/Get flow: after a successful save we stash a one-shot flag in a per-user transient and `wp_safe_redirect()` to the page as a clean GET. The notice renders exactly once on the GET that follows the save; refreshes, back/forward navigation, and visits from the menu produce a clean screen with no spurious notice.

## [1.0.0] - 2026-05-19

### Fixed — End-to-end test pass
- **Feed file permissions on hosts with restrictive umask.** `MVweb_PI_Feeds::generate_feed()` now explicitly `chmod`s the feed directory to `0755` and each generated `.yml` to `0644` after `XMLWriter::flush()`. Without this, hosts like Beget VDS (extended ACLs + 0077 umask) leave the file as `0600` and nginx returns 403 — even though the file exists and is valid.
- **Stats dashboard rendered last_run as a unix timestamp.** `MVweb_PI_Cron::run()` was saving `'last_run' => time()` (int) which overwrote the human-readable `current_time('mysql')` saved by the importer one step earlier. The dashboard then echoed `1779131295` verbatim. Standardised both code paths on `current_time('mysql')`.
- **Stats dashboard "total" was always 0 after a cron-driven import.** `MVweb_PI_Importer::run()` wrote `'total'` only into the bare `update_option()` call but not into `$this->stats`, so the cron wrapper's `array_merge( $importer_stats, ['last_run' => …] )` lost it on the next save. Moved `total`/`last_run` into `$this->stats` itself, so any caller persisting the importer return value gets the full payload.
- **Localisation gaps on Main tab.** Three new strings on the consolidated Main tab — the "no source URL" warning, the "mapping not configured" warning, and the "Manual operations" help text — were not in `ru_RU.po` and rendered in English. Added Russian translations and rebuilt the `.mo`.
- **Stale browser cache after JS/CSS rebuilds.** `wp_enqueue_*` calls were keyed on `MVWEB_PI_VERSION`, so any change between version bumps (including local development) shipped behind a cached asset. Switched the `ver=` arg to `filemtime()` of the actual asset (with `MVWEB_PI_VERSION` as fallback) — every rebuild is now picked up automatically.

### Changed — UX refactor (5 tabs instead of 8)
- Collapsed **Settings + Output + Import + Categories** into a single **Main** tab. The day-to-day operator now sees source, schedule, excluded categories, action buttons and last-run statistics on one screen — same shape the legacy converter shipped with, which our users explicitly preferred over the multi-tab AJAX flow.
- Action row at the bottom of Main carries the four operations as plain buttons: **Import Now** (primary), Download, Convert, Reset Hash. Each writes into its own result panel underneath the row — no more hunting across tabs to see whether a download finished.
- Tabs that still live separately because they have their own concerns: **Mapping** (configured rarely), **Log** (read-only), **Feeds** (separate feature surface), **Help**.
- Removed orphan partials `tab-settings.php`, `tab-output.php`, `tab-import.php`, `tab-categories.php`.
- JS resolves action result containers by `data-result` attribute instead of `.mvweb-card` ancestry, so the action row can live outside any card.
- New CSS section dividers (`.mvweb-pi-section`) and a horizontal action row (`.mvweb-pi-main-actions`) responsive down to 782 px.

### Fixed — Production hardening after first real-world import
- **Lock stuck after fatal error.** A real-world import of 1425 SKUs blew through `set_time_limit(600)` while Imagick was processing a thumbnail. The `finally` clause that released `mvweb_pi_cron_lock` never ran — fatal errors in PHP bypass `finally` — so every subsequent import attempt sat idle for the full 30 min TTL. Reworked locking to mirror the legacy importer's production-proven pattern: `add_option()` (MySQL-level INSERT IGNORE) for the atomic acquire, TTL-based theft of stale locks, and `release_lock()` deletes the row outright. On CLI invocations the lock is also force-cleared at the start of every run — self-healing without waiting for TTL. Added `register_shutdown_function()` to release the lock on `E_ERROR`/OOM/Imagick crashes the moment PHP shuts down.
- **`set_time_limit(600)` too low for image-heavy catalogs.** Replaced with `set_time_limit(0)` — CLI already has no cap, web/AJAX/wp-cron now lift the cap to whatever the host allows and rely on the new wall-clock budget (see below) for time management.
- **Single-process import couldn't survive web-cron timeouts.** Added a 50 s wall-clock budget honoured by `MVweb_PI_Importer::run()` in non-CLI contexts. When the budget expires after a batch boundary, the importer persists `mvweb_pi_import_progress` and returns `incomplete=true`; the cron layer schedules a `mvweb_pi_continue_import` event 5 s later, which re-enters `run()` and picks up via the existing resume path. CLI runs (cron-runner.php, real system cron) are unaffected — they get an unlimited budget and finish in one process.

### Added — Image import policy
- New setting `image_mode` (default `new_only`) controls Imagick involvement during updates:
  - `new_only` — download images only when an SKU is first created; updates leave existing images alone. This is the legacy importer's default and the recommended choice for catalogs larger than a few hundred items, because thumbnail regeneration is by far the most expensive step.
  - `always` — refresh images on every import (the previous unconditional behaviour).
  - `never` — skip image import entirely for text-only catalogs.
- Surfaced as a select on the Settings tab next to Batch Size.
- Persisted through `MVweb_PI_Settings` with a whitelist sanitization.
- The activation hook no longer pre-creates `mvweb_pi_cron_lock` — leaving the row missing lets the first-ever `acquire_lock()` take the race-free `add_option()` path.

### Added — Import pipeline
- CSV, YML (Yandex.Market), XLSX import with streaming parsers (SplFileObject, XMLReader, SimpleXLSX).
- Auto-detection of delimiter, encoding (UTF-8/Windows-1251) and column mapping (EN + RU keywords).
- Google Sheets URL auto-conversion to CSV export.
- ETag/Last-Modified change detection — skips download when source is unchanged.
- Generator-based conversion pipeline; multi-warehouse SKU merge with per-warehouse stock JSON.
- Field mapping UI with 11 dropdowns and auto-detect button.
- Category import with parent/child hierarchy and external ID mapping via term meta `mvweb_pi_external_id`.
- Featured image + gallery import with URL-change detection.
- WP-Cron scheduler with custom intervals (hourly, 6h, 12h, daily); CLI runner (`cron-runner.php`); REST endpoint `POST /wp-json/mvweb-pi/v1/run-import`.
- Checkpoint/resume support for interrupted imports.
- Error email notifications to site admin.

### Added — Yandex.Market YML feed generation
- Streaming feed generation via `XMLWriter` (memory-efficient).
- General feed (all in-stock products) plus per-warehouse feeds.
- Configurable company name, currency (RUR/USD/EUR), auto-generate-after-import toggle.
- Feed list UI with URL, date, product count, file size.

### Added — Frontend
- Per-warehouse stock breakdown on product page via `woocommerce_get_stock_html`.
- Per-warehouse stock display in admin order view.
- BEM-named frontend CSS (`.mvweb-pi-stocks`).

### Added — Logging and operations
- JSONL file logger (`MVweb_PI_Logger`) with size (10 MB) and age (30 days) rotation; dated `.bak` archives.
- Paginated log reading via `SplFileObject::seek()`; level filter (info/warning/error).
- Log viewer UI with pagination and Clear button.

### Added — Localization and docs
- POT translation template with ~150 translatable strings.
- Russian translation (`ru_RU.po` + `ru_RU.mo`) covering UI, Help tab and runtime messages.
- Technical documentation in `docs/plugins/mvweb-price-importer.md`.
- Built-in Help tab with Quick Start, Features, FAQ and Support sections.

### Added — Boilerplate alignment (1.0.0 release prep)
- Adopted MVweb UI Kit · IDE Light theme: `.mvweb-theme-ide` modifier on the root wrap, breadcrumbs, version pill, `nav-tab__dot` markers, optional `nav-tab__badge` slots.
- Tab labels are now user-friendly and fully localized through `__()`.
- Bundled shared classes (`MVweb_Menu`, `MVweb_Updater`, `plugin-update-checker`) under `includes/` so production deployments no longer depend on the studio monorepo `shared/` directory.
- Updated `admin.css` to the latest boilerplate revision (IDE Light overlay over Classic Clean); replaced boilerplate placeholders (`{{PLUGIN_NAME}}`, `{{PLUGIN_PREFIX}}`) with real values.

### Changed
- `acquire_lock()` reworked to a single atomic SQL `UPDATE` with a combined "free or stale" predicate, closing the two-statement race window where two concurrent triggers (AJAX + WP-Cron + REST) could both pass the check.
- `zero_missing_stock()` and `known_skus` are now persisted only after the import generator fully drains. Interrupted imports keep their partial SKU set in the progress option and recover on resume — no more accidental stock-zeroing of products that simply hadn't been streamed yet.
- `mvweb_pi_batch_size` filter is now actually honoured: it runs after the settings value, so plugin authors can override both default and configured batch size.
- Gallery imports deduplicate by URL via the new `_mvweb_pi_gallery_sources` post meta — repeated imports of the same product no longer create duplicate attachments. Stale images previously uploaded by this plugin are now cleaned up when removed from the source.
- `MVweb_PI_Categories` no longer calls `wp_cache_flush()` after bulk creation; only the `product_cat` terms it touched are invalidated through `clean_term_cache()`, eliminating the previous global cache-flush spike on busy stores.
- `MVweb_PI_Logger` constructor is now `private` to enforce the singleton invariant.
- `helpers.php` public functions gained PHP 8 parameter and return type hints.

### Removed
- Unused `MVweb_PI_Cron::INTERVALS` constant and the pre-release `@deprecated 1.0.0` shim `mvweb_pi_release_lock()`.

### Security
- **SSRF — image downloads.** Replaced `media_sideload_image()` (which follows redirects, bypassing `validate_url()`) with a hardened pipeline: download through `MVweb_PI_Loader::download()` (no redirects, IP allowlist, magic-bytes check) into a temp file, then sideload locally via `wp_handle_sideload()` + `wp_insert_attachment()`.
- **SSRF — DNS rebinding.** `validate_url()` now resolves the host through `dns_get_record()` (A + AAAA, all records) and refuses any private/reserved/link-local IP, including AWS metadata link-local. `download()` re-resolves after the HTTP request and refuses the payload if the IP set changed (rebinding detection). `check_etag()` re-validates before each HEAD.
- **SSRF — re-validation.** `mvweb_pi_detect_columns` AJAX now passes the stored source URL through `validate_url()` before downloading.
- **XLSX ZIP-bomb.** Before handing the file to `SimpleXLSX::parse()`, individual ZIP entries are inspected via `ZipArchive::statName()` and the file is rejected when any entry decompresses past 250 MB.
- **Memory exhaustion.** `merge_warehouses()` now checks `memory_get_usage(true)` every 250 rows and aborts cleanly at 80 % of `memory_limit` with a log entry, preventing OOM kills on shared hosting.
- **Credential leakage.** `mvweb_pi_log()` strips `user:pass@` Basic Auth credentials from all URLs before writing to the JSONL log or PHP `error_log`. Recursively masks context arrays as well.
- **Multisite uninstall.** `switch_to_blog()` / `restore_current_blog()` are now wrapped in `try/finally`, so a failure inside one site's cleanup doesn't strand the global blog context. `$wpdb->delete()` calls in `uninstall.php` now pass explicit `%s` format arrays. Also clears the new `_mvweb_pi_gallery_sources` post meta and `mvweb_pi_import_progress` option.
- **Existing protections.** Nonce verification on every AJAX handler and form; `manage_options` capability check on every admin endpoint; REST `permission_callback` enforces `manage_options`; XXE-disabled XML parsing via `LIBXML_NONET | LIBXML_NOENT`; UUID-named files in a protected upload directory (`.htaccess` + `index.php`); magic-bytes validation for downloaded files.

## [1.0.0] - YYYY-MM-DD

_Initial release. The above changelog will be folded into this section by `/wp:master` at release time._
