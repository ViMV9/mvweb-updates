<?php
/**
 * Feeds tab template.
 *
 * YML feed settings, feed list table, and generation controls.
 * Settings (company, currency) are saved via the main form POST.
 * Feed generation is handled via AJAX.
 *
 * Uses MVweb Admin UI Kit (slate palette, Yoast-style layout).
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$feeds_handler  = new MVweb_PI_Feeds();
$company        = $feeds_handler->get_company();
$currency       = $feeds_handler->get_currency();
$feed_slug_raw  = (string) get_option( MVweb_PI_Feeds::OPTION_SLUG, '' );
$auto_generate  = get_option( MVweb_PI_Feeds::OPTION_AUTO_GENERATE, '1' );
$feed_list      = $feeds_handler->get_feed_list();

$currency_options = array(
	'RUR' => __( 'RUR — Russian Ruble', 'mvweb-price-importer' ),
	'USD' => __( 'USD — US Dollar', 'mvweb-price-importer' ),
	'EUR' => __( 'EUR — Euro', 'mvweb-price-importer' ),
);

// Count feeds the operator will get on the next generation:
// always one general feed, plus one per configured warehouse with an id.
$settings_for_feeds = get_option( 'mvweb_pi_settings', array() );
$feed_total         = 1;
foreach ( ( $settings_for_feeds['warehouses'] ?? array() ) as $wh ) {
	if ( ! empty( $wh['id'] ) ) {
		++$feed_total;
	}
}
$generate_btn_label = $feed_total > 1
	? __( 'Generate All Feeds', 'mvweb-price-importer' )
	: __( 'Generate Feed', 'mvweb-price-importer' );
?>

<div class="mvweb-pi-tab-feeds">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Feed Settings', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Configure YML feed parameters for Yandex.Market. Feeds include only products with stock > 0.', 'mvweb-price-importer' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_feeds_company" class="mvweb-form-row__label">
				<?php esc_html_e( 'Company Name', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
					   id="mvweb_pi_feeds_company"
					   name="mvweb_pi_feeds_company"
					   class="mvweb-input"
					   value="<?php echo esc_attr( $company ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Company name displayed in the YML feed header.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_feeds_slug" class="mvweb-form-row__label">
				<?php esc_html_e( 'Feed Slug', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
					   id="mvweb_pi_feeds_slug"
					   name="mvweb_pi_feeds_slug"
					   class="mvweb-input"
					   value="<?php echo esc_attr( $feed_slug_raw ); ?>"
					   pattern="[a-z0-9-]+"
					   placeholder="<?php echo esc_attr( MVweb_PI_Feeds::DEFAULT_SLUG ); ?>"
					   title="<?php esc_attr_e( 'Allowed: lowercase Latin letters, digits and hyphens.', 'mvweb-price-importer' ); ?>">
				<p class="mvweb-form-row__desc">
					<?php
					printf(
						/* translators: %s: example feed URL */
						esc_html__( 'Filename suffix for the feed: products-feed-{slug}.yml. Allowed characters: a–z, 0–9, hyphen. Example: %s', 'mvweb-price-importer' ),
						'<code>' . esc_html( mvweb_pi_get_feeds_url() . 'products-feed-poisk123.yml' ) . '</code>'
					);
					?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_feeds_currency" class="mvweb-form-row__label">
				<?php esc_html_e( 'Currency', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_feeds_currency"
						name="mvweb_pi_feeds_currency"
						class="mvweb-select">
					<?php foreach ( $currency_options as $code => $label ) : ?>
						<option value="<?php echo esc_attr( $code ); ?>"
							<?php selected( $currency, $code ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_pi_feeds_auto_generate" class="mvweb-form-row__label">
				<?php esc_html_e( 'Auto-generate', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							   id="mvweb_pi_feeds_auto_generate"
							   name="mvweb_pi_feeds_auto_generate"
							   value="1"
							   <?php checked( $auto_generate, '1' ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Regenerate feeds automatically after each successful import', 'mvweb-price-importer' ); ?></span>
				</div>
			</div>
		</div>
	</div>

	<?php
	// Feed category filter — which WooCommerce product categories the generated
	// feeds export. Numeric product_cat term ids, stored in a dedicated option,
	// fully separate from the parser's source-category filter on the main tab.
	$feed_excluded_raw = get_option( MVweb_PI_Feeds::OPTION_FEED_EXCLUDED_CATEGORIES, array() );
	$feed_excluded     = array();
	if ( is_array( $feed_excluded_raw ) ) {
		foreach ( $feed_excluded_raw as $tid ) {
			$feed_excluded[ (int) $tid ] = true;
		}
	}
	$feed_cat_mode = get_option( MVweb_PI_Feeds::OPTION_FEED_CATEGORY_FILTER_MODE, 'exclude' );
	$feed_cat_mode = ( 'include' === $feed_cat_mode ) ? 'include' : 'exclude';

	$feed_terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
		)
	);
	if ( is_wp_error( $feed_terms ) ) {
		$feed_terms = array();
	}

	// get_terms() already returns terms ordered by name; group by parent so the
	// tree renders hierarchically like the source-category picker on the main tab.
	$feed_children_by_parent = array();
	foreach ( $feed_terms as $feed_term ) {
		$feed_children_by_parent[ (int) $feed_term->parent ][] = $feed_term;
	}

	$feed_cat_render = function ( int $parent_id, int $depth = 0 ) use ( &$feed_cat_render, $feed_children_by_parent, $feed_excluded ) {
		if ( empty( $feed_children_by_parent[ $parent_id ] ) ) {
			return;
		}
		foreach ( $feed_children_by_parent[ $parent_id ] as $term ) {
			$checked = isset( $feed_excluded[ (int) $term->term_id ] );
			?>
			<li class="mvweb-pi-cat-row" style="--depth: <?php echo (int) $depth; ?>;">
				<label class="mvweb-pi-cat-label">
					<input type="checkbox"
						   name="mvweb_pi_feed_excluded_categories[]"
						   value="<?php echo esc_attr( (string) $term->term_id ); ?>"
						   <?php checked( $checked ); ?>>
					<span class="mvweb-pi-cat-name"><?php echo esc_html( $term->name ); ?></span>
					<span class="mvweb-pi-cat-id"><code><?php
						/* translators: %s: number of products in the category */
						echo esc_html( sprintf( _n( '%s product', '%s products', (int) $term->count, 'mvweb-price-importer' ), number_format_i18n( (int) $term->count ) ) );
					?></code></span>
				</label>
			</li>
			<?php
			$feed_cat_render( (int) $term->term_id, $depth + 1 );
		}
	};
	?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Feed Categories', 'mvweb-price-importer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Choose which product categories the generated feeds export. Ticking a parent applies to every category nested under it. The same choice applies to the general feed and every per-warehouse feed.', 'mvweb-price-importer' ); ?>
		</p>

		<input type="hidden" name="mvweb_pi_feed_categories_submitted" value="1">

		<div class="mvweb-form-row">
			<label for="mvweb_pi_feed_category_filter_mode" class="mvweb-form-row__label">
				<?php esc_html_e( 'Filter mode', 'mvweb-price-importer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_pi_feed_category_filter_mode"
						name="mvweb_pi_feed_category_filter_mode"
						class="mvweb-select"
						style="max-width:320px;">
					<option value="exclude" <?php selected( $feed_cat_mode, 'exclude' ); ?>>
						<?php esc_html_e( 'Exclude ticked branches', 'mvweb-price-importer' ); ?>
					</option>
					<option value="include" <?php selected( $feed_cat_mode, 'include' ); ?>>
						<?php esc_html_e( 'Include only ticked branches', 'mvweb-price-importer' ); ?>
					</option>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Leave everything unticked to export all categories (default). "Exclude" drops the ticked branches from the feed; "Include only" exports just the ticked branches.', 'mvweb-price-importer' ); ?>
				</p>
			</div>
		</div>

		<?php if ( empty( $feed_terms ) ) : ?>
			<div class="mvweb-alert mvweb-alert--info">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'No product categories found yet. Import products first, then pick the categories to export.', 'mvweb-price-importer' ); ?>
				</div>
			</div>
		<?php else : ?>
			<div class="mvweb-pi-cat-picker">
				<div class="mvweb-pi-cat-toolbar">
					<input type="search"
						   class="mvweb-input mvweb-pi-cat-filter"
						   placeholder="<?php esc_attr_e( 'Filter categories by name…', 'mvweb-price-importer' ); ?>">
					<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm mvweb-pi-cat-expand-all">
						<?php esc_html_e( 'Select all', 'mvweb-price-importer' ); ?>
					</button>
					<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm mvweb-pi-cat-clear-all">
						<?php esc_html_e( 'Clear selection', 'mvweb-price-importer' ); ?>
					</button>
					<span class="mvweb-pi-cat-count">
						<?php
						printf(
							/* translators: 1: number of ticked categories, 2: total number of categories */
							esc_html__( '%1$d of %2$d ticked', 'mvweb-price-importer' ),
							count( $feed_excluded ),
							count( $feed_terms )
						);
						?>
					</span>
				</div>

				<ul class="mvweb-pi-cat-tree">
					<?php $feed_cat_render( 0, 0 ); ?>
				</ul>
			</div>
		<?php endif; ?>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Generated Feeds', 'mvweb-price-importer' ); ?></div>
		</div>

		<?php if ( ! empty( $feed_list ) ) : ?>
			<div class="mvweb-table-wrap">
				<table class="mvweb-table" id="mvweb-pi-feeds-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Feed', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'URL', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'Last Generated', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'Products', 'mvweb-price-importer' ); ?></th>
							<th><?php esc_html_e( 'Size', 'mvweb-price-importer' ); ?></th>
							<th class="mvweb-pi-feeds-table__actions-col"><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'mvweb-price-importer' ); ?></span></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $feed_list as $feed ) : ?>
							<tr data-slug="<?php echo esc_attr( $feed['slug'] ); ?>">
								<td>
									<strong><?php echo esc_html( $feed['slug'] ); ?></strong>
								</td>
								<td>
									<a href="<?php echo esc_url( $feed['url'] ); ?>"
									   target="_blank"
									   rel="noopener noreferrer"
									   class="mvweb-pi-feed-url">
										<?php echo esc_html( $feed['url'] ); ?>
									</a>
								</td>
								<td>
									<?php
									echo esc_html(
										wp_date(
											get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
											$feed['modified']
										)
									);
									?>
								</td>
								<td>
									<span class="mvweb-badge"><?php echo esc_html( (string) $feed['products'] ); ?></span>
								</td>
								<td>
									<?php echo esc_html( $feed['size'] ); ?>
								</td>
								<td class="mvweb-pi-feeds-table__actions">
									<button type="button"
											class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-pi-delete-feed-btn"
											data-slug="<?php echo esc_attr( $feed['slug'] ); ?>"
											aria-label="<?php
												/* translators: %s: feed slug */
												echo esc_attr( sprintf( __( 'Delete feed %s', 'mvweb-price-importer' ), $feed['slug'] ) );
											?>">
										<?php esc_html_e( 'Delete', 'mvweb-price-importer' ); ?>
									</button>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php else : ?>
			<div class="mvweb-empty">
				<div class="mvweb-empty__icon">&#128230;</div>
				<div class="mvweb-empty__title"><?php esc_html_e( 'No feeds generated yet', 'mvweb-price-importer' ); ?></div>
				<div class="mvweb-empty__text"><?php esc_html_e( 'Click the button below to generate YML feeds.', 'mvweb-price-importer' ); ?></div>
			</div>
		<?php endif; ?>

		<div class="mvweb-pi-feeds-actions">
			<button type="button"
					class="mvweb-btn mvweb-btn--primary"
					id="mvweb-pi-generate-feeds-btn">
				<?php echo esc_html( $generate_btn_label ); ?>
				<span class="mvweb-spinner" id="mvweb-pi-feeds-spinner"></span>
			</button>
			<div class="mvweb-pi-action-result" id="mvweb-pi-feeds-result"></div>
		</div>
	</div>

</div>
