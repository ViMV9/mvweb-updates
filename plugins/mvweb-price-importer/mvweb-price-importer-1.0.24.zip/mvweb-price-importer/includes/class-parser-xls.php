<?php
/**
 * XLS Parser — legacy binary Excel (BIFF8 / OLE2) parsing via PhpSpreadsheet.
 *
 * The bundled SimpleXLSX only reads the ZIP-based .xlsx format; the old binary
 * .xls (Excel 97-2003) is a completely different container (OLE2/CFB) that no
 * lightweight single-file reader decodes reliably — Cyrillic BIFF8 strings in
 * particular. PhpSpreadsheet's Xls reader handles the codepage/UTF-16 records
 * correctly, so it is bundled under lib/vendor/ for this format.
 *
 * Mirrors the MVweb_PI_Parser_XLSX contract exactly (get_headers + rows
 * generator) so the converter, column mapping and detect_columns need no
 * changes.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Parser_XLS
 *
 * Parses legacy binary .xls files using PhpSpreadsheet with row-limit
 * protection. The whole active sheet is materialised in memory once (like the
 * XLSX parser) — .xls feeds are small in practice; prefer CSV/YML for very
 * large catalogs.
 *
 * @since 1.0.0
 */
class MVweb_PI_Parser_XLS {

	/**
	 * Maximum rows to parse.
	 *
	 * @var int
	 */
	const MAX_ROWS = 50000;

	/**
	 * Path to the XLS file.
	 *
	 * @var string
	 */
	private string $file_path;

	/**
	 * Cached sheet rows (0-indexed rows of 0-indexed columns), or null until
	 * loaded, or empty array on failure.
	 *
	 * @var array[]|null
	 */
	private ?array $sheet_rows = null;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 * @param string $file_path Path to XLS file.
	 */
	public function __construct( string $file_path ) {
		$this->file_path = $file_path;
	}

	/**
	 * Get headers (first row of the sheet).
	 *
	 * @since 1.0.0
	 * @return string[] Array of column header names.
	 */
	public function get_headers(): array {
		$rows = $this->load_rows();
		if ( empty( $rows ) || empty( $rows[0] ) ) {
			return array();
		}

		return array_map( 'trim', array_map( 'strval', $rows[0] ) );
	}

	/**
	 * Stream sheet rows as a generator.
	 *
	 * Yields associative arrays (header => value) for each data row. Stops at
	 * MAX_ROWS. Mirrors MVweb_PI_Parser_XLSX::rows() one-to-one.
	 *
	 * @since 1.0.0
	 * @return \Generator<int, array<string, string>> Yields rows as header => value arrays.
	 */
	public function rows(): \Generator {
		$all_rows = $this->load_rows();
		if ( empty( $all_rows ) ) {
			mvweb_pi_log( 'XLS sheet is empty — no rows to import.', 'warning' );
			return;
		}

		$headers      = array_map( 'trim', array_map( 'strval', array_shift( $all_rows ) ) );
		$header_count = count( $headers );
		$count        = 0;

		if ( empty( $all_rows ) ) {
			mvweb_pi_log( 'XLS sheet has a header row but no data rows.', 'warning' );
			return;
		}

		foreach ( $all_rows as $row ) {
			if ( ++$count > self::MAX_ROWS ) {
				mvweb_pi_log(
					sprintf( 'XLS row limit reached (%d rows). Stopping.', self::MAX_ROWS ),
					'warning'
				);
				break;
			}

			$row = array_map( 'strval', $row );
			if ( $this->is_empty_row( $row ) ) {
				continue;
			}

			// Pad or trim row to match header count.
			$row_count = count( $row );
			if ( $row_count < $header_count ) {
				$row = array_pad( $row, $header_count, '' );
			} elseif ( $row_count > $header_count ) {
				$row = array_slice( $row, 0, $header_count );
			}

			yield array_combine( $headers, $row );
		}
	}

	/**
	 * Load the active sheet into a rows array (cached).
	 *
	 * Reads data only (no styles/formulas) and only the first worksheet, keeping
	 * memory flat on multi-sheet workbooks. Empty cells are returned as ''.
	 *
	 * @since 1.0.0
	 * @return array[] Rows of columns, or empty array on error.
	 */
	private function load_rows(): array {
		if ( null !== $this->sheet_rows ) {
			return $this->sheet_rows;
		}

		$this->sheet_rows = array();

		// Load the bundled PhpSpreadsheet only when an .xls is actually parsed —
		// keeps the vendor autoloader (and its platform check) out of every normal
		// request that never touches this legacy format.
		if ( ! class_exists( 'PhpOffice\\PhpSpreadsheet\\Reader\\Xls' ) ) {
			$autoload = MVWEB_PI_PATH . 'lib/vendor/autoload.php';
			if ( is_readable( $autoload ) ) {
				require_once $autoload;
			}
		}

		if ( ! class_exists( 'PhpOffice\\PhpSpreadsheet\\Reader\\Xls' ) ) {
			mvweb_pi_log(
				__( 'XLS reader unavailable: PhpSpreadsheet library is missing.', 'mvweb-price-importer' ),
				'error'
			);
			return $this->sheet_rows;
		}

		// Silence E_DEPRECATED for the duration of the parse only. PhpSpreadsheet
		// 2.1.x emits deprecation notices on PHP 8.3+ ("Increment on non-numeric
		// string"); with display_errors on they would print mid-request and could
		// corrupt the JSON of an AJAX import. Real errors still surface — the
		// reader throws exceptions, caught below. Restored in finally.
		$prev_reporting = error_reporting( error_reporting() & ~E_DEPRECATED );

		try {
			$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
			$reader->setReadDataOnly( true );

			// Restrict to the first worksheet — a supplier price list is a single
			// sheet, and loading only it keeps memory flat if the workbook carries
			// extra sheets.
			$names = $reader->listWorksheetNames( $this->file_path );
			if ( ! empty( $names[0] ) ) {
				$reader->setLoadSheetsOnly( $names[0] );
			}

			$spreadsheet = $reader->load( $this->file_path );
			$rows        = $spreadsheet->getActiveSheet()->toArray( '', false, false, false );
			$spreadsheet->disconnectWorksheets();
			unset( $spreadsheet );

			if ( is_array( $rows ) ) {
				$this->sheet_rows = $rows;
			}
		} catch ( \Throwable $e ) {
			mvweb_pi_log(
				/* translators: %s: parser error message */
				sprintf( __( 'XLS parse error: %s', 'mvweb-price-importer' ), $e->getMessage() ),
				'error'
			);
			$this->sheet_rows = array();
		} finally {
			error_reporting( $prev_reporting );
		}

		return $this->sheet_rows;
	}

	/**
	 * Check if a row is empty (all cells blank).
	 *
	 * @since 1.0.0
	 * @param array $row Row values.
	 * @return bool True if all cells are empty.
	 */
	private function is_empty_row( array $row ): bool {
		foreach ( $row as $cell ) {
			if ( '' !== trim( $cell ) ) {
				return false;
			}
		}
		return true;
	}
}
