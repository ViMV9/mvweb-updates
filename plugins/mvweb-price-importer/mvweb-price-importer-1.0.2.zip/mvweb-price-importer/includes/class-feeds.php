<?php
/**
 * Feeds class — YML feed generation for Yandex.Market.
 *
 * Generates YML feeds using XMLWriter (streaming, no DOM).
 * Supports general feed and per-warehouse feeds.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Feeds
 *
 * Generates YML feeds for Yandex.Market using XMLWriter for
 * memory-efficient streaming output. Supports a general feed
 * (all products in stock) and per-warehouse feeds.
 *
 * Feed files are stored in wp-content/uploads/pricelists/feeds/
 * which is intentionally public (no .htaccess restriction).
 *
 * @since 1.0.0
 */
class MVweb_PI_Feeds {

	/**
	 * Option key for company name.
	 *
	 * @var string
	 */
	const OPTION_COMPANY = 'mvweb_pi_feeds_company';

	/**
	 * Option key for currency.
	 *
	 * @var string
	 */
	const OPTION_CURRENCY = 'mvweb_pi_feeds_currency';

	/**
	 * Option key for auto-generate after import setting.
	 *
	 * @var string
	 */
	const OPTION_AUTO_GENERATE = 'mvweb_pi_feeds_auto_generate';

	/**
	 * Get company name for feed.
	 *
	 * @since 1.0.0
	 * @return string Company name.
	 */
	public function get_company(): string {
		return get_option( self::OPTION_COMPANY, get_bloginfo( 'name' ) );
	}

	/**
	 * Get currency for feed.
	 *
	 * @since 1.0.0
	 * @return string Currency code (RUR, USD, EUR).
	 */
	public function get_currency(): string {
		return get_option( self::OPTION_CURRENCY, 'RUR' );
	}

	/**
	 * Generate all feeds: general + per-warehouse.
	 *
	 * @since 1.0.0
	 * @return array<string, array{file: string, url: string, products: int}> Results keyed by feed slug.
	 */
	public function generate_all(): array {
		$results  = array();
		$settings = get_option( 'mvweb_pi_settings', array() );
		$warehouses = $settings['warehouses'] ?? array();

		// General feed (all products with stock > 0).
		$results['all'] = $this->generate( 'all' );

		// Per-warehouse feeds.
		foreach ( $warehouses as $wh ) {
			$wh_id = $wh['id'] ?? '';
			if ( empty( $wh_id ) ) {
				continue;
			}
			$slug = sanitize_title( $wh['feed_name'] ?? $wh['name'] ?? $wh_id );
			$results[ $wh_id ] = $this->generate( $slug, $wh_id );
		}

		return $results;
	}

	/**
	 * Generate a single YML feed.
	 *
	 * Uses XMLWriter for streaming output directly to file,
	 * avoiding DOM accumulation in memory (TZ 9.3).
	 *
	 * @since 1.0.0
	 * @param string $slug  Feed slug for filename (e.g. 'all', 'moscow').
	 * @param string $wh_id Warehouse ID. Empty string for general feed.
	 * @return array{file: string, url: string, products: int} Generation result.
	 */
	public function generate( string $slug = 'all', string $wh_id = '' ): array {
		$feeds_dir = mvweb_pi_get_feeds_dir();
		$feeds_url = mvweb_pi_get_feeds_url();
		$filename  = "products-feed-{$slug}.yml";
		$file_path = $feeds_dir . $filename;

		$company  = $this->get_company();
		$currency = $this->get_currency();

		// Ensure feeds directory exists and is world-readable so that the
		// generated YML feed can actually be served by the web server.
		// Hosts with restrictive umasks (e.g. Beget VDS with extended ACLs)
		// otherwise create 0700/0600 entries that nginx returns 403 for.
		wp_mkdir_p( $feeds_dir );
		@chmod( $feeds_dir, 0755 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		$writer = new XMLWriter();
		$writer->openUri( $file_path );
		$writer->setIndent( true );
		$writer->setIndentString( '  ' );
		$writer->startDocument( '1.0', 'UTF-8' );

		// yml_catalog.
		$writer->startElement( 'yml_catalog' );
		$writer->writeAttribute( 'date', wp_date( 'Y-m-d H:i' ) );

		// shop.
		$writer->startElement( 'shop' );
		$writer->writeElement( 'name', $company );
		$writer->writeElement( 'company', $company );
		$writer->writeElement( 'url', home_url( '/' ) );

		// currencies.
		$writer->startElement( 'currencies' );
		$writer->startElement( 'currency' );
		$writer->writeAttribute( 'id', $currency );
		$writer->writeAttribute( 'rate', '1' );
		$writer->endElement(); // currency.
		$writer->endElement(); // currencies.

		// categories.
		$this->write_categories( $writer );

		// offers.
		$writer->startElement( 'offers' );
		$product_count = $this->write_offers( $writer, $wh_id, $currency );
		$writer->endElement(); // offers.

		$writer->endElement(); // shop.
		$writer->endElement(); // yml_catalog.
		$writer->endDocument();
		$writer->flush();

		// Make the freshly written feed world-readable for the same reason
		// the directory is — XMLWriter::openUri honours umask, which on
		// some hosts produces 0600 and locks nginx out.
		@chmod( $file_path, 0644 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		mvweb_pi_log(
			sprintf(
				/* translators: 1: feed slug, 2: product count */
				__( 'Feed "%1$s" generated: %2$d products.', 'mvweb-price-importer' ),
				$slug,
				$product_count
			),
			'info'
		);

		return array(
			'file'     => $file_path,
			'url'      => $feeds_url . $filename,
			'products' => $product_count,
		);
	}

	/**
	 * Write WooCommerce product categories to YML.
	 *
	 * Outputs <categories> element with hierarchical category tree.
	 *
	 * @since 1.0.0
	 * @param XMLWriter $writer XMLWriter instance.
	 * @return void
	 */
	private function write_categories( XMLWriter $writer ): void {
		$writer->startElement( 'categories' );

		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			$writer->endElement(); // categories.
			return;
		}

		foreach ( $terms as $term ) {
			$writer->startElement( 'category' );
			$writer->writeAttribute( 'id', (string) $term->term_id );

			if ( $term->parent > 0 ) {
				$writer->writeAttribute( 'parentId', (string) $term->parent );
			}

			$writer->text( $term->name );
			$writer->endElement(); // category.
		}

		$writer->endElement(); // categories.
	}

	/**
	 * Write product offers to YML.
	 *
	 * For general feed: all products with stock > 0.
	 * For warehouse feed: products with stock > 0 on that specific warehouse.
	 *
	 * @since 1.0.0
	 * @param XMLWriter $writer  XMLWriter instance.
	 * @param string    $wh_id   Warehouse ID. Empty for general feed.
	 * @param string    $currency Currency code.
	 * @return int Number of products written.
	 */
	private function write_offers( XMLWriter $writer, string $wh_id, string $currency ): int {
		$count = 0;
		$page  = 1;

		do {
			$args = array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => 100,
				'paged'          => $page,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => '_stock',
						'value'   => '0',
						'compare' => '>',
						'type'    => 'NUMERIC',
					),
				),
			);

			$query = new WP_Query( $args );

			if ( ! $query->have_posts() ) {
				break;
			}

			while ( $query->have_posts() ) {
				$query->the_post();
				$product = wc_get_product( get_the_ID() );

				if ( ! $product || 'simple' !== $product->get_type() ) {
					continue;
				}

				// For warehouse-specific feed, check warehouse stock.
				if ( '' !== $wh_id ) {
					$stocks_json = get_post_meta( $product->get_id(), '_mvweb_pi_stocks', true );
					$stocks      = ! empty( $stocks_json ) ? json_decode( $stocks_json, true ) : array();
					$wh_stock    = (int) ( $stocks[ $wh_id ] ?? 0 );

					if ( $wh_stock <= 0 ) {
						continue;
					}
				}

				$this->write_single_offer( $writer, $product, $currency );
				++$count;
			}

			wp_reset_postdata();
			++$page;

		} while ( $page <= $query->max_num_pages );

		return $count;
	}

	/**
	 * Write a single offer element.
	 *
	 * XMLWriter automatically escapes special characters (&, <, >, ")
	 * in text content (TZ 9.3).
	 *
	 * @since 1.0.0
	 * @param XMLWriter   $writer   XMLWriter instance.
	 * @param WC_Product  $product  WooCommerce product.
	 * @param string      $currency Currency code.
	 * @return void
	 */
	private function write_single_offer( XMLWriter $writer, WC_Product $product, string $currency ): void {
		$writer->startElement( 'offer' );
		$writer->writeAttribute( 'id', (string) $product->get_id() );
		$writer->writeAttribute( 'available', 'true' );

		// URL.
		$writer->writeElement( 'url', get_permalink( $product->get_id() ) );

		// Price.
		$regular_price = $product->get_regular_price();
		$sale_price    = $product->get_sale_price();

		if ( '' !== $sale_price && (float) $sale_price > 0 ) {
			$writer->writeElement( 'price', $sale_price );
			$writer->writeElement( 'oldprice', $regular_price );
		} else {
			$writer->writeElement( 'price', $regular_price );
		}

		// Currency.
		$writer->writeElement( 'currencyId', $currency );

		// Category.
		$terms = wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'ids' ) );
		if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
			$writer->writeElement( 'categoryId', (string) $terms[0] );
		}

		// Picture.
		$image_id = $product->get_image_id();
		if ( $image_id ) {
			$image_url = wp_get_attachment_url( $image_id );
			if ( $image_url ) {
				$writer->writeElement( 'picture', $image_url );
			}
		}

		// Gallery images.
		$gallery_ids = $product->get_gallery_image_ids();
		foreach ( $gallery_ids as $gallery_id ) {
			$gallery_url = wp_get_attachment_url( $gallery_id );
			if ( $gallery_url ) {
				$writer->writeElement( 'picture', $gallery_url );
			}
		}

		// Name.
		$writer->writeElement( 'name', $product->get_name() );

		// Description.
		$description = $product->get_description();
		if ( ! empty( $description ) ) {
			// Strip HTML tags for YML compatibility.
			$writer->writeElement( 'description', wp_strip_all_tags( $description ) );
		}

		// Barcode.
		$barcode = get_post_meta( $product->get_id(), '_mvweb_pi_barcode', true );
		if ( ! empty( $barcode ) ) {
			$writer->writeElement( 'barcode', $barcode );
		}

		$writer->endElement(); // offer.
	}

	/**
	 * Get list of existing feed files with metadata.
	 *
	 * Scans the feeds directory for YML files and returns
	 * info about each: slug, URL, last modified, product count.
	 *
	 * @since 1.0.0
	 * @return array<int, array{slug: string, url: string, file: string, modified: int, size: string}> Feed list.
	 */
	public function get_feed_list(): array {
		$feeds_dir = mvweb_pi_get_feeds_dir();
		$feeds_url = mvweb_pi_get_feeds_url();
		$feeds     = array();

		$files = glob( $feeds_dir . 'products-feed-*.yml' );
		if ( empty( $files ) ) {
			return $feeds;
		}

		foreach ( $files as $file ) {
			$basename = basename( $file );

			// Extract slug from filename: products-feed-{slug}.yml
			if ( ! preg_match( '/^products-feed-(.+)\.yml$/', $basename, $matches ) ) {
				continue;
			}

			$slug     = $matches[1];
			$modified = filemtime( $file );
			$size     = filesize( $file );

			// Count offers in the feed (quick scan).
			$product_count = $this->count_offers_in_file( $file );

			$feeds[] = array(
				'slug'     => $slug,
				'url'      => $feeds_url . $basename,
				'file'     => $file,
				'modified' => $modified,
				'size'     => size_format( $size ),
				'products' => $product_count,
			);
		}

		return $feeds;
	}

	/**
	 * Count <offer> elements in a YML file.
	 *
	 * Uses a lightweight regex scan instead of full XML parsing
	 * for performance on large files.
	 *
	 * @since 1.0.0
	 * @param string $file_path Absolute path to YML file.
	 * @return int Number of offers found.
	 */
	private function count_offers_in_file( string $file_path ): int {
		if ( ! file_exists( $file_path ) ) {
			return 0;
		}

		$count  = 0;
		$handle = fopen( $file_path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( ! $handle ) {
			return 0;
		}

		while ( ( $line = fgets( $handle ) ) !== false ) {
			if ( str_contains( $line, '<offer ' ) ) {
				++$count;
			}
		}

		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		return $count;
	}

	/**
	 * Delete all generated feed files.
	 *
	 * @since 1.0.0
	 * @return int Number of files deleted.
	 */
	public function delete_all(): int {
		$feeds_dir = mvweb_pi_get_feeds_dir();
		$files     = glob( $feeds_dir . 'products-feed-*.yml' );
		$count     = 0;

		if ( ! empty( $files ) ) {
			foreach ( $files as $file ) {
				if ( wp_delete_file( $file ) !== false ) {
					++$count;
				}
			}
		}

		return $count;
	}
}
