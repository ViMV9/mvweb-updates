# Changelog

All notable changes to MVweb Price Importer will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.2] - 2026-05-20

### Changed
- **Migrated admin UI to the current MVweb boilerplate (slate Yoast-style UI Kit).** Replaced legacy Classic Clean `admin.css` with the slate palette + Yoast-style layout from `_boilerplate/plugin-template`. Settings page now uses `.mvweb-main` shell with `.mvweb-main__header` and `.mvweb-tabs__tab`/`.mvweb-tabs__tab--active`. All five tab partials (Main, Mapping, Log, Feeds, Help) were rewritten under the new component vocabulary: `.mvweb-block` + `.mvweb-block__head` for sections, `.mvweb-form-row` for fields (was `.form-table`), `.mvweb-input`/`.mvweb-select` (was `regular-text`), `.mvweb-alert` (was `.mvweb-notice`), `.mvweb-faq` (was `.mvweb-details`), `.mvweb-toggle` for boolean switches, `.mvweb-empty` for blank states, `.mvweb-statusbar` for the Help footer. Behavior unchanged — only markup and styles.
- **`admin.js` selectors aligned with the new tab vocabulary.** Tab navigation now targets `.mvweb-tabs__tab`/`.mvweb-tabs__tab--active`; AJAX result banners render `.mvweb-alert mvweb-alert--{success|error|warning|info}` instead of the retired `.mvweb-notice` variants. Warehouse row builder emits `.mvweb-input` for the URL cell so it matches the rest of the table.
- **`plugin.css` rewritten** as a thin layer of plugin-specific styles (`.mvweb-pi-*`) plus utilities the boilerplate UI Kit deliberately leaves to the plugin: `.mvweb-tab-content` show/hide, `.mvweb-spinner.is-active` reveal, `.mvweb-pi-stats-dashboard` metric grid, `.mvweb-pi-cat-tree`/`.mvweb-pi-cat-row` category picker, `.mvweb-pi-subblock` heading, `.mvweb-pi-schedule-status` line, responsive collapse at ≤960px.
- **Settings shell widened to 1280px** so the new two-column layout breathes on large monitors. The page header no longer carries the version badge — the meta slot is used for a short tagline.
- **`helpers.php`** declares `strict_types=1` to match boilerplate.
- **`package.json`** adds the `build:locale` script alias so `npm run build:locale` works alongside `build:js` / `build:css` / `build` — matches the new boilerplate scripts surface.

## [1.0.1] - 2026-05-19

### Added
- **Separate CLI runner for feeds (`feeds-cron-runner.php`).** Lets you schedule feed regeneration independently of import via system cron — useful when the price source updates rarely (e.g. daily) but you want feeds rebuilt on a tighter cadence to keep `<yml_catalog date>` fresh. Calls `MVweb_PI_Feeds::generate_all()` directly without going through the import pipeline.
- **Help tab coverage for the feeds cron.** New Step 7 in Quick Start, a dedicated FAQ entry ("How do feeds get updated, and do I need a separate cron for them?"), and a second crontab template alongside the import one in the Note block at the bottom.

### Fixed
- **"Settings saved" notice reappeared on every refresh.** The settings form posted to itself and rendered the success notice in the same request, so Safari (and other browsers that re-submit POSTs without prompting) replayed the save on every Cmd+R. Switched to a proper Post/Redirect/Get flow: after a successful save we stash a one-shot flag in a per-user transient and `wp_safe_redirect()` to the page as a clean GET. The notice renders exactly once on the GET that follows the save; refreshes, back/forward navigation, and visits from the menu produce a clean screen with no spurious notice.

## [1.0.0] - 2026-05-19

### Fixed — End-to-end test pass
- **Feed file permissions on hosts with restrictive umask.** `MVweb_PI_Feeds::generate_feed()` now explicitly `chmod`s the feed directory to `0755` and each generated `.yml` to `0644` after `XMLWriter::flush()`. Without this, hosts like Beget VDS (extended ACLs + 0077 umask) leave the file as `0600` and nginx returns 403 — even though the file exists and is valid.
- **Stats dashboard rendered last_run as a unix timestamp.** `MVweb_PI_Cron::run()` was saving `'last_run' => time()` (int) which overwrote the human-readable `current_time('mysql')` saved by the importer one step earlier. The dashboard then echoed `1779131295` verbatim. Standardised both code paths on `current_time('mysql')`.
- **Stats dashboard "total" was always 0 after a cron-driven import.** `MVweb_PI_Importer::run()` wrote `'total'` only into the bare `update_option()` call but not into `$this->stats`, so the cron wrapper's `array_merge( $importer_stats, ['last_run' => …] )` lost it on the next save. Moved `total`/`last_run` into `$this->stats` itself, so any caller persisting the importer return value gets the full payload.
- **Localisation gaps on Main tab.** Three new strings on the consolidated Main tab — the "no source URL" warning, the "mapping not configured" warning, and the "Manual operations" help text — were not in `ru_RU.po` and rendered in English. Added Russian translations and rebuilt the `.mo`.
- **Stale browser cache after JS/CSS rebuilds.** `wp_enqueue_*` calls were keyed on `MVWEB_PI_VERSION`, so any change between version bumps (including local development) shipped behind a cached asset. Switched the `ver=` arg to `filemtime()` of the actual asset (with `MVWEB_PI_VERSION` as fallback) — every rebuild is now picked up automatically.

### Changed — UX refactor (5 tabs instead of 8)
- Collapsed **Settings + Output + Import + Categories** into a single **Main** tab. The day-to-day operator now sees source, schedule, excluded categories, action buttons and last-run statistics on one screen — same shape the legacy converter shipped with, which our users explicitly preferred over the multi-tab AJAX flow.
- Action row at the bottom of Main carries the four operations as plain buttons: **Import Now** (primary), Download, Convert, Reset Hash. Each writes into its own result panel underneath the row — no more hunting across tabs to see whether a download finished.
- Tabs that still live separately because they have their own concerns: **Mapping** (configured rarely), **Log** (read-only), **Feeds** (separate feature surface), **Help**.
- Removed orphan partials `tab-settings.php`, `tab-output.php`, `tab-import.php`, `tab-categories.php`.
- JS resolves action result containers by `data-result` attribute instead of `.mvweb-card` ancestry, so the action row can live outside any card.
- New CSS section dividers (`.mvweb-pi-section`) and a horizontal action row (`.mvweb-pi-main-actions`) responsive down to 782 px.

### Fixed — Production hardening after first real-world import
- **Lock stuck after fatal error.** A real-world import of 1425 SKUs blew through `set_time_limit(600)` while Imagick was processing a thumbnail. The `finally` clause that released `mvweb_pi_cron_lock` never ran — fatal errors in PHP bypass `finally` — so every subsequent import attempt sat idle for the full 30 min TTL. Reworked locking to mirror the legacy importer's production-proven pattern: `add_option()` (MySQL-level INSERT IGNORE) for the atomic acquire, TTL-based theft of stale locks, and `release_lock()` deletes the row outright. On CLI invocations the lock is also force-cleared at the start of every run — self-healing without waiting for TTL. Added `register_shutdown_function()` to release the lock on `E_ERROR`/OOM/Imagick crashes the moment PHP shuts down.
- **`set_time_limit(600)` too low for image-heavy catalogs.** Replaced with `set_time_limit(0)` — CLI already has no cap, web/AJAX/wp-cron now lift the cap to whatever the host allows and rely on the new wall-clock budget (see below) for time management.
- **Single-process import couldn't survive web-cron timeouts.** Added a 50 s wall-clock budget honoured by `MVweb_PI_Importer::run()` in non-CLI contexts. When the budget expires after a batch boundary, the importer persists `mvweb_pi_import_progress` and returns `incomplete=true`; the cron layer schedules a `mvweb_pi_continue_import` event 5 s later, which re-enters `run()` and picks up via the existing resume path. CLI runs (cron-runner.php, real system cron) are unaffected — they get an unlimited budget and finish in one process.

### Added — Image import policy
- New setting `image_mode` (default `new_only`) controls Imagick involvement during updates:
  - `new_only` — download images only when an SKU is first created; updates leave existing images alone. This is the legacy importer's default and the recommended choice for catalogs larger than a few hundred items, because thumbnail regeneration is by far the most expensive step.
  - `always` — refresh images on every import (the previous unconditional behaviour).
  - `never` — skip image import entirely for text-only catalogs.
- Surfaced as a select on the Settings tab next to Batch Size.
- Persisted through `MVweb_PI_Settings` with a whitelist sanitization.
- The activation hook no longer pre-creates `mvweb_pi_cron_lock` — leaving the row missing lets the first-ever `acquire_lock()` take the race-free `add_option()` path.

### Added — Import pipeline
- CSV, YML (Yandex.Market), XLSX import with streaming parsers (SplFileObject, XMLReader, SimpleXLSX).
- Auto-detection of delimiter, encoding (UTF-8/Windows-1251) and column mapping (EN + RU keywords).
- Google Sheets URL auto-conversion to CSV export.
- ETag/Last-Modified change detection — skips download when source is unchanged.
- Generator-based conversion pipeline; multi-warehouse SKU merge with per-warehouse stock JSON.
- Field mapping UI with 11 dropdowns and auto-detect button.
- Category import with parent/child hierarchy and external ID mapping via term meta `mvweb_pi_external_id`.
- Featured image + gallery import with URL-change detection.
- WP-Cron scheduler with custom intervals (hourly, 6h, 12h, daily); CLI runner (`cron-runner.php`); REST endpoint `POST /wp-json/mvweb-pi/v1/run-import`.
- Checkpoint/resume support for interrupted imports.
- Error email notifications to site admin.

### Added — Yandex.Market YML feed generation
- Streaming feed generation via `XMLWriter` (memory-efficient).
- General feed (all in-stock products) plus per-warehouse feeds.
- Configurable company name, currency (RUR/USD/EUR), auto-generate-after-import toggle.
- Feed list UI with URL, date, product count, file size.

### Added — Frontend
- Per-warehouse stock breakdown on product page via `woocommerce_get_stock_html`.
- Per-warehouse stock display in admin order view.
- BEM-named frontend CSS (`.mvweb-pi-stocks`).

### Added — Logging and operations
- JSONL file logger (`MVweb_PI_Logger`) with size (10 MB) and age (30 days) rotation; dated `.bak` archives.
- Paginated log reading via `SplFileObject::seek()`; level filter (info/warning/error).
- Log viewer UI with pagination and Clear button.

### Added — Localization and docs
- POT translation template with ~150 translatable strings.
- Russian translation (`ru_RU.po` + `ru_RU.mo`) covering UI, Help tab and runtime messages.
- Technical documentation in `docs/plugins/mvweb-price-importer.md`.
- Built-in Help tab with Quick Start, Features, FAQ and Support sections.

### Added — Boilerplate alignment (1.0.0 release prep)
- Adopted MVweb UI Kit · IDE Light theme: `.mvweb-theme-ide` modifier on the root wrap, breadcrumbs, version pill, `nav-tab__dot` markers, optional `nav-tab__badge` slots.
- Tab labels are now user-friendly and fully localized through `__()`.
- Bundled shared classes (`MVweb_Menu`, `MVweb_Updater`, `plugin-update-checker`) under `includes/` so production deployments no longer depend on the studio monorepo `shared/` directory.
- Updated `admin.css` to the latest boilerplate revision (IDE Light overlay over Classic Clean); replaced boilerplate placeholders (`{{PLUGIN_NAME}}`, `{{PLUGIN_PREFIX}}`) with real values.

### Changed
- `acquire_lock()` reworked to a single atomic SQL `UPDATE` with a combined "free or stale" predicate, closing the two-statement race window where two concurrent triggers (AJAX + WP-Cron + REST) could both pass the check.
- `zero_missing_stock()` and `known_skus` are now persisted only after the import generator fully drains. Interrupted imports keep their partial SKU set in the progress option and recover on resume — no more accidental stock-zeroing of products that simply hadn't been streamed yet.
- `mvweb_pi_batch_size` filter is now actually honoured: it runs after the settings value, so plugin authors can override both default and configured batch size.
- Gallery imports deduplicate by URL via the new `_mvweb_pi_gallery_sources` post meta — repeated imports of the same product no longer create duplicate attachments. Stale images previously uploaded by this plugin are now cleaned up when removed from the source.
- `MVweb_PI_Categories` no longer calls `wp_cache_flush()` after bulk creation; only the `product_cat` terms it touched are invalidated through `clean_term_cache()`, eliminating the previous global cache-flush spike on busy stores.
- `MVweb_PI_Logger` constructor is now `private` to enforce the singleton invariant.
- `helpers.php` public functions gained PHP 8 parameter and return type hints.

### Removed
- Unused `MVweb_PI_Cron::INTERVALS` constant and the pre-release `@deprecated 1.0.0` shim `mvweb_pi_release_lock()`.

### Security
- **SSRF — image downloads.** Replaced `media_sideload_image()` (which follows redirects, bypassing `validate_url()`) with a hardened pipeline: download through `MVweb_PI_Loader::download()` (no redirects, IP allowlist, magic-bytes check) into a temp file, then sideload locally via `wp_handle_sideload()` + `wp_insert_attachment()`.
- **SSRF — DNS rebinding.** `validate_url()` now resolves the host through `dns_get_record()` (A + AAAA, all records) and refuses any private/reserved/link-local IP, including AWS metadata link-local. `download()` re-resolves after the HTTP request and refuses the payload if the IP set changed (rebinding detection). `check_etag()` re-validates before each HEAD.
- **SSRF — re-validation.** `mvweb_pi_detect_columns` AJAX now passes the stored source URL through `validate_url()` before downloading.
- **XLSX ZIP-bomb.** Before handing the file to `SimpleXLSX::parse()`, individual ZIP entries are inspected via `ZipArchive::statName()` and the file is rejected when any entry decompresses past 250 MB.
- **Memory exhaustion.** `merge_warehouses()` now checks `memory_get_usage(true)` every 250 rows and aborts cleanly at 80 % of `memory_limit` with a log entry, preventing OOM kills on shared hosting.
- **Credential leakage.** `mvweb_pi_log()` strips `user:pass@` Basic Auth credentials from all URLs before writing to the JSONL log or PHP `error_log`. Recursively masks context arrays as well.
- **Multisite uninstall.** `switch_to_blog()` / `restore_current_blog()` are now wrapped in `try/finally`, so a failure inside one site's cleanup doesn't strand the global blog context. `$wpdb->delete()` calls in `uninstall.php` now pass explicit `%s` format arrays. Also clears the new `_mvweb_pi_gallery_sources` post meta and `mvweb_pi_import_progress` option.
- **Existing protections.** Nonce verification on every AJAX handler and form; `manage_options` capability check on every admin endpoint; REST `permission_callback` enforces `manage_options`; XXE-disabled XML parsing via `LIBXML_NONET | LIBXML_NOENT`; UUID-named files in a protected upload directory (`.htaccess` + `index.php`); magic-bytes validation for downloaded files.

## [1.0.0] - YYYY-MM-DD

_Initial release. The above changelog will be folded into this section by `/wp:master` at release time._
