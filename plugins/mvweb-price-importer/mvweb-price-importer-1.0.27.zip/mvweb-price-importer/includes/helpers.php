<?php
/**
 * Helper functions for MVweb Price Importer
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

declare(strict_types=1);

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get plugin option with default value.
 *
 * @since 1.0.0
 * @param string $key     Option key (without mvweb_pi_ prefix).
 * @param mixed  $default Default value.
 * @return mixed Option value.
 */
function mvweb_pi_get_option( string $key, $default = '' ) {
	return get_option( 'mvweb_pi_' . $key, $default );
}

/**
 * Update plugin option.
 *
 * @since 1.0.0
 * @param string $key   Option key (without mvweb_pi_ prefix).
 * @param mixed  $value Option value.
 * @return bool True if updated, false otherwise.
 */
function mvweb_pi_update_option( string $key, $value ): bool {
	return update_option( 'mvweb_pi_' . $key, $value );
}

/**
 * Delete plugin option.
 *
 * @since 1.0.0
 * @param string $key Option key (without mvweb_pi_ prefix).
 * @return bool True if deleted, false otherwise.
 */
function mvweb_pi_delete_option( string $key ): bool {
	return delete_option( 'mvweb_pi_' . $key );
}

/**
 * Get the pricelists upload directory path.
 *
 * @since 1.0.0
 * @return string Absolute path to pricelists directory.
 */
function mvweb_pi_get_upload_dir(): string {
	$upload_dir = wp_upload_dir();
	return $upload_dir['basedir'] . '/pricelists/';
}

/**
 * Get the feeds directory path.
 *
 * @since 1.0.0
 * @return string Absolute path to feeds directory.
 */
function mvweb_pi_get_feeds_dir(): string {
	return mvweb_pi_get_upload_dir() . 'feeds/';
}

/**
 * Get the feeds directory URL.
 *
 * @since 1.0.0
 * @return string URL to feeds directory.
 */
function mvweb_pi_get_feeds_url(): string {
	$upload_dir = wp_upload_dir();
	return $upload_dir['baseurl'] . '/pricelists/feeds/';
}

/**
 * Strip Basic Auth credentials from any URL appearing inside a string.
 *
 * `https://user:secret@host/path` → `https://***:***@host/path`. Used to
 * sanitize log messages and email bodies so supplier credentials embedded
 * in source URLs don't leak into shared log files (which can be world-
 * readable on Nginx where the bundled .htaccess does nothing).
 *
 * @since 1.0.0
 * @param string $value Arbitrary string that may contain URLs.
 * @return string Sanitized string.
 */
function mvweb_pi_mask_credentials( string $value ): string {
	if ( '' === $value ) {
		return $value;
	}
	return preg_replace(
		'#(https?://)([^:/@\s]+):([^@/\s]+)@#i',
		'$1***:***@',
		$value
	);
}

/**
 * Log message to JSONL file via MVweb_PI_Logger.
 *
 * Always writes to the JSONL log file (wp-content/uploads/pricelists/mvweb_pi.log).
 * Additionally writes to PHP error_log when WP_DEBUG is enabled.
 *
 * @since 1.0.0
 * @param mixed  $message Message to log.
 * @param string $level   Log level (info, warning, error).
 * @param array  $context Optional context data.
 * @return void
 */
function mvweb_pi_log( $message, $level = 'info', $context = array() ) {
	if ( is_array( $message ) || is_object( $message ) ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_print_r
		$message = print_r( $message, true );
	}

	$message = mvweb_pi_mask_credentials( (string) $message );

	// Mask credentials inside context values too, in case a URL string slips in.
	if ( ! empty( $context ) ) {
		array_walk_recursive(
			$context,
			static function ( &$item ) {
				if ( is_string( $item ) ) {
					$item = mvweb_pi_mask_credentials( $item );
				}
			}
		);
	}

	// Write to JSONL log file.
	if ( class_exists( 'MVweb_PI_Logger' ) ) {
		$logger = MVweb_PI_Logger::get_instance();
		$logger->log( $level, $message, $context );
	}

	// Also write to PHP error_log when debugging.
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		$log_message = sprintf(
			'[MVweb Price Importer] [%s] %s',
			strtoupper( $level ),
			$message
		);
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( $log_message );
	}
}

/**
 * Source ids the current settings expect to import from.
 *
 * With warehouses configured, that is each warehouse id; otherwise the single
 * `default` source when a source URL is set. Used to ignore (and clean up)
 * leftover `source-{id}-{uuid}` files of warehouses that were removed from the
 * settings — without this a manual Convert would re-merge a removed warehouse's
 * stock into the total and the general feed even though no feed exists for it
 * any more.
 *
 * @since 1.0.0
 * @param array $settings The `mvweb_pi_settings` option array.
 * @return string[] Expected source ids.
 */
function mvweb_pi_expected_source_ids( array $settings ): array {
	$warehouses = $settings['warehouses'] ?? array();

	if ( ! empty( $warehouses ) && is_array( $warehouses ) ) {
		$ids = array();
		foreach ( $warehouses as $wh ) {
			$id = isset( $wh['id'] ) ? (string) $wh['id'] : '';
			if ( '' !== $id ) {
				$ids[] = $id;
			}
		}
		return $ids;
	}

	return ! empty( $settings['source_url'] ) ? array( 'default' ) : array();
}

/**
 * Normalise supplier text: decode HTML entities and strip invisible characters.
 *
 * Price lists routinely arrive with text mangled by an exporter that encoded it
 * more than once — `Bluetooth-гарнитура &amp;quot;Saches&amp;quot; R3` — and with
 * non-breaking spaces glued into names. Neither sanitize_text_field() nor
 * wp_kses_post() decodes entities, so without this the mangled text lands in the
 * catalogue verbatim.
 *
 * Order matters: entities are decoded BEFORE sanitising, so anything that
 * surfaces from the encoding still passes through the filter. That order is the
 * whole point — WordPress does not filter post_title/post_content on insert
 * (only `pre_term_name` is protected by core), so for products this is the only
 * line of defence.
 *
 * @since 1.0.25
 * @param string $value      Raw text from the price list.
 * @param bool   $allow_html Whether the field keeps HTML (product description).
 * @return string Normalised text, sanitised for its context.
 */
function mvweb_pi_clean_text( string $value, bool $allow_html = false ): string {
	if ( '' === $value ) {
		return $value;
	}

	// Control bytes carry no meaning in product text, and the two used below as
	// placeholders would be mistaken for angle brackets on the way back — a feed
	// carrying them verbatim would lose the text around them. Drop them first.
	$value = str_replace( array( "\x01", "\x02" ), '', $value );

	// Remember the angle brackets that arrived as real markup. Everything that
	// only appears AFTER decoding is text the supplier encoded on purpose, and
	// it must not become markup: wp_kses_post() drops everything between "<"
	// and the next ">", so an encoded "вес &lt; 5 кг, длина &gt; 2 м" would lose
	// that whole fragment once decoding turned it into brackets. Brackets that
	// arrive raw are markup as far as the feed is concerned and keep going
	// through kses unchanged, exactly as they did before this normalisation.
	if ( $allow_html ) {
		$value = str_replace( array( '<', '>' ), array( "\x01", "\x02" ), $value );
	}

	// Decode until the string settles. Two passes cover the common double
	// encoding; the third is headroom for exporters that stack another layer.
	// The cap is a safety stop, not a correctness requirement — decoding always
	// reaches a fixed point on its own.
	for ( $pass = 0; $pass < 3; $pass++ ) {
		$decoded = html_entity_decode( $value, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		if ( $decoded === $value ) {
			break;
		}
		$value = $decoded;
	}

	if ( $allow_html ) {
		// Anything that surfaced from the encoding goes back to a harmless
		// entity, then the original markup is restored.
		$value = str_replace( array( '<', '>' ), array( '&lt;', '&gt;' ), $value );
		$value = str_replace( array( "\x01", "\x02" ), array( '<', '>' ), $value );
	}

	// Invisible characters and the non-breaking space, byte-wise on purpose: a
	// /u regex returns null on malformed UTF-8 and would wipe the whole field.
	// The non-breaking space becomes a regular one so that neighbouring words
	// never glue together; a doubled space is collapsed below.
	$value = str_replace(
		array( "\xE2\x80\x8B", "\xEF\xBB\xBF", "\xC2\xAD", "\xC2\xA0" ),
		array( '', '', '', ' ' ),
		$value
	);

	$value = $allow_html ? wp_kses_post( $value ) : sanitize_text_field( $value );

	// Collapse runs of spaces left behind by the replacements. For descriptions
	// only horizontal whitespace is touched so line breaks survive.
	$value = $allow_html
		? (string) preg_replace( '/[ \t]{2,}/', ' ', $value )
		: (string) preg_replace( '/ {2,}/', ' ', $value );

	return trim( $value );
}
