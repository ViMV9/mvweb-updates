<?php
/**
 * Plugin Name:       MVweb Price Importer
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-price-importer
 * Description:       Automatic import of products from external price lists into WooCommerce.
 * Version:           1.0.27
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Requires Plugins:  woocommerce
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-price-importer
 * Domain Path:       /languages
 *
 * @package mvweb_pi
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_PI_VERSION' ) ) {
	return;
}

/**
 * Plugin version.
 */
define( 'MVWEB_PI_VERSION', '1.0.27' );

/**
 * Plugin directory path.
 */
define( 'MVWEB_PI_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Plugin directory URL.
 */
define( 'MVWEB_PI_URL', plugin_dir_url( __FILE__ ) );

/**
 * Plugin basename.
 */
define( 'MVWEB_PI_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_PI_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_PI_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_PI_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
// Do NOT rely on get_instance() at end of class file — OPcache may skip it.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_PI_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_PI_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-price-importer' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-price-importer'] = array(
		'name'         => 'MVweb Price Importer',
		'description'  => __( 'Automatic import of products from external price lists.', 'mvweb-price-importer' ),
		'url'          => 'https://mvweb.ru/plugins/mvweb-price-importer',
		'settings_url' => 'admin.php?page=mvweb-price-importer',
		'textdomain'   => 'mvweb-price-importer',
	);
	return $plugins;
} );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-price-importer',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_pi_load_textdomain' );

/**
 * Register plugin submenu under MVweb Hub.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_register_menu() {
	$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

	add_submenu_page(
		$parent_slug,
		__( 'MVweb Price Importer', 'mvweb-price-importer' ),
		__( 'Price Importer', 'mvweb-price-importer' ),
		'manage_options',
		'mvweb-price-importer',
		'mvweb_pi_settings_page'
	);
}
add_action( 'admin_menu', 'mvweb_pi_register_menu' );

/**
 * Plugin settings page callback.
 *
 * Delegates to MVweb_PI_Admin for settings handling and rendering.
 *
 * @since 1.0.0
 * @since 1.1.0 Refactored to delegate to MVweb_PI_Admin/MVweb_PI_Settings.
 * @return void
 */
function mvweb_pi_settings_page() {
	$admin = new MVweb_PI_Admin();
	$admin->settings_page();
}

/**
 * Enqueue admin styles and scripts.
 *
 * @since 1.0.0
 * @param string $hook Current admin page hook.
 * @return void
 */
function mvweb_pi_admin_enqueue( $hook ) {
	if ( false === strpos( $hook, 'mvweb-price-importer' ) ) {
		return;
	}

	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	// Cache buster: prefer the bundle's mtime so a re-uploaded build
	// is picked up by browsers without bumping MVWEB_PI_VERSION.
	$asset_ver = static function ( string $relative_path ) {
		$absolute = MVWEB_PI_PATH . $relative_path;
		$mtime    = file_exists( $absolute ) ? filemtime( $absolute ) : false;
		return $mtime ? (string) $mtime : MVWEB_PI_VERSION;
	};

	wp_enqueue_style(
		'mvweb-pi-admin',
		MVWEB_PI_URL . 'admin/css/admin' . $suffix . '.css',
		array(),
		$asset_ver( 'admin/css/admin' . $suffix . '.css' )
	);

	wp_enqueue_style(
		'mvweb-pi-plugin',
		MVWEB_PI_URL . 'admin/css/plugin' . $suffix . '.css',
		array( 'mvweb-pi-admin' ),
		$asset_ver( 'admin/css/plugin' . $suffix . '.css' )
	);

	wp_enqueue_script(
		'mvweb-pi-admin',
		MVWEB_PI_URL . 'admin/js/admin' . $suffix . '.js',
		array( 'jquery' ),
		$asset_ver( 'admin/js/admin' . $suffix . '.js' ),
		true
	);

	wp_localize_script(
		'mvweb-pi-admin',
		'mvweb_pi_ajax',
		array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'mvweb_pi_ajax' ),
			'i18n'     => array(
				'created'         => __( 'created', 'mvweb-price-importer' ),
				'updated'         => __( 'updated', 'mvweb-price-importer' ),
				'skipped'         => __( 'skipped', 'mvweb-price-importer' ),
				'errors'          => __( 'errors', 'mvweb-price-importer' ),
				'products'        => __( 'products', 'mvweb-price-importer' ),
				'invalid'         => __( 'invalid', 'mvweb-price-importer' ),
				'duplicates'      => __( 'duplicates', 'mvweb-price-importer' ),
				'unchanged'       => __( 'no changes', 'mvweb-price-importer' ),
				'downloaded'      => __( 'Sources downloaded.', 'mvweb-price-importer' ),
				'converted'       => __( 'Sources converted.', 'mvweb-price-importer' ),
				'feed_generated'  => __( 'Feed generated.', 'mvweb-price-importer' ),
				'feeds_generated' => __( 'Feeds generated.', 'mvweb-price-importer' ),
				'feed_generating' => __( 'Generating feed…', 'mvweb-price-importer' ),
				'feed_collecting' => __( 'Collecting categories…', 'mvweb-price-importer' ),
				'delete'          => __( 'Delete', 'mvweb-price-importer' ),
				'confirm_delete_feed' => __( 'Delete this feed file? This cannot be undone.', 'mvweb-price-importer' ),
				'invalid_file'    => __( 'Invalid rows file:', 'mvweb-price-importer' ),
				'checkpoint'      => __( 'Checkpoint file:', 'mvweb-price-importer' ),
				'request_failed'  => __( 'Request failed. Please try again.', 'mvweb-price-importer' ),
				'unknown_error'   => __( 'Unknown error.', 'mvweb-price-importer' ),
				'tree_fetched'    => __( 'Category tree loaded.', 'mvweb-price-importer' ),
				'columns_detected' => __( 'columns detected', 'mvweb-price-importer' ),
				'no_columns'      => __( 'No columns found — the file contains no products.', 'mvweb-price-importer' ),
				'import_running_title' => __( 'Import is still running in the background', 'mvweb-price-importer' ),
				'import_running_body'  => __( 'The browser stopped waiting for a response because images for a large catalog take longer to download than a typical HTTP request allows. The import itself has not stopped — the server continues processing in the background. Wait a few minutes and reload the page to see the final stats.', 'mvweb-price-importer' ),
			),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'mvweb_pi_admin_enqueue' );

/**
 * Render the wholesale price input in the product-data «General» panel.
 *
 * Placed under the native price fields via WooCommerce's own field helper, so
 * the markup, price validation class and styling match core price inputs. The
 * value is the same meta the importer writes (`_mvweb_pi_wholesale_price`),
 * making an imported wholesale price visible and correctable by hand. Display
 * and any price calculation on the storefront are left to the theme.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_render_wholesale_field() {
	woocommerce_wp_text_input(
		array(
			'id'          => '_mvweb_pi_wholesale_price',
			'label'       => __( 'Wholesale price', 'mvweb-price-importer' ) . ' (' . get_woocommerce_currency_symbol() . ')',
			'data_type'   => 'price',
			'desc_tip'    => true,
			'description' => __( 'Wholesale price from the price list. Stored separately from the retail price and never used for the storefront price — the theme decides where to show or use it.', 'mvweb-price-importer' ),
		)
	);
}
add_action( 'woocommerce_product_options_pricing', 'mvweb_pi_render_wholesale_field' );

/**
 * Persist the wholesale price field when a product is saved in the editor.
 *
 * WooCommerce verifies its product-editor nonce and the edit capability before
 * `woocommerce_process_product_meta` fires, so this handler only sanitises and
 * stores. An empty value clears the meta. `wc_format_decimal()` normalises the
 * number exactly like WooCommerce stores its own prices, keeping the value
 * consistent with what the importer writes.
 *
 * @since 1.0.0
 * @param int $product_id Product being saved.
 * @return void
 */
function mvweb_pi_save_wholesale_field( $product_id ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verifies its product-editor nonce before this hook fires.
	if ( ! isset( $_POST['_mvweb_pi_wholesale_price'] ) ) {
		return;
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- see above.
	$raw = wc_clean( wp_unslash( $_POST['_mvweb_pi_wholesale_price'] ) );

	if ( '' === $raw ) {
		delete_post_meta( $product_id, '_mvweb_pi_wholesale_price' );
		return;
	}

	update_post_meta( $product_id, '_mvweb_pi_wholesale_price', wc_format_decimal( $raw ) );
}
add_action( 'woocommerce_process_product_meta', 'mvweb_pi_save_wholesale_field' );

/**
 * Create protected upload directory for pricelists.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_create_upload_dir() {
	$upload_dir  = wp_upload_dir();
	$pricelists  = $upload_dir['basedir'] . '/pricelists/';
	$feeds_dir   = $pricelists . 'feeds/';

	wp_mkdir_p( $pricelists );
	wp_mkdir_p( $feeds_dir );

	// index.php — prevent directory listing.
	$index_content = "<?php\n// Silence is golden.\n";
	if ( ! file_exists( $pricelists . 'index.php' ) ) {
		file_put_contents( $pricelists . 'index.php', $index_content );
	}
	if ( ! file_exists( $feeds_dir . 'index.php' ) ) {
		file_put_contents( $feeds_dir . 'index.php', $index_content );
	}

	// .htaccess — deny direct access to pricelists (not feeds).
	$htaccess = $pricelists . '.htaccess';
	if ( ! file_exists( $htaccess ) ) {
		$rules  = "# Protect pricelists directory\n";
		$rules .= "<IfModule mod_authz_core.c>\n";
		$rules .= "    Require all denied\n";
		$rules .= "</IfModule>\n";
		$rules .= "<IfModule !mod_authz_core.c>\n";
		$rules .= "    Order deny,allow\n";
		$rules .= "    Deny from all\n";
		$rules .= "</IfModule>\n";
		file_put_contents( $htaccess, $rules );
	}

	// feeds/ must override the parent deny — Apache .htaccess cascades
	// into subdirectories, so without an explicit allow here the YML
	// feeds are unreachable on the public side even though they are
	// intentionally meant to be served (e.g. for Yandex.Market).
	$feeds_htaccess = $feeds_dir . '.htaccess';
	if ( ! file_exists( $feeds_htaccess ) ) {
		$rules  = "# Allow public access to generated feeds\n";
		$rules .= "<IfModule mod_authz_core.c>\n";
		$rules .= "    Require all granted\n";
		$rules .= "</IfModule>\n";
		$rules .= "<IfModule !mod_authz_core.c>\n";
		$rules .= "    Order allow,deny\n";
		$rules .= "    Allow from all\n";
		$rules .= "</IfModule>\n";
		file_put_contents( $feeds_htaccess, $rules );
	}
}

/**
 * Plugin activation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_activate() {
	// Check WooCommerce dependency.
	if ( ! class_exists( 'WooCommerce' ) ) {
		deactivate_plugins( plugin_basename( __FILE__ ) );
		wp_die(
			esc_html__( 'MVweb Price Importer requires WooCommerce 8.0+ to be installed and active.', 'mvweb-price-importer' ),
			esc_html__( 'Plugin Activation Error', 'mvweb-price-importer' ),
			array( 'back_link' => true )
		);
	}

	// Create protected upload directory.
	mvweb_pi_create_upload_dir();

	// Initialize service options (autoload=no).
	// NOTE: mvweb_pi_cron_lock is deliberately NOT pre-created — it must
	// not exist until a real import starts, otherwise acquire_lock()'s
	// add_option() race-free path can never fire on first run.
	add_option( 'mvweb_pi_last_etags', array(), '', 'no' );
	add_option( 'mvweb_pi_import_stats', array(), '', 'no' );
	add_option( 'mvweb_pi_known_skus', array(), '', 'no' );
}
register_activation_hook( __FILE__, 'mvweb_pi_activate' );

/**
 * Plugin deactivation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_deactivate() {
	wp_clear_scheduled_hook( 'mvweb_pi_cron_import' );
	wp_clear_scheduled_hook( 'mvweb_pi_continue_import' );
	wp_clear_scheduled_hook( 'mvweb_pi_continue_feeds' );
	delete_option( 'mvweb_pi_cron_lock' );
	delete_option( 'mvweb_pi_feed_lock' );
}
register_deactivation_hook( __FILE__, 'mvweb_pi_deactivate' );

// Include additional files.
require_once MVWEB_PI_PATH . 'includes/helpers.php';

// Stage 10: Logger (JSONL file logging).
require_once MVWEB_PI_PATH . 'includes/class-logger.php';

// Stage 2: Loader and Parsers.
require_once MVWEB_PI_PATH . 'includes/class-loader.php';
require_once MVWEB_PI_PATH . 'includes/class-parser-csv.php';
require_once MVWEB_PI_PATH . 'includes/class-parser-yml.php';
require_once MVWEB_PI_PATH . 'includes/class-parser-xlsx.php';
require_once MVWEB_PI_PATH . 'includes/class-parser-xls.php';
require_once MVWEB_PI_PATH . 'includes/class-parser.php';

// Stage 3: Converter.
require_once MVWEB_PI_PATH . 'includes/class-converter.php';

// Stage 4: Importer.
require_once MVWEB_PI_PATH . 'includes/class-importer.php';

// Stage 5: Categories.
require_once MVWEB_PI_PATH . 'includes/class-categories.php';

// Stage 6: Cron and REST.
require_once MVWEB_PI_PATH . 'includes/class-cron.php';
require_once MVWEB_PI_PATH . 'includes/class-rest.php';

// Stage 7: Feeds.
require_once MVWEB_PI_PATH . 'includes/class-feeds.php';

// Admin: Settings and Admin classes.
require_once MVWEB_PI_PATH . 'admin/class-settings.php';
require_once MVWEB_PI_PATH . 'admin/class-admin.php';

// Stage 9: Frontend UI (per-warehouse stock display).
require_once MVWEB_PI_PATH . 'includes/class-ui.php';

// Initialize frontend UI (Stage 9: per-warehouse stock display).
new MVweb_PI_UI();

/**
 * Run one-shot data migrations after the plugin files are updated.
 *
 * The activation hook only fires on (re)activation, not on a silent file/ZIP
 * update or an auto-update through the update checker. We compare the version
 * stored in the DB against the current constant and run any pending migration
 * exactly once when it rises, then record the new version. Hooked on admin_init
 * so it runs in a normal admin request with WooCommerce fully loaded — never on
 * a front-end hit.
 *
 * @since 1.0.14
 * @return void
 */
function mvweb_pi_maybe_upgrade() {
	// The migration mutates the DB; gate it to admins so a logged-in
	// non-admin hitting any wp-admin request (incl. admin-ajax) can't trigger
	// it. The only sensible moment to run is when an admin opens the dashboard
	// after the update.
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$stored = (string) get_option( 'mvweb_pi_version', '' );
	if ( MVWEB_PI_VERSION === $stored ) {
		return;
	}

	// 1.0.14: products that returned to stock under older builds kept a stale
	// product_visibility 'outofstock' term and stayed hidden from the catalogue
	// and search. Drop the term wherever stock says instock.
	if ( '' === $stored || version_compare( $stored, '1.0.14', '<' ) ) {
		if ( class_exists( 'WooCommerce' ) && class_exists( 'MVweb_PI_Importer' ) ) {
			$fixed = MVweb_PI_Importer::resync_hidden_instock_visibility();
			if ( $fixed > 0 && function_exists( 'mvweb_pi_log' ) ) {
				mvweb_pi_log(
					/* translators: %d: number of products */
					sprintf( __( 'Upgrade: restored catalogue visibility for %d in-stock products that were hidden as out of stock.', 'mvweb-price-importer' ), $fixed ),
					'info'
				);
			}
		}
	}

	update_option( 'mvweb_pi_version', MVWEB_PI_VERSION, false );
}
add_action( 'admin_init', 'mvweb_pi_maybe_upgrade' );

// Register custom cron intervals (TZ 8.4).
add_filter( 'cron_schedules', array( 'MVweb_PI_Cron', 'register_intervals' ) );

// Bind cron hook to import runner.
add_action( 'mvweb_pi_cron_import', function () {
	$cron = new MVweb_PI_Cron();
	$cron->run();
} );

// Continuation hook — scheduled by the importer when a web/AJAX/wp-cron run
// hits its wall-clock budget. Same handler, picks up via the resume path.
add_action( MVweb_PI_Cron::CONTINUE_HOOK, function () {
	$cron = new MVweb_PI_Cron();
	$cron->run();
} );

// Feed generation continuation — scheduled when a slice of the post-import
// feed build runs out of wall clock. Separate from the import continuation:
// the catalogue is already imported by then, only the feed is unfinished.
add_action( MVweb_PI_Cron::CONTINUE_FEEDS_HOOK, function () {
	$cron = new MVweb_PI_Cron();
	$cron->continue_feeds();
} );

// Batched WC transient invalidation for touched products only.
//
// The lookup-table (wc_product_meta_lookup) used to be refreshed here too,
// but WC_Data_Store_WP::update_lookup_table() is `protected`, so calling it
// from this closure throws a fatal at end-of-run. The legacy plugin lived
// without that refresh for years — catalog filters and "sort by price"
// degrade gracefully (last write wins on next product save), and a one-off
// WP-CLI "wc tool run regenerate_product_lookup_tables" fixes a fresh
// install after the first import. Not worth a fatal on every cron run.
add_action( 'mvweb_pi_after_import', function ( $stats ) {
	$touched = isset( $stats['touched_ids'] ) && is_array( $stats['touched_ids'] )
		? array_unique( array_map( 'intval', $stats['touched_ids'] ) )
		: array();

	if ( empty( $touched ) ) {
		return;
	}

	// Batched WC transient invalidation. The importer writes meta
	// directly bypassing WC_Product->save(), so WC's per-product
	// transients (`_transient_wc_product_*`, the `products` cache
	// group) would otherwise serve stale reads to the next admin /
	// REST / theme query. Doing this once per touched ID at the end
	// of the run is dramatically cheaper than doing it inline after
	// every meta write — wc_delete_product_transients() is itself
	// 3–5 wp_options operations per call.
	if ( function_exists( 'wc_delete_product_transients' ) ) {
		foreach ( $touched as $pid ) {
			if ( $pid > 0 ) {
				wc_delete_product_transients( $pid );
			}
		}
	}
}, 30, 1 );

// Register REST API routes (TZ 8.1).
add_action( 'rest_api_init', function () {
	$rest = new MVweb_PI_REST();
	$rest->register_routes();
} );

// ───────────────────────────────────────────────
// Settings save handler
// ───────────────────────────────────────────────

/**
 * AJAX handler: detect columns from a downloaded source file.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_detect_columns() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$settings = get_option( 'mvweb_pi_settings', array() );
	$url      = $settings['source_url'] ?? '';

	if ( empty( $url ) ) {
		wp_send_json_error( __( 'No source URL configured.', 'mvweb-price-importer' ) );
	}

	$loader = new MVweb_PI_Loader();

	// Convert Google Sheets URL if needed.
	$url = $loader->convert_google_sheets_url( $url );

	// Re-validate the URL even though it was sanitized on save — the option
	// could have been mutated out-of-band and validate_url() also covers
	// SSRF/scheme/IP checks that sanitize_text_field cannot perform.
	$valid = $loader->validate_url( $url );
	if ( is_wp_error( $valid ) ) {
		wp_send_json_error( $valid->get_error_message() );
	}

	// Determine format and file extension.
	$format = $loader->detect_format( $url );
	$ext    = ( 'yml' === $format ) ? 'yml' : $format;

	// Download to temp file with UUID name.
	$upload_dir  = mvweb_pi_get_upload_dir();
	$uuid        = wp_generate_uuid4();
	$destination = $upload_dir . "detect-{$uuid}.{$ext}";

	$result = $loader->download( $url, $destination );

	if ( is_wp_error( $result ) ) {
		wp_send_json_error( $result->get_error_message() );
	}

	// Detect columns.
	try {
		$detected = MVweb_PI_Parser::detect_columns( $destination );
		wp_send_json_success( $detected );
	} catch ( \Exception $e ) {
		wp_send_json_error( $e->getMessage() );
	} finally {
		// Clean up temp file.
		if ( file_exists( $destination ) ) {
			wp_delete_file( $destination );
		}
	}
}
add_action( 'wp_ajax_mvweb_pi_detect_columns', 'mvweb_pi_ajax_detect_columns' );

/**
 * AJAX handler: download source file(s) from configured URL(s).
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_download_source() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$settings   = get_option( 'mvweb_pi_settings', array() );
	$warehouses = $settings['warehouses'] ?? array();
	$source_url = $settings['source_url'] ?? '';

	// Build list of URLs to download.
	$sources = array();
	if ( ! empty( $warehouses ) ) {
		foreach ( $warehouses as $wh ) {
			if ( ! empty( $wh['url'] ) ) {
				$sources[] = array(
					'id'  => $wh['id'] ?? sanitize_title( $wh['name'] ?? '' ),
					'url' => $wh['url'],
				);
			}
		}
	} elseif ( ! empty( $source_url ) ) {
		$sources[] = array(
			'id'  => 'default',
			'url' => $source_url,
		);
	}

	if ( empty( $sources ) ) {
		wp_send_json_error( __( 'No source URLs configured.', 'mvweb-price-importer' ) );
	}

	$loader     = new MVweb_PI_Loader();
	$upload_dir = mvweb_pi_get_upload_dir();
	$results    = array();
	$errors     = array();

	foreach ( $sources as $source ) {
		$url = $loader->convert_google_sheets_url( $source['url'] );

		// Check ETag — skip if unchanged.
		$changed = $loader->check_etag( $url, $source['id'] );
		if ( ! $changed ) {
			$results[] = array(
				'id'      => $source['id'],
				'status'  => 'unchanged',
				'message' => __( 'File unchanged (ETag match).', 'mvweb-price-importer' ),
			);
			continue;
		}

		// Determine format.
		$format = $loader->detect_format( $url );
		$ext    = ( 'yml' === $format ) ? 'yml' : $format;
		$uuid   = wp_generate_uuid4();
		$dest   = $upload_dir . "source-{$source['id']}-{$uuid}.{$ext}";

		$download_result = $loader->download( $url, $dest );
		if ( is_wp_error( $download_result ) ) {
			$errors[] = array(
				'id'      => $source['id'],
				'message' => $download_result->get_error_message(),
			);
		} else {
			$results[] = array(
				'id'     => $source['id'],
				'status' => 'downloaded',
				'file'   => basename( $dest ),
				'format' => $format,
				'size'   => size_format( filesize( $dest ) ),
			);
		}
	}

	if ( ! empty( $errors ) && empty( $results ) ) {
		wp_send_json_error( $errors );
	}

	wp_send_json_success(
		array(
			'downloaded' => $results,
			'errors'     => $errors,
		)
	);
}
add_action( 'wp_ajax_mvweb_pi_download_source', 'mvweb_pi_ajax_download_source' );

/**
 * AJAX handler: convert downloaded sources into unified format.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_convert_data() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$mapping = get_option( 'mvweb_pi_mapping', array() );

	// Check required fields are mapped.
	$required = array( 'sku', 'name', 'price', 'stock' );
	$missing  = array();
	foreach ( $required as $field ) {
		if ( empty( $mapping[ $field ] ) ) {
			$missing[] = $field;
		}
	}
	if ( ! empty( $missing ) ) {
		wp_send_json_error(
			/* translators: %s: comma-separated list of field names */
			sprintf(
				__( 'Required fields not mapped: %s. Configure mapping in the Mapping tab.', 'mvweb-price-importer' ),
				implode( ', ', $missing )
			)
		);
	}

	// Find downloaded source files.
	$upload_dir   = mvweb_pi_get_upload_dir();
	$source_files = glob( $upload_dir . 'source-*' );

	if ( empty( $source_files ) ) {
		wp_send_json_error( __( 'No downloaded source files found. Download sources first in the Output tab.', 'mvweb-price-importer' ) );
	}

	// Build warehouse_id => file_path map, restricted to warehouses that still
	// exist in the settings. A warehouse removed from the settings can leave its
	// source-{id}-{uuid} file behind; without this guard a manual Convert would
	// re-merge that "ghost" warehouse's stock into the total and the general feed
	// while no per-warehouse feed exists for it any more. The cron path already
	// rebuilds its sources from the settings, so it is unaffected.
	$expected = array_flip( mvweb_pi_expected_source_ids( get_option( 'mvweb_pi_settings', array() ) ) );
	$sources  = array();
	foreach ( $source_files as $file ) {
		$basename = basename( $file );
		// Extract warehouse ID from filename: source-{wh_id}-{uuid}.{ext}
		if ( preg_match( '/^source-(.+?)-[a-f0-9\-]{36}\.\w+$/', $basename, $matches )
			&& isset( $expected[ $matches[1] ] ) ) {
			$sources[ $matches[1] ] = $file;
		}
	}

	if ( empty( $sources ) ) {
		wp_send_json_error( __( 'Could not identify source files. Please re-download.', 'mvweb-price-importer' ) );
	}

	try {
		$converter  = new MVweb_PI_Converter();
		$is_multi   = count( $sources ) > 1;
		$settings   = get_option( 'mvweb_pi_settings', array() );
		$debug_mode = ! empty( $settings['debug_checkpoint'] );

		// Choose single-source or multi-warehouse pipeline.
		if ( $is_multi ) {
			$products = $converter->merge_warehouses( $sources, $mapping );
		} else {
			$products = $converter->convert( $sources, $mapping );
		}

		// In debug mode, write checkpoint file; otherwise, consume generator to count.
		$count = 0;
		if ( $debug_mode ) {
			$checkpoint = $converter->save_checkpoint( $products, $upload_dir );
			// Count lines in checkpoint (subtract header).
			$file_obj = new \SplFileObject( $checkpoint, 'r' );
			$file_obj->seek( PHP_INT_MAX );
			$count = max( 0, $file_obj->key() - 1 );
		} else {
			foreach ( $products as $product ) {
				++$count;
			}
		}

		$invalid_count = count( $converter->get_invalid_rows() );
		$dupes_count   = count( $converter->get_duplicate_skus() );

		// Save invalid rows if debug mode.
		$invalid_file = '';
		if ( $debug_mode && $invalid_count > 0 ) {
			$invalid_file = basename( $converter->save_invalid_rows( $upload_dir ) );
		}

		$response = array(
			'products'       => $count,
			'invalid'        => $invalid_count,
			'duplicates'     => $dupes_count,
			'debug_mode'     => $debug_mode,
			'checkpoint'     => $debug_mode && isset( $checkpoint ) ? basename( $checkpoint ) : '',
			'invalid_file'   => $invalid_file,
		);

		// Operator-grade summary — counterpart to the "Source file
		// downloaded" line so the log shows the full pipeline.
		mvweb_pi_log(
			sprintf(
				/* translators: 1: number of valid products, 2: invalid count, 3: duplicate count */
				__( 'Source converted: %1$d products parsed (%2$d invalid, %3$d duplicates).', 'mvweb-price-importer' ),
				$count,
				$invalid_count,
				$dupes_count
			),
			'info'
		);

		wp_send_json_success( $response );

	} catch ( \Exception $e ) {
		wp_send_json_error( $e->getMessage() );
	}
}
add_action( 'wp_ajax_mvweb_pi_convert_data', 'mvweb_pi_ajax_convert_data' );

/**
 * AJAX handler: fetch the category tree from the source feed without importing.
 *
 * Parses only the <categories> section of the downloaded source files and
 * stores it in mvweb_pi_category_meta so the Category Filter UI can render the
 * tree. No WooCommerce terms are created — the operator picks the branches to
 * import first, then runs the import. This is what lets a fresh site choose
 * categories before any product (or empty wrapper term) lands in the catalogue.
 *
 * @since 1.0.16
 * @return void
 */
function mvweb_pi_ajax_fetch_tree() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	// Find downloaded source files (same discovery as the Convert handler),
	// ignoring leftover files of warehouses no longer in the settings so their
	// categories don't resurface in the tree.
	$upload_dir   = mvweb_pi_get_upload_dir();
	$source_files = glob( $upload_dir . 'source-*' );
	$expected     = array_flip( mvweb_pi_expected_source_ids( get_option( 'mvweb_pi_settings', array() ) ) );
	$source_files = array_values(
		array_filter(
			(array) $source_files,
			static function ( $file ) use ( $expected ) {
				return preg_match( '/^source-(.+?)-[a-f0-9\-]{36}\.\w+$/', basename( $file ), $m )
					&& isset( $expected[ $m[1] ] );
			}
		)
	);

	if ( empty( $source_files ) ) {
		wp_send_json_error( __( 'No downloaded source files found. Click "Download" first, then fetch the category tree.', 'mvweb-price-importer' ) );
	}

	$mapping = get_option( 'mvweb_pi_mapping', array() );
	if ( ! is_array( $mapping ) ) {
		$mapping = array();
	}

	try {
		$converter  = new MVweb_PI_Converter();
		$categories = $converter->categories_only( $source_files, $mapping );

		if ( empty( $categories ) ) {
			wp_send_json_error( __( 'No categories found in the source feed.', 'mvweb-price-importer' ) );
		}

		// Persist the tree sidecar the Category Filter UI reads — id => [name,
		// parent_id]. Deliberately NOT creating terms here.
		$meta = array();
		foreach ( $categories as $cat ) {
			$id = isset( $cat['id'] ) ? (string) $cat['id'] : '';
			if ( '' === $id ) {
				continue;
			}
			$meta[ $id ] = array(
				'name'      => isset( $cat['name'] ) ? (string) $cat['name'] : $id,
				'parent_id' => isset( $cat['parent_id'] ) ? (string) $cat['parent_id'] : '',
			);
		}

		update_option( 'mvweb_pi_category_meta', $meta, false );

		mvweb_pi_log(
			sprintf(
				/* translators: %d: number of categories parsed from the feed */
				__( 'Category tree fetched: %d categories parsed from the feed (no terms created).', 'mvweb-price-importer' ),
				count( $meta )
			),
			'info'
		);

		wp_send_json_success( array( 'count' => count( $meta ) ) );

	} catch ( \Exception $e ) {
		wp_send_json_error( $e->getMessage() );
	}
}
add_action( 'wp_ajax_mvweb_pi_fetch_tree', 'mvweb_pi_ajax_fetch_tree' );

/**
 * AJAX handler: reset ETag/Last-Modified to force re-download.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_reset_etags() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$loader = new MVweb_PI_Loader();
	$loader->reset_etag( '' ); // Reset all warehouses.

	wp_send_json_success( __( 'ETag/hash reset. Files will be re-downloaded on next import.', 'mvweb-price-importer' ) );
}
add_action( 'wp_ajax_mvweb_pi_reset_etags', 'mvweb_pi_ajax_reset_etags' );

/**
 * AJAX handler: save mapping from auto-detect and persist headers.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_save_mapping() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$headers  = isset( $_POST['headers'] ) && is_array( $_POST['headers'] )
		? array_map( 'sanitize_text_field', wp_unslash( $_POST['headers'] ) )
		: array();

	$detected = isset( $_POST['detected'] ) && is_array( $_POST['detected'] )
		? array_map( 'sanitize_text_field', wp_unslash( $_POST['detected'] ) )
		: array();

	// Merge with existing mapping (keep manual overrides).
	$existing = get_option( 'mvweb_pi_mapping', array() );
	$mapping  = array_merge( $existing, $detected );

	// Store headers for dropdown repopulation.
	$mapping['_headers'] = $headers;

	update_option( 'mvweb_pi_mapping', $mapping );

	wp_send_json_success( __( 'Mapping saved.', 'mvweb-price-importer' ) );
}
add_action( 'wp_ajax_mvweb_pi_save_mapping', 'mvweb_pi_ajax_save_mapping' );

/**
 * AJAX handler: run full import cycle.
 *
 * Delegates to MVweb_PI_Cron::run() which handles the full import pipeline
 * including lock acquisition, download, conversion, and import.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_run_import() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$cron   = new MVweb_PI_Cron();
	$result = $cron->run();

	if ( in_array( $result['status'], array( 'completed', 'skipped' ), true ) ) {
		wp_send_json_success( $result );
	}

	wp_send_json_error( $result['message'] );
}
add_action( 'wp_ajax_mvweb_pi_run_import', 'mvweb_pi_ajax_run_import' );

/**
 * AJAX handler: get import progress for real-time polling.
 *
 * Returns current checkpoint data so the admin UI can display
 * a progress bar during long-running imports.
 *
 * @since 1.1.0
 * @return void
 */
function mvweb_pi_ajax_import_progress() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$progress = get_option( MVweb_PI_Importer::PROGRESS_OPTION, array() );
	wp_send_json_success( $progress );
}
add_action( 'wp_ajax_mvweb_pi_import_progress', 'mvweb_pi_ajax_import_progress' );

/**
 * AJAX handler: advance YML feed generation by one time slice.
 *
 * A full catalogue takes longer than a web request may last, so the browser
 * calls this repeatedly: each call works for a fixed budget, saves its
 * checkpoint and reports progress, until it answers `done`. The feed being
 * built is not published until its last offer is written.
 *
 * @since 1.0.0
 * @since 1.0.27 Works in slices; `restart` starts a run over from scratch.
 * @return void
 */
function mvweb_pi_ajax_generate_feeds() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	try {
		$feeds = new MVweb_PI_Feeds();

		// The first call of a fresh click drops whatever a previous, abandoned
		// run left behind — otherwise the operator would resume a checkpoint
		// they meant to replace.
		if ( ! empty( $_POST['restart'] ) ) {
			$feeds->reset_progress();
		} elseif ( ! $feeds->is_running() ) {
			// Mid-loop with no checkpoint left: another driver (the scheduled
			// continuation after an import) finished the run we were watching.
			// Report what is on disk instead of starting the whole thing over.
			$feeds_on_disk = array();
			foreach ( $feeds->get_feed_list() as $feed ) {
				$feeds_on_disk[] = array(
					'slug'     => $feed['slug'],
					'url'      => $feed['url'],
					'products' => $feed['products'],
					'size'     => $feed['size'],
				);
			}

			wp_send_json_success(
				array(
					'done'  => true,
					'feeds' => $feeds_on_disk,
					'total' => array_sum( wp_list_pluck( $feeds_on_disk, 'products' ) ),
					'count' => count( $feeds_on_disk ),
				)
			);
		}

		// Derive the budget from what this host actually allows rather than
		// guessing: a slice must end with room to spare for the chunk in
		// flight and the response, and hosts differ (30 s, 60 s, unlimited).
		$limit   = (int) ini_get( 'max_execution_time' );
		$default = $limit > 0 ? max( 5, min( 15, $limit - 5 ) ) : 15;

		/**
		 * Filters the wall-clock budget of one generation slice, in seconds.
		 *
		 * @since 1.0.27
		 * @param int $default Seconds a single AJAX slice may run.
		 * @param int $limit   The host's max_execution_time, 0 when unlimited.
		 */
		$budget = (int) apply_filters( 'mvweb_pi_feed_slice_budget', $default, $limit );
		$slice  = $feeds->step( time() + max( 1, $budget ) );

		$summary = array();
		$total   = 0;
		foreach ( $slice['results'] as $key => $result ) {
			$summary[] = array(
				'slug'     => $key,
				'url'      => $result['url'],
				'products' => $result['products'],
				// The table row rendered by JS shows the size column too, and
				// it only has what this payload carries.
				'size'     => file_exists( $result['file'] ) ? size_format( filesize( $result['file'] ) ) : '',
			);
			$total += $result['products'];
		}

		wp_send_json_success(
			array(
				'done'     => (bool) $slice['done'],
				'progress' => $slice['progress'],
				'feeds'    => $summary,
				'total'    => $total,
				'count'    => count( $summary ),
			)
		);
	} catch ( \Throwable $e ) {
		wp_send_json_error( $e->getMessage() );
	}
}
add_action( 'wp_ajax_mvweb_pi_generate_feeds', 'mvweb_pi_ajax_generate_feeds' );

/**
 * AJAX handler: delete a single generated feed file by slug.
 *
 * @since 1.0.3
 * @return void
 */
function mvweb_pi_ajax_delete_feed() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce verified above.
	$slug = isset( $_POST['slug'] ) ? sanitize_text_field( wp_unslash( $_POST['slug'] ) ) : '';
	if ( '' === $slug ) {
		wp_send_json_error( __( 'Feed slug is required.', 'mvweb-price-importer' ) );
	}

	$feeds   = new MVweb_PI_Feeds();
	$deleted = $feeds->delete( $slug );

	if ( ! $deleted ) {
		wp_send_json_error( __( 'Feed file not found or could not be deleted.', 'mvweb-price-importer' ) );
	}

	mvweb_pi_log(
		sprintf(
			/* translators: %s: feed slug */
			__( 'Feed file deleted: %s.', 'mvweb-price-importer' ),
			$slug
		),
		'info'
	);

	wp_send_json_success(
		array(
			'slug'    => $slug,
			'message' => __( 'Feed deleted.', 'mvweb-price-importer' ),
		)
	);
}
add_action( 'wp_ajax_mvweb_pi_delete_feed', 'mvweb_pi_ajax_delete_feed' );

/**
 * AJAX handler: get log entries with pagination and filtering.
 *
 * Delegates to MVweb_PI_Logger::get_page() for JSONL reading (TZ 10.2).
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_get_log() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$page  = isset( $_POST['page'] ) ? max( 1, absint( $_POST['page'] ) ) : 1;
	$level = isset( $_POST['level'] ) ? sanitize_key( $_POST['level'] ) : '';

	$logger = MVweb_PI_Logger::get_instance();
	$result = $logger->get_page( $page, MVweb_PI_Logger::PER_PAGE, $level );

	wp_send_json_success( $result );
}
add_action( 'wp_ajax_mvweb_pi_get_log', 'mvweb_pi_ajax_get_log' );

/**
 * AJAX handler: clear the log file.
 *
 * Delegates to MVweb_PI_Logger::clear() for safe cleanup.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pi_ajax_clear_log() {
	check_ajax_referer( 'mvweb_pi_ajax', 'nonce' );

	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( __( 'Insufficient permissions.', 'mvweb-price-importer' ) );
	}

	$logger = MVweb_PI_Logger::get_instance();
	$logger->clear();

	wp_send_json_success( __( 'Log cleared.', 'mvweb-price-importer' ) );
}
add_action( 'wp_ajax_mvweb_pi_clear_log', 'mvweb_pi_ajax_clear_log' );
