<?php
/**
 * REST class — REST API endpoints.
 *
 * Registers POST /wp-json/mvweb-pi/v1/run-import endpoint
 * for triggering imports via external cron or webhooks.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_REST
 *
 * Provides REST API endpoint for triggering price import.
 * Uses the same lock mechanism as AJAX and wp-cron to prevent parallel imports.
 *
 * @since 1.0.0
 */
class MVweb_PI_REST {

	/**
	 * REST API namespace.
	 *
	 * @var string
	 */
	const NAMESPACE = 'mvweb-pi/v1';

	/**
	 * Register REST API routes.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register_routes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/run-import',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'run_import' ),
				'permission_callback' => array( $this, 'check_permission' ),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_status' ),
				'permission_callback' => array( $this, 'check_permission' ),
			)
		);
	}

	/**
	 * Permission callback for REST endpoints.
	 *
	 * Base check: manage_options is always required (non-filterable).
	 * Filter 'mvweb_pi_rest_permission' can ADD extra restrictions but cannot
	 * bypass the base capability check (TZ 17.2).
	 *
	 * @since 1.0.0
	 * @param \WP_REST_Request $request Current request.
	 * @return bool True if permitted.
	 */
	public function check_permission( \WP_REST_Request $request ): bool {
		// Base capability check — always required, not filterable.
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		// Additional filter for extending (not weakening) permissions.
		return (bool) apply_filters( 'mvweb_pi_rest_permission', true, $request );
	}

	/**
	 * Run import via REST API.
	 *
	 * Uses MVweb_PI_Cron::run() which contains the lock mechanism.
	 * Safe to call concurrently — duplicate requests will be rejected by the lock.
	 *
	 * @since 1.0.0
	 * @param \WP_REST_Request $request Current request.
	 * @return \WP_REST_Response
	 */
	public function run_import( \WP_REST_Request $request ): \WP_REST_Response {
		$cron   = new MVweb_PI_Cron();
		$result = $cron->run();

		$status_code = 'error' === $result['status'] ? 500 : 200;
		if ( 'locked' === $result['status'] ) {
			$status_code = 409; // Conflict.
		}

		return new \WP_REST_Response(
			array(
				'success' => in_array( $result['status'], array( 'completed', 'skipped' ), true ),
				'status'  => $result['status'],
				'message' => $result['message'],
				'stats'   => $result['stats'] ?? null,
			),
			$status_code
		);
	}

	/**
	 * Get import status via REST API.
	 *
	 * Returns last import stats, lock state, and schedule info.
	 *
	 * @since 1.0.0
	 * @param \WP_REST_Request $request Current request.
	 * @return \WP_REST_Response
	 */
	public function get_status( \WP_REST_Request $request ): \WP_REST_Response {
		$stats    = get_option( 'mvweb_pi_import_stats', array() );
		$next_run = MVweb_PI_Cron::get_next_run();
		$schedule = MVweb_PI_Cron::get_schedule();

		return new \WP_REST_Response(
			array(
				'last_import' => $stats,
				'is_locked'   => MVweb_PI_Cron::is_locked(),
				'schedule'    => $schedule ?: 'disabled',
				'next_run'    => $next_run ? gmdate( 'Y-m-d H:i:s', $next_run ) : null,
			),
			200
		);
	}
}
