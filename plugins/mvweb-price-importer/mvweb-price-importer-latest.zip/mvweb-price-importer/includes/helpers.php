<?php
/**
 * Helper functions for MVweb Price Importer
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get plugin option with default value.
 *
 * @since 1.0.0
 * @param string $key     Option key (without mvweb_pi_ prefix).
 * @param mixed  $default Default value.
 * @return mixed Option value.
 */
function mvweb_pi_get_option( string $key, $default = '' ) {
	return get_option( 'mvweb_pi_' . $key, $default );
}

/**
 * Update plugin option.
 *
 * @since 1.0.0
 * @param string $key   Option key (without mvweb_pi_ prefix).
 * @param mixed  $value Option value.
 * @return bool True if updated, false otherwise.
 */
function mvweb_pi_update_option( string $key, $value ): bool {
	return update_option( 'mvweb_pi_' . $key, $value );
}

/**
 * Delete plugin option.
 *
 * @since 1.0.0
 * @param string $key Option key (without mvweb_pi_ prefix).
 * @return bool True if deleted, false otherwise.
 */
function mvweb_pi_delete_option( string $key ): bool {
	return delete_option( 'mvweb_pi_' . $key );
}

/**
 * Get the pricelists upload directory path.
 *
 * @since 1.0.0
 * @return string Absolute path to pricelists directory.
 */
function mvweb_pi_get_upload_dir(): string {
	$upload_dir = wp_upload_dir();
	return $upload_dir['basedir'] . '/pricelists/';
}

/**
 * Get the feeds directory path.
 *
 * @since 1.0.0
 * @return string Absolute path to feeds directory.
 */
function mvweb_pi_get_feeds_dir(): string {
	return mvweb_pi_get_upload_dir() . 'feeds/';
}

/**
 * Get the feeds directory URL.
 *
 * @since 1.0.0
 * @return string URL to feeds directory.
 */
function mvweb_pi_get_feeds_url(): string {
	$upload_dir = wp_upload_dir();
	return $upload_dir['baseurl'] . '/pricelists/feeds/';
}

/**
 * Strip Basic Auth credentials from any URL appearing inside a string.
 *
 * `https://user:secret@host/path` → `https://***:***@host/path`. Used to
 * sanitize log messages and email bodies so supplier credentials embedded
 * in source URLs don't leak into shared log files (which can be world-
 * readable on Nginx where the bundled .htaccess does nothing).
 *
 * @since 1.0.0
 * @param string $value Arbitrary string that may contain URLs.
 * @return string Sanitized string.
 */
function mvweb_pi_mask_credentials( string $value ): string {
	if ( '' === $value ) {
		return $value;
	}
	return preg_replace(
		'#(https?://)([^:/@\s]+):([^@/\s]+)@#i',
		'$1***:***@',
		$value
	);
}

/**
 * Log message to JSONL file via MVweb_PI_Logger.
 *
 * Always writes to the JSONL log file (wp-content/uploads/pricelists/mvweb_pi.log).
 * Additionally writes to PHP error_log when WP_DEBUG is enabled.
 *
 * @since 1.0.0
 * @param mixed  $message Message to log.
 * @param string $level   Log level (info, warning, error).
 * @param array  $context Optional context data.
 * @return void
 */
function mvweb_pi_log( $message, $level = 'info', $context = array() ) {
	if ( is_array( $message ) || is_object( $message ) ) {
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_print_r
		$message = print_r( $message, true );
	}

	$message = mvweb_pi_mask_credentials( (string) $message );

	// Mask credentials inside context values too, in case a URL string slips in.
	if ( ! empty( $context ) ) {
		array_walk_recursive(
			$context,
			static function ( &$item ) {
				if ( is_string( $item ) ) {
					$item = mvweb_pi_mask_credentials( $item );
				}
			}
		);
	}

	// Write to JSONL log file.
	if ( class_exists( 'MVweb_PI_Logger' ) ) {
		$logger = MVweb_PI_Logger::get_instance();
		$logger->log( $level, $message, $context );
	}

	// Also write to PHP error_log when debugging.
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		$log_message = sprintf(
			'[MVweb Price Importer] [%s] %s',
			strtoupper( $level ),
			$message
		);
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( $log_message );
	}
}
