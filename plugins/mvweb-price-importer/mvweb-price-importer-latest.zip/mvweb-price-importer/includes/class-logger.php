<?php
/**
 * Logger class — JSONL file logging.
 *
 * Writes import logs to JSONL file with rotation by size (10 MB)
 * and age (30 days). Supports paginated reading via SplFileObject.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PI_Logger
 *
 * JSONL logger with rotation and paginated reading (TZ 10.1–10.3).
 *
 * @since 1.0.0
 */
class MVweb_PI_Logger {

	/**
	 * Maximum log file size in bytes (10 MB).
	 *
	 * @var int
	 */
	const MAX_SIZE_BYTES = 10 * 1024 * 1024;

	/**
	 * Maximum log age in days before rotation.
	 *
	 * @var int
	 */
	const MAX_AGE_DAYS = 30;

	/**
	 * Number of items per page for paginated reading.
	 *
	 * @var int
	 */
	const PER_PAGE = 50;

	/**
	 * Absolute path to the JSONL log file.
	 *
	 * @var string
	 */
	private string $log_file;

	/**
	 * Singleton instance.
	 *
	 * @var self|null
	 */
	private static ?self $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @since 1.0.0
	 * @return self
	 */
	public static function get_instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * Private — use {@see get_instance()} to obtain the singleton.
	 *
	 * @since 1.0.0
	 * @since 1.0.0 Made private to enforce singleton invariant.
	 */
	private function __construct() {
		$upload_dir     = wp_upload_dir();
		$this->log_file = $upload_dir['basedir'] . '/pricelists/mvweb_pi.log';
	}

	/**
	 * Get absolute path to the log file.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public function get_log_file(): string {
		return $this->log_file;
	}

	/**
	 * Write a log entry to the JSONL file.
	 *
	 * @since 1.0.0
	 * @param string $level   Log level: 'debug', 'info', 'warning', 'error'.
	 * @param string $message Human-readable message.
	 * @param array  $context Optional associative array of context data.
	 * @return void
	 */
	public function log( string $level, string $message, array $context = array() ): void {
		// Debug entries are dropped unless the operator explicitly opted in.
		// We still allow info/warning/error through unconditionally because
		// those are the events a non-developer actually needs to see.
		if ( 'debug' === $level ) {
			$settings = get_option( 'mvweb_pi_settings', array() );
			if ( empty( $settings['debug_logging'] ) ) {
				return;
			}
		}

		// Ensure the directory exists.
		$dir = dirname( $this->log_file );
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		// Rotate if needed before writing.
		$this->maybe_rotate();

		$entry = wp_json_encode(
			array(
				'ts'      => time(),
				'date'    => gmdate( 'Y-m-d H:i:s' ),
				'level'   => $level,
				'message' => $message,
				'context' => $context,
			)
		);

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		file_put_contents( $this->log_file, $entry . "\n", FILE_APPEND | LOCK_EX );
	}

	/**
	 * Convenience: log info level.
	 *
	 * @since 1.0.0
	 * @param string $message Message.
	 * @param array  $context Context.
	 * @return void
	 */
	public function info( string $message, array $context = array() ): void {
		$this->log( 'info', $message, $context );
	}

	/**
	 * Convenience: log warning level.
	 *
	 * @since 1.0.0
	 * @param string $message Message.
	 * @param array  $context Context.
	 * @return void
	 */
	public function warning( string $message, array $context = array() ): void {
		$this->log( 'warning', $message, $context );
	}

	/**
	 * Convenience: log error level.
	 *
	 * @since 1.0.0
	 * @param string $message Message.
	 * @param array  $context Context.
	 * @return void
	 */
	public function error( string $message, array $context = array() ): void {
		$this->log( 'error', $message, $context );
	}

	/**
	 * Convenience: log debug level.
	 *
	 * Debug entries are silently dropped unless the user has enabled the
	 * verbose-logging setting — they exist for developers and on-call
	 * troubleshooting, not for everyday operators.
	 *
	 * @since 1.0.0
	 * @param string $message Message.
	 * @param array  $context Context.
	 * @return void
	 */
	public function debug( string $message, array $context = array() ): void {
		$this->log( 'debug', $message, $context );
	}

	/**
	 * Get paginated log entries with optional level filter.
	 *
	 * Reads the JSONL file via SplFileObject for memory efficiency (TZ 10.2).
	 * Returns entries in reverse chronological order (newest first).
	 *
	 * @since 1.0.0
	 * @param int    $page         Page number (1-based).
	 * @param int    $per_page     Items per page.
	 * @param string $level_filter Optional level filter ('info', 'warning', 'error', or '' for all).
	 * @return array{items: array, total: int, total_pages: int, page: int}
	 */
	public function get_page( int $page = 1, int $per_page = 0, string $level_filter = '' ): array {
		if ( 0 === $per_page ) {
			$per_page = self::PER_PAGE;
		}

		$empty = array(
			'items'       => array(),
			'total'       => 0,
			'total_pages' => 0,
			'page'        => $page,
		);

		if ( ! file_exists( $this->log_file ) ) {
			return $empty;
		}

		$file = new \SplFileObject( $this->log_file, 'r' );
		$file->setFlags( \SplFileObject::DROP_NEW_LINE | \SplFileObject::SKIP_EMPTY );

		// Pass 1: count matching lines (stream without accumulating).
		$total = 0;
		foreach ( $file as $line ) {
			if ( '' === trim( $line ) ) {
				continue;
			}
			if ( '' !== $level_filter ) {
				$decoded = json_decode( $line, true );
				if ( ! is_array( $decoded ) || ( $decoded['level'] ?? '' ) !== $level_filter ) {
					continue;
				}
			}
			++$total;
		}

		if ( 0 === $total ) {
			return $empty;
		}

		$total_pages = max( 1, (int) ceil( $total / $per_page ) );
		$offset      = ( $page - 1 ) * $per_page;

		// Reverse order offset: newest first = read from end.
		$reverse_offset = $total - $offset - $per_page;
		$take_count     = $per_page;
		if ( $reverse_offset < 0 ) {
			$take_count    += $reverse_offset;
			$reverse_offset = 0;
		}

		// Pass 2: collect only the required slice.
		$file->rewind();
		$match_index = 0;
		$items       = array();
		foreach ( $file as $line ) {
			if ( '' === trim( $line ) ) {
				continue;
			}
			$decoded = json_decode( $line, true );
			if ( ! is_array( $decoded ) ) {
				continue;
			}
			if ( '' !== $level_filter && ( $decoded['level'] ?? '' ) !== $level_filter ) {
				continue;
			}

			if ( $match_index >= $reverse_offset && $match_index < $reverse_offset + $take_count ) {
				$items[] = $decoded;
			}
			++$match_index;

			if ( $match_index >= $reverse_offset + $take_count ) {
				break;
			}
		}

		// Reverse for newest-first within the page.
		$items = array_reverse( $items );

		return array(
			'items'       => $items,
			'total'       => $total,
			'total_pages' => $total_pages,
			'page'        => $page,
		);
	}

	/**
	 * Delete the log file.
	 *
	 * @since 1.0.0
	 * @return bool True if deleted or didn't exist.
	 */
	public function clear(): bool {
		if ( file_exists( $this->log_file ) ) {
			wp_delete_file( $this->log_file );
		}

		// Also clean up any archived log files.
		$this->cleanup_old_archives();

		return true;
	}

	/**
	 * Rotate the log file if it exceeds size or age limits.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function maybe_rotate(): void {
		if ( ! file_exists( $this->log_file ) ) {
			return;
		}

		$size = filesize( $this->log_file );
		$age  = time() - filemtime( $this->log_file );

		if ( $size > self::MAX_SIZE_BYTES || $age > ( self::MAX_AGE_DAYS * DAY_IN_SECONDS ) ) {
			// Rename current log to dated archive.
			$archive = $this->log_file . '.' . gmdate( 'Ymd-His' ) . '.bak';
			// phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
			rename( $this->log_file, $archive );

			// Clean up old archives.
			$this->cleanup_old_archives();
		}
	}

	/**
	 * Remove archived log files older than MAX_AGE_DAYS.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function cleanup_old_archives(): void {
		$dir = dirname( $this->log_file );
		if ( ! is_dir( $dir ) ) {
			return;
		}

		$archives = glob( $this->log_file . '.*.bak' );
		if ( empty( $archives ) ) {
			return;
		}

		$max_age = self::MAX_AGE_DAYS * DAY_IN_SECONDS;

		foreach ( $archives as $archive ) {
			if ( ( time() - filemtime( $archive ) ) > $max_age ) {
				wp_delete_file( $archive );
			}
		}
	}
}
