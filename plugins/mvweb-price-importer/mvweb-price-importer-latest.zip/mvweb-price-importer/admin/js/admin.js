/**
 * Admin JavaScript for MVweb Price Importer
 *
 * Tab navigation, AJAX handlers for download/convert/detect/reset actions.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

(function($) {
	'use strict';

	/**
	 * Tab navigation without page reload.
	 */
	function initTabs() {
		var $tabs = $('.mvweb-tabs .nav-tab');
		var $contents = $('.mvweb-tab-content');

		$tabs.on('click', function(e) {
			e.preventDefault();

			var $this = $(this);
			var tabId = $this.data('tab');

			// Update active tab.
			$tabs.removeClass('nav-tab-active');
			$this.addClass('nav-tab-active');

			// Show corresponding content.
			$contents.removeClass('active');
			$('#' + tabId).addClass('active');

			// Update URL hash without scrolling.
			if (history.pushState) {
				history.pushState(null, null, '#' + tabId);
			}
		});

		// Activate tab from URL hash.
		var hash = window.location.hash.substring(1);
		if (hash && $('#' + hash).length) {
			$tabs.filter('[data-tab="' + hash + '"]').trigger('click');
		}
	}

	/**
	 * Show status message in a result container.
	 *
	 * @param {jQuery}  $container Result container element.
	 * @param {string}  message    Message text.
	 * @param {string}  type       Message type: 'success', 'error', 'warning'.
	 */
	function showResult($container, message, type) {
		var cssClass = 'mvweb-notice';
		if ('success' === type) {
			cssClass += ' mvweb-notice--success';
		} else if ('error' === type) {
			cssClass += ' mvweb-notice--error';
		} else if ('warning' === type) {
			cssClass += ' mvweb-notice--warning';
		}
		$container.html('<div class="' + cssClass + '">' + message + '</div>');
	}

	/**
	 * Resolve the result container for a Main-tab action button.
	 *
	 * Buttons live in a horizontal action row outside any card, so we
	 * look up their result panel by the `data-result` attribute they
	 * carry (each panel has a matching id below the row).
	 *
	 * @param {jQuery} $button Action button.
	 * @return {jQuery} Result container.
	 */
	function resolveResultContainer($button) {
		var resultId = $button.data('result');
		if (resultId) {
			return $('#' + resultId);
		}
		// Fallback for any legacy card-shaped block.
		return $button.closest('.mvweb-card').find('.mvweb-pi-action-result');
	}

	/**
	 * Initialize Main-tab action buttons (download / convert / reset).
	 */
	function initOutputActions() {
		$('.mvweb-pi-action-btn').on('click', function(e) {
			e.preventDefault();

			var $button = $(this);
			var action = $button.data('action');
			var $spinner = $button.find('.mvweb-spinner');
			var $result = resolveResultContainer($button);

			$button.prop('disabled', true);
			$spinner.addClass('is-active');
			$result.empty();

			$.post(mvweb_pi_ajax.ajax_url, {
				action: action,
				nonce: mvweb_pi_ajax.nonce
			}, function(response) {
				if (response.success) {
					handleActionSuccess(action, response.data, $result);
				} else {
					var errorMsg = typeof response.data === 'string'
						? response.data
						: (response.data && response.data.message ? response.data.message : 'Unknown error.');
					showResult($result, errorMsg, 'error');
				}
			}).fail(function() {
				showResult($result, 'Request failed. Please try again.', 'error');
			}).always(function() {
				$button.prop('disabled', false);
				$spinner.removeClass('is-active');
			});
		});
	}

	/**
	 * Handle successful action response based on action type.
	 *
	 * @param {string} action   AJAX action name.
	 * @param {Object} data     Response data.
	 * @param {jQuery} $result  Result container.
	 */
	function handleActionSuccess(action, data, $result) {
		switch (action) {
			case 'mvweb_pi_download_source':
				handleDownloadResult(data, $result);
				break;

			case 'mvweb_pi_convert_data':
				handleConvertResult(data, $result);
				break;

			case 'mvweb_pi_reset_etags':
				showResult($result, data, 'success');
				break;

			case 'mvweb_pi_run_import':
				handleImportResult(data, $result);
				break;

			default:
				showResult($result, 'Action completed.', 'success');
		}
	}

	/**
	 * Display download results.
	 *
	 * @param {Object} data    Response data with downloaded/errors arrays.
	 * @param {jQuery} $result Result container.
	 */
	function handleDownloadResult(data, $result) {
		var html = '';

		if (data.downloaded && data.downloaded.length) {
			html += '<div class="mvweb-notice mvweb-notice--success">';
			data.downloaded.forEach(function(item) {
				if ('unchanged' === item.status) {
					html += '<div>' + item.id + ': ' + item.message + '</div>';
				} else {
					html += '<div>' + item.id + ': ' + item.format.toUpperCase() + ' (' + item.size + ')</div>';
				}
			});
			html += '</div>';
		}

		if (data.errors && data.errors.length) {
			html += '<div class="mvweb-notice mvweb-notice--error">';
			data.errors.forEach(function(err) {
				html += '<div>' + err.id + ': ' + err.message + '</div>';
			});
			html += '</div>';
		}

		$result.html(html);
	}

	/**
	 * Display convert results.
	 *
	 * @param {Object} data    Response data with product/invalid/duplicate counts.
	 * @param {jQuery} $result Result container.
	 */
	function handleConvertResult(data, $result) {
		var html = '<div class="mvweb-notice mvweb-notice--success">';
		html += '<strong>' + data.products + '</strong> products converted.';

		if (data.invalid > 0) {
			html += ' <span class="mvweb-badge mvweb-badge--warning">' + data.invalid + ' invalid</span>';
		}
		if (data.duplicates > 0) {
			html += ' <span class="mvweb-badge mvweb-badge--outline">' + data.duplicates + ' duplicates</span>';
		}

		if (data.debug_mode && data.checkpoint) {
			html += '<div class="mvweb-help-text">Checkpoint: ' + data.checkpoint + '</div>';
		}
		if (data.invalid_file) {
			html += '<div class="mvweb-help-text">Invalid rows: ' + data.invalid_file + '</div>';
		}

		html += '</div>';
		$result.html(html);
	}

	/**
	 * Display import results.
	 *
	 * @param {Object} data    Response data with stats or skip message.
	 * @param {jQuery} $result Result container.
	 */
	function handleImportResult(data, $result) {
		if ('skipped' === data.status) {
			showResult($result, data.message, 'warning');
			return;
		}

		var stats = data.stats || {};
		var html = '<div class="mvweb-notice mvweb-notice--success">';
		html += '<strong>' + escapeHtml(data.message) + '</strong>';
		html += '<div style="margin-top: 8px;">';
		html += '<span class="mvweb-badge mvweb-badge--success">' + (stats.created || 0) + ' created</span> ';
		html += '<span class="mvweb-badge mvweb-badge--outline">' + (stats.updated || 0) + ' updated</span> ';

		if (stats.skipped > 0) {
			html += '<span class="mvweb-badge">' + stats.skipped + ' skipped</span> ';
		}
		if (stats.errors > 0) {
			html += '<span class="mvweb-badge mvweb-badge--error">' + stats.errors + ' errors</span>';
		}

		html += '</div></div>';
		$result.html(html);

		// Update statistics dashboard if present on the page.
		updateStatsDashboard(stats, data);
	}

	/**
	 * Update the .mvweb-metric cards after an AJAX import.
	 *
	 * We can't reuse the PHP-rendered dashboard because the request that
	 * brought us this stats payload didn't reload the page. So we update
	 * the four metric values in-place — labels stay as the server already
	 * rendered them (already localised), which avoids the previous bug
	 * where the JS injected hard-coded English headers.
	 *
	 * If no dashboard is present yet (first ever import on a fresh page),
	 * fall through to a full reload — PHP will then render the correct
	 * `.mvweb-metrics` grid for us with localised labels.
	 *
	 * @param {Object} stats Import statistics.
	 */
	function updateStatsDashboard(stats) {
		var $dashboard = $('.mvweb-pi-stats-dashboard');
		if (!$dashboard.length) {
			// No metric grid rendered yet — reload so PHP can build it.
			location.reload();
			return;
		}
		$dashboard.find('.mvweb-metric').each(function() {
			var $card  = $(this);
			var label  = $card.find('.mvweb-metric__label').text().toLowerCase();
			var $value = $card.find('.mvweb-metric__value');
			// Match by stable english stat keys, not the localised label —
			// instead compare against the four well-known buckets by index.
			// Cards render in fixed order: created / updated / skipped / errors.
			var idx = $card.index();
			var value;
			if      (idx === 0) value = stats.created || 0;
			else if (idx === 1) value = stats.updated || 0;
			else if (idx === 2) value = stats.skipped || 0;
			else if (idx === 3) value = stats.errors  || 0;
			else                value = null;
			if (value !== null) {
				$value.text(value);
			}
			// Promote errors card to danger styling if non-zero.
			if (idx === 3) {
				$card.toggleClass('mvweb-metric--danger', (stats.errors || 0) > 0);
			}
		});
	}

	/**
	 * Initialize Import tab button.
	 */
	function initImportAction() {
		$('#mvweb-pi-run-import-btn').on('click', function(e) {
			e.preventDefault();

			var $button = $(this);
			var $spinner = $button.find('.mvweb-spinner');
			var $result = $('#mvweb-pi-import-result');
			// Minimum 400ms of visible spinner so a sub-second AJAX response
			// (e.g. ETag-unchanged early exit) does not look like a button
			// click that did nothing.
			var startedAt = Date.now();
			var minVisibleMs = 400;

			$button.prop('disabled', true);
			$spinner.addClass('is-active');
			$result.empty();

			$.post(mvweb_pi_ajax.ajax_url, {
				action: 'mvweb_pi_run_import',
				nonce: mvweb_pi_ajax.nonce
			}, function(response) {
				if (response.success) {
					handleImportResult(response.data, $result);
				} else {
					var errorMsg = typeof response.data === 'string'
						? response.data
						: (response.data && response.data.message ? response.data.message : 'Unknown error.');
					showResult($result, errorMsg, 'error');
				}
			}).fail(function() {
				showResult($result, 'Request failed. Please try again.', 'error');
			}).always(function() {
				var elapsed = Date.now() - startedAt;
				var wait = Math.max(0, minVisibleMs - elapsed);
				setTimeout(function() {
					$button.prop('disabled', false);
					$spinner.removeClass('is-active');
				}, wait);
			});
		});
	}

	/**
	 * Initialize auto-detect columns button on Mapping tab.
	 */
	function initDetectColumns() {
		$('#mvweb-pi-detect-columns').on('click', function(e) {
			e.preventDefault();

			var $button = $(this);
			var $spinner = $('#mvweb-pi-detect-spinner');
			var $status = $('#mvweb-pi-detect-status');

			$button.prop('disabled', true);
			$spinner.addClass('is-active');
			$status.text('');

			$.post(mvweb_pi_ajax.ajax_url, {
				action: 'mvweb_pi_detect_columns',
				nonce: mvweb_pi_ajax.nonce
			}, function(response) {
				if (response.success) {
					updateMappingDropdowns(response.data);
					// Save headers + detected mapping to server.
					saveMappingToServer(response.data);
					$status.html('<span class="mvweb-badge mvweb-badge--success">' +
						response.data.headers.length + ' columns detected</span>');
				} else {
					$status.html('<span class="mvweb-badge mvweb-badge--error">' +
						(typeof response.data === 'string' ? response.data : 'Detection failed.') +
						'</span>');
				}
			}).fail(function() {
				$status.html('<span class="mvweb-badge mvweb-badge--error">Request failed.</span>');
			}).always(function() {
				$button.prop('disabled', false);
				$spinner.removeClass('is-active');
			});
		});
	}

	/**
	 * Update mapping dropdown options with detected headers.
	 *
	 * @param {Object} data Detection result with headers and detected mapping.
	 */
	function updateMappingDropdowns(data) {
		var headers = data.headers || [];
		var detected = data.detected || {};

		$('.mvweb-pi-mapping-select').each(function() {
			var $select = $(this);
			var field = $select.data('field');
			var currentVal = $select.val();

			// Rebuild options.
			var options = '<option value="">' + $select.find('option:first').text() + '</option>';
			headers.forEach(function(header) {
				var selected = '';
				// Auto-select: use detected value if no manual selection exists.
				if (!currentVal && detected[field] === header) {
					selected = ' selected';
				} else if (currentVal === header) {
					selected = ' selected';
				}
				options += '<option value="' + escapeAttr(header) + '"' + selected + '>' +
					escapeHtml(header) + '</option>';
			});

			$select.html(options);
		});
	}

	/**
	 * Save detected mapping and headers to server via AJAX.
	 *
	 * @param {Object} data Detection result.
	 */
	function saveMappingToServer(data) {
		$.post(mvweb_pi_ajax.ajax_url, {
			action: 'mvweb_pi_save_mapping',
			nonce: mvweb_pi_ajax.nonce,
			headers: data.headers,
			detected: data.detected
		});
	}

	/**
	 * Escape HTML entities.
	 *
	 * @param {string} str Input string.
	 * @return {string} Escaped string.
	 */
	function escapeHtml(str) {
		var div = document.createElement('div');
		div.appendChild(document.createTextNode(str));
		return div.innerHTML;
	}

	/**
	 * Escape attribute value.
	 *
	 * @param {string} str Input string.
	 * @return {string} Escaped string.
	 */
	function escapeAttr(str) {
		return String(str)
			.replace(/&/g, '&amp;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#39;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;');
	}

	/**
	 * Initialize Feeds tab generate button.
	 */
	function initFeedsAction() {
		$('#mvweb-pi-generate-feeds-btn').on('click', function(e) {
			e.preventDefault();

			var $button = $(this);
			var $spinner = $button.find('.mvweb-spinner');
			var $result = $('#mvweb-pi-feeds-result');

			$button.prop('disabled', true);
			$spinner.addClass('is-active');
			$result.empty();

			$.post(mvweb_pi_ajax.ajax_url, {
				action: 'mvweb_pi_generate_feeds',
				nonce: mvweb_pi_ajax.nonce
			}, function(response) {
				if (response.success) {
					handleFeedsResult(response.data, $result);
				} else {
					var errorMsg = typeof response.data === 'string'
						? response.data
						: (response.data && response.data.message ? response.data.message : 'Unknown error.');
					showResult($result, errorMsg, 'error');
				}
			}).fail(function() {
				showResult($result, 'Request failed. Please try again.', 'error');
			}).always(function() {
				$button.prop('disabled', false);
				$spinner.removeClass('is-active');
			});
		});
	}

	/**
	 * Display feed generation results.
	 *
	 * @param {Object} data    Response data with feeds array and totals.
	 * @param {jQuery} $result Result container.
	 */
	function handleFeedsResult(data, $result) {
		var html = '<div class="mvweb-notice mvweb-notice--success">';
		html += '<strong>' + data.count + ' feed(s) generated</strong>';
		html += '<div style="margin-top: 8px;">';

		if (data.feeds && data.feeds.length) {
			data.feeds.forEach(function(feed) {
				html += '<div class="mvweb-pi-feed-result-item">';
				html += '<span class="mvweb-badge">' + escapeHtml(feed.slug) + '</span> ';
				html += '<span class="mvweb-badge mvweb-badge--outline">' + feed.products + ' products</span> ';
				html += '<a href="' + escapeAttr(feed.url) + '" target="_blank" rel="noopener noreferrer">' +
					escapeHtml(feed.url) + '</a>';
				html += '</div>';
			});
		}

		html += '</div></div>';
		$result.html(html);

		// Update feeds table with fresh data.
		updateFeedsTable(data.feeds);
	}

	/**
	 * Update the feeds table after generation.
	 *
	 * @param {Array} feeds Array of feed objects.
	 */
	function updateFeedsTable(feeds) {
		var $table = $('#mvweb-pi-feeds-table');
		var $tbody;

		if (!$table.length) {
			// Create table if it doesn't exist (replace the "no feeds" message).
			var $noFeeds = $('.mvweb-pi-tab-feeds > p.description:last');
			if (!$noFeeds.length) {
				return;
			}
			var tableHtml = '<div class="mvweb-table-wrap">' +
				'<table class="mvweb-table mvweb-table--striped" id="mvweb-pi-feeds-table">' +
				'<thead><tr>' +
				'<th>Feed</th><th>URL</th><th>Last Generated</th><th>Products</th>' +
				'</tr></thead>' +
				'<tbody></tbody></table></div>';
			$noFeeds.replaceWith(tableHtml);
			$table = $('#mvweb-pi-feeds-table');
		}

		$tbody = $table.find('tbody');
		$tbody.empty();

		if (!feeds || !feeds.length) {
			return;
		}

		feeds.forEach(function(feed) {
			var row = '<tr>';
			row += '<td><strong>' + escapeHtml(feed.slug) + '</strong></td>';
			row += '<td><a href="' + escapeAttr(feed.url) + '" target="_blank" rel="noopener noreferrer" class="mvweb-pi-feed-url">' +
				escapeHtml(feed.url) + '</a></td>';
			row += '<td>' + new Date().toLocaleString() + '</td>';
			row += '<td><span class="mvweb-badge">' + feed.products + '</span></td>';
			row += '</tr>';
			$tbody.append(row);
		});
	}

	/**
	 * Initialize Settings tab — warehouse CRUD.
	 */
	function initWarehouses() {
		var $body = $('#mvweb-pi-warehouses-body');
		var $addBtn = $('#mvweb-pi-add-warehouse');

		if (!$addBtn.length) {
			return;
		}

		// Add warehouse row.
		$addBtn.on('click', function(e) {
			e.preventDefault();

			var index = $body.find('.mvweb-pi-warehouse-row').length;
			var row = buildWarehouseRow(index, {id: '', name: '', url: '', visible: '1', feed_name: ''});
			$body.append(row);
		});

		// Remove warehouse row (delegated).
		$body.on('click', '.mvweb-pi-remove-warehouse', function(e) {
			e.preventDefault();
			$(this).closest('.mvweb-pi-warehouse-row').remove();
			reindexWarehouseRows();
		});
	}

	/**
	 * Build a warehouse table row.
	 *
	 * @param {number} index Row index.
	 * @param {Object} data  Warehouse data.
	 * @return {string} HTML row.
	 */
	function buildWarehouseRow(index, data) {
		var prefix = 'mvweb_pi_settings[warehouses][' + index + ']';
		var checked = (data.visible === '1' || data.visible === true) ? ' checked' : '';

		var row = '<tr class="mvweb-pi-warehouse-row" data-index="' + index + '">';
		row += '<td><input type="text" name="' + prefix + '[id]" class="mvweb-input mvweb-pi-wh-id" value="' + escapeAttr(data.id) + '" placeholder="moscow" required></td>';
		row += '<td><input type="text" name="' + prefix + '[name]" class="mvweb-input mvweb-pi-wh-name" value="' + escapeAttr(data.name) + '" placeholder="Moscow"></td>';
		row += '<td><input type="url" name="' + prefix + '[url]" class="regular-text mvweb-pi-wh-url" value="' + escapeAttr(data.url) + '" placeholder="https://"></td>';
		row += '<td><label class="mvweb-checkbox"><input type="checkbox" name="' + prefix + '[visible]" value="1"' + checked + '></label></td>';
		row += '<td><input type="text" name="' + prefix + '[feed_name]" class="mvweb-input mvweb-pi-wh-feed" value="' + escapeAttr(data.feed_name) + '" placeholder="Optional"></td>';
		row += '<td><button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-pi-remove-warehouse">&times;</button></td>';
		row += '</tr>';

		return row;
	}

	/**
	 * Reindex warehouse rows after removal.
	 */
	function reindexWarehouseRows() {
		$('#mvweb-pi-warehouses-body .mvweb-pi-warehouse-row').each(function(index) {
			var $row = $(this);
			$row.attr('data-index', index);
			var prefix = 'mvweb_pi_settings[warehouses][' + index + ']';
			$row.find('.mvweb-pi-wh-id').attr('name', prefix + '[id]');
			$row.find('.mvweb-pi-wh-name').attr('name', prefix + '[name]');
			$row.find('.mvweb-pi-wh-url').attr('name', prefix + '[url]');
			$row.find('input[type="checkbox"]').attr('name', prefix + '[visible]');
			$row.find('.mvweb-pi-wh-feed').attr('name', prefix + '[feed_name]');
		});
	}

	/**
	 * Initialize Log tab — load/filter/clear/paginate.
	 */
	function initLogTab() {
		var $loadBtn    = $('#mvweb-pi-load-log');
		var $clearBtn   = $('#mvweb-pi-clear-log');
		var $spinner    = $('#mvweb-pi-log-spinner');

		if (!$loadBtn.length) {
			return;
		}

		// Load logs on Apply click.
		$loadBtn.on('click', function(e) {
			e.preventDefault();
			loadLogPage(1);
		});

		// Clear logs.
		$clearBtn.on('click', function(e) {
			e.preventDefault();
			if (!confirm('Clear all log entries?')) {
				return;
			}

			$spinner.addClass('is-active');
			$clearBtn.prop('disabled', true);

			$.post(mvweb_pi_ajax.ajax_url, {
				action: 'mvweb_pi_clear_log',
				nonce: mvweb_pi_ajax.nonce
			}, function(response) {
				if (response.success) {
					$('#mvweb-pi-log-body').empty();
					$('#mvweb-pi-log-pagination').empty();
				}
			}).always(function() {
				$spinner.removeClass('is-active');
				$clearBtn.prop('disabled', false);
			});
		});

		// Pagination clicks (delegated).
		$('#mvweb-pi-log-pagination').on('click', 'a', function(e) {
			e.preventDefault();
			var page = $(this).data('page');
			if (page) {
				loadLogPage(page);
			}
		});

		// Auto-load first page on tab activation.
		$('.mvweb-tabs .nav-tab').on('click', function() {
			if ($(this).data('tab') === 'log' && $('#mvweb-pi-log-body').children().length === 0) {
				loadLogPage(1);
			}
		});

		// Initial autoload when the page itself lands on the Log tab — either
		// because PHP rendered it with .active (?tab=log) or because the URL
		// hash points to it. The hash-driven trigger inside initTabs() runs
		// before this handler is registered, so we cannot rely on the click
		// event firing here.
		var logIsActive = $('#log').hasClass('active') || window.location.hash === '#log';
		if (logIsActive && $('#mvweb-pi-log-body').children().length === 0) {
			loadLogPage(1);
		}
	}

	/**
	 * Load a specific log page via AJAX.
	 *
	 * @param {number} page Page number.
	 */
	function loadLogPage(page) {
		var $spinner = $('#mvweb-pi-log-spinner');
		var $tbody   = $('#mvweb-pi-log-body');
		var level    = $('#mvweb-pi-log-level').val();

		$spinner.addClass('is-active');

		$.post(mvweb_pi_ajax.ajax_url, {
			action: 'mvweb_pi_get_log',
			nonce: mvweb_pi_ajax.nonce,
			page: page,
			level: level
		}, function(response) {
			if (!response.success) {
				return;
			}

			var data = response.data;
			$tbody.empty();

			if (!data.items || data.items.length === 0) {
				$tbody.html('<tr><td colspan="4" style="text-align: center;">' +
					escapeHtml('No log entries found.') + '</td></tr>');
				$('#mvweb-pi-log-pagination').empty();
				return;
			}

			data.items.forEach(function(item) {
				var levelClass = '';
				if ('error' === item.level) {
					levelClass = 'mvweb-badge--error';
				} else if ('warning' === item.level) {
					levelClass = 'mvweb-badge--warning';
				} else {
					levelClass = 'mvweb-badge--outline';
				}

				var ctx = '';
				if (item.context && typeof item.context === 'object') {
					var parts = [];
					for (var key in item.context) {
						if (item.context.hasOwnProperty(key)) {
							parts.push(escapeHtml(key) + ': ' + escapeHtml(String(item.context[key])));
						}
					}
					ctx = parts.join(', ');
				}

				var row = '<tr>';
				row += '<td>' + escapeHtml(item.date || '') + '</td>';
				row += '<td><span class="mvweb-badge ' + levelClass + '">' + escapeHtml(item.level || '') + '</span></td>';
				row += '<td>' + escapeHtml(item.message || '') + '</td>';
				row += '<td><small>' + ctx + '</small></td>';
				row += '</tr>';
				$tbody.append(row);
			});

			// Build pagination.
			buildLogPagination(data.page, data.total_pages);
		}).always(function() {
			$spinner.removeClass('is-active');
		});
	}

	/**
	 * Build pagination links for log tab.
	 *
	 * @param {number} current    Current page.
	 * @param {number} totalPages Total pages.
	 */
	function buildLogPagination(current, totalPages) {
		var $pagination = $('#mvweb-pi-log-pagination');
		$pagination.empty();

		if (totalPages <= 1) {
			return;
		}

		// Previous.
		if (current > 1) {
			$pagination.append('<li><a href="#" data-page="' + (current - 1) + '">&laquo;</a></li>');
		} else {
			$pagination.append('<li class="disabled"><span>&laquo;</span></li>');
		}

		// Page numbers (show max 7).
		var start = Math.max(1, current - 3);
		var end = Math.min(totalPages, start + 6);
		start = Math.max(1, end - 6);

		for (var i = start; i <= end; i++) {
			if (i === current) {
				$pagination.append('<li class="active"><span>' + i + '</span></li>');
			} else {
				$pagination.append('<li><a href="#" data-page="' + i + '">' + i + '</a></li>');
			}
		}

		// Next.
		if (current < totalPages) {
			$pagination.append('<li><a href="#" data-page="' + (current + 1) + '">&raquo;</a></li>');
		} else {
			$pagination.append('<li class="disabled"><span>&raquo;</span></li>');
		}
	}

	/**
	 * Categories tab — name filter, select-all, clear-all.
	 *
	 * The list can run to thousands of rows on real catalogs, so the
	 * filter does plain string-contains on the visible name client-side;
	 * much faster than round-tripping each keystroke to the server.
	 */
	function initCategoriesTab() {
		var $tree = $('.mvweb-pi-cat-tree');
		if (!$tree.length) {
			return;
		}

		var $rows   = $tree.find('.mvweb-pi-cat-row');
		var $filter = $('#mvweb-pi-cat-filter');

		$filter.on('input', function() {
			var q = $(this).val().toLowerCase().trim();
			if (q === '') {
				$rows.removeClass('is-hidden');
				return;
			}
			$rows.each(function() {
				var name = $(this).find('.mvweb-pi-cat-name').text().toLowerCase();
				$(this).toggleClass('is-hidden', name.indexOf(q) === -1);
			});
		});

		$('#mvweb-pi-cat-expand-all').on('click', function() {
			$rows.not('.is-hidden').find('input[type="checkbox"]').prop('checked', true);
		});

		$('#mvweb-pi-cat-clear-all').on('click', function() {
			$rows.find('input[type="checkbox"]').prop('checked', false);
		});
	}

	/**
	 * Document ready.
	 */
	$(function() {
		initTabs();
		initOutputActions();
		initDetectColumns();
		initImportAction();
		initFeedsAction();
		initWarehouses();
		initLogTab();
		initCategoriesTab();
	});

})(jQuery);
