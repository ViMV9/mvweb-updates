<?php
/**
 * Admin settings page template.
 *
 * Uses MVweb UI Kit · IDE Light theme.
 * Activated via `.mvweb-theme-ide` modifier on the root wrap.
 * Reference: docs/ui-kit-reference.html
 *
 * Tab labels are user-friendly and fully localized.
 * Each tab body lives in a separate partial under admin/views/.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'main'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.

$tabs = array(
	'main'    => array(
		'label' => __( 'Main', 'mvweb-price-importer' ),
		'badge' => null,
	),
	'mapping' => array(
		'label' => __( 'Mapping', 'mvweb-price-importer' ),
		'badge' => null,
	),
	'log'     => array(
		'label' => __( 'Log', 'mvweb-price-importer' ),
		'badge' => null,
	),
	'feeds'   => array(
		'label' => __( 'Feeds', 'mvweb-price-importer' ),
		'badge' => null,
	),
	'help'    => array(
		'label' => __( 'Help', 'mvweb-price-importer' ),
		'badge' => null,
	),
);
?>

<div class="wrap mvweb-settings mvweb-settings--wide mvweb-theme-ide">

	<div class="wp-frame__crumbs">
		<span><?php esc_html_e( 'MVweb Hub', 'mvweb-price-importer' ); ?></span>
		<span class="accent"><?php echo esc_html( get_admin_page_title() ); ?></span>
	</div>

	<div class="mvweb-settings__heading">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<span class="mvweb-settings__pill">v<?php echo esc_html( MVWEB_PI_VERSION ); ?></span>
	</div>

	<?php settings_errors( 'mvweb_pi_messages' ); ?>

	<nav class="nav-tab-wrapper mvweb-tabs" role="tablist">
		<?php foreach ( $tabs as $tab_id => $tab ) : ?>
			<a href="#<?php echo esc_attr( $tab_id ); ?>"
				class="nav-tab <?php echo $current_tab === $tab_id ? 'nav-tab-active' : ''; ?>"
				data-tab="<?php echo esc_attr( $tab_id ); ?>"
				role="tab">
				<span class="nav-tab__dot" aria-hidden="true"></span>
				<?php echo esc_html( $tab['label'] ); ?>
				<?php if ( null !== $tab['badge'] ) : ?>
					<span class="nav-tab__badge"><?php echo esc_html( (string) $tab['badge'] ); ?></span>
				<?php endif; ?>
			</a>
		<?php endforeach; ?>
	</nav>

	<form method="post" action="">
		<?php wp_nonce_field( 'mvweb_pi_settings', 'mvweb_pi_nonce' ); ?>

		<!-- Main Tab -->
		<div id="main" class="mvweb-tab-content <?php echo 'main' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_PI_PATH . 'admin/views/tab-main.php'; ?>
		</div>

		<!-- Mapping Tab -->
		<div id="mapping" class="mvweb-tab-content <?php echo 'mapping' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_PI_PATH . 'admin/views/tab-mapping.php'; ?>
		</div>

		<!-- Log Tab -->
		<div id="log" class="mvweb-tab-content <?php echo 'log' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_PI_PATH . 'admin/views/tab-log.php'; ?>
		</div>

		<!-- Feeds Tab -->
		<div id="feeds" class="mvweb-tab-content <?php echo 'feeds' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_PI_PATH . 'admin/views/tab-feeds.php'; ?>
		</div>

		<?php submit_button( __( 'Save Changes', 'mvweb-price-importer' ), 'primary', 'mvweb_pi_save' ); ?>
	</form>

	<!-- Help Tab (outside form — no form fields) -->
	<div id="help" class="mvweb-tab-content <?php echo 'help' === $current_tab ? 'active' : ''; ?>">
		<?php require MVWEB_PI_PATH . 'admin/views/tab-help.php'; ?>
	</div>
</div>
