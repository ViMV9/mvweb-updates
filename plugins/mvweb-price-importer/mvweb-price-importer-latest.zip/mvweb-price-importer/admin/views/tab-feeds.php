<?php
/**
 * Feeds tab template.
 *
 * YML feed settings, feed list table, and generation controls.
 * Settings (company, currency) are saved via the main form POST.
 * Feed generation is handled via AJAX.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$feeds_handler  = new MVweb_PI_Feeds();
$company        = $feeds_handler->get_company();
$currency       = $feeds_handler->get_currency();
$auto_generate  = get_option( MVweb_PI_Feeds::OPTION_AUTO_GENERATE, '1' );
$feed_list      = $feeds_handler->get_feed_list();

$currency_options = array(
	'RUR' => __( 'RUR — Russian Ruble', 'mvweb-price-importer' ),
	'USD' => __( 'USD — US Dollar', 'mvweb-price-importer' ),
	'EUR' => __( 'EUR — Euro', 'mvweb-price-importer' ),
);
?>

<div class="mvweb-pi-tab-feeds">

	<!-- Feed Settings -->
	<h2 class="mvweb-section-title"><?php esc_html_e( 'Feed Settings', 'mvweb-price-importer' ); ?></h2>
	<p class="mvweb-help-text">
		<?php esc_html_e( 'Configure YML feed parameters for Yandex.Market. Feeds include only products with stock > 0.', 'mvweb-price-importer' ); ?>
	</p>

	<table class="form-table" role="presentation">
		<tr>
			<th scope="row">
				<label for="mvweb_pi_feeds_company"><?php esc_html_e( 'Company Name', 'mvweb-price-importer' ); ?></label>
			</th>
			<td>
				<input type="text"
					   id="mvweb_pi_feeds_company"
					   name="mvweb_pi_feeds_company"
					   class="regular-text"
					   value="<?php echo esc_attr( $company ); ?>">
				<p class="mvweb-help-text">
					<?php esc_html_e( 'Company name displayed in the YML feed header.', 'mvweb-price-importer' ); ?>
				</p>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="mvweb_pi_feeds_currency"><?php esc_html_e( 'Currency', 'mvweb-price-importer' ); ?></label>
			</th>
			<td>
				<select id="mvweb_pi_feeds_currency"
						name="mvweb_pi_feeds_currency"
						class="mvweb-select">
					<?php foreach ( $currency_options as $code => $label ) : ?>
						<option value="<?php echo esc_attr( $code ); ?>"
							<?php selected( $currency, $code ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<?php esc_html_e( 'Auto-generate', 'mvweb-price-importer' ); ?>
			</th>
			<td>
				<label class="mvweb-checkbox">
					<input type="checkbox"
						   id="mvweb_pi_feeds_auto_generate"
						   name="mvweb_pi_feeds_auto_generate"
						   value="1"
						   <?php checked( $auto_generate, '1' ); ?>>
					<?php esc_html_e( 'Regenerate feeds automatically after each successful import', 'mvweb-price-importer' ); ?>
				</label>
			</td>
		</tr>
	</table>

	<!-- Generated Feeds -->
	<h2 class="mvweb-section-title"><?php esc_html_e( 'Generated Feeds', 'mvweb-price-importer' ); ?></h2>

	<?php if ( ! empty( $feed_list ) ) : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table mvweb-table--striped" id="mvweb-pi-feeds-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Feed', 'mvweb-price-importer' ); ?></th>
						<th><?php esc_html_e( 'URL', 'mvweb-price-importer' ); ?></th>
						<th><?php esc_html_e( 'Last Generated', 'mvweb-price-importer' ); ?></th>
						<th><?php esc_html_e( 'Products', 'mvweb-price-importer' ); ?></th>
						<th><?php esc_html_e( 'Size', 'mvweb-price-importer' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $feed_list as $feed ) : ?>
						<tr>
							<td>
								<strong><?php echo esc_html( $feed['slug'] ); ?></strong>
							</td>
							<td>
								<a href="<?php echo esc_url( $feed['url'] ); ?>"
								   target="_blank"
								   rel="noopener noreferrer"
								   class="mvweb-pi-feed-url">
									<?php echo esc_html( $feed['url'] ); ?>
								</a>
							</td>
							<td>
								<?php
								echo esc_html(
									wp_date(
										get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
										$feed['modified']
									)
								);
								?>
							</td>
							<td>
								<span class="mvweb-badge"><?php echo esc_html( $feed['products'] ); ?></span>
							</td>
							<td>
								<?php echo esc_html( $feed['size'] ); ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php else : ?>
		<p class="mvweb-help-text">
			<?php esc_html_e( 'No feeds generated yet. Click the button below to generate YML feeds.', 'mvweb-price-importer' ); ?>
		</p>
	<?php endif; ?>

	<!-- Generate Button -->
	<div class="mvweb-pi-feeds-actions">
		<button type="button"
				class="mvweb-btn mvweb-btn--primary"
				id="mvweb-pi-generate-feeds-btn">
			<?php esc_html_e( 'Generate All Feeds', 'mvweb-price-importer' ); ?>
			<span class="mvweb-spinner" id="mvweb-pi-feeds-spinner"></span>
		</button>
		<div class="mvweb-pi-action-result" id="mvweb-pi-feeds-result"></div>
	</div>

</div>
