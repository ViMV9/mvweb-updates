<?php
/**
 * Log tab template.
 *
 * Import log viewer with pagination and status filters.
 * Log data is loaded via AJAX from JSONL file (Stage 10 backend).
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$upload_dir = wp_upload_dir();
$log_file   = $upload_dir['basedir'] . '/pricelists/mvweb_pi.log';
$log_exists = file_exists( $log_file );
?>

<div class="mvweb-pi-tab-log">
	<h2 class="mvweb-section-title"><?php esc_html_e( 'Import Log', 'mvweb-price-importer' ); ?></h2>
	<p class="mvweb-help-text">
		<?php esc_html_e( 'View import logs with filtering and pagination. Logs are stored in JSONL format and auto-rotated after 10 MB or 30 days.', 'mvweb-price-importer' ); ?>
	</p>

	<!-- Filters -->
	<div class="mvweb-filter-panel">
		<select class="mvweb-select" id="mvweb-pi-log-level">
			<option value=""><?php esc_html_e( 'All levels', 'mvweb-price-importer' ); ?></option>
			<option value="error"><?php esc_html_e( 'Errors', 'mvweb-price-importer' ); ?></option>
			<option value="warning"><?php esc_html_e( 'Warnings', 'mvweb-price-importer' ); ?></option>
			<option value="info"><?php esc_html_e( 'Info', 'mvweb-price-importer' ); ?></option>
			<option value="debug"><?php esc_html_e( 'Debug (verbose)', 'mvweb-price-importer' ); ?></option>
		</select>
		<button type="button" class="mvweb-btn mvweb-btn--sm" id="mvweb-pi-load-log">
			<?php esc_html_e( 'Apply', 'mvweb-price-importer' ); ?>
		</button>
		<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm" id="mvweb-pi-clear-log">
			<?php esc_html_e( 'Clear Log', 'mvweb-price-importer' ); ?>
		</button>
		<span class="mvweb-spinner" id="mvweb-pi-log-spinner"></span>
	</div>

	<!-- Log Table -->
	<?php if ( $log_exists ) : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table mvweb-table--striped" id="mvweb-pi-log-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Date', 'mvweb-price-importer' ); ?></th>
						<th><?php esc_html_e( 'Level', 'mvweb-price-importer' ); ?></th>
						<th><?php esc_html_e( 'Message', 'mvweb-price-importer' ); ?></th>
						<th><?php esc_html_e( 'Context', 'mvweb-price-importer' ); ?></th>
					</tr>
				</thead>
				<tbody id="mvweb-pi-log-body">
					<!-- Loaded via AJAX -->
				</tbody>
			</table>
		</div>

		<!-- Pagination -->
		<nav aria-label="<?php esc_attr_e( 'Log pagination', 'mvweb-price-importer' ); ?>">
			<ul class="mvweb-pagination" id="mvweb-pi-log-pagination"></ul>
		</nav>
	<?php else : ?>
		<div class="mvweb-empty" id="mvweb-pi-log-empty">
			<div class="mvweb-empty__icon">&#128196;</div>
			<div class="mvweb-empty__title"><?php esc_html_e( 'No log file found', 'mvweb-price-importer' ); ?></div>
			<div class="mvweb-empty__text"><?php esc_html_e( 'Logs will appear here after the first import is run.', 'mvweb-price-importer' ); ?></div>
		</div>
	<?php endif; ?>
</div>
