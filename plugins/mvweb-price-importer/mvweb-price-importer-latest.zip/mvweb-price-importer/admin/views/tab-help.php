<?php
/**
 * Help tab template.
 *
 * Built-in documentation for administrators. Targets two audiences:
 *   - first-time operators who need a literal click-by-click walkthrough,
 *   - returning admins who only want to look up a specific FAQ.
 *
 * Each Quick Start step names the exact tab and section, the field/button
 * to interact with, and the visible result the operator should expect —
 * so the user can keep their eyes on the screen instead of jumping back
 * here mid-task.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cron_command = '0 */6 * * * /usr/local/bin/php ' . WP_CONTENT_DIR . '/plugins/mvweb-price-importer/cron-runner.php';
?>

<div class="mvweb-help">

	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Quick Start', 'mvweb-price-importer' ); ?></h2>
		<p class="mvweb-help-text">
			<?php esc_html_e( 'A complete first-import walkthrough. Each step ends with the result you should see on the screen before moving on.', 'mvweb-price-importer' ); ?>
		</p>

		<ol class="mvweb-help__steps">
			<li>
				<div>
					<strong><?php esc_html_e( 'Step 1. Tell the plugin where the price list lives', 'mvweb-price-importer' ); ?></strong>
					<p>
						<?php esc_html_e( 'Open the "Main" tab. In the "Source" section, paste the URL of your price list into the "Source URL" field. CSV, YML (Yandex.Market) and XLSX are supported, and Google Sheets share links are auto-converted to a CSV export.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'If you import from several locations (e.g. Moscow and St. Petersburg warehouses), use the "Warehouses" sub-section instead: click "Add Warehouse", fill in a short ID, name and URL for each one. When warehouses are configured the single "Source URL" above is ignored.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'Click "Save Changes" at the bottom of the page. You will see a green "Settings saved." notice at the top.', 'mvweb-price-importer' ); ?>
					</p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 2. Choose how often to import, batch size, and what to do with images', 'mvweb-price-importer' ); ?></strong>
					<p>
						<?php esc_html_e( 'Still on the "Main" tab, scroll to "Import Schedule". Pick an "Auto-import Interval" (Hourly / Every 6 hours / Every 12 hours / Daily, or "Disabled" if you only want to import manually).', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( '"Batch Size" controls how many products are processed per chunk. 100–250 is a safe default. Reduce it if your hosting kills long-running PHP processes.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( '"Image Import" decides when product photos are downloaded. For catalogs of more than a few hundred items leave the default "Only for new products" — it is by far the cheapest option because re-importing images is what makes runs slow.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'Save again. The notice "Next scheduled import: …" appears with the exact date and time of the upcoming automatic run.', 'mvweb-price-importer' ); ?>
					</p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 3. Map your file columns to WooCommerce fields', 'mvweb-price-importer' ); ?></strong>
					<p>
						<?php esc_html_e( 'Switch to the "Mapping" tab. Click "Detect columns" — the plugin downloads a sample of the source, parses the header row and tries to match SKU, Name, Price, Stock, Image, Category and the rest automatically.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'Review the dropdowns. Anything left blank means the field could not be auto-detected — pick the right column manually. The required fields are SKU, Name, Price and Stock; without them the import refuses to run.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'Click "Save Changes". A "Mapping saved." notice confirms.', 'mvweb-price-importer' ); ?>
					</p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 4. Run the first import', 'mvweb-price-importer' ); ?></strong>
					<p>
						<?php esc_html_e( 'Go back to the "Main" tab. In the "Actions" section press "Import Now" (the purple primary button). The yellow spinner spins until the run finishes.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'For very large catalogs the action splits into chunks: each click processes the next slice and a green notice tells you the chunk is done and the next one is scheduled. Keep pressing "Import Now" — or wait for the WordPress cron to run it automatically — until you see the final "Import complete" notice.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'The "Import Statistics" section right below "Actions" now shows the time of the last run, created/updated/skipped/errors counters, total items in the price list and how many SKUs the plugin already knows.', 'mvweb-price-importer' ); ?>
					</p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 5. Exclude categories you do not want in the shop (optional)', 'mvweb-price-importer' ); ?></strong>
					<p>
						<?php esc_html_e( 'After the first successful import the "Excluded Categories" section on the "Main" tab fills with a tree of every category from the source. Tick any category whose products must be skipped on future imports — ticking a parent automatically excludes everything nested under it.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'Use the filter field to find categories by name, or the "Select all" / "Clear selection" shortcuts. Save Changes and re-run the import — excluded items will be skipped.', 'mvweb-price-importer' ); ?>
					</p>
				</div>
			</li>

			<li>
				<div>
					<strong><?php esc_html_e( 'Step 6. Set up reliable scheduling for production (recommended)', 'mvweb-price-importer' ); ?></strong>
					<p>
						<?php esc_html_e( 'WordPress cron only fires while visitors are browsing the site. On a low-traffic B2B shop the daily import may slip by hours. Replace it with a real system cron job through your hosting panel — the command to register is shown in the yellow "Note" box at the bottom of this page.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'When the system cron is active, set the "Auto-import Interval" on the Main tab to "Disabled" so the same import is not triggered twice.', 'mvweb-price-importer' ); ?>
					</p>
				</div>
			</li>
		</ol>
	</section>

	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Features', 'mvweb-price-importer' ); ?></h2>
		<ul>
			<li><?php esc_html_e( 'Import products from CSV, YML (Yandex.Market), and XLSX files', 'mvweb-price-importer' ); ?></li>
			<li><?php esc_html_e( 'Multi-warehouse support with per-warehouse stock tracking', 'mvweb-price-importer' ); ?></li>
			<li><?php esc_html_e( 'Automatic import on schedule (hourly, every 6/12 hours, daily)', 'mvweb-price-importer' ); ?></li>
			<li><?php esc_html_e( 'Smart update detection via ETag/Last-Modified headers', 'mvweb-price-importer' ); ?></li>
			<li><?php esc_html_e( 'YML feed generation for Yandex.Market (general and per-warehouse)', 'mvweb-price-importer' ); ?></li>
			<li><?php esc_html_e( 'Automatic category import with hierarchy support and per-category exclusions', 'mvweb-price-importer' ); ?></li>
			<li><?php esc_html_e( 'Product image import with policy: only for new products, always, or never', 'mvweb-price-importer' ); ?></li>
			<li><?php esc_html_e( 'Detailed JSONL logging with pagination and level filter', 'mvweb-price-importer' ); ?></li>
		</ul>
	</section>

	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Frequently Asked Questions', 'mvweb-price-importer' ); ?></h2>

		<div class="mvweb-help__faq">
			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'Which file formats are supported?', 'mvweb-price-importer' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'CSV (with semicolon, comma, or tab delimiters), YML (Yandex.Market XML format), and XLSX (Excel). UTF-8 and Windows-1251 encodings are auto-detected.', 'mvweb-price-importer' ); ?></p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'Can I use Google Sheets as a source?', 'mvweb-price-importer' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'Yes. Paste your Google Sheets sharing link and it will be automatically converted to a CSV export URL.', 'mvweb-price-importer' ); ?></p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'What happens to products missing from the new price list?', 'mvweb-price-importer' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'Products not found in the new price list will have their stock set to 0 and status changed to "out of stock". They are not deleted or moved to draft.', 'mvweb-price-importer' ); ?></p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'How do I set up multiple warehouses?', 'mvweb-price-importer' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'In the "Main" tab → "Source" section press "Add Warehouse". Enter a unique ID, a display name and the URL for each warehouse. Stock quantities from all warehouses are summed for the total WooCommerce stock; per-warehouse stock is displayed on the product page if "Visible" is enabled.', 'mvweb-price-importer' ); ?></p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'Why is automatic import not running on time?', 'mvweb-price-importer' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p>
						<?php esc_html_e( 'The "Auto-import Interval" setting on the Main tab uses WordPress cron (wp-cron). The timer itself does not run anything — the scheduled job only fires when a visitor opens any page of the site (front-end, admin, or REST). With a steady flow of traffic the import runs within a few minutes of the time shown next to "Next import at …". On a low-traffic B2B catalog there may be no visitor for hours, and the import will be delayed by exactly that gap.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'For predictable runs configure a real system cron on the hosting panel — the exact command is in the yellow Note box at the bottom of this page. When system cron is active, change the "Auto-import Interval" on the Main tab to "Disabled" so the same import is not started twice.', 'mvweb-price-importer' ); ?>
					</p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'Where are logs stored and how often are they cleaned?', 'mvweb-price-importer' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p>
						<?php
						printf(
							/* translators: %s: log file path */
							esc_html__( 'Logs are stored in JSONL format at %s and read in the "Log" tab.', 'mvweb-price-importer' ),
							'<code>wp-content/uploads/pricelists/mvweb_pi.log</code>'
						);
						?>
					</p>
					<p>
						<?php esc_html_e( 'Rotation is automatic and triggered lazily on the next log write — there is no separate cron job. Two thresholds:', 'mvweb-price-importer' ); ?>
					</p>
					<ul>
						<li><?php esc_html_e( 'When the file passes 10 MB, it is renamed to a dated .bak archive next to it and a fresh log starts.', 'mvweb-price-importer' ); ?></li>
						<li><?php esc_html_e( 'When the file is older than 30 days, the same archive-and-restart happens regardless of size.', 'mvweb-price-importer' ); ?></li>
						<li><?php esc_html_e( 'Archive files (.bak) older than 30 days are deleted on the same write.', 'mvweb-price-importer' ); ?></li>
					</ul>
					<p>
						<?php esc_html_e( 'In practice the log file never grows unboundedly — a busy import that produces hundreds of warnings per run still rolls over within a single day at 10 MB. The "Clear Log" button on the Log tab erases the current file and all archives immediately.', 'mvweb-price-importer' ); ?>
					</p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'How do I see verbose / developer-level details?', 'mvweb-price-importer' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p>
						<?php esc_html_e( 'The log has two layers. Without any extra configuration you only see operator-grade events — downloads completed, conversion summary, import results, errors. That keeps the screen readable when everything is fine.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'When you need to chase a slow or broken import, enable the "Verbose logging" checkbox in Main → Import Schedule. From the next write onward the plugin also records per-batch progress, per-source download details, and individual image-404 misses. Switch the Level filter on the Log tab to "Debug (verbose)" to focus on those entries.', 'mvweb-price-importer' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'Turn the checkbox back off once you are done — debug mode produces orders of magnitude more lines and is what causes log rotation to kick in early.', 'mvweb-price-importer' ); ?>
					</p>
				</div>
			</details>
		</div>
	</section>

	<section class="mvweb-help__section">
		<div class="mvweb-notice mvweb-notice--warning">
			<strong><?php esc_html_e( 'Note:', 'mvweb-price-importer' ); ?></strong>
			<?php esc_html_e( 'WordPress cron (wp-cron) fires only while visitors are on the site. For B2B shops with low traffic, use system cron for reliable scheduling:', 'mvweb-price-importer' ); ?>
			<pre class="mvweb-codeblock"><code><?php echo esc_html( $cron_command ); ?></code></pre>
		</div>
	</section>

	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Support', 'mvweb-price-importer' ); ?></h2>
		<p>
			<?php
			printf(
				/* translators: %s: MVweb plugin URL */
				esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-price-importer' ),
				'<a href="https://mvweb.ru/plugins/mvweb-price-importer" target="_blank">mvweb.ru</a>'
			);
			?>
		</p>
		<p>
			<strong><?php esc_html_e( 'Version:', 'mvweb-price-importer' ); ?></strong> <?php echo esc_html( MVWEB_PI_VERSION ); ?>
		</p>
	</section>
</div>
