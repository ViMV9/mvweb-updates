<?php
/**
 * Mapping tab template.
 *
 * Field mapping between price list columns and WooCommerce product fields.
 * Includes auto-detection button and manual override dropdowns.
 *
 * @package mvweb_pi
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get saved mapping and detected headers.
$saved_mapping     = get_option( 'mvweb_pi_mapping', array() );
$detected_headers  = $saved_mapping['_headers'] ?? array();

// Mapping fields definition: key => [label, required, description].
$mapping_fields = array(
	'sku'         => array(
		'label'       => __( 'SKU', 'mvweb-price-importer' ),
		'required'    => true,
		'description' => __( 'Unique product identifier (article number).', 'mvweb-price-importer' ),
	),
	'name'        => array(
		'label'       => __( 'Name', 'mvweb-price-importer' ),
		'required'    => true,
		'description' => __( 'Product title.', 'mvweb-price-importer' ),
	),
	'description' => array(
		'label'       => __( 'Description', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Product description (HTML allowed).', 'mvweb-price-importer' ),
	),
	'price'       => array(
		'label'       => __( 'Price', 'mvweb-price-importer' ),
		'required'    => true,
		'description' => __( 'Regular price.', 'mvweb-price-importer' ),
	),
	'sale_price'  => array(
		'label'       => __( 'Old Price', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Price before discount (strikethrough price).', 'mvweb-price-importer' ),
	),
	'stock'       => array(
		'label'       => __( 'Stock', 'mvweb-price-importer' ),
		'required'    => true,
		'description' => __( 'Stock quantity.', 'mvweb-price-importer' ),
	),
	'image'       => array(
		'label'       => __( 'Image', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Main product image URL.', 'mvweb-price-importer' ),
	),
	'gallery'     => array(
		'label'       => __( 'Gallery', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Additional image URLs (comma-separated).', 'mvweb-price-importer' ),
	),
	'category'    => array(
		'label'       => __( 'Category', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Category ID from price list.', 'mvweb-price-importer' ),
	),
	'parent_cat'  => array(
		'label'       => __( 'Parent Category', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Parent category ID.', 'mvweb-price-importer' ),
	),
	'barcode'     => array(
		'label'       => __( 'Barcode', 'mvweb-price-importer' ),
		'required'    => false,
		'description' => __( 'Barcode (EAN, UPC, GTIN).', 'mvweb-price-importer' ),
	),
);
?>

<div class="mvweb-pi-tab-mapping">
	<h2 class="mvweb-section-title"><?php esc_html_e( 'Field Mapping', 'mvweb-price-importer' ); ?></h2>
	<p class="mvweb-help-text">
		<?php esc_html_e( 'Map price list columns to WooCommerce product fields. Use the auto-detect button to scan column headers automatically.', 'mvweb-price-importer' ); ?>
	</p>

	<!-- Auto-detect button -->
	<div class="mvweb-pi-mapping-actions">
		<button type="button"
				class="mvweb-btn mvweb-btn--secondary"
				id="mvweb-pi-detect-columns"
				data-action="mvweb_pi_detect_columns">
			<?php esc_html_e( 'Auto-detect Columns', 'mvweb-price-importer' ); ?>
			<span class="mvweb-spinner" id="mvweb-pi-detect-spinner"></span>
		</button>
		<span class="mvweb-pi-detect-status" id="mvweb-pi-detect-status"></span>
	</div>

	<!-- Mapping table -->
	<div class="mvweb-table-wrap">
		<table class="mvweb-table" id="mvweb-pi-mapping-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'WooCommerce Field', 'mvweb-price-importer' ); ?></th>
					<th><?php esc_html_e( 'Source Column', 'mvweb-price-importer' ); ?></th>
					<th><?php esc_html_e( 'Required', 'mvweb-price-importer' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $mapping_fields as $field_key => $field_data ) : ?>
					<tr>
						<td>
							<strong><?php echo esc_html( $field_data['label'] ); ?></strong>
							<div class="mvweb-help-text"><?php echo esc_html( $field_data['description'] ); ?></div>
						</td>
						<td>
							<select name="mvweb_pi_mapping[<?php echo esc_attr( $field_key ); ?>]"
									class="mvweb-select mvweb-pi-mapping-select"
									data-field="<?php echo esc_attr( $field_key ); ?>">
								<option value=""><?php esc_html_e( '— Not mapped —', 'mvweb-price-importer' ); ?></option>
								<?php if ( ! empty( $detected_headers ) ) : ?>
									<?php foreach ( $detected_headers as $header ) : ?>
										<option value="<?php echo esc_attr( $header ); ?>"
											<?php selected( $saved_mapping[ $field_key ] ?? '', $header ); ?>>
											<?php echo esc_html( $header ); ?>
										</option>
									<?php endforeach; ?>
								<?php endif; ?>
							</select>
						</td>
						<td>
							<?php if ( $field_data['required'] ) : ?>
								<span class="mvweb-badge mvweb-badge--error"><?php esc_html_e( 'Yes', 'mvweb-price-importer' ); ?></span>
							<?php else : ?>
								<span class="mvweb-badge mvweb-badge--outline"><?php esc_html_e( 'No', 'mvweb-price-importer' ); ?></span>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<?php if ( empty( $detected_headers ) ) : ?>
		<div class="mvweb-notice mvweb-notice--warning">
			<?php esc_html_e( 'No column headers detected. Configure a source URL in the Settings tab, then click "Auto-detect Columns" to scan the file.', 'mvweb-price-importer' ); ?>
		</div>
	<?php endif; ?>
</div>
