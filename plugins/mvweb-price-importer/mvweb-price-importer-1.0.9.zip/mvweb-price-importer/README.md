# MVweb Price Importer

Automatic import of products from external price lists into WooCommerce.

## Description

MVweb Price Importer allows you to automatically import products from CSV, YML (Yandex.Market), and XLSX price lists into your WooCommerce store. Supports multi-warehouse stock tracking, scheduled imports, and YML feed generation for Yandex.Market.

## Requirements

- WordPress 6.4 or higher
- WooCommerce 8.0 or higher
- PHP 8.0 or higher

## Installation

1. Upload the `mvweb-price-importer` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **MVweb Hub → Price Importer** to configure settings

## Usage

1. **Add Source** — Enter the URL of your price list file on the Settings tab
2. **Map Fields** — Map price list columns to WooCommerce product fields on the Mapping tab
3. **Run Import** — Click "Import Now" on the Import tab or set up automatic imports

## Supported Formats

- **CSV** — Semicolon, comma, or tab delimiters. UTF-8 and Windows-1251 encodings
- **YML** — Yandex.Market XML format (XMLReader, streaming)
- **XLSX** — Excel files via SimpleXLSX

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for the full changelog.

## License

This plugin is licensed under the GPL v2 or later.

## Credits

Developed by [MVweb](https://mvweb.ru)
