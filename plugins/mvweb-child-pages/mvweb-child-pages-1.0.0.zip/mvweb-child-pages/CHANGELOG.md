# Changelog

All notable changes to MVweb Child Pages will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-02-09

### Added
- Shortcode `[mvweb-cp id="..."]` to display child pages
- Shortcode attributes: id, limit, orderby, order, show_image, class, image_size
- Admin settings page with General, Custom CSS, and Help tabs
- Global defaults for image display, size, limit, sorting
- Custom CSS field with frontend-only output via `wp_add_inline_style()`
- Responsive flex layout with CSS variables
- Placeholder SVG for pages without featured image
- BEM modifiers: `--{parent_id}`, `--no-images`, `--empty`
- Parent page validation (existence, type, status, password)
- Filters: `mvweb_cp_query_args`, `mvweb_cp_item_html`, `mvweb_cp_shortcode_atts`, `mvweb_cp_placeholder_url`
- Actions: `mvweb_cp_before_list`, `mvweb_cp_after_list`
- Russian (ru_RU) translation
- Help tab with Quick Start, attributes table, CSS examples, FAQ
- MVweb Hub integration
- Auto-update support via PUC
