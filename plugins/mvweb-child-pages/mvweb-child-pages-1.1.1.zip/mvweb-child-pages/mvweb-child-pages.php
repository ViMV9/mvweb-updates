<?php
/**
 * Plugin Name:       MVweb Child Pages
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-child-pages
 * Description:       Display child pages as a styled list using a shortcode.
 * Version:           1.1.1
 * Requires at least: 6.4
 * Tested up to:      7.1
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-child-pages
 * Domain Path:       /languages
 *
 * @package MVweb_Child_Pages
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_CP_VERSION' ) ) {
	return;
}

/**
 * Plugin version.
 */
define( 'MVWEB_CP_VERSION', '1.1.1' );

/**
 * Plugin directory path.
 */
define( 'MVWEB_CP_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Plugin directory URL.
 */
define( 'MVWEB_CP_URL', plugin_dir_url( __FILE__ ) );

/**
 * Plugin basename.
 */
define( 'MVWEB_CP_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_CP_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_CP_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_CP_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_CP_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_CP_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-child-pages' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-child-pages'] = array(
		'name'         => __( 'MVweb Child Pages', 'mvweb-child-pages' ),
		'description'  => __( 'Display child pages as a styled list using a shortcode.', 'mvweb-child-pages' ),
		'url'          => 'https://mvweb.ru/plugins/mvweb-child-pages',
		'settings_url' => 'admin.php?page=mvweb-child-pages',
		'textdomain'   => 'mvweb-child-pages',
	);
	return $plugins;
} );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-child-pages',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'init', 'mvweb_cp_load_textdomain' );

/**
 * Register plugin submenu under MVweb.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_register_menu() {
	$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

	add_submenu_page(
		$parent_slug,
		__( 'Child Pages', 'mvweb-child-pages' ),
		__( 'Child Pages', 'mvweb-child-pages' ),
		'manage_options',
		'mvweb-child-pages',
		'mvweb_cp_settings_page'
	);
}
add_action( 'admin_menu', 'mvweb_cp_register_menu' );

/**
 * Plugin settings page callback.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	// Save settings.
	if ( isset( $_POST['mvweb_cp_save'] ) ) {
		check_admin_referer( 'mvweb_cp_settings', 'mvweb_cp_nonce' );

		$settings = mvweb_cp_get_settings();

		// General tab fields. The General form always submits the image_size
		// select, so its presence marks a General save (the checkbox alone is
		// unreliable when unchecked). Custom CSS lives in a separate form.
		if ( isset( $_POST['mvweb_cp_image_size'] ) ) {
			$settings['show_image'] = isset( $_POST['mvweb_cp_show_image'] ) ? 'yes' : 'no';
			$settings['image_size'] = sanitize_text_field( wp_unslash( $_POST['mvweb_cp_image_size'] ) );
			// An empty field means "show all" — that is what people expect, and
			// it saves them from knowing that -1 is the internal no-limit value.
			$raw_limit              = isset( $_POST['mvweb_cp_limit'] ) ? trim( wp_unslash( $_POST['mvweb_cp_limit'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$settings['limit']      = ( '' !== $raw_limit && intval( $raw_limit ) > 0 ) ? intval( $raw_limit ) : -1;
			$settings['orderby']    = isset( $_POST['mvweb_cp_orderby'] )
				? sanitize_text_field( wp_unslash( $_POST['mvweb_cp_orderby'] ) )
				: 'menu_order';
			$settings['order']      = isset( $_POST['mvweb_cp_order'] )
				? sanitize_text_field( wp_unslash( $_POST['mvweb_cp_order'] ) )
				: 'ASC';
			$settings['columns']    = isset( $_POST['mvweb_cp_columns'] )
				? sanitize_text_field( wp_unslash( $_POST['mvweb_cp_columns'] ) )
				: 'auto';

			// Placeholder image: keep only IDs that still point at an image.
			$placeholder_id = isset( $_POST['mvweb_cp_placeholder_id'] ) ? absint( $_POST['mvweb_cp_placeholder_id'] ) : 0;
			$settings['placeholder_id'] = wp_attachment_is_image( $placeholder_id ) ? $placeholder_id : 0;

			// Empty-list text: stored as markup, so it is filtered on the way in
			// as well, not only on output. Empty means "hide the list".
			$settings['empty_text'] = isset( $_POST['mvweb_cp_empty_text'] )
				? wp_kses_post( trim( wp_unslash( $_POST['mvweb_cp_empty_text'] ) ) ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				: '';

			// Image box for the «Custom size» option.
			$settings['image_width']  = isset( $_POST['mvweb_cp_image_width'] ) ? absint( $_POST['mvweb_cp_image_width'] ) : 0;
			$settings['image_height'] = isset( $_POST['mvweb_cp_image_height'] ) ? absint( $_POST['mvweb_cp_image_height'] ) : 0;
			if ( $settings['image_width'] < 1 || $settings['image_width'] > 2000 ) {
				$settings['image_width'] = 200;
			}
			if ( $settings['image_height'] < 1 || $settings['image_height'] > 2000 ) {
				$settings['image_height'] = 200;
			}

			// Validate whitelists.
			$allowed_orderby = array( 'menu_order', 'title', 'date', 'ID' );
			$allowed_order   = array( 'ASC', 'DESC' );

			if ( ! in_array( $settings['image_size'], mvweb_cp_get_allowed_image_sizes(), true ) ) {
				$settings['image_size'] = 'full';
			}
			if ( ! in_array( $settings['orderby'], $allowed_orderby, true ) ) {
				$settings['orderby'] = 'menu_order';
			}
			if ( ! in_array( $settings['order'], $allowed_order, true ) ) {
				$settings['order'] = 'ASC';
			}
			if ( ! in_array( $settings['columns'], mvweb_cp_get_allowed_columns(), true ) ) {
				$settings['columns'] = 'auto';
			}
		}

		// Custom CSS tab field (separate form).
		if ( isset( $_POST['mvweb_cp_custom_css'] ) ) {
			$settings['custom_css'] = wp_strip_all_tags( wp_unslash( $_POST['mvweb_cp_custom_css'] ) );
		}

		update_option( 'mvweb_cp_settings', $settings );

		add_settings_error(
			'mvweb_cp_messages',
			'mvweb_cp_message',
			__( 'Settings saved.', 'mvweb-child-pages' ),
			'updated'
		);
	}

	include MVWEB_CP_PATH . 'admin/views/settings-page.php';
}

/**
 * Enqueue admin styles and scripts.
 *
 * @since 1.0.0
 * @param string $hook Current admin page hook.
 * @return void
 */
function mvweb_cp_admin_enqueue( $hook ) {
	if ( false === strpos( $hook, 'mvweb-child-pages' ) ) {
		return;
	}

	$suffix  = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	$css_ver = (string) filemtime( MVWEB_CP_PATH . 'admin/css/admin' . $suffix . '.css' );
	$js_ver  = (string) filemtime( MVWEB_CP_PATH . 'admin/js/admin' . $suffix . '.js' );

	// Media library, for picking the placeholder image.
	wp_enqueue_media();

	wp_enqueue_style(
		'mvweb-cp-admin',
		MVWEB_CP_URL . 'admin/css/admin' . $suffix . '.css',
		array(),
		$css_ver
	);

	wp_enqueue_style(
		'mvweb-cp-plugin',
		MVWEB_CP_URL . 'admin/css/plugin' . $suffix . '.css',
		array( 'mvweb-cp-admin' ),
		(string) filemtime( MVWEB_CP_PATH . 'admin/css/plugin' . $suffix . '.css' )
	);

	wp_enqueue_script(
		'mvweb-cp-admin',
		MVWEB_CP_URL . 'admin/js/admin' . $suffix . '.js',
		array( 'media-editor' ),
		$js_ver,
		true
	);

	wp_localize_script(
		'mvweb-cp-admin',
		'mvwebCpAdmin',
		array(
			'mediaTitle'  => __( 'Choose a placeholder image', 'mvweb-child-pages' ),
			'mediaButton' => __( 'Use this image', 'mvweb-child-pages' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'mvweb_cp_admin_enqueue' );

/**
 * Register shortcode.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_register_shortcode() {
	add_shortcode( 'mvweb-cp', 'mvweb_cp_shortcode_render' );
}
add_action( 'init', 'mvweb_cp_register_shortcode' );

/**
 * Shortcode render callback.
 *
 * @since 1.0.0
 * @param array|string $atts Shortcode attributes.
 * @return string HTML output.
 */
function mvweb_cp_shortcode_render( $atts ) {
	$settings = mvweb_cp_get_settings();

	$atts = shortcode_atts(
		array(
			'id'         => '',
			'limit'      => $settings['limit'],
			'orderby'    => $settings['orderby'],
			'order'      => $settings['order'],
			'show_image' => $settings['show_image'],
			'class'      => '',
			'image_size' => $settings['image_size'],
			'exclude'    => '',
			'include'    => '',
			'columns'    => $settings['columns'],
		),
		$atts,
		'mvweb-cp'
	);

	/**
	 * Filter shortcode attributes.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 */
	$atts = apply_filters( 'mvweb_cp_shortcode_atts', $atts );

	// No id given: fall back to the page the shortcode sits on, which is the
	// most common case — a parent page listing its own children. On a singular
	// view the queried object is the reliable source: the global $post that
	// get_the_ID() reads can be left pointing at another entry by a nested query
	// or another shortcode rendered earlier on the same page.
	if ( '' === $atts['id'] ) {
		$atts['id'] = is_singular() ? get_queried_object_id() : (int) get_the_ID();
	}

	$parent_id = absint( $atts['id'] );
	if ( 0 === $parent_id ) {
		return mvweb_cp_get_notice_html(
			'invalid id',
			__( 'No page id given, and the shortcode is not on a page — add id="12" with the id of the parent page.', 'mvweb-child-pages' )
		);
	}

	// Validate parent page.
	$parent = get_post( $parent_id );
	if ( null === $parent ) {
		return mvweb_cp_get_notice_html(
			'invalid parent id=' . $parent_id,
			/* translators: %d: page id from the shortcode. */
			sprintf( __( 'Page %d does not exist — check the id in the shortcode.', 'mvweb-child-pages' ), $parent_id )
		);
	}
	if ( 'page' !== $parent->post_type ) {
		return mvweb_cp_get_notice_html(
			'id=' . $parent_id . ' is not a page',
			/* translators: %d: page id from the shortcode. */
			sprintf( __( 'Entry %d is not a page, so it cannot have child pages.', 'mvweb-child-pages' ), $parent_id )
		);
	}
	if ( 'publish' !== $parent->post_status ) {
		return mvweb_cp_get_notice_html(
			'invalid parent id=' . $parent_id,
			/* translators: %d: page id from the shortcode. */
			sprintf( __( 'Page %d is not published, so its child pages stay hidden.', 'mvweb-child-pages' ), $parent_id )
		);
	}
	if ( ! empty( $parent->post_password ) ) {
		return mvweb_cp_get_notice_html(
			'parent id=' . $parent_id . ' is password-protected',
			/* translators: %d: page id from the shortcode. */
			sprintf( __( 'Page %d is password-protected, so its child pages are not listed.', 'mvweb-child-pages' ), $parent_id )
		);
	}

	// Validate and sanitize attributes.
	$limit = intval( $atts['limit'] );
	if ( 0 === $limit ) {
		$limit = -1;
	}

	$allowed_orderby = array( 'menu_order', 'title', 'date', 'ID' );
	$orderby         = in_array( $atts['orderby'], $allowed_orderby, true ) ? $atts['orderby'] : 'menu_order';

	$allowed_order = array( 'ASC', 'DESC' );
	$order         = in_array( strtoupper( $atts['order'] ), $allowed_order, true ) ? strtoupper( $atts['order'] ) : 'ASC';

	$show_image = in_array( $atts['show_image'], array( 'yes', 'no' ), true ) ? $atts['show_image'] : $settings['show_image'];

	// Image size is a CSS box now: a preset, a WxH pair, or «full card width».
	$image_box     = mvweb_cp_parse_image_box( $atts['image_size'], $settings );
	$wp_image_size = mvweb_cp_get_wp_image_size( $image_box );

	$extra_class = ! empty( $atts['class'] ) ? sanitize_html_class( $atts['class'] ) : '';

	$columns = in_array( (string) $atts['columns'], mvweb_cp_get_allowed_columns(), true ) ? (string) $atts['columns'] : 'auto';

	$exclude_ids = wp_parse_id_list( $atts['exclude'] );

	// A filled-in «include» means «show these and nothing else», so the raw value
	// is what decides whether the attribute is in play: a list that parses to no
	// usable id at all (include="none") must end in the diagnostic below, not in
	// the full list of children the author did not ask for. The ids themselves go
	// through wp_parse_id_list(), which turns anything non-numeric into 0 and
	// leaves gaps in the keys after dropping duplicates — neither may reach the
	// loop that rebuilds the list.
	$include_raw = trim( (string) $atts['include'] );
	$include_ids = array_values( array_filter( wp_parse_id_list( $include_raw ) ) );

	// Build query args. The limit is applied after sorting (see below), so the
	// query must return every child — otherwise SQL would cut the list before
	// the PHP sort reorders it.
	$query_args = array(
		'child_of'    => $parent_id,
		'parent'      => $parent_id,
		'post_type'   => 'page',
		'post_status' => 'publish',
		'sort_column' => $orderby,
		'sort_order'  => $order,
		'exclude'     => $exclude_ids,
	);

	/**
	 * Filter get_pages() query args.
	 *
	 * @since 1.0.0
	 * @param array $query_args Query arguments.
	 * @param array $atts       Shortcode attributes.
	 */
	$query_args = apply_filters( 'mvweb_cp_query_args', $query_args, $atts );

	$children = get_pages( $query_args );

	// «include» picks from the children already fetched instead of going into the
	// query: the list stays a list of this parent's children — an id from another
	// branch of the site is simply not there to pick — and «exclude» keeps
	// working, which it would not if the ids went to get_pages(), where a
	// non-empty include makes the core drop post__not_in, child_of and parent.
	// The order follows the attribute: writing the ids out by hand is done
	// precisely to arrange them, so the sorting below is skipped.
	if ( ! empty( $children ) && '' !== $include_raw ) {
		$by_id  = array_column( $children, null, 'ID' );
		$picked = array();
		foreach ( $include_ids as $include_id ) {
			if ( isset( $by_id[ $include_id ] ) ) {
				$picked[] = $by_id[ $include_id ];
			}
		}

		$children = $picked;
	}

	// Manual order: WordPress gives every new page menu_order = 0, so 0 means
	// "position not set" — those pages go after the numbered ones instead of
	// jumping to the top, and a page added later lands at the end of the list.
	// Equal values fall back to ID so the order never depends on MySQL.
	if ( ! empty( $children ) && '' === $include_raw && 'menu_order' === $orderby ) {
		usort(
			$children,
			function ( $a, $b ) use ( $order ) {
				$order_a = (int) $a->menu_order;
				$order_b = (int) $b->menu_order;
				$a_unset = ( 0 === $order_a );
				$b_unset = ( 0 === $order_b );

				// Pages without a position always come last, in both directions.
				if ( $a_unset !== $b_unset ) {
					return $a_unset ? 1 : -1;
				}

				$cmp = $a_unset ? 0 : ( $order_a <=> $order_b );
				if ( 0 === $cmp ) {
					$cmp = $a->ID <=> $b->ID;
				}

				return 'DESC' === $order ? -$cmp : $cmp;
			}
		);
	}

	// Natural sort: titles containing numbers sort numerically (17 > 9, not "17" < "9").
	// Titles with a leading number (after common prefix) come before purely alphabetic ones.
	if ( ! empty( $children ) && '' === $include_raw && 'title' === $orderby ) {
		usort(
			$children,
			function ( $a, $b ) use ( $order ) {
				$title_a = get_the_title( $a->ID );
				$title_b = get_the_title( $b->ID );

				// Find the first position where titles differ.
				$len = min( mb_strlen( $title_a ), mb_strlen( $title_b ) );
				$i   = 0;
				while ( $i < $len && mb_substr( $title_a, $i, 1 ) === mb_substr( $title_b, $i, 1 ) ) {
					++$i;
				}

				// Get the first differing characters.
				$char_a    = $i < mb_strlen( $title_a ) ? mb_substr( $title_a, $i, 1 ) : '';
				$char_b    = $i < mb_strlen( $title_b ) ? mb_substr( $title_b, $i, 1 ) : '';
				$a_is_num  = '' !== $char_a && ctype_digit( $char_a );
				$b_is_num  = '' !== $char_b && ctype_digit( $char_b );

				// Digits before letters at the divergence point (regardless of ASC/DESC).
				if ( $a_is_num && ! $b_is_num ) {
					return -1;
				}
				if ( ! $a_is_num && $b_is_num ) {
					return 1;
				}

				// Same type — use natural case-insensitive comparison.
				$cmp = strnatcasecmp( $title_a, $title_b );

				return 'DESC' === $order ? -$cmp : $cmp;
			}
		);
	}

	if ( empty( $children ) ) {
		// A message set in the settings replaces the list for everyone; with no
		// message the block stays hidden and only editors learn why.
		$empty_text = trim( (string) $settings['empty_text'] );
		if ( '' !== $empty_text ) {
			mvweb_cp_enqueue_public_assets();

			return '<div class="mvweb-cp-empty">' . wp_kses_post( $empty_text ) . '</div>';
		}

		// A hand-written list that matched nothing is a different mistake from an
		// empty parent, and the editor needs to hear which one it is.
		if ( '' !== $include_raw ) {
			return mvweb_cp_get_notice_html(
				'include matched no children of id=' . $parent_id,
				/* translators: %d: page id from the shortcode. */
				sprintf( __( 'None of the pages listed in include is a published child page of page %d — check the ids.', 'mvweb-child-pages' ), $parent_id )
			);
		}

		return mvweb_cp_get_notice_html(
			'no children for id=' . $parent_id,
			/* translators: %d: page id from the shortcode. */
			sprintf( __( 'Page %d has no published child pages yet — nothing is shown to visitors.', 'mvweb-child-pages' ), $parent_id )
		);
	}

	// Apply the limit after sorting.
	if ( $limit > 0 ) {
		$children = array_slice( $children, 0, $limit );
	}

	// Enqueue frontend assets.
	mvweb_cp_enqueue_public_assets();

	// Build CSS classes.
	$nav_classes = array( 'mvweb-cp', 'mvweb-cp--' . $parent_id );
	if ( 'no' === $show_image ) {
		$nav_classes[] = 'mvweb-cp--no-images';
	}
	if ( 'auto' !== $columns ) {
		$nav_classes[] = 'mvweb-cp--columns-' . $columns;
	}
	if ( ! empty( $extra_class ) ) {
		$nav_classes[] = $extra_class;
	}

	// Build HTML.
	$output = '';

	/**
	 * Fires before the child pages list.
	 *
	 * @since 1.0.0
	 * @param int   $parent_id Parent page ID.
	 * @param array $atts      Shortcode attributes.
	 */
	do_action( 'mvweb_cp_before_list', $parent_id, $atts );

	// The image box travels as CSS variables — one inline declaration on the
	// container instead of a class per possible size.
	$nav_style = '';
	if ( null !== $image_box && 'yes' === $show_image ) {
		$nav_classes[] = 'mvweb-cp--img-fixed';
		$nav_style     = ' style="--mvweb-cp-img-w:' . (int) $image_box['w'] . 'px;--mvweb-cp-img-h:' . (int) $image_box['h'] . 'px"';
	}

	$output .= '<nav class="' . esc_attr( implode( ' ', $nav_classes ) ) . '"' . $nav_style . ' aria-label="' . esc_attr__( 'Child pages', 'mvweb-child-pages' ) . '">';
	$output .= '<ul class="mvweb-cp__list">';

	// The placeholder is the same for every item — build it once.
	$placeholder_html = 'yes' === $show_image ? mvweb_cp_get_placeholder_html( $wp_image_size ) : '';

	foreach ( $children as $child ) {
		$item_html = '<li class="mvweb-cp__item">';
		$item_html .= '<a class="mvweb-cp__link" href="' . esc_url( get_permalink( $child->ID ) ) . '">';

		if ( 'yes' === $show_image ) {
			if ( has_post_thumbnail( $child->ID ) ) {
				$item_html .= wp_get_attachment_image(
					get_post_thumbnail_id( $child->ID ),
					$wp_image_size,
					false,
					array( 'class' => 'mvweb-cp__image' )
				);
			} else {
				$item_html .= $placeholder_html;
			}
		}

		$item_html .= '<div class="mvweb-cp__title">' . esc_html( get_the_title( $child->ID ) ) . '</div>';
		$item_html .= '</a>';
		$item_html .= '</li>';

		/**
		 * Filter single item HTML.
		 *
		 * @since 1.0.0
		 * @param string  $item_html Item HTML.
		 * @param WP_Post $child     Child page post object.
		 * @param array   $atts      Shortcode attributes.
		 */
		$output .= apply_filters( 'mvweb_cp_item_html', $item_html, $child, $atts );
	}

	$output .= '</ul>';
	$output .= '</nav>';

	/**
	 * Fires after the child pages list.
	 *
	 * @since 1.0.0
	 * @param int   $parent_id Parent page ID.
	 * @param array $atts      Shortcode attributes.
	 */
	do_action( 'mvweb_cp_after_list', $parent_id, $atts );

	return $output;
}

/**
 * Enqueue public assets (only when shortcode is used).
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_enqueue_public_assets() {
	static $enqueued = false;

	if ( $enqueued ) {
		return;
	}

	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	wp_enqueue_style(
		'mvweb-cp-public',
		MVWEB_CP_URL . 'public/css/public' . $suffix . '.css',
		array(),
		MVWEB_CP_VERSION
	);

	// Add custom CSS if set.
	$settings = mvweb_cp_get_settings();
	if ( ! empty( $settings['custom_css'] ) ) {
		wp_add_inline_style( 'mvweb-cp-public', $settings['custom_css'] );
	}

	$enqueued = true;
}

/**
 * Plugin activation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_activate() {
	if ( false === get_option( 'mvweb_cp_settings' ) ) {
		update_option( 'mvweb_cp_settings', mvweb_cp_get_defaults() );
	}
}
register_activation_hook( __FILE__, 'mvweb_cp_activate' );

/**
 * Plugin deactivation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_deactivate() {
	// Settings are preserved.
}
register_deactivation_hook( __FILE__, 'mvweb_cp_deactivate' );

// Include additional files.
require_once MVWEB_CP_PATH . 'includes/helpers.php';
