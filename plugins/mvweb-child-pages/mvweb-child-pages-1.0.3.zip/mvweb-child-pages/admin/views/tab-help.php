<?php
/**
 * Help tab template.
 *
 * @package MVweb_Child_Pages
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-help">
	<!-- Quick Start -->
	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Quick Start', 'mvweb-child-pages' ); ?></h2>
		<ol class="mvweb-help__steps">
			<li>
				<strong><?php esc_html_e( 'Find the parent page ID', 'mvweb-child-pages' ); ?></strong>
				<p><?php esc_html_e( 'Go to Pages in your WordPress admin and hover over the parent page. The ID is shown in the URL.', 'mvweb-child-pages' ); ?></p>
			</li>
			<li>
				<strong><?php esc_html_e( 'Add the shortcode', 'mvweb-child-pages' ); ?></strong>
				<p><?php esc_html_e( 'Insert the shortcode into any page or post:', 'mvweb-child-pages' ); ?> <code>[mvweb-cp id="123"]</code></p>
			</li>
			<li>
				<strong><?php esc_html_e( 'Customize (optional)', 'mvweb-child-pages' ); ?></strong>
				<p><?php esc_html_e( 'Adjust global defaults on the General tab, or override per shortcode using attributes.', 'mvweb-child-pages' ); ?></p>
			</li>
		</ol>
	</section>

	<!-- Shortcode Attributes -->
	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Shortcode Attributes', 'mvweb-child-pages' ); ?></h2>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Attribute', 'mvweb-child-pages' ); ?></th>
					<th><?php esc_html_e( 'Default', 'mvweb-child-pages' ); ?></th>
					<th><?php esc_html_e( 'Description', 'mvweb-child-pages' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><code>id</code></td>
					<td>—</td>
					<td><?php esc_html_e( 'Required. Parent page ID.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td><code>limit</code></td>
					<td><code>-1</code></td>
					<td><?php esc_html_e( 'Max number of child pages. -1 means all.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td><code>orderby</code></td>
					<td><code>menu_order</code></td>
					<td><?php esc_html_e( 'Sort by: menu_order, title, date, ID.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td><code>order</code></td>
					<td><code>ASC</code></td>
					<td><?php esc_html_e( 'Sort direction: ASC or DESC.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td><code>show_image</code></td>
					<td><?php esc_html_e( 'From settings', 'mvweb-child-pages' ); ?></td>
					<td><?php esc_html_e( 'Show images: yes or no.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td><code>class</code></td>
					<td>—</td>
					<td><?php esc_html_e( 'Extra CSS class for the list container.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td><code>image_size</code></td>
					<td><?php esc_html_e( 'From settings', 'mvweb-child-pages' ); ?></td>
					<td><?php esc_html_e( 'Image size: thumbnail, medium, large.', 'mvweb-child-pages' ); ?></td>
				</tr>
			</tbody>
		</table>

		<h3><?php esc_html_e( 'Examples', 'mvweb-child-pages' ); ?></h3>
		<pre><code>[mvweb-cp id="10"]
[mvweb-cp id="25" limit="5" orderby="title"]
[mvweb-cp id="42" show_image="no" order="DESC"]
[mvweb-cp id="10" class="my-custom-list" image_size="large"]</code></pre>
	</section>

	<!-- CSS Customization -->
	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'CSS Customization Examples', 'mvweb-child-pages' ); ?></h2>
		<p><?php esc_html_e( 'Use the Custom CSS tab to add your own styles. Here are some examples:', 'mvweb-child-pages' ); ?></p>

		<h3><?php esc_html_e( 'Change gap between items', 'mvweb-child-pages' ); ?></h3>
		<pre><code>.mvweb-cp {
    --mvweb-cp-gap: 30px;
}</code></pre>

		<h3><?php esc_html_e( 'Change item width', 'mvweb-child-pages' ); ?></h3>
		<pre><code>.mvweb-cp {
    --mvweb-cp-item-width: 300px;
}</code></pre>

		<h3><?php esc_html_e( 'Style a specific list by parent ID', 'mvweb-child-pages' ); ?></h3>
		<pre><code>.mvweb-cp--123 {
    --mvweb-cp-gap: 10px;
    --mvweb-cp-item-width: 200px;
}</code></pre>

		<h3><?php esc_html_e( 'Three-column grid layout', 'mvweb-child-pages' ); ?></h3>
		<pre><code>.mvweb-cp__list {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
}</code></pre>
	</section>

	<!-- FAQ -->
	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Frequently Asked Questions', 'mvweb-child-pages' ); ?></h2>

		<div class="mvweb-help__faq">
			<details class="mvweb-details">
				<summary><?php esc_html_e( 'Where do I find the page ID?', 'mvweb-child-pages' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'Go to Pages in your admin, hover over the page title, and look at the URL in the browser status bar. The number after "post=" is the page ID.', 'mvweb-child-pages' ); ?></p>
				</div>
			</details>

			<details class="mvweb-details">
				<summary><?php esc_html_e( 'Can I use multiple shortcodes on one page?', 'mvweb-child-pages' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'Yes! You can use as many shortcodes as needed, each with a different parent page ID.', 'mvweb-child-pages' ); ?></p>
				</div>
			</details>

			<details class="mvweb-details">
				<summary><?php esc_html_e( 'Why is my list empty?', 'mvweb-child-pages' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'Make sure the parent page exists, is published, is not password-protected, and has published child pages.', 'mvweb-child-pages' ); ?></p>
				</div>
			</details>

			<details class="mvweb-details">
				<summary><?php esc_html_e( 'What image is shown when a page has no featured image?', 'mvweb-child-pages' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'A placeholder image from the plugin is used. You can customize it via the mvweb_cp_placeholder_url filter.', 'mvweb-child-pages' ); ?></p>
				</div>
			</details>
		</div>
	</section>

	<!-- Support -->
	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Support', 'mvweb-child-pages' ); ?></h2>
		<p>
			<?php
			printf(
				/* translators: %s: MVweb plugin URL */
				esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-child-pages' ),
				'<a href="https://mvweb.ru/plugins/mvweb-child-pages" target="_blank">mvweb.ru</a>'
			);
			?>
		</p>
		<p>
			<strong><?php esc_html_e( 'Version:', 'mvweb-child-pages' ); ?></strong> <?php echo esc_html( MVWEB_CP_VERSION ); ?>
		</p>
	</section>
</div>
