<?php
/**
 * Helper functions for MVweb Child Pages
 *
 * @package MVweb_Child_Pages
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get default settings.
 *
 * @since 1.0.0
 * @return array Default settings.
 */
function mvweb_cp_get_defaults() {
	return array(
		'show_image' => 'yes',
		'image_size' => 'medium',
		'limit'      => -1,
		'orderby'    => 'menu_order',
		'order'      => 'ASC',
		'custom_css' => '',
	);
}

/**
 * Get plugin settings merged with defaults.
 *
 * @since 1.0.0
 * @return array Plugin settings.
 */
function mvweb_cp_get_settings() {
	$defaults = mvweb_cp_get_defaults();
	$settings = get_option( 'mvweb_cp_settings', array() );

	return wp_parse_args( $settings, $defaults );
}

/**
 * Log message to debug.log if WP_DEBUG is enabled.
 *
 * @since 1.0.0
 * @param mixed  $message Message to log.
 * @param string $level   Log level (info, warning, error).
 * @return void
 */
function mvweb_cp_log( $message, $level = 'info' ) {
	if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
		return;
	}

	if ( is_array( $message ) || is_object( $message ) ) {
		$message = print_r( $message, true );
	}

	$log_message = sprintf(
		'[MVweb Child Pages] [%s] %s',
		strtoupper( $level ),
		$message
	);

	// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
	error_log( $log_message );
}
