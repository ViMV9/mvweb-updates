<?php
/**
 * General settings tab.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package MVweb_Child_Pages
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = mvweb_cp_get_settings();
?>

<form method="post" action="">
	<?php wp_nonce_field( 'mvweb_cp_settings', 'mvweb_cp_nonce' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'General settings', 'mvweb-child-pages' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Default options for the child pages list. They can be overridden per shortcode.', 'mvweb-child-pages' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label">
				<?php esc_html_e( 'Show images', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_cp_show_image"
							name="mvweb_cp_show_image"
							value="1"
							<?php checked( $settings['show_image'], 'yes' ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Display featured images for child pages', 'mvweb-child-pages' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_cp_image_size" class="mvweb-form-row__label">
				<?php esc_html_e( 'Image size', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_cp_image_size" name="mvweb_cp_image_size" class="mvweb-select">
					<option value="thumbnail" <?php selected( $settings['image_size'], 'thumbnail' ); ?>><?php esc_html_e( 'Thumbnail', 'mvweb-child-pages' ); ?></option>
					<option value="medium" <?php selected( $settings['image_size'], 'medium' ); ?>><?php esc_html_e( 'Medium', 'mvweb-child-pages' ); ?></option>
					<option value="large" <?php selected( $settings['image_size'], 'large' ); ?>><?php esc_html_e( 'Large', 'mvweb-child-pages' ); ?></option>
				</select>
			</div>
		</div>

		<?php
		$placeholder_id  = absint( $settings['placeholder_id'] );
		$placeholder_url = $placeholder_id ? wp_get_attachment_image_url( $placeholder_id, 'medium' ) : '';
		if ( ! $placeholder_url ) {
			$placeholder_id = 0;
		}
		?>
		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label">
				<?php esc_html_e( 'Placeholder image', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-cp-media" data-mvweb-cp-media data-default-src="<?php echo esc_url( MVWEB_CP_URL . 'public/images/placeholder.svg' ); ?>">
					<div class="mvweb-cp-media__preview" data-mvweb-cp-media-preview>
						<?php if ( $placeholder_id ) : ?>
							<img src="<?php echo esc_url( $placeholder_url ); ?>" alt="">
						<?php else : ?>
							<img src="<?php echo esc_url( MVWEB_CP_URL . 'public/images/placeholder.svg' ); ?>" alt="">
						<?php endif; ?>
					</div>
					<div class="mvweb-cp-media__actions">
						<button type="button" class="mvweb-btn" data-mvweb-cp-media-select>
							<?php esc_html_e( 'Choose image', 'mvweb-child-pages' ); ?>
						</button>
						<button type="button" class="mvweb-btn mvweb-btn--ghost" data-mvweb-cp-media-clear <?php disabled( 0, $placeholder_id ); ?>>
							<?php esc_html_e( 'Reset to default', 'mvweb-child-pages' ); ?>
						</button>
					</div>
					<input type="hidden"
						id="mvweb_cp_placeholder_id"
						name="mvweb_cp_placeholder_id"
						value="<?php echo esc_attr( (string) $placeholder_id ); ?>"
						data-mvweb-cp-media-input>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Shown instead of a featured image when a child page has none. Leave empty to use the image bundled with the plugin.', 'mvweb-child-pages' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_cp_limit" class="mvweb-form-row__label">
				<?php esc_html_e( 'Default limit', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
					id="mvweb_cp_limit"
					name="mvweb_cp_limit"
					value="<?php echo esc_attr( $settings['limit'] ); ?>"
					min="-1"
					class="mvweb-input">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Maximum number of child pages to display. Use -1 for no limit.', 'mvweb-child-pages' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_cp_orderby" class="mvweb-form-row__label">
				<?php esc_html_e( 'Default order by', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_cp_orderby" name="mvweb_cp_orderby" class="mvweb-select">
					<option value="menu_order" <?php selected( $settings['orderby'], 'menu_order' ); ?>><?php esc_html_e( 'Menu order', 'mvweb-child-pages' ); ?></option>
					<option value="title" <?php selected( $settings['orderby'], 'title' ); ?>><?php esc_html_e( 'Title', 'mvweb-child-pages' ); ?></option>
					<option value="date" <?php selected( $settings['orderby'], 'date' ); ?>><?php esc_html_e( 'Date', 'mvweb-child-pages' ); ?></option>
					<option value="ID" <?php selected( $settings['orderby'], 'ID' ); ?>><?php esc_html_e( 'ID', 'mvweb-child-pages' ); ?></option>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Menu order uses the "Order" field from each page\'s attributes (also available in Quick Edit). Pages with no number set are placed at the end, so a newly created page never jumps to the top.', 'mvweb-child-pages' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_cp_order" class="mvweb-form-row__label">
				<?php esc_html_e( 'Default order', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_cp_order" name="mvweb_cp_order" class="mvweb-select">
					<option value="ASC" <?php selected( $settings['order'], 'ASC' ); ?>><?php esc_html_e( 'Ascending', 'mvweb-child-pages' ); ?></option>
					<option value="DESC" <?php selected( $settings['order'], 'DESC' ); ?>><?php esc_html_e( 'Descending', 'mvweb-child-pages' ); ?></option>
				</select>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_cp_save" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Changes', 'mvweb-child-pages' ); ?>
		</button>
	</div>
</form>
