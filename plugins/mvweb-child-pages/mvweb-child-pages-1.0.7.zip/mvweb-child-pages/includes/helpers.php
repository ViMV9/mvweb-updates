<?php
/**
 * Helper functions for MVweb Child Pages
 *
 * @package MVweb_Child_Pages
 * @since   1.0.0
 */

declare(strict_types=1);

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get default settings.
 *
 * @since 1.0.0
 * @return array Default settings.
 */
function mvweb_cp_get_defaults() {
	return array(
		'show_image'     => 'yes',
		'image_size'     => 'medium',
		'limit'          => -1,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'placeholder_id' => 0,
		'custom_css'     => '',
	);
}

/**
 * Get plugin settings merged with defaults.
 *
 * @since 1.0.0
 * @return array Plugin settings.
 */
function mvweb_cp_get_settings() {
	$defaults = mvweb_cp_get_defaults();
	$settings = get_option( 'mvweb_cp_settings', array() );

	return wp_parse_args( $settings, $defaults );
}

/**
 * Get the placeholder image markup shown when a child page has no featured image.
 *
 * Prefers the image picked on the settings page; falls back to the bundled SVG,
 * whose URL stays filterable for setups that never open the settings screen.
 *
 * @since 1.0.7
 * @param string $image_size Registered image size to render.
 * @return string Image HTML.
 */
function mvweb_cp_get_placeholder_html( $image_size ) {
	$settings       = mvweb_cp_get_settings();
	$placeholder_id = absint( $settings['placeholder_id'] );

	if ( $placeholder_id > 0 ) {
		$html = wp_get_attachment_image(
			$placeholder_id,
			$image_size,
			false,
			array(
				'class'   => 'mvweb-cp__image mvweb-cp__image--placeholder',
				'alt'     => '',
				'loading' => 'lazy',
			)
		);

		// Empty when the attachment was deleted — fall through to the bundled SVG.
		if ( '' !== $html ) {
			return $html;
		}
	}

	/**
	 * Filter placeholder image URL.
	 *
	 * @since 1.0.0
	 * @param string $url Placeholder URL.
	 */
	$url = apply_filters( 'mvweb_cp_placeholder_url', MVWEB_CP_URL . 'public/images/placeholder.svg' );

	return '<img class="mvweb-cp__image mvweb-cp__image--placeholder" src="' . esc_url( $url ) . '" alt="" loading="lazy">';
}

/**
 * Log message to debug.log if WP_DEBUG is enabled.
 *
 * @since 1.0.0
 * @param mixed  $message Message to log.
 * @param string $level   Log level (info, warning, error).
 * @return void
 */
function mvweb_cp_log( $message, $level = 'info' ) {
	if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
		return;
	}

	if ( is_array( $message ) || is_object( $message ) ) {
		$message = print_r( $message, true );
	}

	$log_message = sprintf(
		'[MVweb Child Pages] [%s] %s',
		strtoupper( $level ),
		$message
	);

	// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
	error_log( $log_message );
}
