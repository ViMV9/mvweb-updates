# Changelog

All notable changes to MVweb Child Pages will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.4] - 2026-06-03

### Changed
- Migrated admin UI to the new MVweb Admin UI Kit (slate palette, Yoast-style sidebar layout)
- `admin.css` replaced with the current boilerplate UI Kit
- Updated bundled `MVweb_Menu` shared class to v2.2.0
- Settings page split into per-tab partials (`tab-general.php`, `tab-custom-css.php`, `tab-help.php`) using `.mvweb-form-row`, `.mvweb-toggle`, `.mvweb-block`, `.mvweb-steps`, `.mvweb-faq`, `.mvweb-table`, `.mvweb-codeblock`
- Tab navigation reworked from WP `.nav-tab` to UI Kit `.mvweb-nav` (admin.js + plugin.css updated)
- Localized the Hub registration `name` and `description` strings (the Hub card now shows «MVweb Дочерние страницы» in ru_RU)

### Added
- `languages/` with `.pot`, `ru_RU.po`/`.mo` (plugin + MVweb Hub strings) and README
- `images/mv-logo-violet.png` for the MVweb Hub brand logo
- `build:locale` npm script
- `declare(strict_types=1)` in `includes/helpers.php`

### Fixed
- Tab panels: restored `.mvweb-tab-content` / `.active` show-hide rules in `plugin.css` (all tabs were rendering stacked on one screen)
- Quick start steps: wrapped each `.mvweb-steps li` content in a `<div>` so it lands in the grid text column (text was breaking one word per line)
- Help code examples: switched from the dark UI Kit `.mvweb-codeblock` to a light plugin `.mvweb-cp-code` card
- Help FAQ: attached the open answer to its question as a single card (the answer was detached below the summary)
- Block head spacing: `.mvweb-block__head` now keeps a 16px gap to the content when the block has no `.mvweb-block__sub` (e.g. the FAQ block) — the UI Kit only spaced it via `__sub`'s margin

## [1.0.3] - 2026-02-10

### Changed
- Admin CSS: updated `admin.css` to latest UI Kit "Classic Clean" boilerplate with new components (`.mvweb-details`, `.mvweb-badge`, `.mvweb-toggle`, `.mvweb-textarea`)
- Settings page: input uses `mvweb-input` class, descriptions use `mvweb-help-text` class

### Fixed
- UI Kit: checkbox vertical alignment (`translate -65%`), input font-size (`14px`), notice spacing

## [1.0.2] - 2026-02-09

### Fixed
- Tab hover: smooth transition via `transition: all 0.2s ease` (matching UI Kit standard)
- Tab hover underline removed via admin.css (UI Kit level fix)

## [1.0.1] - 2026-02-09

### Fixed
- Natural sort for title ordering: digits always come before letters, numeric titles sort as numbers (11 > 9 instead of lexicographic "11" < "9")

## [1.0.0] - 2026-02-09

### Added
- Shortcode `[mvweb-cp id="..."]` to display child pages
- Shortcode attributes: id, limit, orderby, order, show_image, class, image_size
- Admin settings page with General, Custom CSS, and Help tabs
- Global defaults for image display, size, limit, sorting
- Custom CSS field with frontend-only output via `wp_add_inline_style()`
- Responsive flex layout with CSS variables
- Placeholder SVG for pages without featured image
- BEM modifiers: `--{parent_id}`, `--no-images`, `--empty`
- Parent page validation (existence, type, status, password)
- Filters: `mvweb_cp_query_args`, `mvweb_cp_item_html`, `mvweb_cp_shortcode_atts`, `mvweb_cp_placeholder_url`
- Actions: `mvweb_cp_before_list`, `mvweb_cp_after_list`
- Russian (ru_RU) translation
- Help tab with Quick Start, attributes table, CSS examples, FAQ
- MVweb Hub integration
- Auto-update support via PUC
