/**
 * Admin JavaScript for MVweb Child Pages
 *
 * @package MVweb_Child_Pages
 * @since   1.0.0
 */

(function() {
	'use strict';

	/**
	 * Allowed tab IDs (whitelist).
	 */
	var ALLOWED_TABS = ['general', 'custom-css', 'help'];

	/**
	 * Initialize tab navigation.
	 */
	function initTabs() {
		var tabs = document.querySelectorAll('.mvweb-nav__link');
		var contents = document.querySelectorAll('.mvweb-tab-content');

		if (!tabs.length) {
			return;
		}

		tabs.forEach(function(tab) {
			tab.addEventListener('click', function(e) {
				e.preventDefault();

				var tabId = this.getAttribute('data-tab');

				if (ALLOWED_TABS.indexOf(tabId) === -1) {
					return;
				}

				// Update active tab.
				tabs.forEach(function(t) {
					t.classList.remove('mvweb-nav__link--active');
				});
				this.classList.add('mvweb-nav__link--active');

				// Show corresponding content.
				contents.forEach(function(c) {
					c.classList.remove('active');
				});

				var target = document.getElementById(tabId);
				if (target) {
					target.classList.add('active');
				}

				// Update URL hash.
				if (window.history && window.history.pushState) {
					window.history.pushState(null, '', '#' + tabId);
				}
			});
		});

		// Activate tab from URL hash on load.
		var hash = window.location.hash.substring(1);
		if (hash && ALLOWED_TABS.indexOf(hash) !== -1) {
			var hashTab = document.querySelector('.mvweb-nav__link[data-tab="' + hash + '"]');
			if (hashTab) {
				hashTab.click();
			}
		}
	}

	document.addEventListener('DOMContentLoaded', initTabs);
})();
