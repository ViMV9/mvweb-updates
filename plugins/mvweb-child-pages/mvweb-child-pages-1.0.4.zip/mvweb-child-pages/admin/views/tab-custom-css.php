<?php
/**
 * Custom CSS tab.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package MVweb_Child_Pages
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = mvweb_cp_get_settings();
?>

<form method="post" action="">
	<?php wp_nonce_field( 'mvweb_cp_settings', 'mvweb_cp_nonce' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Custom CSS', 'mvweb-child-pages' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'These styles load only on pages that use the shortcode.', 'mvweb-child-pages' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb_cp_custom_css" class="mvweb-form-row__label">
				<?php esc_html_e( 'CSS rules', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb_cp_custom_css"
					name="mvweb_cp_custom_css"
					rows="12"
					class="mvweb-textarea"><?php echo esc_textarea( $settings['custom_css'] ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Add custom CSS styles for the child pages output.', 'mvweb-child-pages' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_cp_save" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Changes', 'mvweb-child-pages' ); ?>
		</button>
	</div>
</form>
