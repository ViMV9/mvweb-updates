<?php
/**
 * General settings tab.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package MVweb_Child_Pages
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = mvweb_cp_get_settings();
?>

<form method="post" action="">
	<?php wp_nonce_field( 'mvweb_cp_settings', 'mvweb_cp_nonce' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'General settings', 'mvweb-child-pages' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Default options for the child pages list. They can be overridden per shortcode.', 'mvweb-child-pages' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label">
				<?php esc_html_e( 'Show images', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_cp_show_image"
							name="mvweb_cp_show_image"
							value="1"
							<?php checked( $settings['show_image'], 'yes' ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Display featured images for child pages', 'mvweb-child-pages' ); ?></span>
				</div>
			</div>
		</div>

		<?php
		// Legacy values (the registered WordPress sizes) mean «full card width».
		$image_size = in_array( $settings['image_size'], mvweb_cp_get_allowed_image_sizes(), true ) ? $settings['image_size'] : 'full';
		?>
		<div class="mvweb-form-row">
			<label for="mvweb_cp_image_size" class="mvweb-form-row__label">
				<?php esc_html_e( 'Image size', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_cp_image_size" name="mvweb_cp_image_size" class="mvweb-select" data-mvweb-cp-image-size>
					<option value="full" <?php selected( $image_size, 'full' ); ?>><?php esc_html_e( 'Full card width', 'mvweb-child-pages' ); ?></option>
					<option value="100" <?php selected( $image_size, '100' ); ?>><?php esc_html_e( 'Small — 100×100', 'mvweb-child-pages' ); ?></option>
					<option value="200" <?php selected( $image_size, '200' ); ?>><?php esc_html_e( 'Medium — 200×200', 'mvweb-child-pages' ); ?></option>
					<option value="300" <?php selected( $image_size, '300' ); ?>><?php esc_html_e( 'Large — 300×300', 'mvweb-child-pages' ); ?></option>
					<option value="custom" <?php selected( $image_size, 'custom' ); ?>><?php esc_html_e( 'Custom size', 'mvweb-child-pages' ); ?></option>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'The size is applied with CSS and the image is cropped to fit, so no new thumbnails are created on the server. Full card width keeps the original proportions.', 'mvweb-child-pages' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row" data-mvweb-cp-image-custom <?php echo 'custom' === $image_size ? '' : 'hidden'; ?>>
			<label for="mvweb_cp_image_width" class="mvweb-form-row__label">
				<?php esc_html_e( 'Custom size, px', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-cp-size">
					<input type="number"
						id="mvweb_cp_image_width"
						name="mvweb_cp_image_width"
						value="<?php echo esc_attr( (string) absint( $settings['image_width'] ) ); ?>"
						min="1"
						max="2000"
						class="mvweb-input"
						aria-label="<?php esc_attr_e( 'Width, px', 'mvweb-child-pages' ); ?>">
					<span aria-hidden="true">×</span>
					<input type="number"
						id="mvweb_cp_image_height"
						name="mvweb_cp_image_height"
						value="<?php echo esc_attr( (string) absint( $settings['image_height'] ) ); ?>"
						min="1"
						max="2000"
						class="mvweb-input"
						aria-label="<?php esc_attr_e( 'Height, px', 'mvweb-child-pages' ); ?>">
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Width and height of the image box. On phones the image stretches to the card width and keeps this height.', 'mvweb-child-pages' ); ?>
				</p>
			</div>
		</div>

		<?php
		$placeholder_id  = absint( $settings['placeholder_id'] );
		$placeholder_url = $placeholder_id ? wp_get_attachment_image_url( $placeholder_id, 'medium' ) : '';
		if ( ! $placeholder_url ) {
			$placeholder_id = 0;
		}
		?>
		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label">
				<?php esc_html_e( 'Placeholder image', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-cp-media" data-mvweb-cp-media data-default-src="<?php echo esc_url( MVWEB_CP_URL . 'public/images/placeholder.svg' ); ?>">
					<div class="mvweb-cp-media__preview" data-mvweb-cp-media-preview>
						<?php if ( $placeholder_id ) : ?>
							<img src="<?php echo esc_url( $placeholder_url ); ?>" alt="">
						<?php else : ?>
							<img src="<?php echo esc_url( MVWEB_CP_URL . 'public/images/placeholder.svg' ); ?>" alt="">
						<?php endif; ?>
					</div>
					<div class="mvweb-cp-media__actions">
						<button type="button" class="mvweb-btn" data-mvweb-cp-media-select>
							<?php esc_html_e( 'Choose image', 'mvweb-child-pages' ); ?>
						</button>
						<button type="button" class="mvweb-btn mvweb-btn--ghost" data-mvweb-cp-media-clear <?php disabled( 0, $placeholder_id ); ?>>
							<?php esc_html_e( 'Reset to default', 'mvweb-child-pages' ); ?>
						</button>
					</div>
					<input type="hidden"
						id="mvweb_cp_placeholder_id"
						name="mvweb_cp_placeholder_id"
						value="<?php echo esc_attr( (string) $placeholder_id ); ?>"
						data-mvweb-cp-media-input>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Shown instead of a featured image when a child page has none. Leave empty to use the image bundled with the plugin.', 'mvweb-child-pages' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_cp_columns" class="mvweb-form-row__label">
				<?php esc_html_e( 'Columns', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_cp_columns" name="mvweb_cp_columns" class="mvweb-select">
					<option value="auto" <?php selected( $settings['columns'], 'auto' ); ?>><?php esc_html_e( 'Auto', 'mvweb-child-pages' ); ?></option>
					<option value="2" <?php selected( $settings['columns'], '2' ); ?>><?php esc_html_e( '2 columns', 'mvweb-child-pages' ); ?></option>
					<option value="3" <?php selected( $settings['columns'], '3' ); ?>><?php esc_html_e( '3 columns', 'mvweb-child-pages' ); ?></option>
					<option value="4" <?php selected( $settings['columns'], '4' ); ?>><?php esc_html_e( '4 columns', 'mvweb-child-pages' ); ?></option>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Auto fits as many cards per row as the available width allows. A fixed count still drops to two columns on tablets and one on phones.', 'mvweb-child-pages' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_cp_empty_text" class="mvweb-form-row__label">
				<?php esc_html_e( 'Text when the list is empty', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb_cp_empty_text"
					name="mvweb_cp_empty_text"
					rows="2"
					class="mvweb-textarea"><?php echo esc_textarea( $settings['empty_text'] ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Shown in place of the list when the parent page has no published child pages. Leave empty to show nothing at all.', 'mvweb-child-pages' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_cp_limit" class="mvweb-form-row__label">
				<?php esc_html_e( 'Default limit', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
					id="mvweb_cp_limit"
					name="mvweb_cp_limit"
					value="<?php echo esc_attr( (int) $settings['limit'] > 0 ? $settings['limit'] : '' ); ?>"
					min="1"
					step="1"
					placeholder="<?php esc_attr_e( 'All', 'mvweb-child-pages' ); ?>"
					class="mvweb-input">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'How many child pages to show at most. Leave the field empty to show all of them.', 'mvweb-child-pages' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_cp_orderby" class="mvweb-form-row__label">
				<?php esc_html_e( 'Default order by', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_cp_orderby" name="mvweb_cp_orderby" class="mvweb-select">
					<option value="menu_order" <?php selected( $settings['orderby'], 'menu_order' ); ?>><?php esc_html_e( 'Menu order', 'mvweb-child-pages' ); ?></option>
					<option value="title" <?php selected( $settings['orderby'], 'title' ); ?>><?php esc_html_e( 'Title', 'mvweb-child-pages' ); ?></option>
					<option value="date" <?php selected( $settings['orderby'], 'date' ); ?>><?php esc_html_e( 'Date', 'mvweb-child-pages' ); ?></option>
					<option value="ID" <?php selected( $settings['orderby'], 'ID' ); ?>><?php esc_html_e( 'ID', 'mvweb-child-pages' ); ?></option>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Menu order uses the "Order" field from each page\'s attributes (also available in Quick Edit). Pages with no number set are placed at the end, so a newly created page never jumps to the top.', 'mvweb-child-pages' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_cp_order" class="mvweb-form-row__label">
				<?php esc_html_e( 'Default order', 'mvweb-child-pages' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_cp_order" name="mvweb_cp_order" class="mvweb-select">
					<option value="ASC" <?php selected( $settings['order'], 'ASC' ); ?>><?php esc_html_e( 'Ascending', 'mvweb-child-pages' ); ?></option>
					<option value="DESC" <?php selected( $settings['order'], 'DESC' ); ?>><?php esc_html_e( 'Descending', 'mvweb-child-pages' ); ?></option>
				</select>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_cp_save" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Changes', 'mvweb-child-pages' ); ?>
		</button>
	</div>
</form>
