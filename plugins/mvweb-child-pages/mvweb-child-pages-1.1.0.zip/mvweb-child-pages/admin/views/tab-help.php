<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package MVweb_Child_Pages
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-child-pages' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Put the shortcode on the parent page', 'mvweb-child-pages' ); ?></strong>
			<p><?php esc_html_e( 'Editing the page whose children you want to list? Then the plain shortcode is all you need — it takes the children of the page it sits on:', 'mvweb-child-pages' ); ?> <code>[mvweb-cp]</code></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Listing another page\'s children', 'mvweb-child-pages' ); ?></strong>
			<p><?php esc_html_e( 'Add the parent page ID: go to Pages, hover over the parent page and read the ID from the URL.', 'mvweb-child-pages' ); ?> <code>[mvweb-cp id="123"]</code></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Customize (optional)', 'mvweb-child-pages' ); ?></strong>
			<p><?php esc_html_e( 'Adjust global defaults on the General tab, or override per shortcode using attributes.', 'mvweb-child-pages' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Shortcode attributes', 'mvweb-child-pages' ); ?></div>
	</div>

	<div class="mvweb-table-wrap">
		<table class="mvweb-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Attribute', 'mvweb-child-pages' ); ?></th>
					<th><?php esc_html_e( 'Default', 'mvweb-child-pages' ); ?></th>
					<th><?php esc_html_e( 'Description', 'mvweb-child-pages' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td class="cell-mono">id</td>
					<td><?php esc_html_e( 'Current page', 'mvweb-child-pages' ); ?></td>
					<td><?php esc_html_e( 'Which page to take child pages from. Leave it out and the shortcode uses the page it is placed on — set it only to list the children of a different page.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">limit</td>
					<td><?php esc_html_e( 'From settings', 'mvweb-child-pages' ); ?></td>
					<td><?php esc_html_e( 'How many child pages to show at most. Leave it out to show them all.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">orderby</td>
					<td class="cell-mono">menu_order</td>
					<td><?php esc_html_e( 'How to order the pages: by their manual order (menu_order), alphabetically (title), by publish date (date) or by ID. See "How do I set my own page order?" in the FAQ below.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">order</td>
					<td class="cell-mono">ASC</td>
					<td><?php esc_html_e( 'Direction of the order: ASC for ascending (A→Z, old→new), DESC for descending.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">show_image</td>
					<td><?php esc_html_e( 'From settings', 'mvweb-child-pages' ); ?></td>
					<td><?php esc_html_e( 'Whether to show the featured image of each page. Use yes or no to override the global setting.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">class</td>
					<td>—</td>
					<td><?php esc_html_e( 'Your own CSS class on the list container, handy for custom styling of a specific list.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">image_size</td>
					<td><?php esc_html_e( 'From settings', 'mvweb-child-pages' ); ?></td>
					<td><?php esc_html_e( 'Size of the image box: full (the whole card width), a preset 100, 200, 300, or your own pair like 240x160. The image is cropped to fit by CSS.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">exclude</td>
					<td>—</td>
					<td><?php esc_html_e( 'IDs of child pages to leave out of the list, separated by commas. The pages stay published, they just do not appear in this list.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">columns</td>
					<td><?php esc_html_e( 'From settings', 'mvweb-child-pages' ); ?></td>
					<td><?php esc_html_e( 'How many cards per row: auto, 2, 3 or 4. Auto fits as many as the width allows; a fixed count still drops to two columns on tablets and one on phones.', 'mvweb-child-pages' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<p class="mvweb-block__sub"><?php esc_html_e( 'Examples', 'mvweb-child-pages' ); ?></p>
	<pre class="mvweb-cp-code"><code>[mvweb-cp]
[mvweb-cp id="10"]
[mvweb-cp id="25" limit="5" orderby="title"]
[mvweb-cp id="42" show_image="no" order="DESC"]
[mvweb-cp id="10" class="my-custom-list" image_size="large"]
[mvweb-cp id="10" exclude="12,15"]
[mvweb-cp id="10" columns="3"]
[mvweb-cp id="10" image_size="200"]
[mvweb-cp id="10" image_size="240x160"]</code></pre>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'CSS customization examples', 'mvweb-child-pages' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Use the Custom CSS tab to add your own styles. Here are some examples:', 'mvweb-child-pages' ); ?></p>

	<pre class="mvweb-cp-code"><code>/* <?php esc_html_e( 'Gap between items', 'mvweb-child-pages' ); ?> */
.mvweb-cp { --mvweb-cp-gap: 30px; }

/* <?php esc_html_e( 'Item width', 'mvweb-child-pages' ); ?> */
.mvweb-cp { --mvweb-cp-item-width: 300px; }

/* <?php esc_html_e( 'Styling one specific list by parent page ID', 'mvweb-child-pages' ); ?> */
.mvweb-cp--123 {
    --mvweb-cp-gap: 10px;
    --mvweb-cp-item-width: 200px;
}

/* <?php esc_html_e( 'Text shown when the list is empty', 'mvweb-child-pages' ); ?> */
.mvweb-cp-empty {
    font-style: italic;
    color: #666;
}</code></pre>
	<p class="mvweb-form-row__desc"><?php esc_html_e( 'The number of columns no longer needs CSS — set it on the General tab or with the columns attribute.', 'mvweb-child-pages' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-child-pages' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Where do I find the page ID?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Go to Pages in your admin, hover over the page title, and look at the URL in the browser status bar. The number after "post=" is the page ID.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How do I set my own page order?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'The manual order lives in WordPress itself, not in this plugin. Open a child page for editing and set the "Order" field: in the block editor it is under Page → Page Attributes in the right sidebar, in the classic editor it is the "Page Attributes" box. The list is then sorted by that number, smallest first.', 'mvweb-child-pages' ); ?></p>
			<p><?php esc_html_e( 'Faster for several pages at once: go to Pages, hover a page and click Quick Edit — the "Order" field is right there, so you can renumber the whole list without opening each page.', 'mvweb-child-pages' ); ?></p>
			<p><?php esc_html_e( 'Tip: number the pages with gaps (10, 20, 30) instead of 1, 2, 3. Then you can insert a page between two others by giving it 15, without renumbering everything.', 'mvweb-child-pages' ); ?></p>
			<p><?php esc_html_e( 'This only applies when "Order by" is set to Menu order — with Title, Date or ID the Order field is ignored.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Where does a newly created page appear in the list?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'At the end. WordPress gives every new page an Order of 0, and the plugin treats 0 as "position not set", so such pages are placed after all numbered ones — a page you add later never jumps to the top of a list you have arranged by hand.', 'mvweb-child-pages' ); ?></p>
			<p><?php esc_html_e( 'Pages that all have Order 0 are sorted by ID, i.e. in the order they were created (reversed when the direction is Descending). To move a new page to a specific spot, just give it an Order number.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How do I hide a single page from the list?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Use the exclude attribute with the page IDs, separated by commas:', 'mvweb-child-pages' ); ?> <code>[mvweb-cp id="10" exclude="12,15"]</code></p>
			<p><?php esc_html_e( 'The excluded pages stay published and reachable by their own URL — they are only left out of this particular list. Each shortcode has its own exclusions, so the same page can be hidden in one list and shown in another.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I use multiple shortcodes on one page?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes! You can use as many shortcodes as needed, each with a different parent page ID.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Why is my list empty?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Open the page while logged in: if the list cannot be built, the plugin now prints the reason right where the list would be — wrong page ID, parent not published, password-protected, or simply no published child pages yet.', 'mvweb-child-pages' ); ?></p>
			<p><?php esc_html_e( 'Visitors never see that message, only users who can edit content do. If you use a caching plugin, clear its cache after fixing the page, otherwise you may keep seeing the old version.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I show a message instead of an empty spot?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes. Fill in "Text when the list is empty" on the General tab — it is shown to everyone in place of the list whenever the parent page has no published child pages. Leave the field empty and nothing is output at all, which is the default.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How big are the images, and why do they all look the same?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'The image box is set on the General tab: full card width (the original proportions, as before), a 100, 200 or 300 pixel square, or your own width and height. The same goes into a single shortcode as image_size:', 'mvweb-child-pages' ); ?> <code>[mvweb-cp id="10" image_size="240x160"]</code></p>
			<p><?php esc_html_e( 'The size is applied with CSS and the image is cropped to fill the box, so no extra thumbnails are generated on the server. That also means the setting works with small uploads, where WordPress never created the larger sizes and every option used to give exactly the same picture.', 'mvweb-child-pages' ); ?></p>
			<p><?php esc_html_e( 'On phones a fixed-size image stretches to the card width and keeps the chosen height, so a single narrow column still looks even.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How do I change the number of columns?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Set "Columns" on the General tab, or override it for one list with the attribute:', 'mvweb-child-pages' ); ?> <code>[mvweb-cp id="10" columns="3"]</code></p>
			<p><?php esc_html_e( 'Auto keeps the current behaviour: cards are about 250px wide and as many as fit go into a row. Whatever you pick, tablets get two columns and phones get one, so the cards stay readable.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'What image is shown when a page has no featured image?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'The placeholder picked on the General tab — press "Choose image" there and take any image from the media library. With nothing picked, the plugin falls back to its own bundled image. Developers can still override that fallback through the mvweb_cp_placeholder_url filter.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-child-pages' ); ?></div>
	</div>
	<p>
		<?php
		echo wp_kses_post(
			sprintf(
				/* translators: %s: MVweb plugin URL */
				__( 'Need help? Visit %s for documentation and support.', 'mvweb-child-pages' ),
				'<a href="https://mvweb.ru/plugins/mvweb-child-pages" target="_blank" rel="noopener noreferrer">mvweb.ru</a>'
			)
		);
		?>
	</p>
	<p>
		<strong><?php esc_html_e( 'Version:', 'mvweb-child-pages' ); ?></strong> <?php echo esc_html( MVWEB_CP_VERSION ); ?>
	</p>
</div>
