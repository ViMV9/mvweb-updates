<?php
/**
 * Helper functions for MVweb Child Pages
 *
 * @package MVweb_Child_Pages
 * @since   1.0.0
 */

declare(strict_types=1);

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get default settings.
 *
 * @since 1.0.0
 * @return array Default settings.
 */
function mvweb_cp_get_defaults() {
	return array(
		'show_image'     => 'yes',
		'image_size'     => 'full',
		'image_width'    => 200,
		'image_height'   => 200,
		'limit'          => -1,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'columns'        => 'auto',
		'placeholder_id' => 0,
		'empty_text'     => '',
		'custom_css'     => '',
	);
}

/**
 * Column counts the list can be locked to, besides the default 'auto'.
 *
 * @since 1.1.0
 * @return array List of allowed values.
 */
function mvweb_cp_get_allowed_columns() {
	return array( 'auto', '2', '3', '4' );
}

/**
 * Image size presets offered in the settings, besides 'custom'.
 *
 * @since 1.1.0
 * @return array List of allowed values.
 */
function mvweb_cp_get_allowed_image_sizes() {
	return array( 'full', '100', '200', '300', 'custom' );
}

/**
 * Work out the pixel box an image should be drawn in.
 *
 * The size is applied with CSS instead of a registered WordPress size: sites
 * rarely have every intermediate size generated (a 300px upload has no «large»
 * file at all), so picking a registered size changed the file but never the
 * rendered result — the card CSS stretches the image to full width either way.
 * A CSS box crops predictably and needs no new files on the server.
 *
 * @since 1.1.0
 * @param string $value    Preset, WxH pair, single number, or a legacy size name.
 * @param array  $settings Plugin settings, for the custom width/height.
 * @return array|null { w, h } in pixels, or null for «full card width».
 */
function mvweb_cp_parse_image_box( $value, $settings ) {
	$value = strtolower( trim( (string) $value ) );

	// Legacy values: the registered WordPress sizes this setting used to hold.
	// They never changed how large the image looked, so they map to «no box» —
	// which is exactly what those sites are already rendering today.
	if ( '' === $value || in_array( $value, array( 'full', 'thumbnail', 'medium', 'large' ), true ) ) {
		return null;
	}

	if ( 'custom' === $value ) {
		$width  = absint( $settings['image_width'] );
		$height = absint( $settings['image_height'] );
		// Separators: Latin x, Cyrillic х (same key on a Russian layout), the
		// multiplication sign and the asterisk. Capitals are listed explicitly
		// because strtolower() above only folds ASCII, not Cyrillic. Digits are
		// [0-9] rather than \d, which under /u also matches non-Latin digits
		// that absint() would then silently turn into zero.
	} elseif ( preg_match( '/^([0-9]+)\s*[xXхХ×*]\s*([0-9]+)$/u', $value, $matches ) ) {
		$width  = absint( $matches[1] );
		$height = absint( $matches[2] );
	} elseif ( ctype_digit( $value ) ) {
		$width  = absint( $value );
		$height = $width;
	} else {
		return null;
	}

	if ( $width < 1 || $height < 1 ) {
		return null;
	}

	return array(
		'w' => min( $width, 2000 ),
		'h' => min( $height, 2000 ),
	);
}

/**
 * Pick the registered WordPress size to request for a given box.
 *
 * Keeps the downloaded file close to what is actually drawn, without
 * registering any size of our own.
 *
 * @since 1.1.0
 * @param array|null $box Box from mvweb_cp_parse_image_box().
 * @return string Registered image size name.
 */
function mvweb_cp_get_wp_image_size( $box ) {
	if ( null === $box || $box['w'] > 300 ) {
		return 'large';
	}

	return $box['w'] <= 150 ? 'thumbnail' : 'medium';
}

/**
 * Get the output for a list that cannot be rendered.
 *
 * Users who can edit content see the reason on the page — an empty spot with no
 * explanation is the hardest thing to debug. Everyone else keeps getting the
 * HTML comment the plugin has always emitted: invisible on the page and to a
 * search engine, though still readable in the page source, so $debug carries
 * the page id and nothing more.
 *
 * @since 1.1.0
 * @param string $debug   Machine-readable reason for the HTML comment.
 * @param string $message Human-readable reason for editors.
 * @return string HTML output.
 */
function mvweb_cp_get_notice_html( $debug, $message ) {
	if ( ! current_user_can( 'edit_posts' ) ) {
		return '<!-- mvweb-cp: ' . $debug . ' -->';
	}

	// The notice is styled markup, and it is returned from points that sit
	// before the regular enqueue call — load the stylesheet here as well.
	mvweb_cp_enqueue_public_assets();

	return '<div class="mvweb-cp-notice"><b>MVweb Child Pages:</b> ' . esc_html( $message ) . '</div>';
}

/**
 * Get plugin settings merged with defaults.
 *
 * @since 1.0.0
 * @return array Plugin settings.
 */
function mvweb_cp_get_settings() {
	$defaults = mvweb_cp_get_defaults();
	$settings = get_option( 'mvweb_cp_settings', array() );

	return wp_parse_args( $settings, $defaults );
}

/**
 * Get the placeholder image markup shown when a child page has no featured image.
 *
 * Prefers the image picked on the settings page; falls back to the bundled SVG,
 * whose URL stays filterable for setups that never open the settings screen.
 *
 * @since 1.0.7
 * @param string $image_size Registered image size to render.
 * @return string Image HTML.
 */
function mvweb_cp_get_placeholder_html( $image_size ) {
	$settings       = mvweb_cp_get_settings();
	$placeholder_id = absint( $settings['placeholder_id'] );

	if ( $placeholder_id > 0 ) {
		$html = wp_get_attachment_image(
			$placeholder_id,
			$image_size,
			false,
			array(
				'class'   => 'mvweb-cp__image mvweb-cp__image--placeholder',
				'alt'     => '',
				'loading' => 'lazy',
			)
		);

		// Empty when the attachment was deleted — fall through to the bundled SVG.
		if ( '' !== $html ) {
			return $html;
		}
	}

	/**
	 * Filter placeholder image URL.
	 *
	 * @since 1.0.0
	 * @param string $url Placeholder URL.
	 */
	$url = apply_filters( 'mvweb_cp_placeholder_url', MVWEB_CP_URL . 'public/images/placeholder.svg' );

	return '<img class="mvweb-cp__image mvweb-cp__image--placeholder" src="' . esc_url( $url ) . '" alt="" loading="lazy">';
}

/**
 * Log message to debug.log if WP_DEBUG is enabled.
 *
 * @since 1.0.0
 * @param mixed  $message Message to log.
 * @param string $level   Log level (info, warning, error).
 * @return void
 */
function mvweb_cp_log( $message, $level = 'info' ) {
	if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
		return;
	}

	if ( is_array( $message ) || is_object( $message ) ) {
		$message = print_r( $message, true );
	}

	$log_message = sprintf(
		'[MVweb Child Pages] [%s] %s',
		strtoupper( $level ),
		$message
	);

	// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
	error_log( $log_message );
}
