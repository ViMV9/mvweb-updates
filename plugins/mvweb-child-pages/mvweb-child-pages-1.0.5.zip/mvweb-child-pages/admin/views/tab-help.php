<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package MVweb_Child_Pages
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-child-pages' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Find the parent page ID', 'mvweb-child-pages' ); ?></strong>
			<p><?php esc_html_e( 'Go to Pages in your WordPress admin and hover over the parent page. The ID is shown in the URL.', 'mvweb-child-pages' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Add the shortcode', 'mvweb-child-pages' ); ?></strong>
			<p><?php esc_html_e( 'Insert the shortcode into any page or post:', 'mvweb-child-pages' ); ?> <code>[mvweb-cp id="123"]</code></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Customize (optional)', 'mvweb-child-pages' ); ?></strong>
			<p><?php esc_html_e( 'Adjust global defaults on the General tab, or override per shortcode using attributes.', 'mvweb-child-pages' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Shortcode attributes', 'mvweb-child-pages' ); ?></div>
	</div>

	<div class="mvweb-table-wrap">
		<table class="mvweb-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Attribute', 'mvweb-child-pages' ); ?></th>
					<th><?php esc_html_e( 'Default', 'mvweb-child-pages' ); ?></th>
					<th><?php esc_html_e( 'Description', 'mvweb-child-pages' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td class="cell-mono">id</td>
					<td>—</td>
					<td><?php esc_html_e( 'Which page to take child pages from. The only required attribute — paste the parent page ID here.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">limit</td>
					<td class="cell-mono">-1</td>
					<td><?php esc_html_e( 'How many child pages to show. Leave -1 to show them all, or set a number to cap the list.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">orderby</td>
					<td class="cell-mono">menu_order</td>
					<td><?php esc_html_e( 'How to order the pages: by their manual order (menu_order), alphabetically (title), by publish date (date) or by ID.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">order</td>
					<td class="cell-mono">ASC</td>
					<td><?php esc_html_e( 'Direction of the order: ASC for ascending (A→Z, old→new), DESC for descending.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">show_image</td>
					<td><?php esc_html_e( 'From settings', 'mvweb-child-pages' ); ?></td>
					<td><?php esc_html_e( 'Whether to show the featured image of each page. Use yes or no to override the global setting.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">class</td>
					<td>—</td>
					<td><?php esc_html_e( 'Your own CSS class on the list container, handy for custom styling of a specific list.', 'mvweb-child-pages' ); ?></td>
				</tr>
				<tr>
					<td class="cell-mono">image_size</td>
					<td><?php esc_html_e( 'From settings', 'mvweb-child-pages' ); ?></td>
					<td><?php esc_html_e( 'Size of the page images: thumbnail (small), medium or large.', 'mvweb-child-pages' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<p class="mvweb-block__sub"><?php esc_html_e( 'Examples', 'mvweb-child-pages' ); ?></p>
	<pre class="mvweb-cp-code"><code>[mvweb-cp id="10"]
[mvweb-cp id="25" limit="5" orderby="title"]
[mvweb-cp id="42" show_image="no" order="DESC"]
[mvweb-cp id="10" class="my-custom-list" image_size="large"]</code></pre>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'CSS customization examples', 'mvweb-child-pages' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Use the Custom CSS tab to add your own styles. Here are some examples:', 'mvweb-child-pages' ); ?></p>

	<pre class="mvweb-cp-code"><code>/* Change gap between items */
.mvweb-cp { --mvweb-cp-gap: 30px; }

/* Change item width */
.mvweb-cp { --mvweb-cp-item-width: 300px; }

/* Style a specific list by parent ID */
.mvweb-cp--123 {
    --mvweb-cp-gap: 10px;
    --mvweb-cp-item-width: 200px;
}

/* Three-column grid layout */
.mvweb-cp__list {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
}</code></pre>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-child-pages' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Where do I find the page ID?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Go to Pages in your admin, hover over the page title, and look at the URL in the browser status bar. The number after "post=" is the page ID.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I use multiple shortcodes on one page?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes! You can use as many shortcodes as needed, each with a different parent page ID.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Why is my list empty?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Make sure the parent page exists, is published, is not password-protected, and has published child pages.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'What image is shown when a page has no featured image?', 'mvweb-child-pages' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'A placeholder image from the plugin is used. You can customize it via the mvweb_cp_placeholder_url filter.', 'mvweb-child-pages' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-child-pages' ); ?></div>
	</div>
	<p>
		<?php
		echo wp_kses_post(
			sprintf(
				/* translators: %s: MVweb plugin URL */
				__( 'Need help? Visit %s for documentation and support.', 'mvweb-child-pages' ),
				'<a href="https://mvweb.ru/plugins/mvweb-child-pages" target="_blank" rel="noopener noreferrer">mvweb.ru</a>'
			)
		);
		?>
	</p>
	<p>
		<strong><?php esc_html_e( 'Version:', 'mvweb-child-pages' ); ?></strong> <?php echo esc_html( MVWEB_CP_VERSION ); ?>
	</p>
</div>
