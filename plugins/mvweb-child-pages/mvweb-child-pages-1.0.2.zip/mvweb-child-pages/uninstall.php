<?php
/**
 * Uninstall MVweb Child Pages
 *
 * Fired when the plugin is uninstalled.
 *
 * @package MVweb_Child_Pages
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Delete plugin options.
delete_option( 'mvweb_cp_settings' );

// For multisite, delete options from all sites.
if ( is_multisite() ) {
	$sites = get_sites();
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );
		delete_option( 'mvweb_cp_settings' );
		restore_current_blog();
	}
}

// Clear any cached data.
wp_cache_flush();
