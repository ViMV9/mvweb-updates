# MVweb Child Pages

Display child pages as a styled list using a shortcode.

## Requirements

- WordPress 6.4+
- PHP 8.0+

## Usage

```
[mvweb-cp id="123"]
[mvweb-cp id="25" limit="5" orderby="title"]
[mvweb-cp id="42" show_image="no" order="DESC"]
```

## Shortcode Attributes

| Attribute | Default | Description |
|-----------|---------|-------------|
| `id` | — | Required. Parent page ID |
| `limit` | `-1` | Max child pages (-1 = all) |
| `orderby` | `menu_order` | Sort by: menu_order, title, date, ID |
| `order` | `ASC` | Direction: ASC, DESC |
| `show_image` | From settings | Show images: yes/no |
| `class` | — | Extra CSS class |
| `image_size` | From settings | Image size: thumbnail, medium, large |

## CSS Customization

Use CSS variables to customize the layout:

```css
.mvweb-cp {
    --mvweb-cp-gap: 30px;
    --mvweb-cp-item-width: 300px;
    --mvweb-cp-border-radius: 12px;
}
```

## Filters

- `mvweb_cp_query_args` — Modify get_pages() arguments
- `mvweb_cp_item_html` — Modify single item HTML
- `mvweb_cp_shortcode_atts` — Modify shortcode attributes
- `mvweb_cp_placeholder_url` — Change placeholder image URL

## Actions

- `mvweb_cp_before_list` — Before the child pages list
- `mvweb_cp_after_list` — After the child pages list
