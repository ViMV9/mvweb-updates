<?php
/**
 * Admin settings page template.
 *
 * @package MVweb_Child_Pages
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings    = mvweb_cp_get_settings();
$current_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'general';
$tabs        = array(
	'general'    => __( 'General', 'mvweb-child-pages' ),
	'custom-css' => __( 'Custom CSS', 'mvweb-child-pages' ),
	'help'       => __( 'Help', 'mvweb-child-pages' ),
);
?>

<div class="wrap mvweb-settings">
	<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

	<?php settings_errors( 'mvweb_cp_messages' ); ?>

	<nav class="nav-tab-wrapper mvweb-cp-tabs">
		<?php foreach ( $tabs as $tab_id => $tab_name ) : ?>
			<a href="#<?php echo esc_attr( $tab_id ); ?>"
			   class="nav-tab <?php echo $current_tab === $tab_id ? 'nav-tab-active' : ''; ?>"
			   data-tab="<?php echo esc_attr( $tab_id ); ?>">
				<?php echo esc_html( $tab_name ); ?>
			</a>
		<?php endforeach; ?>
	</nav>

	<form method="post" action="">
		<?php wp_nonce_field( 'mvweb_cp_settings', 'mvweb_cp_nonce' ); ?>

		<!-- General Tab -->
		<div id="general" class="mvweb-tab-content <?php echo 'general' === $current_tab ? 'active' : ''; ?>">
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">
						<?php esc_html_e( 'Show images', 'mvweb-child-pages' ); ?>
					</th>
					<td>
						<label>
							<input type="checkbox"
								   name="mvweb_cp_show_image"
								   value="1"
								   <?php checked( $settings['show_image'], 'yes' ); ?>>
							<?php esc_html_e( 'Display featured images for child pages', 'mvweb-child-pages' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="mvweb_cp_image_size">
							<?php esc_html_e( 'Image size', 'mvweb-child-pages' ); ?>
						</label>
					</th>
					<td>
						<select id="mvweb_cp_image_size" name="mvweb_cp_image_size">
							<option value="thumbnail" <?php selected( $settings['image_size'], 'thumbnail' ); ?>>
								<?php esc_html_e( 'Thumbnail', 'mvweb-child-pages' ); ?>
							</option>
							<option value="medium" <?php selected( $settings['image_size'], 'medium' ); ?>>
								<?php esc_html_e( 'Medium', 'mvweb-child-pages' ); ?>
							</option>
							<option value="large" <?php selected( $settings['image_size'], 'large' ); ?>>
								<?php esc_html_e( 'Large', 'mvweb-child-pages' ); ?>
							</option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="mvweb_cp_limit">
							<?php esc_html_e( 'Default limit', 'mvweb-child-pages' ); ?>
						</label>
					</th>
					<td>
						<input type="number"
							   id="mvweb_cp_limit"
							   name="mvweb_cp_limit"
							   value="<?php echo esc_attr( $settings['limit'] ); ?>"
							   min="-1"
							   class="small-text">
						<p class="description">
							<?php esc_html_e( 'Maximum number of child pages to display. Use -1 for no limit.', 'mvweb-child-pages' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="mvweb_cp_orderby">
							<?php esc_html_e( 'Default order by', 'mvweb-child-pages' ); ?>
						</label>
					</th>
					<td>
						<select id="mvweb_cp_orderby" name="mvweb_cp_orderby">
							<option value="menu_order" <?php selected( $settings['orderby'], 'menu_order' ); ?>>
								<?php esc_html_e( 'Menu order', 'mvweb-child-pages' ); ?>
							</option>
							<option value="title" <?php selected( $settings['orderby'], 'title' ); ?>>
								<?php esc_html_e( 'Title', 'mvweb-child-pages' ); ?>
							</option>
							<option value="date" <?php selected( $settings['orderby'], 'date' ); ?>>
								<?php esc_html_e( 'Date', 'mvweb-child-pages' ); ?>
							</option>
							<option value="ID" <?php selected( $settings['orderby'], 'ID' ); ?>>
								<?php esc_html_e( 'ID', 'mvweb-child-pages' ); ?>
							</option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="mvweb_cp_order">
							<?php esc_html_e( 'Default order', 'mvweb-child-pages' ); ?>
						</label>
					</th>
					<td>
						<select id="mvweb_cp_order" name="mvweb_cp_order">
							<option value="ASC" <?php selected( $settings['order'], 'ASC' ); ?>>
								<?php esc_html_e( 'Ascending', 'mvweb-child-pages' ); ?>
							</option>
							<option value="DESC" <?php selected( $settings['order'], 'DESC' ); ?>>
								<?php esc_html_e( 'Descending', 'mvweb-child-pages' ); ?>
							</option>
						</select>
					</td>
				</tr>
			</table>
		</div>

		<!-- Custom CSS Tab -->
		<div id="custom-css" class="mvweb-tab-content <?php echo 'custom-css' === $current_tab ? 'active' : ''; ?>">
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">
						<label for="mvweb_cp_custom_css">
							<?php esc_html_e( 'Custom CSS', 'mvweb-child-pages' ); ?>
						</label>
					</th>
					<td>
						<textarea id="mvweb_cp_custom_css"
								  name="mvweb_cp_custom_css"
								  rows="12"
								  class="large-text code"><?php echo esc_textarea( $settings['custom_css'] ); ?></textarea>
						<p class="description">
							<?php esc_html_e( 'Add custom CSS styles for the child pages output. These styles will be loaded only on pages that use the shortcode.', 'mvweb-child-pages' ); ?>
						</p>
					</td>
				</tr>
			</table>
		</div>

		<?php submit_button( __( 'Save Changes', 'mvweb-child-pages' ), 'primary', 'mvweb_cp_save' ); ?>
	</form>

	<!-- Help Tab (outside form — no form fields) -->
	<div id="help" class="mvweb-tab-content">
		<?php include MVWEB_CP_PATH . 'admin/views/tab-help.php'; ?>
	</div>
</div>
