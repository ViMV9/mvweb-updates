<?php
/**
 * Plugin Name:       MVweb Child Pages
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-child-pages
 * Description:       Display child pages as a styled list using a shortcode.
 * Version:           1.0.1
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-child-pages
 * Domain Path:       /languages
 *
 * @package MVweb_Child_Pages
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_CP_VERSION' ) ) {
	return;
}

/**
 * Plugin version.
 */
define( 'MVWEB_CP_VERSION', '1.0.1' );

/**
 * Plugin directory path.
 */
define( 'MVWEB_CP_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Plugin directory URL.
 */
define( 'MVWEB_CP_URL', plugin_dir_url( __FILE__ ) );

/**
 * Plugin basename.
 */
define( 'MVWEB_CP_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_CP_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_CP_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_CP_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_CP_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_CP_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-child-pages' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-child-pages'] = array(
		'name'         => 'MVweb Child Pages',
		'description'  => 'Display child pages as a styled list using a shortcode.',
		'url'          => 'https://mvweb.ru/plugins/mvweb-child-pages',
		'settings_url' => 'admin.php?page=mvweb-child-pages',
		'textdomain'   => 'mvweb-child-pages',
	);
	return $plugins;
} );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-child-pages',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_cp_load_textdomain' );

/**
 * Register plugin submenu under MVweb.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_register_menu() {
	$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

	add_submenu_page(
		$parent_slug,
		__( 'MVweb Child Pages', 'mvweb-child-pages' ),
		__( 'Child Pages', 'mvweb-child-pages' ),
		'manage_options',
		'mvweb-child-pages',
		'mvweb_cp_settings_page'
	);
}
add_action( 'admin_menu', 'mvweb_cp_register_menu' );

/**
 * Plugin settings page callback.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	// Save settings.
	if ( isset( $_POST['mvweb_cp_save'] ) ) {
		check_admin_referer( 'mvweb_cp_settings', 'mvweb_cp_nonce' );

		$settings = mvweb_cp_get_settings();

		$settings['show_image'] = isset( $_POST['mvweb_cp_show_image'] ) ? 'yes' : 'no';
		$settings['image_size'] = isset( $_POST['mvweb_cp_image_size'] )
			? sanitize_text_field( wp_unslash( $_POST['mvweb_cp_image_size'] ) )
			: 'medium';
		$settings['limit']      = isset( $_POST['mvweb_cp_limit'] )
			? intval( $_POST['mvweb_cp_limit'] )
			: -1;
		$settings['orderby']    = isset( $_POST['mvweb_cp_orderby'] )
			? sanitize_text_field( wp_unslash( $_POST['mvweb_cp_orderby'] ) )
			: 'menu_order';
		$settings['order']      = isset( $_POST['mvweb_cp_order'] )
			? sanitize_text_field( wp_unslash( $_POST['mvweb_cp_order'] ) )
			: 'ASC';
		$settings['custom_css'] = isset( $_POST['mvweb_cp_custom_css'] )
			? wp_strip_all_tags( wp_unslash( $_POST['mvweb_cp_custom_css'] ) )
			: '';

		// Validate whitelists.
		$allowed_sizes   = array( 'thumbnail', 'medium', 'large' );
		$allowed_orderby = array( 'menu_order', 'title', 'date', 'ID' );
		$allowed_order   = array( 'ASC', 'DESC' );

		if ( ! in_array( $settings['image_size'], $allowed_sizes, true ) ) {
			$settings['image_size'] = 'medium';
		}
		if ( ! in_array( $settings['orderby'], $allowed_orderby, true ) ) {
			$settings['orderby'] = 'menu_order';
		}
		if ( ! in_array( $settings['order'], $allowed_order, true ) ) {
			$settings['order'] = 'ASC';
		}

		update_option( 'mvweb_cp_settings', $settings );

		add_settings_error(
			'mvweb_cp_messages',
			'mvweb_cp_message',
			__( 'Settings saved.', 'mvweb-child-pages' ),
			'updated'
		);
	}

	include MVWEB_CP_PATH . 'admin/views/settings-page.php';
}

/**
 * Enqueue admin styles and scripts.
 *
 * @since 1.0.0
 * @param string $hook Current admin page hook.
 * @return void
 */
function mvweb_cp_admin_enqueue( $hook ) {
	if ( false === strpos( $hook, 'mvweb-child-pages' ) ) {
		return;
	}

	$suffix  = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	$css_ver = (string) filemtime( MVWEB_CP_PATH . 'admin/css/admin' . $suffix . '.css' );
	$js_ver  = (string) filemtime( MVWEB_CP_PATH . 'admin/js/admin' . $suffix . '.js' );

	wp_enqueue_style(
		'mvweb-cp-admin',
		MVWEB_CP_URL . 'admin/css/admin' . $suffix . '.css',
		array(),
		$css_ver
	);

	wp_enqueue_style(
		'mvweb-cp-plugin',
		MVWEB_CP_URL . 'admin/css/plugin' . $suffix . '.css',
		array( 'mvweb-cp-admin' ),
		(string) filemtime( MVWEB_CP_PATH . 'admin/css/plugin' . $suffix . '.css' )
	);

	wp_enqueue_script(
		'mvweb-cp-admin',
		MVWEB_CP_URL . 'admin/js/admin' . $suffix . '.js',
		array(),
		$js_ver,
		true
	);
}
add_action( 'admin_enqueue_scripts', 'mvweb_cp_admin_enqueue' );

/**
 * Register shortcode.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_register_shortcode() {
	add_shortcode( 'mvweb-cp', 'mvweb_cp_shortcode_render' );
}
add_action( 'init', 'mvweb_cp_register_shortcode' );

/**
 * Shortcode render callback.
 *
 * @since 1.0.0
 * @param array|string $atts Shortcode attributes.
 * @return string HTML output.
 */
function mvweb_cp_shortcode_render( $atts ) {
	$settings = mvweb_cp_get_settings();

	$atts = shortcode_atts(
		array(
			'id'         => '',
			'limit'      => $settings['limit'],
			'orderby'    => $settings['orderby'],
			'order'      => $settings['order'],
			'show_image' => $settings['show_image'],
			'class'      => '',
			'image_size' => $settings['image_size'],
		),
		$atts,
		'mvweb-cp'
	);

	/**
	 * Filter shortcode attributes.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 */
	$atts = apply_filters( 'mvweb_cp_shortcode_atts', $atts );

	// Validate id.
	if ( '' === $atts['id'] ) {
		return '';
	}

	$parent_id = absint( $atts['id'] );
	if ( 0 === $parent_id ) {
		return '<!-- mvweb-cp: invalid id -->';
	}

	// Validate parent page.
	$parent = get_post( $parent_id );
	if ( null === $parent ) {
		return '<!-- mvweb-cp: invalid parent id=' . $parent_id . ' -->';
	}
	if ( 'page' !== $parent->post_type ) {
		return '<!-- mvweb-cp: id=' . $parent_id . ' is not a page -->';
	}
	if ( 'publish' !== $parent->post_status ) {
		return '<!-- mvweb-cp: invalid parent id=' . $parent_id . ' -->';
	}
	if ( ! empty( $parent->post_password ) ) {
		return '<!-- mvweb-cp: parent id=' . $parent_id . ' is password-protected -->';
	}

	// Validate and sanitize attributes.
	$limit = intval( $atts['limit'] );
	if ( 0 === $limit ) {
		$limit = -1;
	}

	$allowed_orderby = array( 'menu_order', 'title', 'date', 'ID' );
	$orderby         = in_array( $atts['orderby'], $allowed_orderby, true ) ? $atts['orderby'] : 'menu_order';

	$allowed_order = array( 'ASC', 'DESC' );
	$order         = in_array( strtoupper( $atts['order'] ), $allowed_order, true ) ? strtoupper( $atts['order'] ) : 'ASC';

	$show_image = in_array( $atts['show_image'], array( 'yes', 'no' ), true ) ? $atts['show_image'] : $settings['show_image'];

	$allowed_sizes = array( 'thumbnail', 'medium', 'large' );
	$image_size    = in_array( $atts['image_size'], $allowed_sizes, true ) ? $atts['image_size'] : $settings['image_size'];

	$extra_class = ! empty( $atts['class'] ) ? sanitize_html_class( $atts['class'] ) : '';

	// Build query args.
	$query_args = array(
		'child_of'    => $parent_id,
		'parent'      => $parent_id,
		'post_type'   => 'page',
		'post_status' => 'publish',
		'sort_column' => $orderby,
		'sort_order'  => $order,
		'number'      => $limit,
	);

	/**
	 * Filter get_pages() query args.
	 *
	 * @since 1.0.0
	 * @param array $query_args Query arguments.
	 * @param array $atts       Shortcode attributes.
	 */
	$query_args = apply_filters( 'mvweb_cp_query_args', $query_args, $atts );

	$children = get_pages( $query_args );

	// Natural sort: digits first, then letters; numeric titles sorted as numbers (11 > 9).
	if ( ! empty( $children ) && 'title' === $orderby ) {
		usort(
			$children,
			function ( $a, $b ) use ( $order ) {
				$title_a    = get_the_title( $a->ID );
				$title_b    = get_the_title( $b->ID );
				$a_is_digit = ctype_digit( mb_substr( $title_a, 0, 1 ) );
				$b_is_digit = ctype_digit( mb_substr( $title_b, 0, 1 ) );

				// Digits-first: titles starting with a digit come before letters.
				if ( $a_is_digit && ! $b_is_digit ) {
					return -1;
				}
				if ( ! $a_is_digit && $b_is_digit ) {
					return 1;
				}

				// Both same type — use natural case-insensitive comparison.
				$cmp = strnatcasecmp( $title_a, $title_b );

				return 'DESC' === $order ? -$cmp : $cmp;
			}
		);
	}

	if ( empty( $children ) ) {
		return '<!-- mvweb-cp: no children for id=' . $parent_id . ' -->';
	}

	// Enqueue frontend assets.
	mvweb_cp_enqueue_public_assets();

	// Build CSS classes.
	$nav_classes = array( 'mvweb-cp', 'mvweb-cp--' . $parent_id );
	if ( 'no' === $show_image ) {
		$nav_classes[] = 'mvweb-cp--no-images';
	}
	if ( ! empty( $extra_class ) ) {
		$nav_classes[] = $extra_class;
	}

	// Build HTML.
	$output = '';

	/**
	 * Fires before the child pages list.
	 *
	 * @since 1.0.0
	 * @param int   $parent_id Parent page ID.
	 * @param array $atts      Shortcode attributes.
	 */
	do_action( 'mvweb_cp_before_list', $parent_id, $atts );

	$output .= '<nav class="' . esc_attr( implode( ' ', $nav_classes ) ) . '" aria-label="' . esc_attr__( 'Child pages', 'mvweb-child-pages' ) . '">';
	$output .= '<ul class="mvweb-cp__list">';

	foreach ( $children as $child ) {
		$item_html = '<li class="mvweb-cp__item">';
		$item_html .= '<a class="mvweb-cp__link" href="' . esc_url( get_permalink( $child->ID ) ) . '">';

		if ( 'yes' === $show_image ) {
			if ( has_post_thumbnail( $child->ID ) ) {
				$item_html .= wp_get_attachment_image(
					get_post_thumbnail_id( $child->ID ),
					$image_size,
					false,
					array( 'class' => 'mvweb-cp__image' )
				);
			} else {
				/**
				 * Filter placeholder image URL.
				 *
				 * @since 1.0.0
				 * @param string $url Placeholder URL.
				 */
				$placeholder_url = apply_filters(
					'mvweb_cp_placeholder_url',
					MVWEB_CP_URL . 'public/images/placeholder.svg'
				);
				$item_html .= '<img class="mvweb-cp__image mvweb-cp__image--placeholder" src="' . esc_url( $placeholder_url ) . '" alt="" loading="lazy">';
			}
		}

		$item_html .= '<div class="mvweb-cp__title">' . esc_html( get_the_title( $child->ID ) ) . '</div>';
		$item_html .= '</a>';
		$item_html .= '</li>';

		/**
		 * Filter single item HTML.
		 *
		 * @since 1.0.0
		 * @param string  $item_html Item HTML.
		 * @param WP_Post $child     Child page post object.
		 * @param array   $atts      Shortcode attributes.
		 */
		$output .= apply_filters( 'mvweb_cp_item_html', $item_html, $child, $atts );
	}

	$output .= '</ul>';
	$output .= '</nav>';

	/**
	 * Fires after the child pages list.
	 *
	 * @since 1.0.0
	 * @param int   $parent_id Parent page ID.
	 * @param array $atts      Shortcode attributes.
	 */
	do_action( 'mvweb_cp_after_list', $parent_id, $atts );

	return $output;
}

/**
 * Enqueue public assets (only when shortcode is used).
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_enqueue_public_assets() {
	static $enqueued = false;

	if ( $enqueued ) {
		return;
	}

	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	wp_enqueue_style(
		'mvweb-cp-public',
		MVWEB_CP_URL . 'public/css/public' . $suffix . '.css',
		array(),
		MVWEB_CP_VERSION
	);

	// Add custom CSS if set.
	$settings = mvweb_cp_get_settings();
	if ( ! empty( $settings['custom_css'] ) ) {
		wp_add_inline_style( 'mvweb-cp-public', $settings['custom_css'] );
	}

	$enqueued = true;
}

/**
 * Plugin activation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_activate() {
	if ( false === get_option( 'mvweb_cp_settings' ) ) {
		update_option( 'mvweb_cp_settings', mvweb_cp_get_defaults() );
	}
}
register_activation_hook( __FILE__, 'mvweb_cp_activate' );

/**
 * Plugin deactivation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cp_deactivate() {
	// Settings are preserved.
}
register_deactivation_hook( __FILE__, 'mvweb_cp_deactivate' );

// Include additional files.
require_once MVWEB_CP_PATH . 'includes/helpers.php';
