<?php
/**
 * Frontend shortcode for MVweb Object Map.
 *
 * Registers the [mvweb_map] shortcode that renders a Yandex map with the
 * published objects. Assets are registered up front and enqueued lazily only
 * when the shortcode is actually rendered on a page. Each shortcode instance
 * gets its own container so several maps can coexist on one page.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shortcode controller.
 *
 * @since 1.0.0
 */
final class MVweb_OM_Shortcode {

	/**
	 * Whether assets have been enqueued for the current request.
	 *
	 * @var bool
	 */
	private static $enqueued = false;

	/**
	 * Incrementing instance counter for unique container IDs.
	 *
	 * @var int
	 */
	private static $instance = 0;

	/**
	 * Wire WordPress hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
	}

	/**
	 * Register the shortcode.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_shortcode() {
		add_shortcode( 'mvweb_map', array( __CLASS__, 'render' ) );
	}

	/**
	 * Register (not enqueue) the frontend assets.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_assets() {
		wp_register_style(
			'mvweb-om-public',
			MVWEB_OM_URL . 'public/css/object-map.min.css',
			array(),
			MVWEB_OM_VERSION
		);

		$api_key = (string) MVweb_OM_Settings::get( 'api_key' );
		if ( '' !== $api_key ) {
			wp_register_script(
				'mvweb-om-ymaps',
				'https://api-maps.yandex.ru/v3/?apikey=' . rawurlencode( $api_key ) . '&lang=' . rawurlencode( self::map_lang() ),
				array(),
				null,
				true
			);
		}

		wp_register_script(
			'mvweb-om-public',
			MVWEB_OM_URL . 'public/js/object-map.min.js',
			'' !== $api_key ? array( 'mvweb-om-ymaps' ) : array(),
			MVWEB_OM_VERSION,
			true
		);

		$settings = MVweb_OM_Settings::get();

		wp_localize_script(
			'mvweb-om-public',
			'mvwebOmData',
			array(
				'restUrl'     => esc_url_raw( rest_url( MVweb_OM_REST::NAMESPACE_V1 . '/objects' ) ),
				'hasKey'      => ( '' !== (string) $settings['api_key'] ),
				'mapType'     => (string) $settings['map_type'],
				'cluster'     => (bool) $settings['cluster_enabled'],
				'modal'       => (bool) $settings['modal_enabled'],
				'accent'      => (string) $settings['accent_color'],
				'defaultZoom' => (int) $settings['default_zoom'],
				'card'        => array(
					'bg'          => (string) $settings['card_bg'],
					'border'      => (string) $settings['card_border'],
					'titleColor'  => (string) $settings['card_title_color'],
					'textColor'   => (string) $settings['card_text_color'],
					'hoverBorder' => (string) $settings['card_hover_border'],
					'showPhoto'   => (bool) $settings['card_show_photo'],
					'showAddress' => (bool) $settings['card_show_address'],
					'showExcerpt' => (bool) $settings['card_show_excerpt'],
					'radius'      => (int) $settings['card_radius'],
					'borderWidth' => (int) $settings['card_border_width'],
					'density'     => (string) $settings['card_density'],
					'shadow'      => (bool) $settings['card_shadow'],
					'photoSize'   => (int) $settings['card_photo_size'],
					'photoPos'    => (string) $settings['card_photo_pos'],
				),
				'i18n'        => array(
					'loading'  => __( 'Loading map…', 'mvweb-object-map' ),
					'noKey'    => __( 'The map is not configured yet.', 'mvweb-object-map' ),
					'error'    => __( 'Could not load the map.', 'mvweb-object-map' ),
					'empty'    => __( 'No objects to show.', 'mvweb-object-map' ),
					'all'      => __( 'All', 'mvweb-object-map' ),
					'more'     => __( 'More details', 'mvweb-object-map' ),
					'route'    => __( 'Get directions', 'mvweb-object-map' ),
					'search'   => __( 'Search objects…', 'mvweb-object-map' ),
					'sortName' => __( 'By name', 'mvweb-object-map' ),
					'sortNew'  => __( 'Newest first', 'mvweb-object-map' ),
					'mapTab'   => __( 'Map', 'mvweb-object-map' ),
					'listTab'  => __( 'List', 'mvweb-object-map' ),
					'close'    => __( 'Close', 'mvweb-object-map' ),
					'prev'     => __( 'Previous', 'mvweb-object-map' ),
					'next'     => __( 'Next', 'mvweb-object-map' ),
				),
			)
		);
	}

	/**
	 * Render the shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function render( $atts ): string {
		$atts = is_array( $atts ) ? $atts : array();
		$atts = shortcode_atts(
			array(
				'category' => '',
				'ids'      => '',
				'list'     => 'no',
				'filter'   => 'yes',
				'height'   => '500px',
				'zoom'     => '',
				'center'   => '',
				'cluster'  => '',
				'type'     => '',
			),
			$atts,
			'mvweb_map'
		);

		self::enqueue_assets();
		++self::$instance;

		$config = array(
			'category' => sanitize_text_field( $atts['category'] ),
			'ids'      => sanitize_text_field( $atts['ids'] ),
			'list'     => 'yes' === strtolower( (string) $atts['list'] ),
			'filter'   => 'no' !== strtolower( (string) $atts['filter'] ),
			'zoom'     => '' !== $atts['zoom'] ? absint( $atts['zoom'] ) : null,
			'center'   => self::parse_center( (string) $atts['center'] ),
			'cluster'  => self::parse_tristate( (string) $atts['cluster'] ),
			'type'     => in_array( $atts['type'], array( 'map', 'satellite', 'hybrid' ), true ) ? $atts['type'] : '',
		);

		$dom_id = 'mvweb-om-map-' . self::$instance;
		$height = preg_replace( '/[^0-9a-z%.]/i', '', (string) $atts['height'] );
		if ( '' === $height ) {
			$height = '500px';
		}

		ob_start();
		require MVWEB_OM_PATH . 'public/templates/map.php';
		return ob_get_clean();
	}

	/**
	 * Enqueue assets once per request.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function enqueue_assets() {
		if ( self::$enqueued ) {
			return;
		}
		wp_enqueue_style( 'mvweb-om-public' );
		wp_enqueue_script( 'mvweb-om-public' );
		self::$enqueued = true;
	}

	/**
	 * Parse a "lat,lng" center attribute into a validated string or empty.
	 *
	 * @since 1.0.0
	 * @param string $raw Raw center value.
	 * @return string
	 */
	private static function parse_center( $raw ) {
		$raw = trim( $raw );
		if ( '' === $raw ) {
			return '';
		}
		$parts = array_map( 'trim', explode( ',', $raw ) );
		if ( 2 !== count( $parts ) ) {
			return '';
		}
		$lat = mvweb_om_sanitize_lat( $parts[0] );
		$lng = mvweb_om_sanitize_lng( $parts[1] );
		return ( '' !== $lat && '' !== $lng ) ? $lat . ',' . $lng : '';
	}

	/**
	 * Parse a yes/no override into true/false/null.
	 *
	 * @since 1.0.0
	 * @param string $raw Raw value.
	 * @return bool|null
	 */
	private static function parse_tristate( $raw ) {
		$raw = strtolower( trim( $raw ) );
		if ( 'yes' === $raw ) {
			return true;
		}
		if ( 'no' === $raw ) {
			return false;
		}
		return null;
	}

	/**
	 * Resolve the Yandex Maps language from the site locale.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function map_lang() {
		$locale = get_locale();
		return ( 0 === strpos( $locale, 'ru' ) ) ? 'ru_RU' : 'en_US';
	}
}
