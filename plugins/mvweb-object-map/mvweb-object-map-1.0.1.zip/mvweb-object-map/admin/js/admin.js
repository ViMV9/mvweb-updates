/**
 * Admin JavaScript for MVweb Object Map.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
		initSpecsRepeater();
		initColorPickers();
	});

	/**
	 * Sync every color-picker's value label with its swatch input.
	 */
	function initColorPickers() {
		document.querySelectorAll('.mvweb-color-picker').forEach(function (picker) {
			var input = picker.querySelector('.mvweb-color-picker__swatch');
			var value = picker.querySelector('.mvweb-color-picker__value');
			if (!input || !value) {
				return;
			}
			input.addEventListener('input', function () {
				value.textContent = input.value;
			});
		});
	}

	/**
	 * Tab navigation for the UI Kit sidebar layout.
	 */
	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length || !panels.length) {
			return;
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();
				var target = link.getAttribute('data-tab');

				links.forEach(function (l) { l.classList.remove('mvweb-nav__link--active'); });
				panels.forEach(function (p) { p.classList.remove('active'); });

				link.classList.add('mvweb-nav__link--active');
				var panel = document.getElementById(target);
				if (panel) {
					panel.classList.add('active');
				}
			});
		});
	}

	/**
	 * Characteristics schema repeater: add, remove, toggle type-specific rows.
	 */
	function initSpecsRepeater() {
		var repeater = document.getElementById('mvweb-om-specs');
		var addBtn = document.querySelector('.mvweb-om-spec-add');
		var template = document.getElementById('mvweb-om-spec-template');

		if (!repeater || !addBtn || !template) {
			return;
		}

		var i18n = (window.mvwebOmAdmin && window.mvwebOmAdmin.i18n) || {};

		addBtn.addEventListener('click', function () {
			var index = parseInt(repeater.getAttribute('data-next-index'), 10) || 0;
			var fragment = template.content.cloneNode(true);
			replaceIndexTokens(fragment, index);
			var item = fragment.querySelector('.mvweb-repeater__item');
			repeater.appendChild(fragment);
			repeater.setAttribute('data-next-index', String(index + 1));
			if (item) {
				syncTypeRows(item);
			}
		});

		repeater.addEventListener('click', function (event) {
			var removeBtn = event.target.closest('.mvweb-om-spec-remove');
			if (!removeBtn) {
				return;
			}
			var item = removeBtn.closest('.mvweb-repeater__item');
			if (!item) {
				return;
			}
			if (window.confirm(i18n.confirmRemove || 'Remove this field?')) {
				item.parentNode.removeChild(item);
			}
		});

		repeater.addEventListener('change', function (event) {
			if (!event.target.classList.contains('mvweb-om-spec-type')) {
				return;
			}
			var item = event.target.closest('.mvweb-repeater__item');
			if (item) {
				syncTypeRows(item);
			}
		});

		repeater.querySelectorAll('.mvweb-repeater__item').forEach(syncTypeRows);
	}

	/**
	 * Replace the __INDEX__ placeholder in name/data attributes of a fragment.
	 *
	 * @param {DocumentFragment} fragment Cloned template fragment.
	 * @param {number}           index    Row index to inject.
	 */
	function replaceIndexTokens(fragment, index) {
		var token = '__INDEX__';
		var idx = String(index);

		fragment.querySelectorAll('[name]').forEach(function (el) {
			el.setAttribute('name', el.getAttribute('name').split(token).join(idx));
		});

		var item = fragment.querySelector('[data-index]');
		if (item) {
			item.setAttribute('data-index', idx);
		}
	}

	/**
	 * Show or hide the unit/options rows based on the selected field type.
	 *
	 * @param {HTMLElement} item Repeater row element.
	 */
	function syncTypeRows(item) {
		var typeSelect = item.querySelector('.mvweb-om-spec-type');
		var unitRow = item.querySelector('.mvweb-om-spec-unit');
		var optionsRow = item.querySelector('.mvweb-om-spec-options');
		if (!typeSelect) {
			return;
		}
		var type = typeSelect.value;
		if (unitRow) {
			unitRow.style.display = ('number' === type) ? '' : 'none';
		}
		if (optionsRow) {
			optionsRow.style.display = ('select' === type) ? '' : 'none';
		}
	}
})();
