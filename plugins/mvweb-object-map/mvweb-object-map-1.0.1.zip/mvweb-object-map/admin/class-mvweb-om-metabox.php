<?php
/**
 * Object metaboxes for MVweb Object Map.
 *
 * Renders the object detail metaboxes (location, gallery, icon, contacts,
 * links, characteristics) in the `mvweb_object` editor and persists the meta
 * on save with nonce, capability and post-type checks.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Object metabox controller.
 *
 * @since 1.0.0
 */
final class MVweb_OM_Metabox {

	/**
	 * Nonce action.
	 */
	const NONCE_ACTION = 'mvweb_om_save_object';

	/**
	 * Nonce field name.
	 */
	const NONCE_FIELD = 'mvweb_om_object_nonce';

	/**
	 * Wire WordPress hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'register' ) );
		add_action( 'save_post_' . MVweb_OM_CPT::POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Register the object metabox.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register() {
		add_meta_box(
			'mvweb_om_details',
			__( 'Object details', 'mvweb-object-map' ),
			array( __CLASS__, 'render' ),
			MVweb_OM_CPT::POST_TYPE,
			'normal',
			'high'
		);
	}

	/**
	 * Render the metabox.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Current object.
	 * @return void
	 */
	public static function render( $post ) {
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );

		$data = array(
			'lat'         => (string) get_post_meta( $post->ID, '_mvweb_om_lat', true ),
			'lng'         => (string) get_post_meta( $post->ID, '_mvweb_om_lng', true ),
			'address'     => (string) get_post_meta( $post->ID, '_mvweb_om_address', true ),
			'phone'       => (string) get_post_meta( $post->ID, '_mvweb_om_phone', true ),
			'hours'       => (string) get_post_meta( $post->ID, '_mvweb_om_hours', true ),
			'more_url'    => (string) get_post_meta( $post->ID, '_mvweb_om_more_url', true ),
			'icon_preset' => (string) get_post_meta( $post->ID, '_mvweb_om_icon_preset', true ),
			'icon_image'  => (int) get_post_meta( $post->ID, '_mvweb_om_icon_image', true ),
			'gallery'     => mvweb_om_decode_array( get_post_meta( $post->ID, '_mvweb_om_gallery', true ) ),
			'links'       => mvweb_om_decode_array( get_post_meta( $post->ID, '_mvweb_om_links', true ) ),
			'specs'       => mvweb_om_decode_array( get_post_meta( $post->ID, '_mvweb_om_specs', true ) ),
			'schema'      => MVweb_OM_Settings::get( 'specs_schema' ),
		);

		require MVWEB_OM_PATH . 'admin/views/metabox-object.php';
	}

	/**
	 * Persist object meta on save.
	 *
	 * @since 1.0.0
	 * @param int     $post_id Object ID.
	 * @param WP_Post $post    Object.
	 * @return void
	 */
	public static function save( $post_id, $post ) {
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST[ self::NONCE_FIELD ] ) ) {
			return;
		}

		$nonce = wp_unslash( $_POST[ self::NONCE_FIELD ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- nonce is verified, not stored.
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			return;
		}

		if ( ! ( $post instanceof WP_Post ) || MVweb_OM_CPT::POST_TYPE !== $post->post_type ) {
			return;
		}

		self::save_scalar( $post_id, '_mvweb_om_lat', 'mvweb_om_sanitize_lat' );
		self::save_scalar( $post_id, '_mvweb_om_lng', 'mvweb_om_sanitize_lng' );
		self::save_scalar( $post_id, '_mvweb_om_address', 'sanitize_text_field' );
		self::save_scalar( $post_id, '_mvweb_om_phone', 'sanitize_text_field' );
		self::save_scalar( $post_id, '_mvweb_om_hours', 'sanitize_text_field' );
		self::save_scalar( $post_id, '_mvweb_om_more_url', 'mvweb_om_sanitize_url' );
		self::save_scalar( $post_id, '_mvweb_om_icon_preset', 'sanitize_key' );

		$icon_image = isset( $_POST['mvweb_om_icon_image'] ) ? absint( $_POST['mvweb_om_icon_image'] ) : 0;
		if ( $icon_image > 0 ) {
			update_post_meta( $post_id, '_mvweb_om_icon_image', $icon_image );
		} else {
			delete_post_meta( $post_id, '_mvweb_om_icon_image' );
		}

		self::save_json( $post_id, '_mvweb_om_gallery', 'mvweb_om_gallery', 'mvweb_om_sanitize_gallery_json' );
		self::save_json( $post_id, '_mvweb_om_links', 'mvweb_om_links', 'mvweb_om_sanitize_links_json' );
		self::save_specs( $post_id );
	}

	/**
	 * Save characteristics, keeping only fields defined in the specs schema.
	 *
	 * @since 1.0.0
	 * @param int $post_id Object ID.
	 * @return void
	 */
	private static function save_specs( $post_id ) {
		$raw = isset( $_POST['mvweb_om_specs'] ) ? (array) wp_unslash( $_POST['mvweb_om_specs'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- sanitized below in mvweb_om_sanitize_specs_json(); nonce verified in save() before this helper runs.

		$allowed = array();
		foreach ( (array) MVweb_OM_Settings::get( 'specs_schema' ) as $field ) {
			if ( ! empty( $field['id'] ) ) {
				$allowed[] = sanitize_key( $field['id'] );
			}
		}

		$json = mvweb_om_sanitize_specs_json( $raw, $allowed );

		if ( '{}' !== $json && '[]' !== $json && '' !== $json ) {
			update_post_meta( $post_id, '_mvweb_om_specs', $json );
		} else {
			delete_post_meta( $post_id, '_mvweb_om_specs' );
		}
	}

	/**
	 * Save one scalar field through a sanitizer.
	 *
	 * @since 1.0.0
	 * @param int      $post_id   Object ID.
	 * @param string   $meta_key  Meta key.
	 * @param callable $sanitizer Sanitize callback.
	 * @return void
	 */
	private static function save_scalar( $post_id, $meta_key, $sanitizer ) {
		$field = ltrim( $meta_key, '_' );
		$raw   = isset( $_POST[ $field ] ) ? wp_unslash( $_POST[ $field ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- sanitized below via $sanitizer; nonce verified in save() before this helper runs.
		$value = call_user_func( $sanitizer, $raw );

		if ( '' !== $value ) {
			update_post_meta( $post_id, $meta_key, $value );
		} else {
			delete_post_meta( $post_id, $meta_key );
		}
	}

	/**
	 * Save one JSON array field through a sanitizer.
	 *
	 * @since 1.0.0
	 * @param int      $post_id   Object ID.
	 * @param string   $meta_key  Meta key.
	 * @param string   $field     POST field name.
	 * @param callable $sanitizer Sanitize callback returning a JSON string.
	 * @return void
	 */
	private static function save_json( $post_id, $meta_key, $field, $sanitizer ) {
		$raw  = isset( $_POST[ $field ] ) ? wp_unslash( $_POST[ $field ] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- sanitized below via $sanitizer; nonce verified in save() before this helper runs.
		$json = call_user_func( $sanitizer, $raw );

		if ( '[]' !== $json && '' !== $json ) {
			update_post_meta( $post_id, $meta_key, $json );
		} else {
			delete_post_meta( $post_id, $meta_key );
		}
	}

	/**
	 * Enqueue the metabox assets on the object editor screen only.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
			return;
		}

		$screen = get_current_screen();
		if ( ! $screen || MVweb_OM_CPT::POST_TYPE !== $screen->post_type ) {
			return;
		}

		wp_enqueue_media();

		wp_enqueue_style(
			'mvweb-om-metabox',
			MVWEB_OM_URL . 'admin/css/plugin.min.css',
			array(),
			MVWEB_OM_VERSION
		);

		$api_key = (string) MVweb_OM_Settings::get( 'api_key' );
		if ( '' !== $api_key ) {
			wp_enqueue_script(
				'mvweb-om-ymaps',
				'https://api-maps.yandex.ru/v3/?apikey=' . rawurlencode( $api_key ) . '&lang=' . rawurlencode( self::map_lang() ),
				array(),
				null,
				true
			);
		}

		wp_enqueue_script(
			'mvweb-om-object',
			MVWEB_OM_URL . 'admin/js/object-edit.min.js',
			array( 'media-views' ),
			MVWEB_OM_VERSION,
			true
		);

		wp_localize_script(
			'mvweb-om-object',
			'mvwebOmObject',
			array(
				'hasKey' => ( '' !== $api_key ),
				'i18n'   => array(
					'selectImage'   => __( 'Select image', 'mvweb-object-map' ),
					'useImage'      => __( 'Use image', 'mvweb-object-map' ),
					'noKey'         => __( 'Add a Yandex Maps API key in the plugin settings to enable the map picker and geocoder.', 'mvweb-object-map' ),
					'notFound'      => __( 'Address not found.', 'mvweb-object-map' ),
					'searchError'   => __( 'Search failed. Try again.', 'mvweb-object-map' ),
					'confirmRemove' => __( 'Remove this row?', 'mvweb-object-map' ),
				),
			)
		);
	}

	/**
	 * Resolve the Yandex Maps language from the site locale.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function map_lang() {
		$locale = get_user_locale();
		return ( 0 === strpos( $locale, 'ru' ) ) ? 'ru_RU' : 'en_US';
	}
}
