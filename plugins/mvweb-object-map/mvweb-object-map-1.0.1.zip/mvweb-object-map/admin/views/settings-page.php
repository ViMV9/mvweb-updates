<?php
/**
 * Admin settings page template.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 * Reference: docs/ui-kit-reference.html
 *
 * Структура:
 *   .wrap.mvweb-settings  — корневой контейнер (max-width 1280px из UI Kit)
 *     ├── aside.mvweb-sidebar  — левая колонка 272px (бренд + меню вкладок)
 *     │     └── ul.mvweb-nav   — вкладки рендерятся как nav-ссылки с иконкой
 *     └── main.mvweb-main      — правая колонка (header + контент вкладок)
 *
 * Каждая вкладка — отдельный partial admin/views/tab-{slug}.php.
 * Переключение вкладок — на JS (admin.js), классы .mvweb-tab-content.active.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$requested_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.
$allowed_tabs  = array( 'general', 'specs', 'appearance', 'help' );
$current_tab   = in_array( $requested_tab, $allowed_tabs, true ) ? $requested_tab : 'general';

$tabs = array(
	'general'    => array(
		'label' => __( 'General', 'mvweb-object-map' ),
		'count' => null,
		'icon'  => 'grid',
	),
	'specs'      => array(
		'label' => __( 'Characteristics', 'mvweb-object-map' ),
		'count' => null,
		'icon'  => 'gear',
	),
	'appearance' => array(
		'label' => __( 'Appearance', 'mvweb-object-map' ),
		'count' => null,
		'icon'  => 'brush',
	),
	'help'       => array(
		'label' => __( 'Help', 'mvweb-object-map' ),
		'count' => null,
		'icon'  => 'help',
	),
);

$icons = array(
	'grid'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'gear'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
	'brush' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9.06 11.9l8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08"/><path d="M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 0 0-3-3.02z"/></svg>',
	'help'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">OM</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Object Map', 'mvweb-object-map' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_OM_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $tabs as $tab_id => $tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $tab_id ); ?>"
						class="<?php echo esc_attr( 'mvweb-nav__link' . ( $current_tab === $tab_id ? ' mvweb-nav__link--active' : '' ) ); ?>"
						data-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo $icons[ $tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $tab['label'] ); ?>
						<?php if ( null !== $tab['count'] ) : ?>
							<span class="mvweb-tabs__count"><?php echo esc_html( (string) $tab['count'] ); ?></span>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors( 'mvweb_om_messages' ); ?>

		<?php $settings = MVweb_OM_Settings::get(); ?>

		<form method="post" action="options.php">
			<?php settings_fields( MVweb_OM_Settings::OPTION_GROUP ); ?>

			<div id="general" class="<?php echo esc_attr( 'mvweb-tab-content' . ( 'general' === $current_tab ? ' active' : '' ) ); ?>">
				<?php require MVWEB_OM_PATH . 'admin/views/tab-general.php'; ?>
			</div>

			<div id="specs" class="<?php echo esc_attr( 'mvweb-tab-content' . ( 'specs' === $current_tab ? ' active' : '' ) ); ?>">
				<?php require MVWEB_OM_PATH . 'admin/views/tab-specs.php'; ?>
			</div>

			<div id="appearance" class="<?php echo esc_attr( 'mvweb-tab-content' . ( 'appearance' === $current_tab ? ' active' : '' ) ); ?>">
				<?php require MVWEB_OM_PATH . 'admin/views/tab-appearance.php'; ?>
			</div>

			<div id="help" class="<?php echo esc_attr( 'mvweb-tab-content' . ( 'help' === $current_tab ? ' active' : '' ) ); ?>">
				<?php require MVWEB_OM_PATH . 'admin/views/tab-help.php'; ?>
			</div>

			<div class="mvweb-submit">
				<button type="submit" class="mvweb-btn mvweb-btn--primary">
					<?php esc_html_e( 'Save Changes', 'mvweb-object-map' ); ?>
				</button>
				<span class="mvweb-submit__hint"><kbd>⌘ S</kbd></span>
			</div>
		</form>

	</main>
</div>
