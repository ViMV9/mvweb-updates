<?php
/**
 * List appearance settings tab.
 *
 * Global look of the catalog list cards, applied on the frontend via CSS
 * variables and modifier classes. Fields are namespaced under
 * `mvweb_om_settings[...]` and saved via the Settings API form.
 *
 * @package mvweb_om
 * @since   1.0.0
 *
 * @var array $settings Current settings (provided by settings-page.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$opt = 'mvweb_om_settings';

/**
 * Render a color-picker form row.
 *
 * @param string $opt   Option name.
 * @param string $key   Setting key.
 * @param string $label Field label.
 * @param string $value Current value.
 * @param string $desc  Optional description.
 * @return void
 */
$mvweb_om_color_row = function ( $opt, $key, $label, $value, $desc = '' ) {
	?>
	<div class="mvweb-form-row">
		<label for="mvweb_om_<?php echo esc_attr( $key ); ?>" class="mvweb-form-row__label"><?php echo esc_html( $label ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-color-picker">
				<input type="color"
					id="mvweb_om_<?php echo esc_attr( $key ); ?>"
					name="<?php echo esc_attr( $opt ); ?>[<?php echo esc_attr( $key ); ?>]"
					class="mvweb-color-picker__swatch"
					value="<?php echo esc_attr( '' !== $value ? $value : '#ffffff' ); ?>">
				<span class="mvweb-color-picker__value"><?php echo esc_html( '' !== $value ? $value : __( 'Default', 'mvweb-object-map' ) ); ?></span>
			</label>
			<?php if ( '' !== $desc ) : ?>
				<p class="mvweb-form-row__desc"><?php echo esc_html( $desc ); ?></p>
			<?php endif; ?>
		</div>
	</div>
	<?php
};

/**
 * Render a toggle form row.
 *
 * @param string $opt     Option name.
 * @param string $key     Setting key.
 * @param string $label   Field label.
 * @param bool   $checked Whether checked.
 * @param string $text    Toggle description text.
 * @return void
 */
$mvweb_om_toggle_row = function ( $opt, $key, $label, $checked, $text ) {
	?>
	<div class="mvweb-form-row">
		<label for="mvweb_om_<?php echo esc_attr( $key ); ?>" class="mvweb-form-row__label"><?php echo esc_html( $label ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox"
						id="mvweb_om_<?php echo esc_attr( $key ); ?>"
						name="<?php echo esc_attr( $opt ); ?>[<?php echo esc_attr( $key ); ?>]"
						value="1"
						<?php checked( $checked ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php echo esc_html( $text ); ?></span>
			</div>
		</div>
	</div>
	<?php
};
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Accent color', 'mvweb-object-map' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_accent_color" class="mvweb-form-row__label"><?php esc_html_e( 'Accent color', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-color-picker">
				<input type="color"
					id="mvweb_om_accent_color"
					name="<?php echo esc_attr( $opt ); ?>[accent_color]"
					class="mvweb-color-picker__swatch"
					value="<?php echo esc_attr( $settings['accent_color'] ); ?>">
				<span class="mvweb-color-picker__value"><?php echo esc_html( $settings['accent_color'] ); ?></span>
			</label>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Used for map markers, balloon buttons and links across the map.', 'mvweb-object-map' ); ?>
			</p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Card colors', 'mvweb-object-map' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Colors of the catalog list cards shown next to the map.', 'mvweb-object-map' ); ?>
	</p>

	<?php
	$mvweb_om_color_row( $opt, 'card_bg', __( 'Card background', 'mvweb-object-map' ), $settings['card_bg'] );
	$mvweb_om_color_row( $opt, 'card_border', __( 'Card border', 'mvweb-object-map' ), $settings['card_border'] );
	$mvweb_om_color_row( $opt, 'card_title_color', __( 'Title color', 'mvweb-object-map' ), $settings['card_title_color'], __( 'Leave as Default to inherit the theme text color.', 'mvweb-object-map' ) );
	$mvweb_om_color_row( $opt, 'card_text_color', __( 'Address / text color', 'mvweb-object-map' ), $settings['card_text_color'] );
	$mvweb_om_color_row( $opt, 'card_hover_border', __( 'Hover border', 'mvweb-object-map' ), $settings['card_hover_border'], __( 'Leave as Default to use the accent color.', 'mvweb-object-map' ) );
	?>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Card content', 'mvweb-object-map' ); ?></div>
	</div>

	<?php
	$mvweb_om_toggle_row( $opt, 'card_show_photo', __( 'Photo', 'mvweb-object-map' ), $settings['card_show_photo'], __( 'Show the object thumbnail in the card', 'mvweb-object-map' ) );
	$mvweb_om_toggle_row( $opt, 'card_show_address', __( 'Address', 'mvweb-object-map' ), $settings['card_show_address'], __( 'Show the address under the title', 'mvweb-object-map' ) );
	$mvweb_om_toggle_row( $opt, 'card_show_excerpt', __( 'Description', 'mvweb-object-map' ), $settings['card_show_excerpt'], __( 'Show a short description (two lines) in the card', 'mvweb-object-map' ) );
	?>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Shape & density', 'mvweb-object-map' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_radius" class="mvweb-form-row__label"><?php esc_html_e( 'Corner radius (px)', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_om_card_radius" class="mvweb-input" min="0" max="40" step="1"
				name="<?php echo esc_attr( $opt ); ?>[card_radius]"
				value="<?php echo esc_attr( (string) $settings['card_radius'] ); ?>">
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_border_width" class="mvweb-form-row__label"><?php esc_html_e( 'Border width (px)', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_om_card_border_width" class="mvweb-input" min="0" max="8" step="1"
				name="<?php echo esc_attr( $opt ); ?>[card_border_width]"
				value="<?php echo esc_attr( (string) $settings['card_border_width'] ); ?>">
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_density" class="mvweb-form-row__label"><?php esc_html_e( 'Density', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_om_card_density" class="mvweb-select" name="<?php echo esc_attr( $opt ); ?>[card_density]">
				<option value="comfortable" <?php selected( $settings['card_density'], 'comfortable' ); ?>><?php esc_html_e( 'Comfortable', 'mvweb-object-map' ); ?></option>
				<option value="compact" <?php selected( $settings['card_density'], 'compact' ); ?>><?php esc_html_e( 'Compact', 'mvweb-object-map' ); ?></option>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_shadow" class="mvweb-form-row__label"><?php esc_html_e( 'Shadow', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" id="mvweb_om_card_shadow" value="1"
						name="<?php echo esc_attr( $opt ); ?>[card_shadow]"
						<?php checked( $settings['card_shadow'] ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Add a soft drop shadow to cards', 'mvweb-object-map' ); ?></span>
			</div>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Photo', 'mvweb-object-map' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_photo_size" class="mvweb-form-row__label"><?php esc_html_e( 'Photo size (px)', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_om_card_photo_size" class="mvweb-input" min="32" max="160" step="1"
				name="<?php echo esc_attr( $opt ); ?>[card_photo_size]"
				value="<?php echo esc_attr( (string) $settings['card_photo_size'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Applies when the photo is on the left. On top, the photo is full width.', 'mvweb-object-map' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_photo_pos" class="mvweb-form-row__label"><?php esc_html_e( 'Photo position', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_om_card_photo_pos" class="mvweb-select" name="<?php echo esc_attr( $opt ); ?>[card_photo_pos]">
				<option value="left" <?php selected( $settings['card_photo_pos'], 'left' ); ?>><?php esc_html_e( 'Left', 'mvweb-object-map' ); ?></option>
				<option value="top" <?php selected( $settings['card_photo_pos'], 'top' ); ?>><?php esc_html_e( 'Top', 'mvweb-object-map' ); ?></option>
			</select>
		</div>
	</div>
</div>
