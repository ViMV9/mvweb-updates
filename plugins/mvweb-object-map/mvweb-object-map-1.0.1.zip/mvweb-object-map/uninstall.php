<?php
/**
 * Uninstall MVweb Object Map.
 *
 * Object posts, taxonomy terms and plugin options are removed only when the
 * "Delete all data on uninstall" setting is enabled. Otherwise everything is
 * preserved so the data survives a reinstall.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Remove all plugin data for the current site.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_om_uninstall_site() {
	$settings = get_option( 'mvweb_om_settings', array() );
	$delete   = is_array( $settings ) && ! empty( $settings['delete_data_on_uninstall'] );

	if ( ! $delete ) {
		return;
	}

	$objects = get_posts(
		array(
			'post_type'        => 'mvweb_object',
			'post_status'      => 'any',
			'numberposts'      => -1,
			'fields'           => 'ids',
			'suppress_filters' => true,
		)
	);
	foreach ( $objects as $object_id ) {
		wp_delete_post( $object_id, true );
	}

	$terms = get_terms(
		array(
			'taxonomy'   => 'mvweb_object_category',
			'hide_empty' => false,
			'fields'     => 'ids',
		)
	);
	if ( is_array( $terms ) ) {
		foreach ( $terms as $term_id ) {
			wp_delete_term( $term_id, 'mvweb_object_category' );
		}
	}

	$cache_keys = get_option( 'mvweb_om_cache_keys', array() );
	if ( is_array( $cache_keys ) ) {
		foreach ( $cache_keys as $key ) {
			delete_transient( $key );
		}
	}

	delete_option( 'mvweb_om_settings' );
	delete_option( 'mvweb_om_cache_keys' );
}

if ( is_multisite() ) {
	$sites = get_sites();
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );
		mvweb_om_uninstall_site();
		restore_current_blog();
	}
} else {
	mvweb_om_uninstall_site();
}

wp_cache_flush();
