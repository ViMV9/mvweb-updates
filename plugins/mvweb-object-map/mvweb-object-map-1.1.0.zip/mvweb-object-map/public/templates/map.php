<?php
/**
 * Frontend map template.
 *
 * @package mvweb_om
 * @since   1.0.0
 *
 * @var array  $config       Per-instance config (provided by MVweb_OM_Shortcode::render()).
 * @var array  $root_classes Root container classes (design modifiers).
 * @var string $dom_id       Unique container ID.
 * @var string $height       Sanitized CSS height.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mvweb_om_config_json = wp_json_encode( $config );
?>
<div class="<?php echo esc_attr( implode( ' ', $root_classes ) ); ?>"
	id="<?php echo esc_attr( $dom_id ); ?>"
	data-scheme="<?php echo esc_attr( $config['scheme'] ); ?>"
	data-config="<?php echo esc_attr( $mvweb_om_config_json ? $mvweb_om_config_json : '{}' ); ?>">

	<?php if ( $config['list'] ) : ?>
		<div class="mvweb-om__tabs" role="tablist">
			<button type="button" class="mvweb-om__tab mvweb-om__tab--active" data-view="map" role="tab" aria-selected="true"><?php esc_html_e( 'Map', 'mvweb-object-map' ); ?></button>
			<button type="button" class="mvweb-om__tab" data-view="list" role="tab" aria-selected="false"><?php esc_html_e( 'List', 'mvweb-object-map' ); ?></button>
		</div>
	<?php endif; ?>

	<div class="mvweb-om__body">
		<div class="mvweb-om__map" style="height:<?php echo esc_attr( $height ); ?>">
			<div class="mvweb-om__status">
				<span class="mvweb-om__spinner" aria-hidden="true"></span>
				<span class="mvweb-om__status-text"></span>
			</div>
			<?php if ( $config['filter'] ) : ?>
				<div class="mvweb-om__filter" hidden></div>
			<?php endif; ?>
			<div class="mvweb-om__canvas"></div>
		</div>

		<?php if ( $config['list'] ) : ?>
			<div class="mvweb-om__list">
				<div class="mvweb-om__list-controls">
					<label class="mvweb-om__sr" for="<?php echo esc_attr( $dom_id ); ?>-search"><?php esc_html_e( 'Search objects', 'mvweb-object-map' ); ?></label>
					<input type="search" class="mvweb-om__search" id="<?php echo esc_attr( $dom_id ); ?>-search">
					<label class="mvweb-om__sr" for="<?php echo esc_attr( $dom_id ); ?>-sort"><?php esc_html_e( 'Sort objects', 'mvweb-object-map' ); ?></label>
					<select class="mvweb-om__sort" id="<?php echo esc_attr( $dom_id ); ?>-sort">
						<option value="name"></option>
						<option value="new"></option>
					</select>
				</div>
				<div class="mvweb-om__cards"></div>
			</div>
		<?php endif; ?>
	</div>
</div>
