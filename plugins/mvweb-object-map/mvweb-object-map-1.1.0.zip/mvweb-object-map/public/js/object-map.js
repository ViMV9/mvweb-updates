/**
 * Frontend map for MVweb Object Map.
 *
 * Renders a Yandex map (JS API 3.0) per [mvweb_map] instance: markers,
 * clustering, category filter and balloons. All object text is inserted via
 * textContent and URLs via setAttribute — never innerHTML — because the REST
 * payload is plain text and must not be trusted as HTML.
 *
 * The file is both the classic view and the core for design variants. Variant
 * modules register themselves through window.mvwebOm.register(); an axis
 * without a module (or set to "classic") runs the classic code below.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

(function () {
	'use strict';

	var data = window.mvwebOmData || {};
	var i18n = data.i18n || {};

	var AXES = ['marker', 'balloon', 'list', 'mobile'];
	var SLUG = /^[a-z0-9-]+$/;
	var SCHEMES = ['light', 'dark', 'auto'];
	var PHONE_QUERY = '(max-width: 782px)';
	var BEHAVIORS_FULL = ['drag', 'pinchZoom', 'scrollZoom', 'dblClick'];
	var CLUSTER_Z = 200000;
	var BEHAVIORS_TOUCH = ['pinchZoom', 'dblClick'];
	var SEARCH_DELAY = 180;
	var SVG_NS = 'http://www.w3.org/2000/svg';

	var registry = { marker: {}, balloon: {}, list: {}, mobile: {} };
	var waiters = [];
	var collator = new Intl.Collator();
	var lockCount = 0;
	var WAIT_MAX = 3000;

	var api = window.mvwebOm = window.mvwebOm || {};

	/**
	 * Register a variant module factory.
	 *
	 * The factory is called once per map instance with ctx and returns the
	 * module object for the axis (see MapInstance.prototype.createModules).
	 *
	 * @param {string}   axis    One of marker, balloon, list, mobile.
	 * @param {string}   name    Variant slug.
	 * @param {Function} factory function (ctx) returning the module object.
	 */
	api.register = function (axis, name, factory) {
		if (!registry.hasOwnProperty(axis) || !SLUG.test(String(name)) || typeof factory !== 'function') {
			return;
		}
		registry[axis][name] = factory;
		waiters = waiters.filter(function (check) {
			return !check();
		});
	};

	/**
	 * Resolve once the variant modules a map needs are registered.
	 *
	 * Variant scripts run after the core, and a script optimizer may run the
	 * core after the document is parsed. The map then waits for the modules;
	 * after the page load (or WAIT_MAX when it is already loaded) it gives up
	 * and the missing axes fall back to the classic view.
	 *
	 * @param {Array} needed [axis, slug] pairs.
	 * @return {Promise}
	 */
	function whenRegistered(needed) {
		return new Promise(function (resolve) {
			var check = function () {
				var ready = needed.every(function (pair) {
					return api.get(pair[0], pair[1]);
				});
				if (ready) {
					resolve();
				}
				return ready;
			};
			if (check()) {
				return;
			}
			waiters.push(check);
			if (document.readyState === 'complete') {
				setTimeout(resolve, WAIT_MAX);
			} else {
				window.addEventListener('load', function () {
					setTimeout(resolve, 0);
				}, { once: true });
			}
		});
	}

	/**
	 * Look up a registered factory.
	 *
	 * @param {string} axis Axis name.
	 * @param {string} name Variant slug.
	 * @return {Function|null}
	 */
	api.get = function (axis, name) {
		return (registry.hasOwnProperty(axis) && registry[axis].hasOwnProperty(name)) ? registry[axis][name] : null;
	};

	/**
	 * Create all map instances on the page.
	 */
	function boot() {
		document.querySelectorAll('.mvweb-om').forEach(function (root) {
			new MapInstance(root).init();
		});
	}

	/**
	 * One map instance bound to a single shortcode container.
	 *
	 * @param {HTMLElement} root Container element.
	 */
	function MapInstance(root) {
		this.root = root;
		this.config = parseConfig(root.getAttribute('data-config'));
		this.canvas = root.querySelector('.mvweb-om__canvas');
		this.statusEl = root.querySelector('.mvweb-om__status');
		this.statusText = root.querySelector('.mvweb-om__status-text');
		this.filterEl = root.querySelector('.mvweb-om__filter');
		this.map = null;
		this.markersLayer = null;
		this.clusterer = null;
		this.markerObjects = [];
		this.markerEls = Object.create(null);
		this.objects = [];
		this.categories = [];
		this.schema = [];
		this.byId = Object.create(null);
		this.activeCats = new Set();
		this.query = '';
		this.sort = 'name';
		this.selectedId = null;
		this.hoverId = null;
		this.viewCache = null;
		this.handlers = Object.create(null);
		this.insets = Object.create(null);
		this.locks = 0;
		this.focusEl = null;
		this.focusId = null;
		this.mods = { marker: null, balloon: null, list: null, mobile: null, phone: null };
		this.ctx = null;
		this.applyAccent();
		this.applyCardStyle();
	}

	/**
	 * Start loading: the map API, the REST payload and the clusterer run in
	 * parallel, the map is drawn when all three are settled.
	 */
	MapInstance.prototype.init = function () {
		if (!data.hasKey || typeof ymaps3 === 'undefined') {
			this.showStatus(i18n.noKey || '');
			return;
		}
		this.showStatus(i18n.loading || '');

		var self = this;
		var ready = ymaps3.ready;
		Promise.all([
			ready,
			this.fetchObjects(),
			ready.then(function () {
				return self.loadClusterer();
			}),
			whenRegistered(this.neededModules())
		])
			.then(function (result) {
				var payload = result[1];
				self.objects = (payload && payload.objects) || [];
				self.categories = (payload && payload.categories) || [];
				self.schema = (payload && payload.schema) || [];
				if (!self.objects.length) {
					self.showStatus(i18n.empty || '');
					return;
				}
				self.clustererApi = result[2];
				self.buildIndex();
				self.buildCategoryColors();
				self.spreadOverlaps();
				self.renderMap();
			})
			.catch(function (err) {
				console.error('[mvweb-om]', err);
				self.showStatus(i18n.error || '');
			});
	};

	/**
	 * Variant modules this map needs, as [axis, slug] pairs.
	 *
	 * A "list-*" phone view belongs to the list module, not to a mobile one.
	 *
	 * @return {Array}
	 */
	MapInstance.prototype.neededModules = function () {
		var variants = this.config.variants;
		var out = [];
		AXES.forEach(function (axis) {
			if (variants[axis] !== 'classic') {
				out.push([axis, variants[axis]]);
			}
		});
		if (variants.phone !== 'classic' && variants.phone.indexOf('list-') !== 0) {
			out.push(['mobile', variants.phone]);
		}
		return out;
	};

	/**
	 * Apply the configured accent color as a CSS variable on the root.
	 */
	MapInstance.prototype.applyAccent = function () {
		if (data.accent) {
			this.root.style.setProperty('--mvweb-om-accent', data.accent);
		}
	};

	/**
	 * Apply the configured list-card appearance (CSS variables + modifiers).
	 */
	MapInstance.prototype.applyCardStyle = function () {
		var c = data.card;
		if (!c) {
			return;
		}
		var s = this.root.style;
		var setVar = function (name, value) {
			if (value) {
				s.setProperty(name, value);
			}
		};
		setVar('--mvweb-om-card-bg', c.bg);
		setVar('--mvweb-om-card-border', c.border);
		setVar('--mvweb-om-card-title', c.titleColor);
		setVar('--mvweb-om-card-text', c.textColor);
		setVar('--mvweb-om-card-hover', c.hoverBorder);
		if (c.radius || 0 === c.radius) {
			s.setProperty('--mvweb-om-card-radius', c.radius + 'px');
		}
		if (c.borderWidth || 0 === c.borderWidth) {
			s.setProperty('--mvweb-om-card-border-width', c.borderWidth + 'px');
		}
		if (c.photoSize) {
			s.setProperty('--mvweb-om-card-photo', c.photoSize + 'px');
		}
		if (c.photoRatio) {
			s.setProperty('--mvweb-om-card-ratio', c.photoRatio);
		}
		this.root.classList.toggle('mvweb-om--cards-compact', 'compact' === c.density);
		this.root.classList.toggle('mvweb-om--cards-shadow', !!c.shadow);
		this.root.classList.toggle('mvweb-om--cards-photo-top', 'top' === c.photoPos);
	};

	/**
	 * Show a status message (spinner area).
	 *
	 * @param {string} text Message.
	 */
	MapInstance.prototype.showStatus = function (text) {
		if (this.statusText) {
			this.statusText.textContent = text;
		}
		if (this.statusEl) {
			this.statusEl.hidden = false;
		}
		this.root.classList.add('mvweb-om--status');
	};

	/**
	 * Hide the status message.
	 */
	MapInstance.prototype.hideStatus = function () {
		if (this.statusEl) {
			this.statusEl.hidden = true;
		}
		this.root.classList.remove('mvweb-om--status');
	};

	/**
	 * Fetch objects from the REST endpoint with the instance filter.
	 *
	 * @return {Promise} Resolves to the decoded payload.
	 */
	MapInstance.prototype.fetchObjects = function () {
		var url = new URL(data.restUrl, window.location.origin);
		if (this.config.category) {
			url.searchParams.set('category', this.config.category);
		}
		if (this.config.ids) {
			url.searchParams.set('ids', this.config.ids);
		}

		return fetch(url.toString(), { credentials: 'omit' }).then(function (res) {
			if (!res.ok) {
				throw new Error('HTTP ' + res.status);
			}
			return res.json();
		});
	};

	/**
	 * Index the loaded objects by id.
	 */
	MapInstance.prototype.buildIndex = function () {
		var byId = Object.create(null);
		this.objects.forEach(function (obj) {
			byId[String(obj.id)] = obj;
		});
		this.byId = byId;
	};

	/**
	 * Create the Yandex map and draw everything.
	 *
	 * Runs once the API, the payload and the clusterer are available.
	 */
	MapInstance.prototype.renderMap = function () {
		var YMap = ymaps3.YMap;
		var YMapDefaultSchemeLayer = ymaps3.YMapDefaultSchemeLayer;
		var YMapDefaultFeaturesLayer = ymaps3.YMapDefaultFeaturesLayer;

		var center = this.resolveCenter();
		var zoom = this.config.zoom || data.defaultZoom || 10;
		var props = { location: { center: center, zoom: zoom } };
		var twoFingers = isCoarsePointer() && 'preview' !== this.config.variants.phone;
		if (twoFingers) {
			props.behaviors = BEHAVIORS_TOUCH;
		}

		this.map = new YMap(this.canvas, props);
		this.map.addChild(new YMapDefaultSchemeLayer({}));
		this.markersLayer = new YMapDefaultFeaturesLayer();
		this.map.addChild(this.markersLayer);

		this.applyTheme();
		if (twoFingers) {
			this.initTwoFingers();
		}

		this.ctx = this.buildContext();
		this.createModules();

		this.drawMarkers();
		this.fitToMarkers();
		if (this.mods.list) {
			this.mods.list.render(this.view());
		} else {
			this.buildFilter();
			this.buildList();
		}
		this.initTabs();
		this.hideStatus();
	};

	/**
	 * Load the grid clusterer package when clustering is enabled.
	 *
	 * The ymaps3 loader fetches the package from its own CDN, no extra CDN
	 * registration is needed. A failed load is non-fatal — the map falls back
	 * to plain (unclustered) markers instead of erroring out.
	 *
	 * @return {Promise} Resolves to the clusterer module or null.
	 */
	MapInstance.prototype.loadClusterer = function () {
		if (!this.clusterEnabled()) {
			return Promise.resolve(null);
		}
		return ymaps3.import('@yandex/ymaps3-clusterer@0.0.1').catch(function () {
			return null;
		});
	};

	/**
	 * Whether clustering is enabled (instance override or global default).
	 *
	 * @return {boolean}
	 */
	MapInstance.prototype.clusterEnabled = function () {
		var override = this.config.cluster;
		if (override === true || override === false) {
			return override;
		}
		return !!data.cluster;
	};

	/**
	 * Resolve the start center from config or the first object.
	 *
	 * @return {Array} [lng, lat]
	 */
	MapInstance.prototype.resolveCenter = function () {
		var center = parseLatLng(this.config.center) || parseLatLng(data.defaultCenter);
		if (center) {
			return center;
		}
		var first = this.objects[0];
		return first ? [first.lng, first.lat] : [37.617635, 55.755814];
	};

	/**
	 * Apply the map theme from the scheme setting and follow the system
	 * preference when the scheme is "auto".
	 *
	 * Only the map is recolored; the classic cards and balloon stay as they are.
	 */
	MapInstance.prototype.applyTheme = function () {
		var self = this;
		var scheme = this.config.scheme;
		if (scheme !== 'auto' || !window.matchMedia) {
			this.setMapTheme('dark' === scheme ? 'dark' : 'light');
			return;
		}
		this.themeQuery = window.matchMedia('(prefers-color-scheme: dark)');
		this.themeListener = function () {
			self.setMapTheme(self.themeQuery.matches ? 'dark' : 'light');
		};
		this.themeQuery.addEventListener('change', this.themeListener);
		this.themeListener();
	};

	/**
	 * Switch the map theme.
	 *
	 * @param {string} theme light or dark.
	 */
	MapInstance.prototype.setMapTheme = function (theme) {
		try {
			this.map.update({ theme: theme });
		} catch (err) {
			return;
		}
	};

	/**
	 * Touch screens: one finger scrolls the page, two fingers move the map.
	 *
	 * The map starts without drag; a second finger switches drag on, the last
	 * finger lifted switches it off. A single-finger swipe shows a hint.
	 */
	MapInstance.prototype.initTwoFingers = function () {
		var self = this;
		var host = this.root.querySelector('.mvweb-om__map');
		var hint = document.createElement('div');
		var timer = 0;
		hint.className = 'mvweb-om__touch-hint';
		hint.setAttribute('aria-hidden', 'true');
		hint.textContent = i18n.twoFingers || 'Use two fingers to move the map';
		if (host) {
			host.appendChild(hint);
		}
		this.root.classList.add('mvweb-om--two-fingers');

		var options = { passive: true, capture: true };
		this.canvas.addEventListener('touchstart', function (e) {
			if (e.touches.length >= 2) {
				self.map.setBehaviors(BEHAVIORS_FULL);
				hint.classList.remove('mvweb-om__touch-hint--on');
			}
		}, options);
		this.canvas.addEventListener('touchmove', function (e) {
			if (e.touches.length === 1 && !(e.target && e.target.closest && e.target.closest('[class*="mvweb-om-balloon-"]'))) {
				hint.classList.add('mvweb-om__touch-hint--on');
				clearTimeout(timer);
				timer = setTimeout(function () {
					hint.classList.remove('mvweb-om__touch-hint--on');
				}, 1200);
			}
		}, options);
		var release = function (e) {
			if (e.touches.length === 0) {
				self.map.setBehaviors(BEHAVIORS_TOUCH);
			}
		};
		this.canvas.addEventListener('touchend', release, options);
		this.canvas.addEventListener('touchcancel', release, options);
	};

	/**
	 * Build the ctx object handed to variant modules.
	 *
	 * @return {Object}
	 */
	MapInstance.prototype.buildContext = function () {
		var self = this;
		return {
			root: this.root,
			map: this.map,
			data: data,
			i18n: i18n,
			config: this.config,
			schema: this.schema,
			objects: this.objects,
			categories: this.categories,
			view: function () { return self.view(); },
			select: function (id, source) { self.select(id, source); },
			hover: function (id) { self.hover(id); },
			setCats: function (cats) { self.setCats(cats); },
			setQuery: function (query) { self.setQuery(query); },
			setSort: function (sort) { self.setSort(sort); },
			on: function (name, fn) { self.on(name, fn); },
			off: function (name, fn) { self.off(name, fn); },
			flyTo: function (obj, opts) { self.flyTo(obj, opts); },
			setInsets: function (owner, insets) { self.setInsets(owner, insets); },
			insets: function (except) { return self.insetSum(except); },
			isPhone: isPhone,
			lock: function () { self.lock(); },
			unlock: function () { self.unlock(); },
			focus: {
				remember: function (el) { self.rememberFocus(el); },
				restore: function () { self.restoreFocus(); }
			},
			neighbors: function (id) { return self.neighbors(id); },
			icon: icon
		};
	};

	/**
	 * Instantiate the registered modules for the chosen variants and mount them.
	 *
	 * Module shapes:
	 * marker  — create(obj, ctx), cluster(features, coordinates, ctx), gridSize.
	 * balloon — open(obj), close(), minMap { width, height }.
	 * list    — render(view).
	 * mobile  — open(obj), close(), detailPc(obj), minMap { width, height }.
	 * Any module may also define mount(ctx), and destroy() that undoes a failed
	 * mount. open/close must be safe to call repeatedly.
	 */
	MapInstance.prototype.createModules = function () {
		var variants = this.config.variants;
		var self = this;
		var made = Object.create(null);
		var make = function (axis, name) {
			if (!name || name === 'classic') {
				return null;
			}
			var key = axis + ':' + name;
			if (key in made) {
				return made[key];
			}
			var factory = api.get(axis, name);
			var mod = null;
			if (factory) {
				try {
					mod = factory(self.ctx) || null;
				} catch (err) {
					console.error('[mvweb-om] ' + axis + '/' + name, err);
					mod = null;
				}
			}
			made[key] = mod;
			return mod;
		};

		AXES.forEach(function (axis) {
			self.mods[axis] = make(axis, variants[axis]);
		});
		this.mods.phone = make('mobile', variants.phone);
		if (this.mods.list && typeof this.mods.list.render !== 'function') {
			this.mods.list = null;
		}

		this.uniqueMods().forEach(function (mod) {
			if (typeof mod.mount === 'function') {
				try {
					mod.mount(self.ctx);
				} catch (err) {
					console.error('[mvweb-om] mount', err);
					if (typeof mod.destroy === 'function') {
						try {
							mod.destroy();
						} catch (ignore) {
							console.error('[mvweb-om] destroy', ignore);
						}
					}
					Object.keys(self.mods).forEach(function (key) {
						if (self.mods[key] === mod) {
							self.mods[key] = null;
						}
					});
				}
			}
		});

		this.markFallbacks();
	};

	/**
	 * Swap the root class of every axis whose module did not start to the
	 * classic one, so the variant stylesheets stop hiding the classic parts.
	 */
	MapInstance.prototype.markFallbacks = function () {
		var variants = this.config.variants;
		var mods = this.mods;
		var root = this.root;
		var swap = function (axis) {
			root.classList.remove('mvweb-om--' + axis + '-' + variants[axis]);
			root.classList.add('mvweb-om--' + axis + '-classic');
		};

		AXES.forEach(function (axis) {
			if (variants[axis] !== 'classic' && !mods[axis]) {
				swap(axis);
			}
		});
		var phoneOwner = variants.phone.indexOf('list-') === 0 ? mods.list : mods.phone;
		if (variants.phone !== 'classic' && !phoneOwner) {
			swap('phone');
		}
	};

	/**
	 * All distinct module objects of this instance.
	 *
	 * @return {Array}
	 */
	MapInstance.prototype.uniqueMods = function () {
		var out = [];
		var mods = this.mods;
		Object.keys(mods).forEach(function (axis) {
			if (mods[axis] && out.indexOf(mods[axis]) === -1) {
				out.push(mods[axis]);
			}
		});
		return out;
	};

	/**
	 * Subscribe to an instance event: select, deselect, hover, filter, visible,
	 * viewport.
	 *
	 * @param {string}   name Event name.
	 * @param {Function} fn   Handler.
	 */
	MapInstance.prototype.on = function (name, fn) {
		if (typeof fn !== 'function') {
			return;
		}
		(this.handlers[name] = this.handlers[name] || []).push(fn);
		if ('viewport' === name) {
			this.watchViewport();
		}
	};

	/**
	 * Remove an event handler.
	 *
	 * @param {string}   name Event name.
	 * @param {Function} fn   Handler passed to on().
	 */
	MapInstance.prototype.off = function (name, fn) {
		var list = this.handlers[name];
		var at = list ? list.indexOf(fn) : -1;
		if (at !== -1) {
			list.splice(at, 1);
		}
	};

	/**
	 * Fire an instance event.
	 *
	 * @param {string} name    Event name.
	 * @param {*}      payload Event data.
	 */
	MapInstance.prototype.emit = function (name, payload) {
		var list = this.handlers[name];
		if (!list) {
			return;
		}
		list.slice().forEach(function (fn) {
			try {
				fn(payload);
			} catch (err) {
				console.error('[mvweb-om] ' + name, err);
			}
		});
	};

	/**
	 * Start forwarding map movement as the viewport event (once, on demand).
	 */
	MapInstance.prototype.watchViewport = function () {
		if (this.viewportBound || !this.map || !ymaps3.YMapListener) {
			return;
		}
		this.viewportBound = true;
		var self = this;
		var frame = 0;
		var last = null;
		this.map.addChild(new ymaps3.YMapListener({
			layer: 'any',
			onUpdate: function (event) {
				last = event;
				if (frame) {
					return;
				}
				frame = requestAnimationFrame(function () {
					var loc = (last && last.location) || {};
					frame = 0;
					self.emit('viewport', {
						center: loc.center,
						zoom: loc.zoom,
						bounds: loc.bounds,
						inAction: !!(last && last.mapInAction)
					});
				});
			}
		}));
	};

	/**
	 * Select an object, or clear the selection when id is empty.
	 *
	 * @param {number|string|null} id     Object id.
	 * @param {string}             source Who asked: marker, list or any module name.
	 */
	MapInstance.prototype.select = function (id, source) {
		if (null === id || undefined === id || '' === id) {
			this.deselect();
			return;
		}
		var obj = this.byId[String(id)];
		if (!obj) {
			return;
		}
		var from = source || 'api';
		var prev = this.selectedId;
		if (null !== prev && String(prev) !== String(obj.id)) {
			this.markerState(prev, 'mvweb-om__marker--selected', false);
		}
		this.selectedId = obj.id;
		this.markerState(obj.id, 'mvweb-om__marker--selected', true);
		this.emit('select', { id: obj.id, obj: obj, source: from, prev: prev });
		this.showObject(obj, from);
	};

	/**
	 * Clear the selection and close whatever shows the object.
	 */
	MapInstance.prototype.deselect = function () {
		var prev = this.selectedId;
		if (null === prev) {
			return;
		}
		this.selectedId = null;
		this.markerState(prev, 'mvweb-om__marker--selected', false);
		this.closeObject(null);
		this.emit('deselect', { id: prev });
	};

	/**
	 * Mark an object as hovered (or clear the hover when id is empty).
	 *
	 * @param {number|string|null} id Object id.
	 */
	MapInstance.prototype.hover = function (id) {
		var next = (null === id || undefined === id || '' === id) ? null : id;
		if (null !== this.hoverId) {
			this.markerState(this.hoverId, 'mvweb-om__marker--hover', false);
		}
		this.hoverId = next;
		if (null !== next) {
			this.markerState(next, 'mvweb-om__marker--hover', true);
		}
		this.emit('hover', { id: next, obj: null === next ? null : (this.byId[String(next)] || null) });
	};

	/**
	 * Toggle a state class on the current marker element of an object.
	 *
	 * @param {number|string} id  Object id.
	 * @param {string}        cls Class name.
	 * @param {boolean}       on  Add or remove.
	 */
	MapInstance.prototype.markerState = function (id, cls, on) {
		var el = this.markerEls[String(id)];
		if (el) {
			el.classList.toggle(cls, on);
		}
		this.clusterState();
	};

	/**
	 * Mark the clusters that hide the hovered or the selected object.
	 */
	MapInstance.prototype.clusterState = function () {
		var hover = null === this.hoverId ? null : String(this.hoverId);
		var selected = null === this.selectedId ? null : String(this.selectedId);
		this.clusterEls = (this.clusterEls || []).filter(function (el) {
			return el.isConnected;
		});
		this.clusterEls.forEach(function (el) {
			var ids = el.mvwebOmIds || [];
			el.classList.toggle('mvweb-om__cluster--hover', null !== hover && ids.indexOf(hover) !== -1);
			el.classList.toggle('mvweb-om__cluster--selected', null !== selected && ids.indexOf(selected) !== -1);
		});
	};

	/**
	 * Show the selected object with the part that owns the current context.
	 *
	 * Phone: the phone module, else the classic code. Desktop: a marker click
	 * opens the balloon (module or classic); a list click centers the map and
	 * opens the object window (module, classic modal) or the balloon module.
	 *
	 * @param {Object} obj    Object data.
	 * @param {string} source Selection source.
	 */
	MapInstance.prototype.showObject = function (obj, source) {
		var mods = this.mods;
		var phone = isPhone();
		var fromList = 'marker' !== source && 'api' !== source && 'balloon' !== source;

		if (phone && mods.phone && typeof mods.phone.open === 'function') {
			this.closeObject(mods.phone);
			if (fromList) {
				this.flyTo(obj, { zoom: 16 });
			}
			mods.phone.open(obj);
			return;
		}

		if (!fromList) {
			if (mods.balloon && typeof mods.balloon.open === 'function' && this.fits(mods.balloon)) {
				this.closeObject(mods.balloon);
				mods.balloon.open(obj);
				return;
			}
			this.openBalloon(obj);
			return;
		}

		this.flyTo(obj, { zoom: 16 });
		if (mods.mobile && typeof mods.mobile.detailPc === 'function' && this.fits(mods.mobile)) {
			this.closeObject(mods.mobile);
			mods.mobile.detailPc(obj);
		} else if (data.modal) {
			this.openModal(obj);
		} else if (mods.balloon && typeof mods.balloon.open === 'function' && this.fits(mods.balloon)) {
			this.closeObject(mods.balloon);
			mods.balloon.open(obj);
		} else if (mods.mobile || mods.list) {
			this.openBalloon(obj);
		}
	};

	/**
	 * Whether the map is large enough for a module (its minMap).
	 *
	 * @param {Object} mod Module object.
	 * @return {boolean}
	 */
	MapInstance.prototype.fits = function (mod) {
		var min = mod && mod.minMap;
		if (!min) {
			return true;
		}
		return (!min.width || this.canvas.clientWidth >= min.width) && (!min.height || this.canvas.clientHeight >= min.height);
	};

	/**
	 * Close every object view except the one given (classic balloon, classic
	 * modal and all module views).
	 *
	 * @param {Object|null} keep Module that is about to open.
	 */
	MapInstance.prototype.closeObject = function (keep) {
		this.closeBalloon();
		this.closeModal();
		this.uniqueMods().forEach(function (mod) {
			if (mod !== keep && typeof mod.close === 'function') {
				mod.close();
			}
		});
	};

	/**
	 * Fly the map to an object. Centers in the free part of the map when
	 * insets are set.
	 *
	 * @param {Object} obj  Object data.
	 * @param {Object} opts Optional { zoom, duration }.
	 */
	MapInstance.prototype.flyTo = function (obj, opts) {
		var location = {
			center: [obj.lng, obj.lat],
			duration: (opts && undefined !== opts.duration) ? opts.duration : 300
		};
		if (opts && opts.zoom) {
			location.zoom = opts.zoom;
		}
		this.map.update({ location: location });
	};

	/**
	 * Set the part of the map covered by an owner's panel. Owners add up.
	 *
	 * @param {string}      owner Owner key.
	 * @param {Object|null} inset { t, r, b, l } in px, null removes the owner.
	 */
	MapInstance.prototype.setInsets = function (owner, inset) {
		if (inset) {
			this.insets[owner] = [inset.t || 0, inset.r || 0, inset.b || 0, inset.l || 0];
		} else {
			delete this.insets[owner];
		}
		var sum = this.insetSum();
		var style = this.root.style;
		style.setProperty('--mvweb-om-inset-r', sum.r + 'px');
		style.setProperty('--mvweb-om-inset-b', sum.b + 'px');
		style.setProperty('--mvweb-om-inset-l', sum.l + 'px');
		if (this.map && typeof this.map.setMargin === 'function') {
			this.map.setMargin([sum.t, sum.r, sum.b, sum.l]);
		}
	};

	/**
	 * Sum of the panel insets, optionally without one owner.
	 *
	 * @param {string} except Owner key to leave out.
	 * @return {Object} { t, r, b, l } in px.
	 */
	MapInstance.prototype.insetSum = function (except) {
		var sum = [0, 0, 0, 0];
		var insets = this.insets;
		Object.keys(insets).forEach(function (key) {
			if (key === except) {
				return;
			}
			for (var i = 0; i < 4; i++) {
				sum[i] += insets[key][i];
			}
		});
		return { t: sum[0], r: sum[1], b: sum[2], l: sum[3] };
	};

	/**
	 * Lock page scroll (counter shared by all instances).
	 */
	MapInstance.prototype.lock = function () {
		this.locks++;
		lockCount++;
		document.documentElement.classList.add('mvweb-om-lock');
	};

	/**
	 * Release one scroll lock taken by this instance.
	 */
	MapInstance.prototype.unlock = function () {
		if (this.locks < 1) {
			return;
		}
		this.locks--;
		lockCount--;
		if (lockCount < 1) {
			document.documentElement.classList.remove('mvweb-om-lock');
		}
	};

	/**
	 * Remember the element to return focus to.
	 *
	 * @param {HTMLElement} el Element, defaults to the active one.
	 */
	MapInstance.prototype.rememberFocus = function (el) {
		this.focusEl = el || document.activeElement;
		this.focusId = this.selectedId;
	};

	/**
	 * Return focus to the remembered element.
	 */
	MapInstance.prototype.restoreFocus = function () {
		var el = this.focusEl;
		this.focusEl = null;
		if ((!el || !el.isConnected) && null !== this.focusId && undefined !== this.focusId) {
			el = this.markerEls[String(this.focusId)];
		}
		this.focusId = null;
		if (el && el.isConnected && typeof el.focus === 'function') {
			el.focus();
		}
	};

	/**
	 * Neighbours of an object in the current list order. The ends wrap around.
	 *
	 * @param {number|string} id Object id.
	 * @return {Object} { prev, next, index, total }; prev and next are objects or null.
	 */
	MapInstance.prototype.neighbors = function (id) {
		var list = this.computeView().objects;
		var total = list.length;
		var index = -1;
		for (var i = 0; i < total; i++) {
			if (String(list[i].id) === String(id)) {
				index = i;
				break;
			}
		}
		if (index === -1 || total < 2) {
			return { prev: null, next: null, index: index, total: total };
		}
		return {
			prev: list[(index - 1 + total) % total],
			next: list[(index + 1) % total],
			index: index,
			total: total
		};
	};

	/**
	 * Set the active categories. The classic filter UI only ever sets one.
	 *
	 * @param {Set|Array} cats Category slugs, empty for all.
	 */
	MapInstance.prototype.setCats = function (cats) {
		var next = new Set();
		if (cats) {
			cats.forEach(function (slug) {
				if (slug) {
					next.add(String(slug));
				}
			});
		}
		this.activeCats = next;
		this.viewCache = null;
		this.syncFilterButtons();
		if (!this.map) {
			return;
		}
		if (null !== this.selectedId && this.visibleObjects().indexOf(this.byId[String(this.selectedId)]) === -1) {
			this.deselect();
		}
		this.drawMarkers();
		this.fitToMarkers();
		this.refreshList();
		this.emit('filter', this.filterState());
	};

	/**
	 * Set the list search query.
	 *
	 * @param {string} query Raw query.
	 */
	MapInstance.prototype.setQuery = function (query) {
		var next = String(query || '').trim().toLowerCase().slice(0, 200);
		if (next === this.query) {
			return;
		}
		this.query = next;
		this.viewCache = null;
		this.refreshList();
		this.emit('filter', this.filterState());
	};

	/**
	 * Set the list sort order.
	 *
	 * @param {string} sort name, new, or spec:<field id>:asc|desc (numeric value of a characteristic).
	 */
	MapInstance.prototype.setSort = function (sort) {
		var next = ('new' === sort || 'name:desc' === sort) ? sort : 'name';
		if (typeof sort === 'string' && /^spec:[a-z0-9_-]+:(asc|desc)$/.test(sort)) {
			next = sort;
		}
		if (next === this.sort) {
			return;
		}
		this.sort = next;
		this.viewCache = null;
		if (this.sortEl && this.sortEl.value !== next && this.sortEl.querySelector('option[value="' + next + '"]')) {
			this.sortEl.value = next;
		}
		this.refreshList();
		this.emit('filter', this.filterState());
	};

	/**
	 * Current filter state for the filter event.
	 *
	 * @return {Object}
	 */
	MapInstance.prototype.filterState = function () {
		return { cats: Array.from(this.activeCats), query: this.query, sort: this.sort };
	};

	/**
	 * Re-render the list part that owns the current view.
	 */
	MapInstance.prototype.refreshList = function () {
		if (!this.map) {
			return;
		}
		if (this.mods.list) {
			this.mods.list.render(this.view());
		} else if (this.cardsEl) {
			this.renderCards();
		}
	};

	/**
	 * The list as shown: filtered by categories and search, sorted.
	 *
	 * Search matches the title; modules of the list axis also match the address.
	 *
	 * @return {Object} { objects }
	 */
	MapInstance.prototype.computeView = function () {
		if (this.viewCache) {
			return this.viewCache;
		}
		var query = this.query;
		var withAddress = !!(this.mods.list || this.mods.phone);
		var list = this.visibleObjects().slice();
		if (query) {
			list = list.filter(function (obj) {
				return (obj.title || '').toLowerCase().indexOf(query) !== -1 ||
					(withAddress && (obj.address || '').toLowerCase().indexOf(query) !== -1);
			});
		}
		if ('name' === this.sort || 'name:desc' === this.sort) {
			var nameDir = 'name:desc' === this.sort ? -1 : 1;
			list.sort(function (a, b) {
				return collator.compare(a.title || '', b.title || '') * nameDir;
			});
		} else if (0 === this.sort.indexOf('spec:')) {
			var parts = this.sort.split(':');
			var dir = 'desc' === parts[2] ? -1 : 1;
			list.sort(function (a, b) {
				var va = specRaw(a, parts[1]);
				var vb = specRaw(b, parts[1]);
				if (null === va || null === vb) {
					return null === va ? (null === vb ? 0 : 1) : -1;
				}
				return (va - vb) * dir;
			});
		}
		this.viewCache = { objects: list };
		return this.viewCache;
	};

	/**
	 * State snapshot for list modules.
	 *
	 * @return {Object} { objects, total, cats, query, sort, selectedId, hoverId }
	 */
	MapInstance.prototype.view = function () {
		return {
			objects: this.computeView().objects,
			total: this.objects.length,
			cats: Array.from(this.activeCats),
			query: this.query,
			sort: this.sort,
			selectedId: this.selectedId,
			hoverId: this.hoverId
		};
	};

	/**
	 * Build a slug → color map from the category list.
	 */
	MapInstance.prototype.buildCategoryColors = function () {
		this.catColors = Object.create(null);
		var self = this;
		this.categories.forEach(function (cat) {
			if (cat.color) {
				self.catColors[cat.slug] = cat.color;
			}
		});
	};

	/**
	 * Resolve an object's marker color from its first colored category.
	 *
	 * @param {Object} obj Object data.
	 * @return {string} Hex color or '' when none is set.
	 */
	MapInstance.prototype.categoryColor = function (obj) {
		var map = this.catColors || Object.create(null);
		var cats = obj.categories || [];
		for (var i = 0; i < cats.length; i++) {
			if (map[cats[i]]) {
				return map[cats[i]];
			}
		}
		return '';
	};

	/**
	 * Nudge objects sharing the same coordinates onto a small ring so they
	 * cluster at low zoom but separate into side-by-side markers when zoomed
	 * in, instead of staying stacked under a single "N" bubble.
	 */
	MapInstance.prototype.spreadOverlaps = function () {
		var groups = Object.create(null);
		this.objects.forEach(function (obj) {
			var key = obj.lat.toFixed(5) + ',' + obj.lng.toFixed(5);
			(groups[key] = groups[key] || []).push(obj);
		});

		var radius = 0.00025;
		Object.keys(groups).forEach(function (key) {
			var group = groups[key];
			if (group.length < 2) {
				return;
			}
			group.forEach(function (obj, i) {
				var angle = (2 * Math.PI * i) / group.length;
				var latRad = obj.lat * Math.PI / 180;
				obj.routeLat = obj.lat;
				obj.routeLng = obj.lng;
				obj.lat += radius * Math.cos(angle);
				obj.lng += radius * Math.sin(angle) / Math.cos(latRad);
			});
		});
	};

	/**
	 * Draw markers (clustered or plain) for the active categories.
	 */
	MapInstance.prototype.drawMarkers = function () {
		var self = this;
		var list = this.visibleObjects();
		this.clearMarkers();

		if (this.clusterEnabled() && this.clustererApi) {
			this.drawClustered(list);
		} else {
			var YMapMarker = ymaps3.YMapMarker;
			list.forEach(function (obj) {
				var marker = new YMapMarker(
					{ coordinates: [obj.lng, obj.lat], zIndex: markerZ(obj) },
					self.buildMarkerEl(obj)
				);
				self.markersLayer.addChild(marker);
				self.markerObjects.push(marker);
			});
		}
		this.emit('visible', { objects: list });
	};

	/**
	 * Draw markers through the Yandex grid clusterer.
	 *
	 * @param {Array} list Visible objects.
	 */
	MapInstance.prototype.drawClustered = function (list) {
		var self = this;
		var YMapClusterer = this.clustererApi.YMapClusterer;
		var clusterByGrid = this.clustererApi.clusterByGrid;
		var markerMod = this.mods.marker;
		var gridSize = (markerMod && markerMod.gridSize) || 64;

		var features = list.map(function (obj, idx) {
			return {
				type: 'Feature',
				id: String(obj.id),
				geometry: { type: 'Point', coordinates: [obj.lng, obj.lat] },
				properties: { obj: obj, order: idx }
			};
		});

		var marker = function (feature) {
			return new ymaps3.YMapMarker(
				{ coordinates: feature.geometry.coordinates, zIndex: markerZ(feature.properties.obj) },
				self.buildMarkerEl(feature.properties.obj)
			);
		};

		var cluster = function (coordinates, features) {
			return new ymaps3.YMapMarker(
				{ coordinates: coordinates, zIndex: CLUSTER_Z + Math.round(markerZ({ lat: coordinates[1] }) / 10) },
				self.buildClusterEl(features, coordinates)
			);
		};

		this.clusterer = new YMapClusterer({
			method: clusterByGrid({ gridSize: gridSize }),
			features: features,
			marker: marker,
			cluster: cluster
		});
		this.map.addChild(this.clusterer);
	};

	/**
	 * Build a cluster bubble element that zooms in on click.
	 *
	 * @param {Array} features    Clustered features.
	 * @param {Array} coordinates Cluster center [lng, lat].
	 * @return {HTMLElement}
	 */
	MapInstance.prototype.buildClusterEl = function (features, coordinates) {
		var self = this;
		var mod = this.mods.marker;
		var el = null;
		if (mod && typeof mod.cluster === 'function') {
			el = mod.cluster(features, coordinates, this.ctx);
		}
		if (!el) {
			el = this.buildClassicClusterEl(features);
		}

		if (!el.hasAttribute('role')) {
			var label = (i18n.clusterLabel || 'Objects: %d. Zoom in').replace('%d', String(features.length));
			el.setAttribute('role', 'button');
			el.setAttribute('tabindex', '0');
			el.setAttribute('title', label);
			el.appendChild(srText(label));
			el.addEventListener('keydown', function (e) {
				if ('Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key) {
					e.preventDefault();
					el.click();
				}
			});
		}

		el.mvwebOmIds = features.map(function (f) {
			return String(f.properties.obj.id);
		});
		this.clusterEls = (this.clusterEls || []).filter(function (item) {
			return item.isConnected;
		});
		this.clusterEls.push(el);
		if (null !== this.hoverId && el.mvwebOmIds.indexOf(String(this.hoverId)) !== -1) {
			el.classList.add('mvweb-om__cluster--hover');
		}
		if (null !== this.selectedId && el.mvwebOmIds.indexOf(String(this.selectedId)) !== -1) {
			el.classList.add('mvweb-om__cluster--selected');
		}

		el.addEventListener('click', function () {
			var zoom = (self.map.zoom || data.defaultZoom || 10) + 2;
			self.map.update({ location: { center: coordinates, zoom: zoom, duration: 300 } });
		});
		return el;
	};

	/**
	 * Build the classic cluster bubble.
	 *
	 * @param {Array} features Clustered features.
	 * @return {HTMLElement}
	 */
	MapInstance.prototype.buildClassicClusterEl = function (features) {
		var el = document.createElement('div');
		el.className = 'mvweb-om__cluster';
		el.textContent = String(features.length);

		var newest = features[0];
		if (newest) {
			features.forEach(function (f) {
				if (f.properties.order < newest.properties.order) {
					newest = f;
				}
			});
			var color = this.categoryColor(newest.properties.obj);
			if (color) {
				el.style.background = color;
			}
		}
		return el;
	};

	/**
	 * Objects filtered by the active categories.
	 *
	 * @return {Array}
	 */
	MapInstance.prototype.visibleObjects = function () {
		if (!this.activeCats.size) {
			return this.objects;
		}
		var cats = this.activeCats;
		return this.objects.filter(function (obj) {
			return (obj.categories || []).some(function (slug) {
				return cats.has(slug);
			});
		});
	};

	/**
	 * Build a marker DOM element for an object (module or classic) and wire
	 * the behaviour every marker shares.
	 *
	 * @param {Object} obj Object data.
	 * @return {HTMLElement}
	 */
	MapInstance.prototype.buildMarkerEl = function (obj) {
		var self = this;
		var mod = this.mods.marker;
		var el = null;
		if (mod && typeof mod.create === 'function') {
			el = mod.create(obj, this.ctx);
		}
		if (!el) {
			el = this.buildClassicMarkerEl(obj);
		}

		if (!el.hasAttribute('role')) {
			el.setAttribute('role', 'button');
			el.setAttribute('tabindex', '0');
			el.appendChild(srText(obj.title || ''));
		}

		el.addEventListener('click', function (e) {
			e.stopPropagation();
			self.select(obj.id, 'marker');
		});
		el.addEventListener('keydown', function (e) {
			if ('Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key) {
				e.preventDefault();
				e.stopPropagation();
				self.select(obj.id, 'marker');
			}
		});
		el.addEventListener('pointerenter', function (e) {
			if ('mouse' === e.pointerType) {
				self.hover(obj.id);
			}
		});
		el.addEventListener('pointerleave', function (e) {
			if ('mouse' === e.pointerType && String(self.hoverId) === String(obj.id)) {
				self.hover(null);
			}
		});
		el.addEventListener('focus', function () {
			if (el.matches(':focus-visible')) {
				self.hover(obj.id);
			}
		});
		el.addEventListener('blur', function () {
			if (String(self.hoverId) === String(obj.id)) {
				self.hover(null);
			}
		});

		this.markerEls[String(obj.id)] = el;
		if (null !== this.selectedId && String(this.selectedId) === String(obj.id)) {
			el.classList.add('mvweb-om__marker--selected');
		}
		if (null !== this.hoverId && String(this.hoverId) === String(obj.id)) {
			el.classList.add('mvweb-om__marker--hover');
		}
		return el;
	};

	/**
	 * Build the classic marker element.
	 *
	 * @param {Object} obj Object data.
	 * @return {HTMLElement}
	 */
	MapInstance.prototype.buildClassicMarkerEl = function (obj) {
		var el = document.createElement('div');
		el.className = 'mvweb-om__marker';

		if (obj.icon && obj.icon.type === 'image' && isSafeUrl(obj.icon.url)) {
			var img = document.createElement('img');
			img.setAttribute('src', obj.icon.url);
			img.setAttribute('alt', '');
			el.appendChild(img);
		} else {
			if (obj.icon && /^[a-z0-9_-]+$/i.test(obj.icon.preset || '')) {
				el.classList.add('mvweb-om__marker--' + obj.icon.preset);
			}
			var color = this.categoryColor(obj);
			if (color) {
				el.style.background = color;
			}
		}
		return el;
	};

	/**
	 * Open a single balloon for an object (closing any previous one).
	 *
	 * The balloon is a fixed card pinned to the top-center of the map container
	 * (not a map marker), so it is always fully visible over the map regardless
	 * of where the marker sits — it never anchors into a corner or clips at the
	 * map edges. The map still recenters on the marker for context.
	 *
	 * @param {Object} obj Object data.
	 */
	MapInstance.prototype.openBalloon = function (obj) {
		this.closeBalloon();
		this.closeModal();

		var host = this.root.querySelector('.mvweb-om__map');
		if (!host) {
			return;
		}
		this.balloon = this.buildBalloonEl(obj);
		host.appendChild(this.balloon);
		this.flyTo(obj);
	};

	/**
	 * Close the open balloon, if any.
	 */
	MapInstance.prototype.closeBalloon = function () {
		if (this.balloon) {
			if (this.balloon.parentNode) {
				this.balloon.parentNode.removeChild(this.balloon);
			}
			this.balloon = null;
		}
	};

	/**
	 * Build the balloon DOM for an object. Text via textContent, links via
	 * setAttribute — no innerHTML with object data.
	 *
	 * @param {Object} obj Object data.
	 * @return {HTMLElement}
	 */
	MapInstance.prototype.buildBalloonEl = function (obj) {
		var self = this;
		var box = document.createElement('div');
		box.className = 'mvweb-om__balloon';

		var close = document.createElement('button');
		close.type = 'button';
		close.className = 'mvweb-om__balloon-close';
		setButtonLabel(close, '×', i18n.close || 'Close');
		close.addEventListener('click', function () { self.select(null); });
		box.appendChild(close);

		if (obj.thumb && isSafeUrl(obj.thumb)) {
			var photo = document.createElement('img');
			photo.className = 'mvweb-om__balloon-photo';
			photo.setAttribute('src', obj.thumb);
			photo.setAttribute('alt', '');
			photo.setAttribute('loading', 'lazy');
			photo.setAttribute('decoding', 'async');
			box.appendChild(photo);
		}

		var title = document.createElement('div');
		title.className = 'mvweb-om__balloon-title';
		title.textContent = obj.title || '';
		box.appendChild(title);

		if (obj.address) {
			box.appendChild(textRow('mvweb-om__balloon-address', obj.address));
		}
		if (obj.excerpt) {
			box.appendChild(textRow('mvweb-om__balloon-excerpt', obj.excerpt));
		}
		if (obj.phone) {
			var phone = document.createElement('a');
			phone.className = 'mvweb-om__balloon-phone';
			var hasPlus = obj.phone.trim().charAt(0) === '+';
			var digits = obj.phone.replace(/[^0-9]/g, '');
			phone.setAttribute('href', 'tel:' + (hasPlus ? '+' : '') + digits);
			phone.textContent = obj.phone;
			box.appendChild(phone);
		}
		if (obj.hours) {
			box.appendChild(textRow('mvweb-om__balloon-hours', obj.hours));
		}

		var specs = (obj.specs || []).filter(function (s) { return s.inBalloon; });
		if (specs.length) {
			box.appendChild(buildSpecsDl(specs, 'mvweb-om__balloon-specs'));
		}

		if (obj.links && obj.links.length) {
			var links = buildLinks(obj.links, 'mvweb-om__balloon-links');
			if (links.childNodes.length) {
				box.appendChild(links);
			}
		}

		box.appendChild(buildActions(obj, 'mvweb-om__balloon-actions'));

		return box;
	};

	/**
	 * Build the category filter toggles.
	 */
	MapInstance.prototype.buildFilter = function () {
		if (!this.filterEl || !this.categories.length) {
			return;
		}
		var self = this;
		this.filterEl.textContent = '';

		var allBtn = filterButton(i18n.all || '', '');
		allBtn.classList.add('mvweb-om__filter-btn--active');
		this.filterEl.appendChild(allBtn);

		this.categories.forEach(function (cat) {
			self.filterEl.appendChild(filterButton(cat.name, cat.slug, cat.color));
		});

		this.filterEl.hidden = false;
		this.filterEl.addEventListener('click', function (e) {
			var btn = e.target.closest('.mvweb-om__filter-btn');
			if (!btn) {
				return;
			}
			var slug = btn.getAttribute('data-slug') || '';
			self.select(null);
			self.setCats(slug ? [slug] : []);
		});
	};

	/**
	 * Mirror the active categories on the classic filter buttons.
	 */
	MapInstance.prototype.syncFilterButtons = function () {
		if (!this.filterEl) {
			return;
		}
		var cats = this.activeCats;
		this.filterEl.querySelectorAll('.mvweb-om__filter-btn').forEach(function (btn) {
			var slug = btn.getAttribute('data-slug') || '';
			btn.classList.toggle('mvweb-om__filter-btn--active', slug ? cats.has(slug) : !cats.size);
		});
	};

	/**
	 * Fit the map view to the visible markers.
	 */
	MapInstance.prototype.fitToMarkers = function () {
		var list = this.visibleObjects();
		if (this.config.center || this.config.zoom || data.defaultCenter || !list.length) {
			return;
		}
		var lngs = list.map(function (o) { return o.lng; });
		var lats = list.map(function (o) { return o.lat; });
		var bounds = [
			[Math.min.apply(null, lngs), Math.min.apply(null, lats)],
			[Math.max.apply(null, lngs), Math.max.apply(null, lats)]
		];
		try {
			this.map.update({ location: { bounds: bounds, duration: 300 } });
		} catch (err) {
			this.map.update({ location: { center: [lngs[0], lats[0]], zoom: 12 } });
		}
	};

	/**
	 * Remove all object markers from the layer.
	 */
	MapInstance.prototype.clearMarkers = function () {
		var self = this;
		if (this.markerObjects) {
			this.markerObjects.forEach(function (m) {
				self.markersLayer.removeChild(m);
			});
		}
		this.markerObjects = [];
		this.markerEls = Object.create(null);

		if (this.clusterer) {
			this.map.removeChild(this.clusterer);
			this.clusterer = null;
		}
	};

	/**
	 * Build the side catalog list with search and sort (when list is enabled).
	 */
	MapInstance.prototype.buildList = function () {
		if (!this.config.list) {
			return;
		}
		this.cardsEl = this.root.querySelector('.mvweb-om__cards');
		this.searchEl = this.root.querySelector('.mvweb-om__search');
		this.sortEl = this.root.querySelector('.mvweb-om__sort');
		if (!this.cardsEl) {
			return;
		}

		if (!this.listBound) {
			this.bindListControls();
			this.listBound = true;
			this.query = String(this.searchEl ? this.searchEl.value : '').trim().toLowerCase().slice(0, 200);
			this.sort = (this.sortEl && 'new' === this.sortEl.value) ? 'new' : 'name';
			this.viewCache = null;
		}

		this.renderCards();
	};

	/**
	 * Wire the search/sort controls once.
	 */
	MapInstance.prototype.bindListControls = function () {
		var self = this;

		if (this.searchEl) {
			var search = debounce(function () {
				self.setQuery(self.searchEl.value);
			}, SEARCH_DELAY);
			this.searchEl.setAttribute('placeholder', i18n.search || '');
			this.searchEl.addEventListener('input', search);
		}
		if (this.sortEl) {
			var optName = this.sortEl.querySelector('option[value="name"]');
			var optNew = this.sortEl.querySelector('option[value="new"]');
			if (optName) {
				optName.textContent = i18n.sortName || '';
			}
			if (optNew) {
				optNew.textContent = i18n.sortNew || '';
			}
			this.sortEl.addEventListener('change', function () {
				self.setSort(self.sortEl.value);
			});
		}
	};

	/**
	 * Render the cards for the current filter, search and sort.
	 */
	MapInstance.prototype.renderCards = function () {
		var self = this;
		var fragment = document.createDocumentFragment();

		this.computeView().objects.forEach(function (obj) {
			fragment.appendChild(self.buildCardEl(obj));
		});

		this.cardsEl.textContent = '';
		this.cardsEl.appendChild(fragment);
	};

	/**
	 * Build one catalog card. Click centers the map (and opens the modal when
	 * enabled). Text via textContent only.
	 *
	 * @param {Object} obj Object data.
	 * @return {HTMLElement}
	 */
	MapInstance.prototype.buildCardEl = function (obj) {
		var self = this;
		var card = document.createElement('button');
		card.type = 'button';
		card.className = 'mvweb-om__card';

		var cfg = data.card || {};

		if (false !== cfg.showPhoto && obj.thumb && isSafeUrl(obj.thumb)) {
			var img = document.createElement('img');
			img.className = 'mvweb-om__card-photo';
			img.setAttribute('src', obj.thumb);
			img.setAttribute('alt', '');
			img.setAttribute('loading', 'lazy');
			img.setAttribute('decoding', 'async');
			card.appendChild(img);
		}

		var body = document.createElement('span');
		body.className = 'mvweb-om__card-body';

		var title = document.createElement('span');
		title.className = 'mvweb-om__card-title';
		title.textContent = obj.title || '';
		body.appendChild(title);

		if (false !== cfg.showAddress && obj.address) {
			var addr = document.createElement('span');
			addr.className = 'mvweb-om__card-address';
			addr.textContent = obj.address;
			body.appendChild(addr);
		}

		if (cfg.showExcerpt && obj.excerpt) {
			var ex = document.createElement('span');
			ex.className = 'mvweb-om__card-excerpt';
			ex.textContent = obj.excerpt;
			body.appendChild(ex);
		}
		card.appendChild(body);

		card.addEventListener('click', function () {
			self.select(obj.id, 'list');
		});
		return card;
	};

	/**
	 * Wire the mobile Map/List tabs (when list is enabled).
	 */
	MapInstance.prototype.initTabs = function () {
		if (!this.config.list) {
			return;
		}
		var self = this;
		var tabs = this.root.querySelectorAll('.mvweb-om__tab');
		if (!tabs.length) {
			return;
		}

		this.root.classList.add('mvweb-om--view-map');
		tabs.forEach(function (tab) {
			tab.addEventListener('click', function () {
				var view = tab.getAttribute('data-view');
				if ('map' !== view && 'list' !== view) {
					return;
				}
				self.root.classList.remove('mvweb-om--view-map', 'mvweb-om--view-list');
				self.root.classList.add('mvweb-om--view-' + view);
				tabs.forEach(function (t) {
					var on = t === tab;
					t.classList.toggle('mvweb-om__tab--active', on);
					t.setAttribute('aria-selected', on ? 'true' : 'false');
				});
				if (view === 'map' && self.map) {
					self.map.update({});
				}
			});
		});
	};

	/**
	 * Open the full-card modal for an object. Text via textContent only.
	 *
	 * @param {Object} obj Object data.
	 */
	MapInstance.prototype.openModal = function (obj) {
		this.closeModal();
		this.closeBalloon();
		var self = this;

		var dialog = document.createElement('dialog');
		dialog.className = 'mvweb-om__modal';
		if (data.accent) {
			dialog.style.setProperty('--mvweb-om-accent', data.accent);
		}
		if (data.card && data.card.photoRatio) {
			dialog.style.setProperty('--mvweb-om-card-ratio', data.card.photoRatio);
		}
		dialog.addEventListener('click', function (e) {
			if (e.target === dialog) {
				dialog.close();
			}
		});
		dialog.addEventListener('close', function () {
			if (dialog.parentNode) {
				dialog.parentNode.removeChild(dialog);
			}
			if (self.modal === dialog) {
				self.modal = null;
				self.select(null);
			}
		});

		var box = document.createElement('div');
		box.className = 'mvweb-om__modal-box';

		var close = document.createElement('button');
		close.type = 'button';
		close.className = 'mvweb-om__modal-close';
		setButtonLabel(close, '×', i18n.close || 'Close');
		close.addEventListener('click', function () { dialog.close(); });
		box.appendChild(close);

		if (obj.gallery && obj.gallery.length) {
			box.appendChild(buildGallery(obj.gallery));
		} else if (obj.thumb) {
			box.appendChild(buildGallery([obj.thumb]));
		}

		var title = document.createElement('h3');
		title.className = 'mvweb-om__modal-title';
		title.textContent = obj.title || '';
		box.appendChild(title);

		if (obj.address) {
			box.appendChild(textRow('mvweb-om__modal-address', obj.address));
		}
		if (obj.phone) {
			var mphone = document.createElement('a');
			mphone.className = 'mvweb-om__modal-phone';
			var mHasPlus = obj.phone.trim().charAt(0) === '+';
			var mDigits = obj.phone.replace(/[^0-9]/g, '');
			mphone.setAttribute('href', 'tel:' + (mHasPlus ? '+' : '') + mDigits);
			mphone.textContent = obj.phone;
			box.appendChild(mphone);
		}
		if (obj.hours) {
			box.appendChild(textRow('mvweb-om__modal-hours', obj.hours));
		}
		if (obj.excerpt) {
			box.appendChild(textRow('mvweb-om__modal-excerpt', obj.excerpt));
		}
		if (obj.specs && obj.specs.length) {
			box.appendChild(buildSpecsDl(obj.specs, 'mvweb-om__modal-specs'));
		}

		if (obj.links && obj.links.length) {
			var mlinks = buildLinks(obj.links, 'mvweb-om__modal-links');
			if (mlinks.childNodes.length) {
				box.appendChild(mlinks);
			}
		}

		box.appendChild(buildActions(obj, 'mvweb-om__modal-actions'));

		dialog.appendChild(box);
		document.body.appendChild(dialog);
		this.modal = dialog;

		dialog.showModal();
	};

	/**
	 * Close the modal, if any.
	 */
	MapInstance.prototype.closeModal = function () {
		var dialog = this.modal;
		if (dialog) {
			this.modal = null;
			if (typeof dialog.close === 'function' && dialog.open) {
				dialog.close();
			} else if (dialog.parentNode) {
				dialog.parentNode.removeChild(dialog);
			}
		}
	};

	/**
	 * Parse the per-instance JSON config and normalize the variant fields.
	 *
	 * @param {string} raw JSON string.
	 * @return {Object}
	 */
	function parseConfig(raw) {
		var config = {};
		if (raw) {
			try {
				config = JSON.parse(raw) || {};
			} catch (err) {
				config = {};
			}
		}
		var given = (config.variants && 'object' === typeof config.variants) ? config.variants : {};
		var variants = {};
		AXES.concat('phone').forEach(function (axis) {
			var name = given[axis];
			variants[axis] = ('string' === typeof name && SLUG.test(name)) ? name : 'classic';
		});
		config.variants = variants;
		config.scheme = SCHEMES.indexOf(config.scheme) !== -1 ? config.scheme : 'light';
		return config;
	}

	/**
	 * Parse a "lat,lng" string into a [lng, lat] pair for ymaps, or null.
	 *
	 * @param {string} str Raw "lat,lng" string.
	 * @return {Array|null}
	 */
	function parseLatLng(str) {
		if (!str) {
			return null;
		}
		var parts = String(str).split(',');
		var lat = parseFloat(parts[0]);
		var lng = parseFloat(parts[1]);
		return (!isNaN(lat) && !isNaN(lng)) ? [lng, lat] : null;
	}

	/**
	 * Whether the viewport is in phone layout (same breakpoint as the CSS).
	 *
	 * @return {boolean}
	 */
	function isPhone() {
		return !!window.matchMedia && window.matchMedia(PHONE_QUERY).matches;
	}

	/**
	 * Whether the primary pointer is a finger.
	 *
	 * @return {boolean}
	 */
	/**
	 * Numeric value of a characteristic, or null when it has none.
	 *
	 * @param {Object} obj Object data.
	 * @param {string} id  Characteristic field id.
	 * @return {number|null}
	 */
	function specRaw(obj, id) {
		var specs = obj.specs || [];
		for (var i = 0; i < specs.length; i++) {
			if (specs[i].id === id && 'number' === typeof specs[i].raw) {
				return specs[i].raw;
			}
		}
		return null;
	}

	/**
	 * Marker stacking order: southern markers above northern ones.
	 *
	 * @param {Object} obj Object data.
	 * @return {number}
	 */
	function markerZ(obj) {
		return Math.round((90 - (Number(obj.lat) || 0)) * 1000);
	}

	function isCoarsePointer() {
		return !!window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
	}

	/**
	 * Delay a function until calls stop for the given time.
	 *
	 * @param {Function} fn   Function to run.
	 * @param {number}   wait Delay in ms.
	 * @return {Function}
	 */
	function debounce(fn, wait) {
		var timer = 0;
		return function () {
			clearTimeout(timer);
			timer = setTimeout(fn, wait);
		};
	}

	/**
	 * Build an SVG icon from a preset path.
	 *
	 * @param {string} slug Preset slug from mvwebOmData.icons.
	 * @return {SVGElement|null} Null when the preset is unknown.
	 */
	function icon(slug) {
		var paths = data.icons || {};
		if (!paths.hasOwnProperty(slug) || 'string' !== typeof paths[slug]) {
			return null;
		}
		var svg = document.createElementNS(SVG_NS, 'svg');
		var path = document.createElementNS(SVG_NS, 'path');
		svg.setAttribute('class', 'mvweb-om-ui__icon');
		svg.setAttribute('viewBox', '0 0 24 24');
		svg.setAttribute('fill', 'none');
		svg.setAttribute('stroke', 'currentColor');
		svg.setAttribute('stroke-width', '2');
		svg.setAttribute('stroke-linecap', 'round');
		svg.setAttribute('stroke-linejoin', 'round');
		svg.setAttribute('aria-hidden', 'true');
		svg.setAttribute('focusable', 'false');
		path.setAttribute('d', paths[slug]);
		svg.appendChild(path);
		return svg;
	}

	/**
	 * Build a visually hidden text node for assistive technology.
	 *
	 * @param {string} text Text.
	 * @return {HTMLElement}
	 */
	function srText(text) {
		var el = document.createElement('span');
		el.className = 'mvweb-om__sr';
		el.textContent = text;
		return el;
	}

	/**
	 * Give an icon button a visible glyph and a hidden text label plus title.
	 *
	 * @param {HTMLElement} btn   Button.
	 * @param {string}      glyph Visible glyph.
	 * @param {string}      label Accessible label.
	 */
	function setButtonLabel(btn, glyph, label) {
		var mark = document.createElement('span');
		mark.setAttribute('aria-hidden', 'true');
		mark.textContent = glyph;
		btn.appendChild(mark);
		btn.appendChild(srText(label));
		btn.setAttribute('title', label);
	}

	/**
	 * Build a text row element.
	 *
	 * @param {string} cls  Class name.
	 * @param {string} text Text content.
	 * @return {HTMLElement}
	 */
	function textRow(cls, text) {
		var el = document.createElement('div');
		el.className = cls;
		el.textContent = text;
		return el;
	}

	/**
	 * Whether a URL is safe to place into src/href (http(s) or root-relative).
	 *
	 * Defence-in-depth on top of the server-side mvweb_om_sanitize_url().
	 *
	 * @param {string} url URL to test.
	 * @return {boolean}
	 */
	function isSafeUrl(url) {
		if (typeof url !== 'string') {
			return false;
		}
		var s = url.trim().toLowerCase();
		return s.indexOf('http://') === 0 || s.indexOf('https://') === 0 || s.indexOf('/') === 0;
	}

	/**
	 * Value of a characteristic: a link for the "url" type, text otherwise.
	 *
	 * @param {Object} spec Spec row ({ type, value }).
	 * @param {string} cls  Class name of the link.
	 * @return {Node}
	 */
	function specValue(spec, cls) {
		if ('url' === spec.type && isSafeUrl(spec.value)) {
			var a = document.createElement('a');
			a.className = cls;
			a.setAttribute('href', spec.value);
			a.setAttribute('target', '_blank');
			a.setAttribute('rel', 'noopener noreferrer');
			a.textContent = spec.value.replace(/^https?:\/\/(www\.)?/i, '').replace(/\/$/, '');
			return a;
		}
		return document.createTextNode(String(spec.value));
	}

	/**
	 * Build the action buttons (details link + route) shared by the balloon
	 * and the modal. The route always links to Yandex Maps directions.
	 *
	 * @param {Object} obj Object payload.
	 * @param {string} cls Container class name.
	 * @return {HTMLElement}
	 */
	function buildActions(obj, cls) {
		var actions = document.createElement('div');
		actions.className = cls;
		if (obj.moreUrl && isSafeUrl(obj.moreUrl)) {
			var more = document.createElement('a');
			more.className = 'mvweb-om__btn';
			more.setAttribute('href', obj.moreUrl);
			more.setAttribute('target', '_blank');
			more.setAttribute('rel', 'noopener noreferrer');
			more.textContent = i18n.more || '';
			actions.appendChild(more);
		}
		if (data.showRoute) {
			var route = document.createElement('a');
			route.className = 'mvweb-om__btn mvweb-om__btn--ghost';
			var rLat = ('number' === typeof obj.routeLat) ? obj.routeLat : obj.lat;
			var rLng = ('number' === typeof obj.routeLng) ? obj.routeLng : obj.lng;
			route.setAttribute('href', 'https://yandex.ru/maps/?rtext=~' + encodeURIComponent(rLat) + ',' + encodeURIComponent(rLng));
			route.setAttribute('target', '_blank');
			route.setAttribute('rel', 'noopener noreferrer');
			route.textContent = i18n.route || '';
			actions.appendChild(route);
		}
		return actions;
	}

	/**
	 * Build the object links list (label + external URL). Returns an element
	 * that may be empty when no links are safe — the caller checks childNodes.
	 * Text via textContent, URLs via setAttribute.
	 *
	 * @param {Array}  links Link rows ({ label, url }).
	 * @param {string} cls   Container class name.
	 * @return {HTMLElement}
	 */
	function buildLinks(links, cls) {
		var wrap = document.createElement('div');
		wrap.className = cls;
		(links || []).forEach(function (link) {
			if (!link || !isSafeUrl(link.url)) {
				return;
			}
			var a = document.createElement('a');
			a.className = 'mvweb-om__link';
			a.setAttribute('href', link.url);
			a.setAttribute('target', '_blank');
			a.setAttribute('rel', 'noopener noreferrer');
			a.textContent = link.label || link.url;
			wrap.appendChild(a);
		});
		return wrap;
	}

	/**
	 * Build a definition list of spec label/value rows (text via textContent).
	 *
	 * @param {Array}  specs Spec rows ({ label, value }).
	 * @param {string} cls   Class name for the <dl>.
	 * @return {HTMLElement}
	 */
	function buildSpecsDl(specs, cls) {
		var dl = document.createElement('dl');
		dl.className = cls;
		specs.forEach(function (s) {
			var dt = document.createElement('dt');
			dt.textContent = s.label;
			var dd = document.createElement('dd');
			dd.appendChild(specValue(s, 'mvweb-om__link'));
			dl.appendChild(dt);
			dl.appendChild(dd);
		});
		return dl;
	}

	/**
	 * Build a simple photo slider (prev/next) from a list of image URLs.
	 *
	 * @param {Array} urls Image URLs.
	 * @return {HTMLElement}
	 */
	function buildGallery(urls) {
		urls = urls.filter(isSafeUrl);
		var wrap = document.createElement('div');
		wrap.className = 'mvweb-om__slider';

		if (!urls.length) {
			return wrap;
		}

		var img = document.createElement('img');
		img.className = 'mvweb-om__slider-img';
		img.setAttribute('src', urls[0]);
		img.setAttribute('alt', '');
		wrap.appendChild(img);

		if (urls.length < 2) {
			return wrap;
		}

		var index = 0;
		var prev = sliderBtn('mvweb-om__slider-prev', '‹', i18n.prev || 'Previous');
		var next = sliderBtn('mvweb-om__slider-next', '›', i18n.next || 'Next');

		prev.addEventListener('click', function () {
			index = (index - 1 + urls.length) % urls.length;
			img.setAttribute('src', urls[index]);
		});
		next.addEventListener('click', function () {
			index = (index + 1) % urls.length;
			img.setAttribute('src', urls[index]);
		});

		wrap.appendChild(prev);
		wrap.appendChild(next);
		return wrap;
	}

	/**
	 * Build a slider navigation button.
	 *
	 * @param {string} cls   Class name.
	 * @param {string} glyph Visible glyph.
	 * @param {string} label Accessible label.
	 * @return {HTMLElement}
	 */
	function sliderBtn(cls, glyph, label) {
		var btn = document.createElement('button');
		btn.type = 'button';
		btn.className = 'mvweb-om__slider-btn ' + cls;
		setButtonLabel(btn, glyph, label);
		return btn;
	}

	/**
	 * Build a filter toggle button.
	 *
	 * @param {string} label Visible label.
	 * @param {string} slug  Category slug ('' for all).
	 * @param {string} color Category color for the legend dot (optional).
	 * @return {HTMLElement}
	 */
	function filterButton(label, slug, color) {
		var btn = document.createElement('button');
		btn.type = 'button';
		btn.className = 'mvweb-om__filter-btn';
		btn.setAttribute('data-slug', slug);
		if (color) {
			var dot = document.createElement('span');
			dot.className = 'mvweb-om__filter-dot';
			dot.style.background = color;
			btn.appendChild(dot);
		}
		var text = document.createElement('span');
		text.textContent = label;
		btn.appendChild(text);
		return btn;
	}

	if (document.readyState !== 'loading') {
		boot();
	} else {
		document.addEventListener('DOMContentLoaded', boot);
	}
})();
