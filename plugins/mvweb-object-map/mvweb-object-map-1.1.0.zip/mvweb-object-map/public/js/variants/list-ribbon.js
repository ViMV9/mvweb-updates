/**
 * List variant "ribbon": a row of categories with counters above the map and
 * a card list beside it (under the map on phones).
 *
 * Object text goes in via textContent, URLs via setAttribute (shared.parts).
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var B = 'mvweb-om-list-ribbon';
	var PAGE = 30;
	var EAGER = 3;
	var SEARCH_DELAY = 180;
	var COLOR = /^#[0-9a-f]{3,8}$/i;

	api.register('list', 'ribbon', function (ctx) {
		var parts = null;
		var card = {};
		var reduced = false;
		var bar = null;
		var track = null;
		var more = null;
		var chips = [];
		var list = null;
		var input = null;
		var select = null;
		var found = null;
		var scroller = null;
		var cards = null;
		var empty = null;
		var emptyText = null;
		var emptyReset = null;
		var emptyAll = null;
		var showMore = null;
		var cardEls = Object.create(null);
		var objects = [];
		var shown = 0;
		var selectedId = null;
		var hoverId = null;
		var timer = 0;
		var frame = 0;
		var observer = null;
		var handlers = {};

		/**
		 * Read a translated string.
		 *
		 * @param {string} key      Key in the i18n object.
		 * @param {string} fallback English text.
		 * @return {string}
		 */
		function t(key, fallback) {
			return (ctx.i18n && ctx.i18n[key]) || fallback;
		}

		/**
		 * Create an element with a class and optional text.
		 *
		 * @param {string} tag  Tag name.
		 * @param {string} cls  Class name.
		 * @param {string} body Text content (optional).
		 * @return {HTMLElement}
		 */
		function make(tag, cls, body) {
			var el = document.createElement(tag);
			if (cls) {
				el.className = cls;
			}
			if (body) {
				el.textContent = body;
			}
			return el;
		}

		/**
		 * Number of loaded objects per category slug.
		 *
		 * @return {Object}
		 */
		function countCats() {
			var counts = Object.create(null);
			(ctx.objects || []).forEach(function (obj) {
				(obj.categories || []).forEach(function (slug) {
					counts[slug] = (counts[slug] || 0) + 1;
				});
			});
			return counts;
		}

		/**
		 * Build one category chip.
		 *
		 * @param {string} slug  Category slug, empty for all.
		 * @param {string} name  Visible name.
		 * @param {number} count Number of objects.
		 * @param {string} color Category color (optional).
		 * @return {HTMLButtonElement}
		 */
		function chip(slug, name, count, color) {
			var btn = make('button', B + '__chip');
			btn.type = 'button';
			btn.setAttribute('data-slug', slug);
			btn.setAttribute('aria-pressed', 'false');
			if (slug) {
				var dot = make('span', B + '__swatch');
				dot.setAttribute('aria-hidden', 'true');
				if (COLOR.test(color || '')) {
					dot.style.setProperty('--mvweb-om-ribbon-c', color);
				}
				btn.appendChild(dot);
			}
			btn.appendChild(make('span', B + '__name', name));
			btn.appendChild(make('span', B + '__count', String(count)));
			btn.addEventListener('click', function () {
				ctx.setCats(slug ? [slug] : []);
			});
			return btn;
		}

		/**
		 * Build the category ribbon and put it above the map.
		 */
		function buildBar() {
			var counts = countCats();
			bar = make('div', B + '__bar');
			track = make('div', B + '__track');
			track.setAttribute('role', 'group');
			track.setAttribute('aria-label', t('categories', 'Categories'));
			bar.appendChild(track);

			chips = [chip('', t('all', 'All'), (ctx.objects || []).length, '')];
			(ctx.categories || []).forEach(function (cat) {
				if (cat && cat.slug && counts[cat.slug]) {
					chips.push(chip(String(cat.slug), cat.name || String(cat.slug), counts[cat.slug], cat.color));
				}
			});
			chips.forEach(function (btn) {
				track.appendChild(btn);
			});
			if (chips.length < 2) {
				bar.hidden = true;
			}

			more = parts.iconButton('chev-r', t('moreCats', 'More categories'), function () {
				var step = Math.max(track.clientWidth * 0.6, 120);
				track.scrollBy({ left: step, behavior: reduced ? 'auto' : 'smooth' });
			}, 'mvweb-om-ui__icon-btn--plain ' + B + '__more');
			more.hidden = true;
			bar.appendChild(more);

			var body = ctx.root.querySelector('.mvweb-om__body');
			ctx.root.insertBefore(bar, body && body.parentNode === ctx.root ? body : ctx.root.firstChild);

			track.addEventListener('scroll', queueArrow, { passive: true });
			if (typeof ResizeObserver === 'function') {
				observer = new ResizeObserver(queueArrow);
				observer.observe(track);
			} else {
				window.addEventListener('resize', queueArrow);
			}
			queueArrow();
		}

		/**
		 * Update the arrow and the fade of the ribbon on the next frame.
		 */
		function queueArrow() {
			if (frame) {
				return;
			}
			frame = requestAnimationFrame(function () {
				frame = 0;
				var overflow = track.scrollWidth > track.clientWidth + 1;
				var atEnd = track.scrollLeft + track.clientWidth >= track.scrollWidth - 1;
				more.hidden = !overflow;
				more.disabled = atEnd;
				track.classList.toggle(B + '__track--fade', overflow && !atEnd);
			});
		}

		/**
		 * Mirror the active categories on the chips.
		 *
		 * @param {Array} cats Active category slugs.
		 */
		function syncChips(cats) {
			var active = null;
			chips.forEach(function (btn) {
				var slug = btn.getAttribute('data-slug');
				var on = slug ? cats.indexOf(slug) !== -1 : !cats.length;
				btn.setAttribute('aria-pressed', on ? 'true' : 'false');
				if (on && !active) {
					active = btn;
				}
			});
			if (active && track && !bar.hidden) {
				var r = active.getBoundingClientRect();
				var box = track.getBoundingClientRect();
				if (r.left < box.left || r.right > box.right - 40) {
					track.scrollBy({ left: r.left - box.left - 16, behavior: reduced ? 'auto' : 'smooth' });
				}
			}
		}

		/**
		 * Build the list panel: search, counter, sort, cards, empty state.
		 */
		function buildList() {
			list = make('div', B + '__list');

			var head = make('div', B + '__head');
			var search = make('label', B + '__search');
			var searchIcon = parts.icon('search', 'sm');
			if (searchIcon) {
				search.appendChild(searchIcon);
			}
			search.appendChild(make('span', 'mvweb-om__sr', t('searchLabel', 'Search objects')));
			input = make('input', B + '__input');
			input.type = 'search';
			input.setAttribute('placeholder', t('searchHint', 'Name or address'));
			input.setAttribute('autocomplete', 'off');
			input.setAttribute('enterkeyhint', 'search');
			search.appendChild(input);
			head.appendChild(search);

			found = make('span', B + '__found');
			found.setAttribute('role', 'status');
			head.appendChild(found);

			var sort = make('label', B + '__sort');
			sort.appendChild(make('span', 'mvweb-om__sr', t('sortLabel', 'Sort objects')));
			select = make('select', B + '__select');
			[['name', t('sortName', 'By name')], ['new', t('sortNew', 'Newest first')]].forEach(function (pair) {
				var opt = make('option', '', pair[1]);
				opt.value = pair[0];
				select.appendChild(opt);
			});
			sort.appendChild(select);
			var chev = parts.icon('chev-d', 'sm');
			if (chev) {
				sort.appendChild(chev);
			}
			head.appendChild(sort);
			list.appendChild(head);

			scroller = make('div', B + '__scroll');
			cards = make('ul', B + '__cards');
			cards.setAttribute('role', 'list');
			scroller.appendChild(cards);

			empty = make('div', B + '__empty');
			empty.hidden = true;
			var emptyIcon = make('span', B + '__empty-ico');
			var bigSearch = parts.icon('search');
			if (bigSearch) {
				emptyIcon.appendChild(bigSearch);
			}
			empty.appendChild(emptyIcon);
			empty.appendChild(make('span', B + '__empty-title', t('emptyTitle', 'Nothing found')));
			emptyText = make('span', B + '__empty-text');
			empty.appendChild(emptyText);
			var actions = make('span', B + '__empty-actions');
			emptyReset = make('button', B + '__reset', t('resetSearch', 'Clear search'));
			emptyReset.type = 'button';
			emptyAll = make('button', B + '__all', t('allCats', 'Search in all categories'));
			emptyAll.type = 'button';
			actions.appendChild(emptyReset);
			actions.appendChild(emptyAll);
			empty.appendChild(actions);
			scroller.appendChild(empty);

			showMore = make('button', 'mvweb-om-ui__btn mvweb-om-ui__btn--outline ' + B + '__showmore', t('showMore', 'Show more'));
			showMore.type = 'button';
			showMore.hidden = true;
			scroller.appendChild(showMore);
			list.appendChild(scroller);

			var body = ctx.root.querySelector('.mvweb-om__body') || ctx.root;
			body.appendChild(list);

			input.addEventListener('input', function () {
				clearTimeout(timer);
				timer = setTimeout(function () {
					ctx.setQuery(input.value);
				}, SEARCH_DELAY);
			});
			select.addEventListener('change', function () {
				ctx.setSort(select.value);
			});
			emptyReset.addEventListener('click', function () {
				clearTimeout(timer);
				input.value = '';
				ctx.setQuery('');
				input.focus();
			});
			emptyAll.addEventListener('click', function () {
				ctx.setCats([]);
				input.focus();
			});
			showMore.addEventListener('click', function () {
				var from = shown;
				fill(Math.min(objects.length, shown + PAGE));
				var first = cards.children[from];
				if (first && first.firstChild) {
					first.firstChild.focus();
				}
			});
		}

		/**
		 * Build one object card.
		 *
		 * @param {Object}  obj   Object data.
		 * @param {boolean} eager Load the photo without lazy loading.
		 * @return {HTMLElement} The list item.
		 */
		function buildCard(obj, eager) {
			var id = String(obj.id);
			var item = make('li', B + '__item');
			var btn = make('button', B + '__card');
			btn.type = 'button';
			btn.setAttribute('data-id', id);

			var img = null;
			if (false !== card.showPhoto) {
				img = parts.photo(obj, { size: 'top' === card.photoPos ? 'photo' : 'thumb', eager: eager, className: B + '__photo' });
			}
			if (img) {
				btn.appendChild(img);
			} else {
				btn.classList.add(B + '__card--nophoto');
			}

			var body = make('span', B + '__body');
			var cat = parts.cat(obj, ctx);
			if (cat) {
				body.appendChild(cat);
			}
			body.appendChild(make('span', B + '__title', obj.title || ''));
			if (false !== card.showAddress && obj.address) {
				body.appendChild(make('span', B + '__addr', obj.address));
			}
			if (card.showExcerpt && obj.excerpt) {
				body.appendChild(make('span', B + '__excerpt', obj.excerpt));
			}
			var facts = parts.facts(obj, ctx, { flag: 'list' });
			if (facts) {
				facts.classList.add(B + '__facts');
				body.appendChild(facts);
			}
			btn.appendChild(body);

			if (null !== selectedId && String(selectedId) === id) {
				btn.setAttribute('aria-current', 'true');
			}
			if (null !== hoverId && String(hoverId) === id) {
				btn.setAttribute('data-hover', '');
			}

			btn.addEventListener('click', function () {
				ctx.select(obj.id, 'list');
			});
			btn.addEventListener('pointerenter', function (e) {
				if ('mouse' === e.pointerType) {
					ctx.hover(obj.id);
				}
			});
			btn.addEventListener('pointerleave', function (e) {
				if ('mouse' === e.pointerType && String(hoverId) === id) {
					ctx.hover(null);
				}
			});
			btn.addEventListener('focus', function () {
				ctx.hover(obj.id);
			});
			btn.addEventListener('blur', function () {
				if (String(hoverId) === id) {
					ctx.hover(null);
				}
			});

			cardEls[id] = btn;
			item.appendChild(btn);
			return item;
		}

		/**
		 * Append cards until the given count is shown.
		 *
		 * @param {number} upto Number of cards to show.
		 */
		function fill(upto) {
			var fragment = document.createDocumentFragment();
			for (var i = shown; i < upto; i++) {
				fragment.appendChild(buildCard(objects[i], i < EAGER));
			}
			cards.appendChild(fragment);
			shown = Math.max(shown, upto);
			showMore.hidden = shown >= objects.length;
		}

		/**
		 * Position of an object in the current list, or -1.
		 *
		 * @param {number|string} id Object id.
		 * @return {number}
		 */
		function indexOf(id) {
			for (var i = 0; i < objects.length; i++) {
				if (String(objects[i].id) === String(id)) {
					return i;
				}
			}
			return -1;
		}

		/**
		 * Write "Found: N" with the number in bold.
		 *
		 * @param {number} n Number of objects.
		 */
		function setFound(n) {
			var pattern = t('found', 'Found: %d');
			var at = pattern.indexOf('%d');
			var num = make('b', '', String(n));
			found.textContent = at === -1 ? pattern + ' ' : pattern.slice(0, at);
			found.appendChild(num);
			if (at !== -1) {
				found.appendChild(document.createTextNode(pattern.slice(at + 2)));
			}
		}

		/**
		 * Name of the first active category, or ''.
		 *
		 * @param {Array} cats Active category slugs.
		 * @return {string}
		 */
		function catName(cats) {
			var name = '';
			if (cats.length) {
				(ctx.categories || []).some(function (cat) {
					if (cat && String(cat.slug) === cats[0]) {
						name = cat.name || cat.slug;
					}
					return !!name;
				});
			}
			return name;
		}

		/**
		 * Fill the empty state for the current search and category.
		 *
		 * @param {Object} view List view.
		 */
		function setEmpty(view) {
			var name = catName(view.cats);
			var line = '';
			if (view.query && name) {
				line = t('emptyQueryCat', 'No objects match “%1$s” in “%2$s”.').split('%2$s').join(name).split('%1$s').join(view.query);
			} else if (view.query) {
				line = t('emptyQuery', 'No objects match “%s”.').split('%s').join(view.query);
			}
			emptyText.textContent = line;
			emptyText.hidden = !line;
			emptyReset.hidden = !view.query;
			emptyAll.hidden = !view.cats.length;
		}

		/**
		 * Scroll the list panel so that a card is visible (desktop only).
		 *
		 * @param {HTMLElement} btn Card button.
		 */
		function reveal(btn) {
			if (ctx.isPhone() || !scroller) {
				return;
			}
			var r = btn.getBoundingClientRect();
			var box = scroller.getBoundingClientRect();
			if (r.top < box.top || r.bottom > box.bottom) {
				scroller.scrollBy({ top: r.top - box.top - 12, behavior: reduced ? 'auto' : 'smooth' });
			}
		}

		/**
		 * Mark the selected card.
		 *
		 * @param {number|string|null} id     Object id or null.
		 * @param {string}             source Who selected it.
		 */
		function setSelected(id, source) {
			if (null !== selectedId && cardEls[String(selectedId)]) {
				cardEls[String(selectedId)].removeAttribute('aria-current');
			}
			selectedId = (null === id || undefined === id || '' === id) ? null : id;
			if (null === selectedId || !cards) {
				return;
			}
			var at = indexOf(selectedId);
			if (at >= shown) {
				fill(Math.min(objects.length, (Math.floor(at / PAGE) + 1) * PAGE));
			}
			var btn = cardEls[String(selectedId)];
			if (!btn) {
				return;
			}
			btn.setAttribute('aria-current', 'true');
			if ('list' !== source) {
				reveal(btn);
			}
		}

		/**
		 * Mark the hovered card.
		 *
		 * @param {number|string|null} id Object id or null.
		 */
		function setHover(id) {
			if (null !== hoverId && cardEls[String(hoverId)]) {
				cardEls[String(hoverId)].removeAttribute('data-hover');
			}
			hoverId = (null === id || undefined === id || '' === id) ? null : id;
			if (null !== hoverId && cardEls[String(hoverId)]) {
				cardEls[String(hoverId)].setAttribute('data-hover', '');
			}
		}

		/**
		 * Draw the list for a view.
		 *
		 * @param {Object} view { objects, total, cats, query, sort, selectedId, hoverId }.
		 */
		function render(view) {
			var cats = (view && view.cats) || [];
			syncChips(cats);
			if (!list) {
				return;
			}
			objects = (view && view.objects) || [];
			selectedId = view && undefined !== view.selectedId ? view.selectedId : selectedId;
			hoverId = view && undefined !== view.hoverId ? view.hoverId : hoverId;

			if (!view.query && input.value.trim() && document.activeElement !== input) {
				input.value = '';
			}
			if (select.value !== view.sort && ('name' === view.sort || 'new' === view.sort)) {
				select.value = view.sort;
			}

			cardEls = Object.create(null);
			cards.textContent = '';
			shown = 0;
			fill(Math.min(objects.length, PAGE));
			if (null !== selectedId) {
				setSelected(selectedId, 'list');
			}
			scroller.scrollTop = 0;

			setFound(objects.length);
			cards.hidden = !objects.length;
			empty.hidden = !!objects.length;
			if (!objects.length) {
				setEmpty(view);
			}
		}

		return {
			/**
			 * Build the ribbon and the list and subscribe to the instance events.
			 */
			mount: function () {
				parts = api.shared && api.shared.parts;
				if (!parts) {
					throw new Error('mvwebOm.shared.parts is missing');
				}
				card = (ctx.data && ctx.data.card) || {};
				reduced = !!window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

				if (ctx.config && ctx.config.filter) {
					buildBar();
				}
				if (ctx.config && ctx.config.list) {
					buildList();
				}

				handlers.select = function (p) {
					setSelected(p.id, p.source);
					if ('list' === p.source && ctx.isPhone() && !(ctx.data && ctx.data.modal)) {
						var map = ctx.root.querySelector('.mvweb-om__map');
						if (map) {
							map.scrollIntoView({ block: 'center', behavior: reduced ? 'auto' : 'smooth' });
						}
					}
				};
				handlers.deselect = function () {
					setSelected(null);
				};
				handlers.hover = function (p) {
					setHover(p.id);
				};
				Object.keys(handlers).forEach(function (name) {
					ctx.on(name, handlers[name]);
				});
			},

			render: render,

			/**
			 * Remove the ribbon and the list and drop the subscriptions.
			 */
			destroy: function () {
				clearTimeout(timer);
				if (frame) {
					cancelAnimationFrame(frame);
				}
				if (observer) {
					observer.disconnect();
				} else {
					window.removeEventListener('resize', queueArrow);
				}
				Object.keys(handlers).forEach(function (name) {
					ctx.off(name, handlers[name]);
				});
				[bar, list].forEach(function (el) {
					if (el && el.parentNode) {
						el.parentNode.removeChild(el);
					}
				});
				bar = list = null;
				cardEls = Object.create(null);
			}
		};
	});
})();
