/**
 * List variant "sidebar": a panel on the left of the map, like in maps apps.
 * Search, categories as checkboxes with colors and counters (five shown, the
 * rest under "More"), the object list as rows. The selected row opens up with
 * the contacts and the buttons. Phones do not show the panel: the phone
 * belongs to the phone module.
 *
 * Object text goes in via textContent, URLs via setAttribute (shared.parts).
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var B = 'mvweb-om-list-sidebar';
	var PAGE = 30;
	var EAGER = 4;
	var SHOWN_CATS = 5;
	var SEARCH_DELAY = 180;
	var COLOR = /^#[0-9a-f]{3,8}$/i;
	var SVG_NS = 'http://www.w3.org/2000/svg';
	var CHECK = 'm5 12.5 4.5 4.5L19 7.5';
	var uid = 0;

	api.register('list', 'sidebar', function (ctx) {
		var parts = null;
		var card = {};
		var reduced = false;
		var id = B + '-' + (++uid);
		var panel = null;
		var searchBox = null;
		var input = null;
		var catsHead = null;
		var catsBody = null;
		var picked = null;
		var summary = null;
		var moreBtn = null;
		var catRows = [];
		var catsOpen = true;
		var moreOpen = false;
		var listHead = null;
		var found = null;
		var select = null;
		var cards = null;
		var empty = null;
		var emptyText = null;
		var emptyReset = null;
		var emptyAll = null;
		var showMore = null;
		var itemEls = Object.create(null);
		var objects = [];
		var shown = 0;
		var selectedId = null;
		var hoverId = null;
		var timer = 0;
		var handlers = {};

		/**
		 * Read a translated string.
		 *
		 * @param {string} key      Key in the i18n object.
		 * @param {string} fallback English text.
		 * @return {string}
		 */
		function t(key, fallback) {
			return (ctx.i18n && ctx.i18n[key]) || fallback;
		}

		/**
		 * Create an element with a class and optional text.
		 *
		 * @param {string} tag  Tag name.
		 * @param {string} cls  Class name.
		 * @param {string} body Text content (optional).
		 * @return {HTMLElement}
		 */
		function make(tag, cls, body) {
			var el = document.createElement(tag);
			if (cls) {
				el.className = cls;
			}
			if (body) {
				el.textContent = body;
			}
			return el;
		}

		/**
		 * Check mark for the category box.
		 *
		 * @return {SVGElement}
		 */
		function checkIcon() {
			var svg = document.createElementNS(SVG_NS, 'svg');
			var path = document.createElementNS(SVG_NS, 'path');
			svg.setAttribute('class', B + '__tick');
			svg.setAttribute('viewBox', '0 0 24 24');
			svg.setAttribute('fill', 'none');
			svg.setAttribute('stroke', 'currentColor');
			svg.setAttribute('stroke-width', '3');
			svg.setAttribute('stroke-linecap', 'round');
			svg.setAttribute('stroke-linejoin', 'round');
			svg.setAttribute('aria-hidden', 'true');
			svg.setAttribute('focusable', 'false');
			path.setAttribute('d', CHECK);
			svg.appendChild(path);
			return svg;
		}

		/**
		 * Number of loaded objects per category slug.
		 *
		 * @return {Object}
		 */
		function countCats() {
			var counts = Object.create(null);
			(ctx.objects || []).forEach(function (obj) {
				(obj.categories || []).forEach(function (slug) {
					counts[slug] = (counts[slug] || 0) + 1;
				});
			});
			return counts;
		}

		/**
		 * Build the search field.
		 */
		function buildSearch() {
			searchBox = make('div', B + '__search');
			var label = make('label', B + '__field');
			var ico = parts.icon('search', 'sm');
			if (ico) {
				label.appendChild(ico);
			}
			label.appendChild(make('span', 'mvweb-om__sr', t('searchLabel', 'Search objects')));
			input = make('input', B + '__input');
			input.type = 'search';
			input.setAttribute('placeholder', t('searchHint', 'Name or address'));
			input.setAttribute('autocomplete', 'off');
			input.setAttribute('enterkeyhint', 'search');
			label.appendChild(input);
			searchBox.appendChild(label);
			panel.appendChild(searchBox);

			input.addEventListener('input', function () {
				clearTimeout(timer);
				timer = setTimeout(function () {
					ctx.setQuery(input.value);
				}, SEARCH_DELAY);
			});
		}

		/**
		 * Build the category block: a head that folds it, checkboxes, "More".
		 */
		function buildCats() {
			var counts = countCats();
			var list = [];
			(ctx.categories || []).forEach(function (cat) {
				if (cat && cat.slug && counts[cat.slug]) {
					list.push(cat);
				}
			});
			if (list.length < 2) {
				return;
			}

			var wrap = make('div', B + '__cats');
			var bodyId = id + '-cats';
			catsHead = make('button', B + '__catshead');
			catsHead.type = 'button';
			catsHead.setAttribute('aria-expanded', 'true');
			catsHead.setAttribute('aria-controls', bodyId);
			catsHead.appendChild(make('span', B + '__catstitle', t('categories', 'Categories')));
			picked = make('span', B + '__picked');
			picked.hidden = true;
			catsHead.appendChild(picked);
			summary = make('span', B + '__summary');
			catsHead.appendChild(summary);
			var chev = parts.icon('chev-d', 'sm');
			if (chev) {
				chev.classList.add(B + '__chev');
				catsHead.appendChild(chev);
			}
			wrap.appendChild(catsHead);

			catsBody = make('div', B + '__catbody');
			catsBody.id = bodyId;
			var ul = make('ul', B + '__catlist');
			list.forEach(function (cat) {
				var slug = String(cat.slug);
				var li = make('li', B + '__catitem');
				var label = make('label', B + '__cat');
				if (COLOR.test(cat.color || '')) {
					label.style.setProperty('--mvweb-om-sidebar-c', cat.color);
				}
				var box = make('input', B + '__check');
				box.type = 'checkbox';
				box.value = slug;
				label.appendChild(box);
				var mark = make('span', B + '__box');
				mark.appendChild(checkIcon());
				label.appendChild(mark);
				label.appendChild(make('span', B + '__name', cat.name || slug));
				label.appendChild(make('span', B + '__count', String(counts[cat.slug])));
				li.appendChild(label);
				ul.appendChild(li);
				box.addEventListener('change', applyCats);
				catRows.push({ slug: slug, name: cat.name || slug, li: li, box: box });
			});
			catsBody.appendChild(ul);

			if (catRows.length > SHOWN_CATS) {
				moreBtn = make('button', B + '__more');
				moreBtn.type = 'button';
				moreBtn.setAttribute('aria-expanded', 'false');
				moreBtn.addEventListener('click', function () {
					moreOpen = !moreOpen;
					syncCats();
				});
				catsBody.appendChild(moreBtn);
			}
			wrap.appendChild(catsBody);
			panel.appendChild(wrap);

			catsHead.addEventListener('click', function () {
				catsOpen = !catsOpen;
				syncCats();
			});
		}

		/**
		 * Send the checked categories to the core.
		 */
		function applyCats() {
			var cats = [];
			catRows.forEach(function (row) {
				if (row.box.checked) {
					cats.push(row.slug);
				}
			});
			ctx.setCats(cats);
		}

		/**
		 * Mirror the active categories and the folds on the category block.
		 *
		 * @param {Array} cats Active category slugs (optional, keeps the boxes as they are).
		 */
		function syncCats(cats) {
			if (!catsHead) {
				return;
			}
			var names = [];
			catRows.forEach(function (row, i) {
				if (cats) {
					row.box.checked = cats.indexOf(row.slug) !== -1;
				}
				if (row.box.checked) {
					names.push(row.name);
				}
				row.li.hidden = i >= SHOWN_CATS && !moreOpen && !row.box.checked;
			});
			picked.textContent = String(names.length);
			picked.hidden = !names.length;
			summary.textContent = names.join(', ');
			catsHead.setAttribute('aria-expanded', catsOpen ? 'true' : 'false');
			catsBody.hidden = !catsOpen;
			if (moreBtn) {
				var rest = 0;
				catRows.forEach(function (row) {
					rest += row.li.hidden ? 1 : 0;
				});
				moreBtn.setAttribute('aria-expanded', moreOpen ? 'true' : 'false');
				moreBtn.textContent = moreOpen ? t('collapse', 'Collapse') : t('moreCatsCount', 'Show %d more').replace('%d', String(rest));
				moreBtn.hidden = !moreOpen && !rest;
			}
		}

		/**
		 * Build the list part: counter, sort, rows, empty state, "Show more".
		 */
		function buildList() {
			listHead = make('div', B + '__head');
			found = make('span', B + '__found');
			found.setAttribute('role', 'status');
			listHead.appendChild(found);

			var sort = make('label', B + '__sort');
			sort.appendChild(make('span', 'mvweb-om__sr', t('sortLabel', 'Sort objects')));
			select = make('select', B + '__select');
			[['name', t('sortName', 'By name')], ['new', t('sortNew', 'Newest first')]].forEach(function (pair) {
				var opt = make('option', '', pair[1]);
				opt.value = pair[0];
				select.appendChild(opt);
			});
			sort.appendChild(select);
			var chev = parts.icon('chev-d', 'sm');
			if (chev) {
				sort.appendChild(chev);
			}
			listHead.appendChild(sort);
			panel.appendChild(listHead);

			cards = make('ul', B + '__cards');
			cards.setAttribute('role', 'list');
			panel.appendChild(cards);

			empty = make('div', B + '__empty');
			empty.hidden = true;
			var emptyIcon = make('span', B + '__empty-ico');
			var bigSearch = parts.icon('search');
			if (bigSearch) {
				emptyIcon.appendChild(bigSearch);
			}
			empty.appendChild(emptyIcon);
			empty.appendChild(make('span', B + '__empty-title', t('emptyTitle', 'Nothing found')));
			emptyText = make('span', B + '__empty-text');
			empty.appendChild(emptyText);
			var actions = make('span', B + '__empty-actions');
			emptyReset = make('button', B + '__reset', t('resetSearch', 'Clear search'));
			emptyReset.type = 'button';
			emptyAll = make('button', B + '__all', t('allCats', 'Search in all categories'));
			emptyAll.type = 'button';
			actions.appendChild(emptyReset);
			actions.appendChild(emptyAll);
			empty.appendChild(actions);
			panel.appendChild(empty);

			showMore = make('button', 'mvweb-om-ui__btn mvweb-om-ui__btn--outline ' + B + '__showmore', t('showMore', 'Show more'));
			showMore.type = 'button';
			showMore.hidden = true;
			panel.appendChild(showMore);

			select.addEventListener('change', function () {
				ctx.setSort(select.value);
			});
			emptyReset.addEventListener('click', function () {
				clearTimeout(timer);
				if (input) {
					input.value = '';
				}
				ctx.setQuery('');
				if (input) {
					input.focus();
				}
			});
			emptyAll.addEventListener('click', function () {
				ctx.setCats([]);
				if (input) {
					input.focus();
				}
			});
			showMore.addEventListener('click', function () {
				var from = shown;
				fill(Math.min(objects.length, shown + PAGE));
				var first = cards.children[from];
				if (first && first.firstChild) {
					first.firstChild.focus();
				}
			});
		}

		/**
		 * Contacts and buttons of the selected row.
		 *
		 * @param {Object} obj Object data.
		 * @return {HTMLElement|null} Null when the object has none.
		 */
		function buildExtra(obj) {
			var rows = parts.rows(obj, ctx, { address: false });
			var actions = parts.actions(obj, ctx, { call: false, primary: 'more' });
			if (!rows && !actions) {
				return null;
			}
			var extra = make('div', B + '__extra');
			if (rows) {
				rows.classList.add(B + '__contacts');
				extra.appendChild(rows);
			}
			if (actions) {
				actions.classList.add(B + '__actions');
				extra.appendChild(actions);
			}
			return extra;
		}

		/**
		 * Build one object row.
		 *
		 * @param {Object}  obj   Object data.
		 * @param {boolean} eager Load the photo without lazy loading.
		 * @return {HTMLElement} The list item.
		 */
		function buildRow(obj, eager) {
			var key = String(obj.id);
			var item = make('li', B + '__item');
			var btn = make('button', B + '__card');
			btn.type = 'button';
			btn.setAttribute('data-id', key);

			var body = make('span', B + '__body');
			body.appendChild(make('span', B + '__title', obj.title || ''));
			var meta = make('span', B + '__meta');
			var cat = parts.cat(obj, ctx);
			if (cat) {
				cat.classList.add(B + '__cat-label');
				meta.appendChild(cat);
			}
			var facts = parts.facts(obj, ctx, { flag: 'list' });
			if (facts) {
				facts.classList.add(B + '__facts');
				meta.appendChild(facts);
			}
			if (meta.childNodes.length) {
				body.appendChild(meta);
			}
			if (false !== card.showAddress && obj.address) {
				body.appendChild(make('span', B + '__addr', obj.address));
			}
			if (card.showExcerpt && obj.excerpt) {
				body.appendChild(make('span', B + '__excerpt', obj.excerpt));
			}
			btn.appendChild(body);

			var img = false !== card.showPhoto ? parts.photo(obj, { size: 'thumb', eager: eager, className: B + '__photo' }) : null;
			if (img) {
				btn.appendChild(img);
			} else {
				btn.classList.add(B + '__card--nophoto');
			}

			if (null !== hoverId && String(hoverId) === key) {
				btn.setAttribute('data-hover', '');
			}

			btn.addEventListener('click', function () {
				ctx.select(obj.id, 'list');
			});
			btn.addEventListener('pointerenter', function (e) {
				if ('mouse' === e.pointerType) {
					ctx.hover(obj.id);
				}
			});
			btn.addEventListener('pointerleave', function (e) {
				if ('mouse' === e.pointerType && String(hoverId) === key) {
					ctx.hover(null);
				}
			});
			btn.addEventListener('focus', function () {
				ctx.hover(obj.id);
			});
			btn.addEventListener('blur', function () {
				if (String(hoverId) === key) {
					ctx.hover(null);
				}
			});

			item.appendChild(btn);
			itemEls[key] = { item: item, btn: btn, obj: obj, extra: null };
			return item;
		}

		/**
		 * Append rows until the given count is shown.
		 *
		 * @param {number} upto Number of rows to show.
		 */
		function fill(upto) {
			var fragment = document.createDocumentFragment();
			for (var i = shown; i < upto; i++) {
				fragment.appendChild(buildRow(objects[i], i < EAGER));
			}
			cards.appendChild(fragment);
			shown = Math.max(shown, upto);
			showMore.hidden = shown >= objects.length;
		}

		/**
		 * Position of an object in the current list, or -1.
		 *
		 * @param {number|string} key Object id.
		 * @return {number}
		 */
		function indexOf(key) {
			for (var i = 0; i < objects.length; i++) {
				if (String(objects[i].id) === String(key)) {
					return i;
				}
			}
			return -1;
		}

		/**
		 * Write "Found: N" with the number in bold.
		 *
		 * @param {number} n Number of objects.
		 */
		function setFound(n) {
			var pattern = t('found', 'Found: %d');
			var at = pattern.indexOf('%d');
			found.textContent = at === -1 ? pattern + ' ' : pattern.slice(0, at);
			found.appendChild(make('b', '', String(n)));
			if (at !== -1) {
				found.appendChild(document.createTextNode(pattern.slice(at + 2)));
			}
		}

		/**
		 * Fill the empty state for the current search and categories.
		 *
		 * @param {Object} view List view.
		 */
		function setEmpty(view) {
			var line = '';
			if (view.query && view.cats.length) {
				line = t('emptyQueryCats', 'No objects match “%s” in the selected categories.').split('%s').join(view.query);
			} else if (view.query) {
				line = t('emptyQuery', 'No objects match “%s”.').split('%s').join(view.query);
			}
			emptyText.textContent = line;
			emptyText.hidden = !line;
			emptyReset.hidden = !view.query;
			emptyAll.hidden = !view.cats.length;
		}

		/**
		 * Height of the sticky search on top of the panel.
		 *
		 * @return {number}
		 */
		function stickyHeight() {
			return searchBox ? searchBox.offsetHeight : 0;
		}

		/**
		 * Scroll the panel so that a row is visible.
		 *
		 * @param {HTMLElement} el Row element.
		 */
		function reveal(el) {
			if (ctx.isPhone() || !panel) {
				return;
			}
			var r = el.getBoundingClientRect();
			var box = panel.getBoundingClientRect();
			var top = box.top + stickyHeight();
			if (r.top < top || r.bottom > box.bottom) {
				panel.scrollBy({ top: r.top - top - 8, behavior: reduced ? 'auto' : 'smooth' });
			}
		}

		/**
		 * Mark the selected row and open its contacts.
		 *
		 * @param {number|string|null} key    Object id or null.
		 * @param {string}              source Who selected it.
		 */
		function setSelected(key, source) {
			var prev = null === selectedId ? null : itemEls[String(selectedId)];
			if (prev) {
				prev.btn.removeAttribute('aria-current');
				prev.item.classList.remove(B + '__item--current');
				if (prev.extra && prev.extra.parentNode) {
					prev.extra.parentNode.removeChild(prev.extra);
				}
				prev.extra = null;
			}
			selectedId = (null === key || undefined === key || '' === key) ? null : key;
			if (null === selectedId || !cards) {
				return;
			}
			var at = indexOf(selectedId);
			if (at >= shown) {
				fill(Math.min(objects.length, (Math.floor(at / PAGE) + 1) * PAGE));
			}
			var row = itemEls[String(selectedId)];
			if (!row) {
				return;
			}
			row.btn.setAttribute('aria-current', 'true');
			row.item.classList.add(B + '__item--current');
			row.extra = buildExtra(row.obj);
			if (row.extra) {
				row.item.appendChild(row.extra);
			}
			if ('list' !== source) {
				reveal(row.item);
			}
		}

		/**
		 * Mark the hovered row.
		 *
		 * @param {number|string|null} key Object id or null.
		 */
		function setHover(key) {
			if (null !== hoverId && itemEls[String(hoverId)]) {
				itemEls[String(hoverId)].btn.removeAttribute('data-hover');
			}
			hoverId = (null === key || undefined === key || '' === key) ? null : key;
			if (null !== hoverId && itemEls[String(hoverId)]) {
				itemEls[String(hoverId)].btn.setAttribute('data-hover', '');
			}
		}

		/**
		 * Draw the panel for a view.
		 *
		 * @param {Object} view { objects, total, cats, query, sort, selectedId, hoverId }.
		 */
		function render(view) {
			var cats = (view && view.cats) || [];
			syncCats(cats);
			if (!cards) {
				return;
			}
			objects = (view && view.objects) || [];
			selectedId = view && undefined !== view.selectedId ? view.selectedId : selectedId;
			hoverId = view && undefined !== view.hoverId ? view.hoverId : hoverId;

			if (input && !view.query && input.value.trim() && document.activeElement !== input) {
				input.value = '';
			}
			if (select.value !== view.sort && ('name' === view.sort || 'new' === view.sort)) {
				select.value = view.sort;
			}

			itemEls = Object.create(null);
			cards.textContent = '';
			shown = 0;
			fill(Math.min(objects.length, PAGE));
			if (null !== selectedId) {
				setSelected(selectedId, 'list');
			}
			var top = listHead.offsetTop - stickyHeight();
			if (panel.scrollTop > top) {
				panel.scrollTop = Math.max(0, top);
			}

			setFound(objects.length);
			cards.hidden = !objects.length;
			empty.hidden = !!objects.length;
			if (!objects.length) {
				setEmpty(view);
			}
		}

		return {
			/**
			 * Build the panel and subscribe to the instance events.
			 */
			mount: function () {
				parts = api.shared && api.shared.parts;
				if (!parts) {
					throw new Error('mvwebOm.shared.parts is missing');
				}
				card = (ctx.data && ctx.data.card) || {};
				reduced = !!window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
				var withList = !!(ctx.config && ctx.config.list);
				var withCats = !!(ctx.config && ctx.config.filter);

				panel = make('div', B + '__panel');
				if (withList) {
					buildSearch();
				}
				if (withCats) {
					buildCats();
				}
				if (withList) {
					buildList();
				}
				if (!panel.childNodes.length) {
					panel = null;
					return;
				}
				var body = ctx.root.querySelector('.mvweb-om__body') || ctx.root;
				body.insertBefore(panel, body.firstChild);
				syncCats();

				handlers.select = function (p) {
					setSelected(p.id, p.source);
				};
				handlers.deselect = function () {
					setSelected(null);
				};
				handlers.hover = function (p) {
					setHover(p.id);
				};
				Object.keys(handlers).forEach(function (name) {
					ctx.on(name, handlers[name]);
				});
			},

			render: render,

			/**
			 * Remove the panel and drop the subscriptions.
			 */
			destroy: function () {
				clearTimeout(timer);
				Object.keys(handlers).forEach(function (name) {
					ctx.off(name, handlers[name]);
				});
				if (panel && panel.parentNode) {
					panel.parentNode.removeChild(panel);
				}
				panel = cards = catsHead = null;
				catRows = [];
				itemEls = Object.create(null);
			}
		};
	});
})();
