/**
 * Phone and object window variant "preview" (D4).
 *
 * Phone: the map in the page is a still preview with an object count and an
 * "Expand the map" button that moves the same map canvas into a full-screen
 * dialog with all gestures. The list goes in the page under the map, the
 * classic tabs are hidden. An object opens in a full-screen dialog: the photo
 * sticks to the top, the text slides over it, the title shows in the top bar
 * once the photo is scrolled away, and a bottom bar holds Call and Directions.
 * Desktop: the same object dialog as a two-column window.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var B = 'mvweb-om-mobile-preview';
	var PHONE_QUERY = '(max-width: 782px)';
	var BEHAVIORS_FULL = ['drag', 'pinchZoom', 'scrollZoom', 'dblClick'];
	var SVG_NS = 'http://www.w3.org/2000/svg';
	var SHAPES = {
		expand: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5',
		collapse: 'M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5'
	};
	var GUARDED = ['pointerdown', 'pointermove', 'pointerup', 'pointercancel', 'touchstart', 'touchmove', 'touchend', 'touchcancel'];
	var uid = 0;
	var plurals = null;

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		if (cls) {
			el.className = cls;
		}
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * Build an outline icon of this variant (expand or collapse).
	 *
	 * @param {string} name Key of SHAPES.
	 * @return {SVGElement}
	 */
	function shape(name) {
		var svg = document.createElementNS(SVG_NS, 'svg');
		var path = document.createElementNS(SVG_NS, 'path');
		svg.setAttribute('class', 'mvweb-om-ui__icon');
		svg.setAttribute('viewBox', '0 0 24 24');
		svg.setAttribute('fill', 'none');
		svg.setAttribute('stroke', 'currentColor');
		svg.setAttribute('stroke-width', '2');
		svg.setAttribute('stroke-linecap', 'round');
		svg.setAttribute('stroke-linejoin', 'round');
		svg.setAttribute('aria-hidden', 'true');
		svg.setAttribute('focusable', 'false');
		path.setAttribute('d', SHAPES[name]);
		svg.appendChild(path);
		return svg;
	}

	/**
	 * Build a pill button with an icon and a visible label.
	 *
	 * @param {string}   cls     Element class.
	 * @param {string}   icon    Key of SHAPES.
	 * @param {string}   label   Visible text.
	 * @param {Function} onClick Click handler.
	 * @return {HTMLButtonElement}
	 */
	function pill(cls, icon, label, onClick) {
		var btn = make('button', B + '__pill ' + cls);
		btn.type = 'button';
		btn.appendChild(shape(icon));
		btn.appendChild(make('span', '', label));
		btn.addEventListener('click', onClick);
		return btn;
	}

	/**
	 * Append a node when it exists.
	 *
	 * @param {HTMLElement}      parent Parent element.
	 * @param {HTMLElement|null} child  Child or null.
	 * @param {string}           cls    Extra class for the child (optional).
	 */
	function add(parent, child, cls) {
		if (!child) {
			return;
		}
		if (cls) {
			child.classList.add(cls);
		}
		parent.appendChild(child);
	}

	/**
	 * Object count text with the plural form of the page language.
	 *
	 * @param {Object} i18n Translated strings.
	 * @param {number} n    Count.
	 * @return {string}
	 */
	function countText(i18n, n) {
		var form = 'other';
		try {
			plurals = plurals || new Intl.PluralRules(document.documentElement.lang || 'en');
			form = plurals.select(n);
		} catch (err) {
			form = 1 === n ? 'one' : 'other';
		}
		var key = 'objects' + form.charAt(0).toUpperCase() + form.slice(1);
		var tpl = i18n[key] || i18n.objectsOther || (1 === n ? '%d object' : '%d objects');
		return tpl.replace('%d', String(n));
	}

	api.register('mobile', 'preview', function (ctx) {
		var shared = api.shared || {};
		var parts = shared.parts;
		if (!parts || typeof shared.gallery !== 'function') {
			return null;
		}

		var i18n = ctx.i18n || {};
		var root = ctx.root;
		var phoneQuery = window.matchMedia(PHONE_QUERY);
		var id = ++uid;
		var titleId = B + '-' + id + '-title';
		var mapTitleId = B + '-' + id + '-map';

		var host = null;
		var canvas = null;
		var filter = null;
		var count = null;
		var expand = null;
		var full = null;
		var collapse = null;
		var slot = null;

		var dlg = null;
		var topbar = null;
		var tbTitle = null;
		var more = null;
		var scroller = null;
		var media = null;
		var content = null;
		var bar = null;

		var mapOpen = false;
		var still = false;
		var current = null;
		var layers = [];
		var skipPop = 0;
		var frame = 0;

		/**
		 * Put a history entry so the system Back button closes the layer (phone only).
		 *
		 * @param {string} name Layer name: map or object.
		 * @return {boolean} Whether an entry was added.
		 */
		function pushLayer(name) {
			if (!ctx.isPhone() || !window.history || typeof history.pushState !== 'function') {
				return false;
			}
			history.pushState({ mvwebOm: name }, '');
			layers.push(name);
			return true;
		}

		/**
		 * Remove the history entry of a layer that was closed on screen.
		 *
		 * @param {string} name Layer name.
		 */
		function popLayer(name) {
			var at = layers.lastIndexOf(name);
			if (at === -1) {
				return;
			}
			layers.splice(at, 1);
			skipPop++;
			history.back();
		}

		/**
		 * Back button: close the top layer.
		 */
		function onPop() {
			if (skipPop > 0) {
				skipPop--;
				return;
			}
			var top = layers.pop();
			if ('object' === top) {
				finishObject(true, true);
			} else if ('map' === top) {
				collapseMap(true);
			}
		}

		/**
		 * Switch the map gestures if the API allows it.
		 *
		 * @param {Array} list Behaviors.
		 */
		function behaviors(list) {
			if (ctx.map && typeof ctx.map.setBehaviors === 'function') {
				ctx.map.setBehaviors(list);
			}
		}

		/**
		 * Keep pointer and touch input of the still preview away from the map
		 * engine: it has no gestures there, and a page scroll that starts on the
		 * map would otherwise swallow the next tap on a marker. Clicks still reach
		 * the markers.
		 *
		 * @param {Event} e Pointer or touch event.
		 */
		function guard(e) {
			if (still && canvas.parentNode === host) {
				e.stopPropagation();
			}
		}

		/**
		 * Apply the phone or desktop page layout.
		 */
		function applyLayout() {
			var phone = ctx.isPhone();
			root.classList.toggle(B + '--phone', phone);
			if (phone) {
				if (filter && filter.parentNode === host) {
					host.parentNode.insertBefore(filter, host.nextSibling);
				}
				if (!mapOpen) {
					behaviors([]);
					still = true;
				}
				return;
			}
			if (mapOpen) {
				collapseMap(false);
			}
			if (filter && filter.parentNode !== host) {
				host.insertBefore(filter, canvas.parentNode === host ? canvas : count);
			}
			if (still) {
				behaviors(BEHAVIORS_FULL);
				still = false;
			}
		}

		/**
		 * Show the number of objects on the map.
		 *
		 * @param {Object} payload Visible event: { objects }.
		 */
		function onVisible(payload) {
			var list = (payload && payload.objects) || ctx.objects || [];
			count.textContent = countText(i18n, list.length);
		}

		/**
		 * Move the map canvas into the full-screen dialog with all gestures.
		 */
		function expandMap() {
			if (mapOpen || !full) {
				return;
			}
			mapOpen = true;
			slot.appendChild(canvas);
			full.showModal();
			ctx.lock();
			behaviors(BEHAVIORS_FULL);
			still = false;
			pushLayer('map');
		}

		/**
		 * Return the map canvas to the page preview.
		 *
		 * @param {boolean} viaHistory Closed by the Back button.
		 */
		function collapseMap(viaHistory) {
			if (!mapOpen) {
				return;
			}
			mapOpen = false;
			if (full.open) {
				full.close();
			}
			host.insertBefore(canvas, count);
			if (ctx.isPhone()) {
				behaviors([]);
				still = true;
			}
			ctx.unlock();
			if (!viaHistory) {
				popLayer('map');
			}
			if (ctx.isPhone() && expand.isConnected) {
				expand.focus();
			}
		}

		/**
		 * Show or hide the title in the top bar once the photo is scrolled away.
		 */
		function paintTop() {
			frame = 0;
			var limit = media.offsetHeight ? media.offsetHeight - topbar.offsetHeight - 20 : 24;
			if (scroller.scrollTop > Math.max(24, limit)) {
				dlg.setAttribute('data-scrolled', '');
			} else {
				dlg.removeAttribute('data-scrolled');
			}
		}

		/**
		 * Throttle the top bar update to one per frame.
		 */
		function onScroll() {
			if (!frame) {
				frame = requestAnimationFrame(paintTop);
			}
		}

		/**
		 * Close the object dialog on a click on the backdrop (desktop window).
		 *
		 * @param {MouseEvent} e Click.
		 */
		function onBackdrop(e) {
			if (e.target !== dlg) {
				return;
			}
			var r = dlg.getBoundingClientRect();
			if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) {
				finishObject(true, false);
			}
		}

		/**
		 * Build the map preview controls and both dialogs.
		 */
		function build() {
			count = make('span', B + '__count');
			expand = pill(B + '__expand', 'expand', i18n.expandMap || 'Expand the map', expandMap);
			host.appendChild(count);
			host.appendChild(expand);

			full = make('dialog', B + '__full');
			full.setAttribute('aria-labelledby', mapTitleId);
			var mapTitle = make('span', 'mvweb-om__sr', i18n.mapTab || 'Map');
			mapTitle.id = mapTitleId;
			slot = make('div', B + '__slot');
			collapse = pill(B + '__collapse', 'collapse', i18n.collapseMap || 'Collapse the map', function () {
				collapseMap(false);
			});
			full.appendChild(mapTitle);
			full.appendChild(slot);
			full.appendChild(collapse);
			full.addEventListener('close', function () {
				if (!full.open) {
					collapseMap(false);
				}
			});
			root.appendChild(full);

			dlg = make('dialog', B + '__dlg');
			dlg.setAttribute('aria-labelledby', titleId);
			topbar = make('div', B + '__topbar');
			topbar.appendChild(parts.iconButton('close', i18n.close || 'Close', function () {
				finishObject(true, false);
			}, 'mvweb-om-ui__icon-btn--glass ' + B + '__close'));
			tbTitle = make('span', B + '__tb-title');
			tbTitle.setAttribute('aria-hidden', 'true');
			topbar.appendChild(tbTitle);
			more = make('a', B + '__more');
			more.setAttribute('target', '_blank');
			more.setAttribute('rel', 'noopener noreferrer');
			more.appendChild(make('span', '', i18n.more || 'More details'));
			add(more, parts.icon('arrow', 'sm'));
			more.hidden = true;
			topbar.appendChild(more);

			scroller = make('div', B + '__scroll');
			media = make('div', B + '__media');
			content = make('div', B + '__content');
			scroller.appendChild(media);
			scroller.appendChild(content);
			bar = make('div', B + '__bar');

			dlg.appendChild(topbar);
			dlg.appendChild(scroller);
			dlg.appendChild(bar);
			scroller.addEventListener('scroll', onScroll, { passive: true });
			dlg.addEventListener('click', onBackdrop);
			dlg.addEventListener('close', function () {
				if (!dlg.open) {
					finishObject(true, false);
				}
			});
			root.appendChild(dlg);
		}

		/**
		 * Fill the object dialog with an object.
		 *
		 * @param {Object} obj Object data.
		 * @return {Object} Gallery instance.
		 */
		function fill(obj) {
			var urls = (obj.gallery && obj.gallery.length) ? obj.gallery : [obj.photo || obj.thumb || ''];
			var gal = shared.gallery(ctx, { urls: urls, ratio: '6 / 5', counter: true, dots: true, alt: obj.title || '' });

			media.textContent = '';
			if (gal.count) {
				media.appendChild(gal.el);
			}
			dlg.classList.toggle(B + '__dlg--plain', !gal.count);

			content.textContent = '';
			var head = make('div', B + '__head');
			add(head, parts.cat(obj, ctx));
			var title = parts.title(obj, B + '__title');
			title.id = titleId;
			head.appendChild(title);
			add(head, parts.rows(obj, ctx, { phone: false, hours: false }));
			content.appendChild(head);
			add(content, parts.rows(obj, ctx, { address: false }), B + '__meta');
			if (obj.excerpt) {
				content.appendChild(make('p', B + '__excerpt', obj.excerpt));
			}
			var specs = parts.specs(obj, ctx, {});
			if (specs) {
				content.appendChild(make('div', B + '__label', i18n.specs || 'Characteristics'));
				content.appendChild(specs);
			}
			add(content, parts.links(obj));

			tbTitle.textContent = obj.title || '';
			if (obj.moreUrl && parts.isSafeUrl(obj.moreUrl)) {
				more.setAttribute('href', obj.moreUrl);
				more.hidden = false;
			} else {
				more.removeAttribute('href');
				more.hidden = true;
			}

			bar.textContent = '';
			var acts = parts.actions(obj, ctx, { more: false, primary: obj.phone ? 'call' : 'route' });
			bar.hidden = !acts;
			add(bar, acts);

			scroller.scrollTop = 0;
			content.scrollTop = 0;
			dlg.removeAttribute('data-scrolled');
			return gal;
		}

		/**
		 * Open the object dialog, or swap its content when it is already open.
		 *
		 * @param {Object} obj Object data.
		 */
		function show(obj) {
			if (!dlg || !obj) {
				return;
			}
			if (current) {
				current.gallery.destroy();
				current.gallery = fill(obj);
				current.id = obj.id;
				dlg.querySelector('.' + B + '__close').focus();
				return;
			}
			ctx.focus.remember();
			current = { id: obj.id, gallery: fill(obj), pushed: false };
			dlg.showModal();
			ctx.lock();
			current.pushed = pushLayer('object');
		}

		/**
		 * Close the object dialog and clean up.
		 *
		 * @param {boolean} fromUser   Closed on screen: clear the selection in the core.
		 * @param {boolean} viaHistory Closed by the Back button.
		 */
		function finishObject(fromUser, viaHistory) {
			if (!current) {
				return;
			}
			var done = current;
			current = null;
			if (dlg.open) {
				dlg.close();
			}
			if (frame) {
				cancelAnimationFrame(frame);
				frame = 0;
			}
			done.gallery.destroy();
			ctx.unlock();
			if (done.pushed && !viaHistory) {
				popLayer('object');
			}
			ctx.focus.restore();
			if (fromUser) {
				ctx.select(null, 'mobile');
			}
		}

		return {
			minMap: null,

			/**
			 * Build the preview controls and dialogs and apply the layout.
			 */
			mount: function () {
				host = root.querySelector('.mvweb-om__map');
				canvas = root.querySelector('.mvweb-om__canvas');
				filter = root.querySelector('.mvweb-om__filter');
				if (!host || !canvas) {
					throw new Error('mobile/preview: no map container');
				}
				build();
				GUARDED.forEach(function (type) {
					canvas.addEventListener(type, guard, { capture: true, passive: true });
				});
				onVisible({ objects: ctx.objects });
				ctx.on('visible', onVisible);
				window.addEventListener('popstate', onPop);
				phoneQuery.addEventListener('change', applyLayout);
				applyLayout();
			},

			/**
			 * Phone: open the object page.
			 *
			 * @param {Object} obj Object data.
			 */
			open: function (obj) {
				show(obj);
			},

			/**
			 * Desktop: open the object window in two columns.
			 *
			 * @param {Object} obj Object data.
			 */
			detailPc: function (obj) {
				show(obj);
			},

			/**
			 * Close the object dialog (called by the core).
			 */
			close: function () {
				finishObject(false, false);
			},

			/**
			 * Remove everything this module added.
			 */
			destroy: function () {
				finishObject(false, true);
				collapseMap(true);
				ctx.off('visible', onVisible);
				GUARDED.forEach(function (type) {
					canvas.removeEventListener(type, guard, { capture: true, passive: true });
				});
				window.removeEventListener('popstate', onPop);
				phoneQuery.removeEventListener('change', applyLayout);
				if (filter && host && filter.parentNode !== host) {
					host.insertBefore(filter, canvas);
				}
				[count, expand, full, dlg].forEach(function (el) {
					if (el && el.parentNode) {
						el.parentNode.removeChild(el);
					}
				});
				root.classList.remove(B + '--phone');
				layers = [];
			}
		};
	});
})();
