/**
 * List variant "glass": the map fills the block; a translucent bar with the
 * search and a category legend floats at the top left, the list is a panel
 * on the right that can be hidden. Phones get only the bar, the list there
 * belongs to the phone module.
 *
 * Object text goes in via textContent, URLs via setAttribute (shared.parts).
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var B = 'mvweb-om-list-glass';
	var OWNER = 'list-glass';
	var PAGE = 30;
	var EAGER = 3;
	var SEARCH_DELAY = 180;
	var MID = 760;
	var NARROW = 600;
	var GAP = 16;
	var COLOR = /^#[0-9a-f]{3,8}$/i;
	var SVG_NS = 'http://www.w3.org/2000/svg';
	var GLYPHS = {
		filter: 'M4 5h16l-6 8v6l-4-2v-4z',
		check: 'm5 12.5 4.5 4.5L19 7.5'
	};
	var COVERS = '.mvweb-om-balloon-showcase--card, .mvweb-om-ui__sheet:not([hidden])';
	var uid = 0;

	api.register('list', 'glass', function (ctx) {
		var parts = null;
		var card = {};
		var reduced = false;
		var host = null;
		var id = B + '-' + (++uid);
		var float = null;
		var input = null;
		var catBtn = null;
		var badge = null;
		var pop = null;
		var rows = [];
		var showBtn = null;
		var listBtn = null;
		var listNum = null;
		var drawer = null;
		var found = null;
		var select = null;
		var closeBtn = null;
		var scroller = null;
		var cards = null;
		var empty = null;
		var emptyText = null;
		var emptyReset = null;
		var emptyAll = null;
		var showMore = null;
		var cardEls = Object.create(null);
		var objects = [];
		var shown = 0;
		var selectedId = null;
		var hoverId = null;
		var wantOpen = true;
		var covered = false;
		var visible = null;
		var refocus = null;
		var timer = 0;
		var frame = 0;
		var observer = null;
		var handlers = {};

		/**
		 * Read a translated string.
		 *
		 * @param {string} key      Key in the i18n object.
		 * @param {string} fallback English text.
		 * @return {string}
		 */
		function t(key, fallback) {
			return (ctx.i18n && ctx.i18n[key]) || fallback;
		}

		/**
		 * Create an element with a class and optional text.
		 *
		 * @param {string} tag  Tag name.
		 * @param {string} cls  Class name.
		 * @param {string} body Text content (optional).
		 * @return {HTMLElement}
		 */
		function make(tag, cls, body) {
			var el = document.createElement(tag);
			if (cls) {
				el.className = cls;
			}
			if (body) {
				el.textContent = body;
			}
			return el;
		}

		/**
		 * Build an icon from the shared set or the local filter/check glyphs.
		 *
		 * @param {string} name Icon name.
		 * @param {string} cls  Extra class (optional).
		 * @return {SVGElement|null}
		 */
		function glyph(name, cls) {
			var svg = parts.icon(name, 'sm');
			if (!svg && GLYPHS.hasOwnProperty(name)) {
				svg = document.createElementNS(SVG_NS, 'svg');
				var path = document.createElementNS(SVG_NS, 'path');
				svg.setAttribute('class', 'mvweb-om-ui__icon mvweb-om-ui__icon--sm');
				svg.setAttribute('viewBox', '0 0 24 24');
				svg.setAttribute('fill', 'none');
				svg.setAttribute('stroke', 'currentColor');
				svg.setAttribute('stroke-width', '2');
				svg.setAttribute('stroke-linecap', 'round');
				svg.setAttribute('stroke-linejoin', 'round');
				svg.setAttribute('aria-hidden', 'true');
				svg.setAttribute('focusable', 'false');
				path.setAttribute('d', GLYPHS[name]);
				svg.appendChild(path);
			}
			if (svg && cls) {
				svg.setAttribute('class', svg.getAttribute('class') + ' ' + cls);
			}
			return svg;
		}

		/**
		 * Put a number into a "%d" pattern as a text node or a given element.
		 *
		 * @param {HTMLElement} el      Target element (emptied).
		 * @param {string}      pattern Translated pattern with %d.
		 * @param {number}      n       Number.
		 * @param {string}      tag     Tag for the number (optional).
		 */
		function fillCount(el, pattern, n, tag) {
			var at = pattern.indexOf('%d');
			var num = tag ? make(tag, '', String(n)) : document.createTextNode(String(n));
			el.textContent = at === -1 ? pattern + ' ' : pattern.slice(0, at);
			el.appendChild(num);
			if (at !== -1) {
				el.appendChild(document.createTextNode(pattern.slice(at + 2)));
			}
		}

		/**
		 * Number of loaded objects per category slug.
		 *
		 * @return {Object}
		 */
		function countCats() {
			var counts = Object.create(null);
			(ctx.objects || []).forEach(function (obj) {
				(obj.categories || []).forEach(function (slug) {
					counts[slug] = (counts[slug] || 0) + 1;
				});
			});
			return counts;
		}

		/**
		 * Build the search field.
		 *
		 * @return {HTMLElement}
		 */
		function buildSearch() {
			var label = make('label', B + '__search');
			var ico = glyph('search');
			if (ico) {
				label.appendChild(ico);
			}
			label.appendChild(make('span', 'mvweb-om__sr', t('searchLabel', 'Search objects')));
			input = make('input', B + '__input');
			input.type = 'search';
			input.setAttribute('placeholder', t('searchHint', 'Name or address'));
			input.setAttribute('autocomplete', 'off');
			input.setAttribute('enterkeyhint', 'search');
			label.appendChild(input);
			input.addEventListener('input', function () {
				clearTimeout(timer);
				timer = setTimeout(function () {
					ctx.setQuery(input.value);
				}, SEARCH_DELAY);
			});
			return label;
		}

		/**
		 * Build one legend row: a checkbox with the category mark, name and count.
		 *
		 * @param {Object} cat   Category.
		 * @param {number} count Number of objects.
		 * @return {HTMLElement} The list item.
		 */
		function buildRow(cat, count) {
			var item = make('li', B + '__item');
			var label = make('label', B + '__row');
			var box = make('input', B + '__check');
			box.type = 'checkbox';
			box.value = String(cat.slug);
			var mark = make('span', B + '__mark');
			mark.setAttribute('aria-hidden', 'true');
			if (COLOR.test(cat.color || '')) {
				label.style.setProperty('--mvweb-om-glass-c', cat.color);
			}
			label.appendChild(box);
			label.appendChild(mark);
			label.appendChild(make('span', B + '__name', cat.name || String(cat.slug)));
			label.appendChild(make('span', B + '__count', String(count)));
			var tick = glyph('check', B + '__tick');
			if (tick) {
				label.appendChild(tick);
			}
			box.addEventListener('change', applyCats);
			rows.push(box);
			item.appendChild(label);
			return item;
		}

		/**
		 * Send the checked categories to the core.
		 */
		function applyCats() {
			var cats = [];
			rows.forEach(function (box) {
				if (box.checked) {
					cats.push(box.value);
				}
			});
			ctx.setCats(cats);
		}

		/**
		 * Build the category button and its legend popover.
		 *
		 * @param {Array} list Categories that have objects, with counts.
		 * @return {Array} [button, popover].
		 */
		function buildCats(list) {
			var label = t('categories', 'Categories');
			catBtn = make('button', B + '__catbtn');
			catBtn.type = 'button';
			catBtn.setAttribute('aria-expanded', 'false');
			catBtn.setAttribute('aria-controls', id + '-pop');
			catBtn.setAttribute('title', label);
			var ico = glyph('filter');
			if (ico) {
				catBtn.appendChild(ico);
			}
			catBtn.appendChild(make('span', B + '__catlabel', label));
			badge = make('span', B + '__badge');
			badge.hidden = true;
			catBtn.appendChild(badge);
			var chev = glyph('chev-d', B + '__chev');
			if (chev) {
				catBtn.appendChild(chev);
			}

			pop = make('div', B + '__pop');
			pop.id = id + '-pop';
			pop.hidden = true;
			var head = make('div', B + '__pophead');
			var title = make('span', B + '__poptitle', t('showOnMap', 'Show on the map'));
			title.id = id + '-poptitle';
			head.appendChild(title);
			var reset = make('button', B + '__reset', t('resetCats', 'Reset'));
			reset.type = 'button';
			head.appendChild(reset);
			pop.appendChild(head);

			var legend = make('ul', B + '__legend');
			legend.setAttribute('role', 'list');
			legend.setAttribute('aria-labelledby', title.id);
			list.forEach(function (pair) {
				legend.appendChild(buildRow(pair[0], pair[1]));
			});
			pop.appendChild(legend);

			var foot = make('div', B + '__popfoot');
			showBtn = make('button', 'mvweb-om-ui__btn ' + B + '__show');
			showBtn.type = 'button';
			foot.appendChild(showBtn);
			pop.appendChild(foot);

			catBtn.addEventListener('click', function () {
				setPop(pop.hidden);
			});
			reset.addEventListener('click', function () {
				rows.forEach(function (box) {
					box.checked = false;
				});
				ctx.setCats([]);
			});
			showBtn.addEventListener('click', function () {
				setPop(false);
				catBtn.focus();
			});
			return [catBtn, pop];
		}

		/**
		 * Open or close the legend popover.
		 *
		 * @param {boolean} open Whether to open.
		 */
		function setPop(open) {
			if (!pop) {
				return;
			}
			if (open) {
				var room = host.clientHeight - float.offsetTop - float.offsetHeight - 24;
				pop.style.setProperty('--mvweb-om-glass-pop-max', Math.max(room, 160) + 'px');
			}
			pop.hidden = !open;
			catBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
		}

		/**
		 * Build the floating bar: search, categories button, legend popover.
		 */
		function buildFloat() {
			var counts = countCats();
			var list = [];
			(ctx.categories || []).forEach(function (cat) {
				if (cat && cat.slug && counts[cat.slug]) {
					list.push([cat, counts[cat.slug]]);
				}
			});
			var withSearch = !!(ctx.config && ctx.config.list);
			var withCats = !!(ctx.config && ctx.config.filter) && list.length > 0;
			if (!withSearch && !withCats) {
				return;
			}
			float = make('div', B + '__float' + (withSearch ? '' : ' ' + B + '__float--bare'));
			if (withSearch) {
				float.appendChild(buildSearch());
			}
			if (withCats) {
				buildCats(list).forEach(function (el) {
					float.appendChild(el);
				});
			}
			host.appendChild(float);
		}

		/**
		 * Build the list panel and the button that brings it back.
		 */
		function buildDrawer() {
			listBtn = make('button', B + '__listbtn');
			listBtn.type = 'button';
			listBtn.hidden = true;
			var ico = glyph('list');
			if (ico) {
				listBtn.appendChild(ico);
			}
			listNum = make('span', '');
			listBtn.appendChild(listNum);
			host.appendChild(listBtn);

			drawer = make('div', B + '__drawer');
			var head = make('div', B + '__head');
			found = make('span', B + '__found');
			found.setAttribute('role', 'status');
			head.appendChild(found);

			var sort = make('label', B + '__sort');
			sort.appendChild(make('span', 'mvweb-om__sr', t('sortLabel', 'Sort objects')));
			select = make('select', B + '__select');
			[['name', t('sortName', 'By name')], ['new', t('sortNew', 'Newest first')]].forEach(function (pair) {
				var opt = make('option', '', pair[1]);
				opt.value = pair[0];
				select.appendChild(opt);
			});
			sort.appendChild(select);
			var chev = glyph('chev-d');
			if (chev) {
				sort.appendChild(chev);
			}
			head.appendChild(sort);

			closeBtn = parts.iconButton('close', t('hideList', 'Hide list'), function () {
				wantOpen = false;
				apply();
				listBtn.focus();
			}, 'mvweb-om-ui__icon-btn--compact ' + B + '__close');
			head.appendChild(closeBtn);
			drawer.appendChild(head);

			scroller = make('div', B + '__scroll');
			cards = make('ul', B + '__cards');
			cards.setAttribute('role', 'list');
			scroller.appendChild(cards);

			empty = make('div', B + '__empty');
			empty.hidden = true;
			var emptyIcon = make('span', B + '__empty-ico');
			var big = parts.icon('search');
			if (big) {
				emptyIcon.appendChild(big);
			}
			empty.appendChild(emptyIcon);
			empty.appendChild(make('span', B + '__empty-title', t('emptyTitle', 'Nothing found')));
			emptyText = make('span', B + '__empty-text');
			empty.appendChild(emptyText);
			var actions = make('span', B + '__empty-actions');
			emptyReset = make('button', B + '__empty-reset', t('resetSearch', 'Clear search'));
			emptyReset.type = 'button';
			emptyAll = make('button', B + '__empty-all', t('allCats', 'Search in all categories'));
			emptyAll.type = 'button';
			actions.appendChild(emptyReset);
			actions.appendChild(emptyAll);
			empty.appendChild(actions);
			scroller.appendChild(empty);

			showMore = make('button', 'mvweb-om-ui__btn mvweb-om-ui__btn--outline ' + B + '__more', t('showMore', 'Show more'));
			showMore.type = 'button';
			showMore.hidden = true;
			scroller.appendChild(showMore);
			drawer.appendChild(scroller);
			host.appendChild(drawer);

			listBtn.addEventListener('click', function () {
				wantOpen = true;
				if (covered) {
					ctx.select(null);
					covered = false;
				}
				apply();
				closeBtn.focus();
			});
			select.addEventListener('change', function () {
				ctx.setSort(select.value);
			});
			emptyReset.addEventListener('click', function () {
				clearTimeout(timer);
				if (input) {
					input.value = '';
				}
				ctx.setQuery('');
				(input || closeBtn).focus();
			});
			emptyAll.addEventListener('click', function () {
				rows.forEach(function (box) {
					box.checked = false;
				});
				ctx.setCats([]);
				(input || closeBtn).focus();
			});
			showMore.addEventListener('click', function () {
				var from = shown;
				fill(Math.min(objects.length, shown + PAGE));
				var first = cards.children[from];
				if (first && first.firstChild) {
					first.firstChild.focus();
				}
			});
		}

		/**
		 * Build one object card.
		 *
		 * @param {Object}  obj   Object data.
		 * @param {boolean} eager Load the photo without lazy loading.
		 * @return {HTMLElement} The list item.
		 */
		function buildCard(obj, eager) {
			var key = String(obj.id);
			var item = make('li', B + '__cell');
			var btn = make('button', B + '__card');
			btn.type = 'button';
			btn.setAttribute('data-id', key);

			var img = false !== card.showPhoto ? parts.photo(obj, { size: 'thumb', eager: eager, className: B + '__photo' }) : null;
			if (img) {
				btn.appendChild(img);
			} else {
				btn.classList.add(B + '__card--nophoto');
			}

			var body = make('span', B + '__body');
			var cat = parts.cat(obj, ctx);
			if (cat) {
				body.appendChild(cat);
			}
			body.appendChild(make('span', B + '__title', obj.title || ''));
			if (false !== card.showAddress && obj.address) {
				body.appendChild(make('span', B + '__addr', obj.address));
			}
			if (card.showExcerpt && obj.excerpt) {
				body.appendChild(make('span', B + '__excerpt', obj.excerpt));
			}
			var facts = parts.facts(obj, ctx, { flag: 'list' });
			if (facts) {
				facts.classList.add(B + '__facts');
				body.appendChild(facts);
			}
			btn.appendChild(body);

			if (null !== selectedId && String(selectedId) === key) {
				btn.setAttribute('aria-current', 'true');
			}
			if (null !== hoverId && String(hoverId) === key) {
				btn.setAttribute('data-hover', '');
			}

			btn.addEventListener('click', function () {
				ctx.select(obj.id, 'list');
			});
			btn.addEventListener('pointerenter', function (e) {
				if ('mouse' === e.pointerType) {
					ctx.hover(obj.id);
				}
			});
			btn.addEventListener('pointerleave', function (e) {
				if ('mouse' === e.pointerType && String(hoverId) === key) {
					ctx.hover(null);
				}
			});
			btn.addEventListener('focus', function () {
				ctx.hover(obj.id);
			});
			btn.addEventListener('blur', function () {
				if (String(hoverId) === key) {
					ctx.hover(null);
				}
			});

			cardEls[key] = btn;
			item.appendChild(btn);
			return item;
		}

		/**
		 * Append cards until the given count is shown.
		 *
		 * @param {number} upto Number of cards to show.
		 */
		function fill(upto) {
			var fragment = document.createDocumentFragment();
			for (var i = shown; i < upto; i++) {
				fragment.appendChild(buildCard(objects[i], i < EAGER));
			}
			cards.appendChild(fragment);
			shown = Math.max(shown, upto);
			showMore.hidden = shown >= objects.length;
		}

		/**
		 * Position of an object in the current list, or -1.
		 *
		 * @param {number|string} key Object id.
		 * @return {number}
		 */
		function indexOf(key) {
			for (var i = 0; i < objects.length; i++) {
				if (String(objects[i].id) === String(key)) {
					return i;
				}
			}
			return -1;
		}

		/**
		 * Fill the empty state for the current search and categories.
		 *
		 * @param {Object} view List view.
		 */
		function setEmpty(view) {
			var line = '';
			if (view.query && view.cats.length) {
				line = t('emptyQueryCats', 'No objects match “%s” in the selected categories.').split('%s').join(view.query);
			} else if (view.query) {
				line = t('emptyQuery', 'No objects match “%s”.').split('%s').join(view.query);
			}
			emptyText.textContent = line;
			emptyText.hidden = !line;
			emptyReset.hidden = !view.query;
			emptyAll.hidden = !view.cats.length;
		}

		/**
		 * Whether the list panel is shown in the current layout.
		 *
		 * @return {boolean}
		 */
		function isShown() {
			return !!drawer && !ctx.isPhone() && wantOpen && !covered;
		}

		/**
		 * Lay out the bar and the panel for the map width and the open state,
		 * and reserve the right edge of the map while the panel is shown.
		 */
		function apply() {
			var width = host.clientWidth;
			var root = ctx.root;
			root.classList.toggle(B + '--mid', width < MID && width >= NARROW);
			root.classList.toggle(B + '--narrow', width < NARROW);
			if (!drawer) {
				return;
			}
			var on = isShown();
			root.classList.toggle(B + '--open', on);
			root.classList.toggle(B + '--closed', !on && !ctx.isPhone());
			root.classList.toggle(B + '--covered', covered);
			listBtn.hidden = on || ctx.isPhone();
			if (on) {
				drawer.removeAttribute('inert');
			} else {
				drawer.setAttribute('inert', '');
			}
			var inset = on && width >= NARROW ? drawer.offsetWidth + GAP : 0;
			if (inset !== visible) {
				visible = inset;
				ctx.setInsets(OWNER, inset ? { r: inset } : null);
			}
		}

		/**
		 * Re-run the layout on the next frame.
		 */
		function queue() {
			if (frame) {
				return;
			}
			frame = requestAnimationFrame(function () {
				frame = 0;
				apply();
			});
		}

		/**
		 * Collapse the panel while another part shows a card over the map.
		 *
		 * @param {HTMLElement|null} from Panel element that had focus when the object was selected.
		 */
		function checkCover(from) {
			if (!drawer || ctx.isPhone() || null === selectedId) {
				return;
			}
			var next = !!ctx.root.querySelector(COVERS);
			if (next && !covered) {
				refocus = from || null;
			}
			covered = next;
			apply();
		}

		/**
		 * Lift the collapse once the card is closed.
		 */
		function uncover() {
			if (!covered) {
				return;
			}
			covered = false;
			apply();
			var active = document.activeElement;
			if (refocus && refocus.isConnected && isShown() && (!active || active === document.body)) {
				refocus.focus({ preventScroll: true });
			}
			refocus = null;
		}

		/**
		 * Scroll the panel so that a card is visible.
		 *
		 * @param {HTMLElement} btn Card button.
		 */
		function reveal(btn) {
			if (!isShown()) {
				return;
			}
			var r = btn.getBoundingClientRect();
			var box = scroller.getBoundingClientRect();
			if (r.top < box.top || r.bottom > box.bottom) {
				scroller.scrollBy({ top: r.top - box.top - 12, behavior: reduced ? 'auto' : 'smooth' });
			}
		}

		/**
		 * Mark the selected card.
		 *
		 * @param {number|string|null} key    Object id or null.
		 * @param {string}             source Who selected it.
		 */
		function setSelected(key, source) {
			if (null !== selectedId && cardEls[String(selectedId)]) {
				cardEls[String(selectedId)].removeAttribute('aria-current');
			}
			selectedId = (null === key || undefined === key || '' === key) ? null : key;
			if (null === selectedId || !cards) {
				return;
			}
			var at = indexOf(selectedId);
			if (at >= shown) {
				fill(Math.min(objects.length, (Math.floor(at / PAGE) + 1) * PAGE));
			}
			var btn = cardEls[String(selectedId)];
			if (!btn) {
				return;
			}
			btn.setAttribute('aria-current', 'true');
			if ('list' !== source) {
				reveal(btn);
			}
		}

		/**
		 * Mark the hovered card.
		 *
		 * @param {number|string|null} key Object id or null.
		 */
		function setHover(key) {
			if (null !== hoverId && cardEls[String(hoverId)]) {
				cardEls[String(hoverId)].removeAttribute('data-hover');
			}
			hoverId = (null === key || undefined === key || '' === key) ? null : key;
			if (null !== hoverId && cardEls[String(hoverId)]) {
				cardEls[String(hoverId)].setAttribute('data-hover', '');
			}
		}

		/**
		 * Draw the bar state and the list for a view.
		 *
		 * @param {Object} view { objects, total, cats, query, sort, selectedId, hoverId }.
		 */
		function render(view) {
			var cats = (view && view.cats) || [];
			var list = (view && view.objects) || [];
			var n = list.length;

			rows.forEach(function (box) {
				box.checked = cats.indexOf(box.value) !== -1;
			});
			if (pop) {
				pop.classList.toggle(B + '__pop--all', !cats.length);
				badge.textContent = String(cats.length);
				badge.hidden = !cats.length;
				fillCount(showBtn, t('showCount', 'Show %d'), n);
			}
			if (input && !view.query && input.value.trim() && document.activeElement !== input) {
				input.value = '';
			}
			if (!drawer) {
				return;
			}
			fillCount(listNum, t('listCount', 'List · %d'), n);
			fillCount(found, t('found', 'Found: %d'), n, 'b');
			if (select.value !== view.sort && ('name' === view.sort || 'new' === view.sort)) {
				select.value = view.sort;
			}

			objects = list;
			selectedId = undefined !== view.selectedId ? view.selectedId : selectedId;
			hoverId = undefined !== view.hoverId ? view.hoverId : hoverId;
			cardEls = Object.create(null);
			cards.textContent = '';
			shown = 0;
			fill(Math.min(n, PAGE));
			if (null !== selectedId) {
				setSelected(selectedId, 'list');
			}
			scroller.scrollTop = 0;
			cards.hidden = !n;
			empty.hidden = !!n;
			if (!n) {
				setEmpty(view);
			}
		}

		/**
		 * Close the legend on a press outside the bar.
		 *
		 * @param {Event} e Pointer event.
		 */
		function onOutside(e) {
			if (pop && !pop.hidden && float && !float.contains(e.target)) {
				setPop(false);
			}
		}

		/**
		 * Close the legend on Escape and return focus to its button.
		 *
		 * @param {KeyboardEvent} e Key event.
		 */
		function onKey(e) {
			if ('Escape' === e.key && pop && !pop.hidden) {
				e.stopPropagation();
				setPop(false);
				catBtn.focus();
			}
		}

		return {
			/**
			 * Build the bar and the list panel and subscribe to the instance events.
			 */
			mount: function () {
				parts = api.shared && api.shared.parts;
				if (!parts) {
					throw new Error('mvwebOm.shared.parts is missing');
				}
				card = (ctx.data && ctx.data.card) || {};
				reduced = !!window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
				host = ctx.root.querySelector('.mvweb-om__map') || ctx.root;

				buildFloat();
				if (ctx.config && ctx.config.list) {
					wantOpen = host.clientWidth >= NARROW;
					buildDrawer();
				}
				if (float) {
					float.addEventListener('keydown', onKey);
					document.addEventListener('pointerdown', onOutside, true);
				}

				if (typeof ResizeObserver === 'function') {
					observer = new ResizeObserver(queue);
					observer.observe(host);
				} else {
					window.addEventListener('resize', queue);
				}
				apply();

				handlers.select = function (p) {
					var active = document.activeElement;
					var from = drawer && drawer.contains(active) ? active : null;
					setSelected(p.id, p.source);
					setTimeout(function () {
						checkCover(from);
					}, 0);
				};
				handlers.deselect = function () {
					setSelected(null);
					uncover();
				};
				handlers.hover = function (p) {
					setHover(p.id);
				};
				Object.keys(handlers).forEach(function (name) {
					ctx.on(name, handlers[name]);
				});
			},

			render: render,

			/**
			 * Remove the bar and the panel, the map inset and the subscriptions.
			 */
			destroy: function () {
				clearTimeout(timer);
				if (frame) {
					cancelAnimationFrame(frame);
				}
				if (observer) {
					observer.disconnect();
				} else {
					window.removeEventListener('resize', queue);
				}
				document.removeEventListener('pointerdown', onOutside, true);
				Object.keys(handlers).forEach(function (name) {
					ctx.off(name, handlers[name]);
				});
				if (visible) {
					ctx.setInsets(OWNER, null);
				}
				[float, listBtn, drawer].forEach(function (el) {
					if (el && el.parentNode) {
						el.parentNode.removeChild(el);
					}
				});
				[B + '--mid', B + '--narrow', B + '--open', B + '--closed', B + '--covered'].forEach(function (cls) {
					ctx.root.classList.remove(cls);
				});
				float = listBtn = drawer = pop = null;
				rows = [];
				cardEls = Object.create(null);
			}
		};
	});
})();
