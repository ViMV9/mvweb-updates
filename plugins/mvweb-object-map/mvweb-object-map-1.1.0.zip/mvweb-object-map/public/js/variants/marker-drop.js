/**
 * Marker variant "drop": a category-colored drop with the category icon,
 * cluster as an accent circle that grows with rings.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var SVG_NS = 'http://www.w3.org/2000/svg';
	var COLOR = /^#[0-9a-f]{3,8}$/i;
	var DROP = 'M18 44.5S2.5 28.6 2.5 17.5a15.5 15.5 0 0 1 31 0C33.5 28.6 18 44.5 18 44.5z';
	var B = 'mvweb-om-marker-drop';

	/**
	 * Whether a URL is safe to place into src (http(s) or root-relative).
	 *
	 * @param {string} url URL to test.
	 * @return {boolean}
	 */
	function isSafeUrl(url) {
		if (typeof url !== 'string') {
			return false;
		}
		var s = url.trim().toLowerCase();
		return s.indexOf('http://') === 0 || s.indexOf('https://') === 0 || s.indexOf('/') === 0;
	}

	/**
	 * Readable icon color on top of a category color (WCAG relative luminance,
	 * same rule as the accent ink in PHP).
	 *
	 * @param {string} hex Background color, #rgb, #rgba, #rrggbb or #rrggbbaa.
	 * @return {string} '#ffffff' or '#111827'.
	 */
	function inkFor(hex) {
		var h = hex.replace('#', '');
		if (h.length < 6) {
			h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
		}
		var lum = 0;
		[0.2126, 0.7152, 0.0722].forEach(function (weight, i) {
			var c = parseInt(h.substr(i * 2, 2), 16) / 255;
			c = c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
			lum += weight * c;
		});
		return lum > 0.179 ? '#111827' : '#ffffff';
	}

	/**
	 * The object's first category from the payload.
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} ctx Map context.
	 * @return {Object|null}
	 */
	function firstCategory(obj, ctx) {
		var slug = (obj.categories || [])[0];
		var found = null;
		(ctx.categories || []).some(function (cat) {
			if (cat.slug === slug) {
				found = cat;
			}
			return !!found;
		});
		return found;
	}

	/**
	 * Marker icon by priority: own image, object preset, category icon, home.
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} cat First category or null.
	 * @param {Object} ctx Map context.
	 * @return {Element|null}
	 */
	function markerIcon(obj, cat, ctx) {
		var own = obj.icon || {};
		if ('image' === own.type && isSafeUrl(own.url)) {
			var img = document.createElement('img');
			img.className = B + '__img';
			img.setAttribute('src', own.url);
			img.setAttribute('alt', '');
			img.setAttribute('decoding', 'async');
			img.setAttribute('loading', 'lazy');
			return img;
		}
		var svg = (own.preset && ctx.icon(own.preset)) || (cat && cat.icon && ctx.icon(cat.icon)) || ctx.icon('home');
		if (svg) {
			svg.setAttribute('class', 'mvweb-om-ui__icon ' + B + '__ico');
		}
		return svg;
	}

	/**
	 * Make a cluster element reachable from the keyboard.
	 *
	 * @param {HTMLElement} el    Cluster element.
	 * @param {number}      count Objects in the cluster.
	 * @param {Object}      ctx   Map context.
	 */
	function clusterA11y(el, count, ctx) {
		var label = (ctx.i18n.clusterLabel || 'Objects: %d. Zoom in').replace('%d', String(count));
		var sr = document.createElement('span');
		sr.className = 'mvweb-om__sr';
		sr.textContent = label;
		el.appendChild(sr);
		el.setAttribute('role', 'button');
		el.setAttribute('tabindex', '0');
		el.setAttribute('title', label);
		el.addEventListener('keydown', function (e) {
			if ('Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key) {
				e.preventDefault();
				e.stopPropagation();
				el.click();
			}
		});
	}

	api.register('marker', 'drop', function (ctx) {
		return {
			gridSize: 64,

			/**
			 * Build the drop marker of an object.
			 *
			 * @param {Object} obj Object data.
			 * @return {HTMLElement}
			 */
			create: function (obj) {
				var cat = firstCategory(obj, ctx);
				var el = document.createElement('div');
				el.className = 'mvweb-om__marker ' + B + '__m';
				el.setAttribute('title', obj.title || '');
				if (cat && COLOR.test(cat.color || '')) {
					el.style.setProperty('--mvweb-om-marker-c', cat.color);
					el.style.setProperty('--mvweb-om-marker-ink', inkFor(cat.color));
				}

				var drop = document.createElementNS(SVG_NS, 'svg');
				var path = document.createElementNS(SVG_NS, 'path');
				drop.setAttribute('class', B + '__drop');
				drop.setAttribute('viewBox', '0 0 36 46');
				drop.setAttribute('aria-hidden', 'true');
				drop.setAttribute('focusable', 'false');
				path.setAttribute('d', DROP);
				drop.appendChild(path);
				el.appendChild(drop);

				var ico = markerIcon(obj, cat, ctx);
				if (ico) {
					el.appendChild(ico);
				}
				return el;
			},

			/**
			 * Build a cluster circle sized by the number of objects.
			 *
			 * @param {Array} features Clustered features.
			 * @return {HTMLElement}
			 */
			cluster: function (features) {
				var count = features.length;
				var size = count < 10 ? 's' : (count < 100 ? 'm' : 'l');
				var el = document.createElement('div');
				var num = document.createElement('span');
				el.className = B + '__cl ' + B + '__cl--' + size;
				num.setAttribute('aria-hidden', 'true');
				num.textContent = String(count);
				el.appendChild(num);
				clusterA11y(el, count, ctx);
				return el;
			}
		};
	});
})();
