/**
 * Phone and object window variant "fab" (D3).
 *
 * Phone: the page shows a list of objects with large photos and a floating
 * "Map" button. The button moves the same map canvas into a full-screen
 * dialog; there a "List" button returns, and a tapped marker shows a short
 * card above it. An object opens as a full-screen page with a sticky bar of
 * actions. The system Back button closes the object page and the map.
 * Desktop: the object opens in an almost full-screen window with a large
 * photo, thumbnails and a sticky contact card.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var B = 'mvweb-om-mobile-fab';
	var PHONE_QUERY = '(max-width: 782px)';
	var BEHAVIORS_FULL = ['drag', 'pinchZoom', 'scrollZoom', 'dblClick'];
	var COLOR = /^#[0-9a-f]{3,8}$/i;
	var PAGE = 30;
	var EAGER = 2;
	var SEARCH_DELAY = 180;
	var SVG_NS = 'http://www.w3.org/2000/svg';
	var uid = 0;

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		if (cls) {
			el.className = cls;
		}
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * Append a node when it exists.
	 *
	 * @param {HTMLElement}      parent Parent element.
	 * @param {HTMLElement|null} child  Child or null.
	 * @param {string}           cls    Extra class for the child (optional).
	 */
	function add(parent, child, cls) {
		if (!child) {
			return;
		}
		if (cls) {
			child.classList.add(cls);
		}
		parent.appendChild(child);
	}

	/**
	 * Funnel icon of the sort control.
	 *
	 * @return {SVGElement}
	 */
	function sortIcon() {
		var svg = document.createElementNS(SVG_NS, 'svg');
		var path = document.createElementNS(SVG_NS, 'path');
		svg.setAttribute('class', 'mvweb-om-ui__icon');
		svg.setAttribute('viewBox', '0 0 24 24');
		svg.setAttribute('fill', 'none');
		svg.setAttribute('stroke', 'currentColor');
		svg.setAttribute('stroke-width', '2');
		svg.setAttribute('stroke-linecap', 'round');
		svg.setAttribute('stroke-linejoin', 'round');
		svg.setAttribute('aria-hidden', 'true');
		svg.setAttribute('focusable', 'false');
		path.setAttribute('d', 'M4 5h16l-6 8v6l-4-2v-4z');
		svg.appendChild(path);
		return svg;
	}

	/**
	 * Photo URLs of an object: the gallery, else the main photo.
	 *
	 * @param {Object} obj   Object data.
	 * @param {Object} parts Shared card parts.
	 * @return {Array}
	 */
	function photos(obj, parts) {
		var list = (obj.gallery && obj.gallery.length) ? obj.gallery : [obj.photo || obj.thumb || ''];
		return list.filter(parts.isSafeUrl);
	}

	/**
	 * Spec rows of an object flagged for the balloon (the three key figures).
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} ctx Map context.
	 * @return {Array}
	 */
	function keyFigures(obj, ctx) {
		var specs = obj.specs || [];
		var schema = ctx.schema || [];
		var ids = {};
		if (!schema.length) {
			return specs.filter(function (s) { return s.inBalloon && s.value; }).slice(0, 3);
		}
		schema.forEach(function (field) {
			if (field.show && field.show.indexOf('balloon') !== -1) {
				ids[field.id] = true;
			}
		});
		return specs.filter(function (s) {
			return undefined !== s.id && ids[s.id] === true && s.value;
		}).slice(0, 3);
	}

	api.register('mobile', 'fab', function (ctx) {
		var shared = api.shared || {};
		var parts = shared.parts;
		if (!parts || typeof shared.gallery !== 'function') {
			return null;
		}

		var i18n = ctx.i18n || {};
		var root = ctx.root;
		var phoneQuery = window.matchMedia(PHONE_QUERY);
		var id = ++uid;
		var titleId = B + '-' + id + '-title';
		var mapTitleId = B + '-' + id + '-map';

		var host = null;
		var canvas = null;

		var page = null;
		var input = null;
		var select = null;
		var chipRows = [];
		var found = null;
		var cards = null;
		var empty = null;
		var emptyText = null;
		var emptyReset = null;
		var emptyAll = null;
		var showMore = null;
		var fab = null;

		var full = null;
		var slot = null;
		var mapChips = null;
		var card = null;
		var listBtn = null;

		var dlg = null;
		var back = null;
		var tbTitle = null;
		var scroller = null;
		var media = null;
		var main = null;
		var aside = null;

		var objects = [];
		var shown = 0;
		var galleries = [];
		var pending = [];
		var observer = null;
		var visible = ctx.objects || [];
		var needFit = true;
		var mapOpen = false;
		var cardObj = null;
		var current = null;
		var opener = null;
		var lastSource = '';
		var layers = [];
		var skipPop = 0;
		var timer = 0;
		var handlers = {};

		/**
		 * Read a translated string.
		 *
		 * @param {string} key      Key in the i18n object.
		 * @param {string} fallback English text.
		 * @return {string}
		 */
		function t(key, fallback) {
			return i18n[key] || fallback;
		}

		/**
		 * Put a history entry so the system Back button closes the layer (phone only).
		 *
		 * @param {string} name Layer name: map or object.
		 * @return {boolean} Whether an entry was added.
		 */
		function pushLayer(name) {
			if (!ctx.isPhone() || !window.history || typeof history.pushState !== 'function') {
				return false;
			}
			history.pushState({ mvwebOm: name }, '');
			layers.push(name);
			return true;
		}

		/**
		 * Remove the history entry of a layer that was closed on screen.
		 *
		 * @param {string} name Layer name.
		 */
		function popLayer(name) {
			var at = layers.lastIndexOf(name);
			if (at === -1) {
				return;
			}
			layers.splice(at, 1);
			skipPop++;
			history.back();
		}

		/**
		 * Back button: close the top layer.
		 */
		function onPop() {
			if (skipPop > 0) {
				skipPop--;
				return;
			}
			var top = layers.pop();
			if ('object' === top) {
				finishObject(true);
			} else if ('map' === top) {
				collapseMap(true);
			}
		}

		/**
		 * Switch the map gestures if the API allows it.
		 *
		 * @param {Array} list Behaviors.
		 */
		function behaviors(list) {
			if (ctx.map && typeof ctx.map.setBehaviors === 'function') {
				ctx.map.setBehaviors(list);
			}
		}

		/**
		 * Keep one-finger drag in the full-screen map: the two-finger mode of
		 * the core turns drag off when the last finger is lifted.
		 */
		function keepDrag() {
			if (mapOpen) {
				behaviors(BEHAVIORS_FULL);
			}
		}

		/**
		 * Build the category chips row.
		 *
		 * @param {string} cls Extra class of the row.
		 * @return {HTMLElement|null}
		 */
		function buildChips(cls) {
			var cats = ctx.categories || [];
			if (!(ctx.config && ctx.config.filter) || !cats.length) {
				return null;
			}
			var row = make('div', B + '__chips ' + cls);
			row.setAttribute('role', 'group');
			row.setAttribute('aria-label', t('categories', 'Categories'));
			var chip = function (label, slug, color) {
				var btn = make('button', B + '__chip');
				btn.type = 'button';
				btn.setAttribute('data-slug', slug);
				btn.setAttribute('aria-pressed', 'false');
				if (slug) {
					var dot = make('span', B + '__dot');
					if (COLOR.test(color || '')) {
						dot.style.setProperty('--mvweb-om-ui-c', color);
					}
					btn.appendChild(dot);
				}
				btn.appendChild(document.createTextNode(label));
				row.appendChild(btn);
			};
			chip(t('all', 'All'), '', '');
			cats.forEach(function (cat) {
				if (cat && cat.slug) {
					chip(cat.name || cat.slug, String(cat.slug), cat.color);
				}
			});
			row.addEventListener('click', function (e) {
				var btn = e.target.closest('.' + B + '__chip');
				if (!btn) {
					return;
				}
				var slug = btn.getAttribute('data-slug') || '';
				ctx.select(null, 'mobile');
				ctx.setCats(slug ? [slug] : []);
			});
			chipRows.push(row);
			return row;
		}

		/**
		 * Mirror the active categories on every chips row.
		 *
		 * @param {Array} cats Active category slugs.
		 */
		function syncChips(cats) {
			chipRows.forEach(function (row) {
				row.querySelectorAll('.' + B + '__chip').forEach(function (btn) {
					var slug = btn.getAttribute('data-slug') || '';
					btn.setAttribute('aria-pressed', (slug ? cats.indexOf(slug) !== -1 : !cats.length) ? 'true' : 'false');
				});
			});
		}

		/**
		 * Build the list page: search, chips, counter, sort, cards, empty state
		 * and the floating Map button.
		 */
		function buildPage() {
			page = make('div', B + '__page');

			var search = make('label', B + '__search');
			add(search, parts.icon('search', 'sm'));
			search.appendChild(make('span', 'mvweb-om__sr', t('searchLabel', 'Search objects')));
			input = make('input', B + '__input');
			input.type = 'search';
			input.setAttribute('placeholder', t('searchHint', 'Name or address'));
			input.setAttribute('autocomplete', 'off');
			input.setAttribute('enterkeyhint', 'search');
			search.appendChild(input);
			var tools = make('div', B + '__tools');
			tools.appendChild(search);

			var sort = make('label', B + '__sort');
			sort.setAttribute('title', t('sortLabel', 'Sort objects'));
			sort.appendChild(make('span', 'mvweb-om__sr', t('sortLabel', 'Sort objects')));
			select = make('select', B + '__select');
			[['name', t('sortName', 'By name')], ['new', t('sortNew', 'Newest first')]].forEach(function (pair) {
				var opt = make('option', '', pair[1]);
				opt.value = pair[0];
				select.appendChild(opt);
			});
			sort.appendChild(select);
			sort.appendChild(sortIcon());
			tools.appendChild(sort);
			page.appendChild(tools);

			add(page, buildChips(B + '__chips--page'));

			found = make('span', 'mvweb-om__sr ' + B + '__found');
			found.setAttribute('role', 'status');
			page.appendChild(found);

			cards = make('ul', B + '__cards');
			cards.setAttribute('role', 'list');
			page.appendChild(cards);

			empty = make('div', B + '__empty');
			empty.hidden = true;
			empty.appendChild(make('span', B + '__empty-title', t('emptyTitle', 'Nothing found')));
			emptyText = make('span', B + '__empty-text');
			empty.appendChild(emptyText);
			emptyReset = make('button', 'mvweb-om-ui__btn mvweb-om-ui__btn--outline', t('resetSearch', 'Clear search'));
			emptyReset.type = 'button';
			emptyAll = make('button', 'mvweb-om-ui__btn mvweb-om-ui__btn--outline', t('allCats', 'Search in all categories'));
			emptyAll.type = 'button';
			empty.appendChild(emptyReset);
			empty.appendChild(emptyAll);
			page.appendChild(empty);

			showMore = make('button', 'mvweb-om-ui__btn mvweb-om-ui__btn--outline ' + B + '__more', t('showMore', 'Show more'));
			showMore.type = 'button';
			showMore.hidden = true;
			page.appendChild(showMore);

			var dock = make('div', B + '__dock');
			fab = make('button', B + '__fab');
			fab.type = 'button';
			add(fab, parts.icon('map'));
			fab.appendChild(make('span', '', t('mapTab', 'Map')));
			dock.appendChild(fab);
			page.appendChild(dock);

			root.appendChild(page);

			input.addEventListener('input', function () {
				clearTimeout(timer);
				timer = setTimeout(function () {
					ctx.setQuery(input.value);
				}, SEARCH_DELAY);
			});
			select.addEventListener('change', function () {
				ctx.setSort(select.value);
			});
			emptyReset.addEventListener('click', function () {
				clearTimeout(timer);
				input.value = '';
				ctx.setQuery('');
				input.focus();
			});
			emptyAll.addEventListener('click', function () {
				ctx.setCats([]);
			});
			showMore.addEventListener('click', function () {
				var first = shown;
				fill(Math.min(objects.length, shown + PAGE));
				var btn = cards.children[first] && cards.children[first].querySelector('.' + B + '__open');
				if (btn) {
					btn.focus({ preventScroll: true });
				}
			});
			fab.addEventListener('click', expandMap);
		}

		/**
		 * Put a gallery into a card media box.
		 *
		 * @param {HTMLElement} box Media box with the object on it.
		 */
		function buildGallery(box) {
			var obj = box.mvwebOmObj;
			if (!obj || box.firstChild) {
				return;
			}
			var gal = shared.gallery(ctx, { urls: photos(obj, parts), dots: true, alt: obj.title || '' });
			box.appendChild(gal.el);
			galleries.push(gal);
		}

		/**
		 * Observer callback: build galleries of cards that come near the screen.
		 *
		 * @param {Array} entries Intersection entries.
		 */
		function onNear(entries) {
			entries.forEach(function (entry) {
				if (entry.isIntersecting) {
					observer.unobserve(entry.target);
					buildGallery(entry.target);
				}
			});
		}

		/**
		 * Build one list card.
		 *
		 * @param {Object} obj   Object data.
		 * @param {number} index Position in the list.
		 * @return {HTMLElement}
		 */
		function buildCard(obj, index) {
			var item = make('li', B + '__item');
			var box = make('div', B + '__card');
			var urls = photos(obj, parts);
			var open = function () {
				opener = btn;
				ctx.select(obj.id, 'list');
			};

			if (urls.length) {
				var mediaBox = make('div', B + '__media');
				mediaBox.mvwebOmObj = obj;
				mediaBox.addEventListener('click', function (e) {
					if (!e.target.closest('button')) {
						open();
					}
				});
				box.appendChild(mediaBox);
				if (index < EAGER || !observer) {
					buildGallery(mediaBox);
				} else {
					observer.observe(mediaBox);
					pending.push(mediaBox);
				}
			} else {
				box.classList.add(B + '__card--plain');
			}
			add(box, parts.cat(obj, ctx), B + '__badge');

			var btn = make('button', B + '__open');
			btn.type = 'button';
			btn.appendChild(make('span', B + '__name', obj.title || ''));
			if (obj.address) {
				btn.appendChild(make('span', B + '__sub', obj.address));
			}
			add(btn, parts.facts(obj, ctx, { flag: 'list' }));
			btn.addEventListener('click', open);
			box.appendChild(btn);

			item.appendChild(box);
			return item;
		}

		/**
		 * Append cards until the given count is shown.
		 *
		 * @param {number} upto Number of cards to show.
		 */
		function fill(upto) {
			var fragment = document.createDocumentFragment();
			for (var i = shown; i < upto; i++) {
				fragment.appendChild(buildCard(objects[i], i));
			}
			cards.appendChild(fragment);
			shown = Math.max(shown, upto);
			showMore.hidden = shown >= objects.length;
		}

		/**
		 * Drop the cards and their galleries.
		 */
		function clearCards() {
			galleries.forEach(function (gal) {
				gal.destroy();
			});
			galleries = [];
			if (observer) {
				pending.forEach(function (box) {
					observer.unobserve(box);
				});
			}
			pending = [];
			cards.textContent = '';
			shown = 0;
		}

		/**
		 * Write "Found: N" into the counter.
		 *
		 * @param {number} n Number of objects.
		 */
		function setFound(n) {
			found.textContent = t('found', 'Found: %d').replace('%d', String(n));
		}

		/**
		 * Draw the list for the current view.
		 */
		function render() {
			var view = ctx.view();
			objects = view.objects || [];
			syncChips(view.cats || []);
			if (!view.query && input.value.trim() && document.activeElement !== input) {
				input.value = '';
			}
			if (select.value !== view.sort) {
				select.value = 'new' === view.sort ? 'new' : 'name';
			}
			clearCards();
			fill(Math.min(objects.length, PAGE));
			setFound(objects.length);
			cards.hidden = !objects.length;
			empty.hidden = !!objects.length;
			emptyText.textContent = view.query ? t('emptyQuery', 'No objects match “%s”.').split('%s').join(view.query) : '';
			emptyText.hidden = !view.query;
			emptyReset.hidden = !view.query;
			emptyAll.hidden = !(view.cats && view.cats.length);
			if (listBtn) {
				listBtn.lastChild.textContent = t('listCount', 'List · %d').replace('%d', String(objects.length));
			}
		}

		/**
		 * Apply the phone or desktop page layout.
		 */
		function applyLayout() {
			var phone = ctx.isPhone();
			root.classList.toggle(B + '--phone', phone);
			if (!phone && mapOpen) {
				collapseMap(false);
			}
		}

		/**
		 * Fit the map to the visible objects once it has a real size.
		 */
		function fit() {
			var cfg = ctx.config || {};
			if (!needFit || !ctx.map || cfg.center || cfg.zoom || (ctx.data && ctx.data.defaultCenter) || !visible.length) {
				return;
			}
			needFit = false;
			var lngs = visible.map(function (o) { return o.lng; });
			var lats = visible.map(function (o) { return o.lat; });
			var bounds = [
				[Math.min.apply(null, lngs), Math.min.apply(null, lats)],
				[Math.max.apply(null, lngs), Math.max.apply(null, lats)]
			];
			try {
				ctx.map.update({ location: { bounds: bounds, duration: 0 } });
			} catch (err) {
				ctx.map.update({ location: { center: [lngs[0], lats[0]], zoom: 12 } });
			}
		}

		/**
		 * Reserve the chips row and the bottom controls of the full-screen map.
		 */
		function insets() {
			if (!mapOpen) {
				ctx.setInsets('fab', null);
				return;
			}
			var top = mapChips ? mapChips.offsetHeight : 0;
			var bottom = card && !card.hidden ? full.clientHeight - card.offsetTop : full.clientHeight - listBtn.offsetTop;
			ctx.setInsets('fab', { t: top, b: Math.max(0, bottom) });
		}

		/**
		 * Move the map canvas into the full-screen dialog with all gestures.
		 */
		function expandMap() {
			if (mapOpen || !full) {
				return;
			}
			mapOpen = true;
			slot.appendChild(canvas);
			full.showModal();
			ctx.lock();
			behaviors(BEHAVIORS_FULL);
			pushLayer('map');
			requestAnimationFrame(function () {
				if (!mapOpen) {
					return;
				}
				insets();
				fit();
			});
		}

		/**
		 * Return the map canvas to the page and close the full-screen map.
		 *
		 * @param {boolean} viaHistory Closed by the Back button.
		 */
		function collapseMap(viaHistory) {
			if (!mapOpen) {
				return;
			}
			mapOpen = false;
			var had = cardObj;
			hideCard();
			if (full.open) {
				full.close();
			}
			host.appendChild(canvas);
			ctx.setInsets('fab', null);
			ctx.unlock();
			if (!viaHistory) {
				popLayer('map');
			}
			cardObj = null;
			if (had) {
				ctx.select(null, 'mobile');
			}
			if (ctx.isPhone() && fab && fab.isConnected) {
				fab.focus({ preventScroll: true });
			}
		}

		/**
		 * Fill and show the short card above the List button (full-screen map).
		 *
		 * @param {Object} obj Object data.
		 */
		function showCard(obj) {
			cardObj = obj;
			card.textContent = '';
			var pic = parts.photo(obj, { size: 'thumb', eager: true, className: B + '__thumb' });
			card.classList.toggle(B + '__peek--plain', !pic);
			add(card, pic);
			var body = make('span', B + '__peek-body');
			add(body, parts.cat(obj, ctx));
			body.appendChild(make('span', B + '__name', obj.title || ''));
			if (obj.address) {
				body.appendChild(make('span', B + '__sub', obj.address));
			}
			card.appendChild(body);
			add(card, parts.icon('chev-r'));
			card.hidden = false;
			insets();
		}

		/**
		 * Hide the short card of the full-screen map.
		 */
		function hideCard() {
			if (card && !card.hidden) {
				card.hidden = true;
				card.textContent = '';
				insets();
			}
		}

		/**
		 * Close the object window on a click on the backdrop (desktop window).
		 *
		 * @param {MouseEvent} e Click.
		 */
		function onBackdrop(e) {
			if (e.target !== dlg) {
				return;
			}
			var r = dlg.getBoundingClientRect();
			if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) {
				finishObject(false);
			}
		}

		/**
		 * Build the full-screen map dialog and the object dialog.
		 */
		function buildDialogs() {
			full = make('dialog', B + '__map');
			full.setAttribute('aria-labelledby', mapTitleId);
			var mapTitle = make('span', 'mvweb-om__sr', t('mapTab', 'Map'));
			mapTitle.id = mapTitleId;
			full.appendChild(mapTitle);
			slot = make('div', B + '__slot');
			full.appendChild(slot);
			mapChips = buildChips(B + '__chips--map');
			add(full, mapChips);
			card = make('button', B + '__peek');
			card.type = 'button';
			card.hidden = true;
			card.addEventListener('click', function () {
				if (cardObj) {
					opener = card;
					show(cardObj, 'map');
				}
			});
			full.appendChild(card);
			listBtn = make('button', B + '__fab ' + B + '__fab--list');
			listBtn.type = 'button';
			add(listBtn, parts.icon('list'));
			listBtn.appendChild(make('span', '', t('listCount', 'List · %d').replace('%d', String(objects.length))));
			listBtn.addEventListener('click', function () {
				collapseMap(false);
			});
			full.appendChild(listBtn);
			full.addEventListener('close', function () {
				if (!full.open) {
					collapseMap(false);
				}
			});
			root.appendChild(full);

			dlg = make('dialog', B + '__dlg');
			dlg.setAttribute('aria-labelledby', titleId);
			var topbar = make('div', B + '__topbar');
			back = parts.iconButton('chev-l', t('backList', 'Back to the list'), function () {
				finishObject(false);
			}, 'mvweb-om-ui__icon-btn--glass ' + B + '__back');
			topbar.appendChild(back);
			tbTitle = make('span', B + '__tb-title');
			tbTitle.setAttribute('aria-hidden', 'true');
			topbar.appendChild(tbTitle);
			topbar.appendChild(parts.iconButton('close', t('close', 'Close'), closeAll, 'mvweb-om-ui__icon-btn--glass ' + B + '__close'));
			scroller = make('div', B + '__scroll');
			media = make('div', B + '__photos');
			var cols = make('div', B + '__cols');
			main = make('div', B + '__main');
			aside = make('div', B + '__aside');
			cols.appendChild(main);
			cols.appendChild(aside);
			scroller.appendChild(media);
			scroller.appendChild(cols);
			dlg.appendChild(topbar);
			dlg.appendChild(scroller);
			dlg.addEventListener('click', onBackdrop);
			dlg.addEventListener('close', function () {
				if (!dlg.open) {
					finishObject(false);
				}
			});
			root.appendChild(dlg);
		}

		/**
		 * Fill the object dialog with an object.
		 *
		 * @param {Object} obj Object data.
		 * @return {Object} Gallery instance.
		 */
		function fillObject(obj) {
			var gal = shared.gallery(ctx, { urls: photos(obj, parts), counter: true, thumbs: true, alt: obj.title || '' });
			media.textContent = '';
			if (gal.count) {
				media.appendChild(gal.el);
			}
			dlg.classList.toggle(B + '__dlg--plain', !gal.count);
			dlg.classList.toggle(B + '__dlg--single', 1 === gal.count);

			main.textContent = '';
			var head = make('div', B + '__head');
			add(head, parts.cat(obj, ctx));
			var title = parts.title(obj, B + '__title');
			title.id = titleId;
			head.appendChild(title);
			add(head, parts.rows(obj, ctx, { phone: false, hours: false }));
			main.appendChild(head);

			var figures = keyFigures(obj, ctx);
			if (figures.length) {
				var list = make('ul', B + '__figures');
				figures.forEach(function (s) {
					var li = make('li', '');
					li.appendChild(make('b', '', s.value));
					li.appendChild(make('span', '', s.label || ''));
					list.appendChild(li);
				});
				main.appendChild(list);
			}
			if (obj.excerpt) {
				main.appendChild(make('p', B + '__excerpt', obj.excerpt));
			}
			add(main, parts.rows(obj, ctx, { address: false }), B + '__meta');
			var specs = parts.specs(obj, ctx, {});
			if (specs) {
				main.appendChild(make('div', B + '__label', t('specs', 'Characteristics')));
				main.appendChild(specs);
			}
			add(main, parts.links(obj));
			if (obj.moreUrl && parts.isSafeUrl(obj.moreUrl)) {
				var more = make('a', 'mvweb-om-ui__btn mvweb-om-ui__btn--outline ' + B + '__more-link');
				more.setAttribute('href', obj.moreUrl);
				more.setAttribute('target', '_blank');
				more.setAttribute('rel', 'noopener noreferrer');
				more.appendChild(make('span', '', t('more', 'More details')));
				add(more, parts.icon('arrow', 'sm'));
				main.appendChild(more);
			}

			aside.textContent = '';
			var acts = parts.actions(obj, ctx, { more: false, primary: obj.phone ? 'call' : 'route' });
			aside.hidden = !acts;
			if (acts) {
				aside.appendChild(make('div', B + '__aside-title', t('contact', 'Contact')));
				aside.appendChild(acts);
			}

			tbTitle.textContent = obj.title || '';
			scroller.scrollTop = 0;
			return gal;
		}

		/**
		 * Open the object dialog, or swap its content when it is already open.
		 *
		 * @param {Object} obj    Object data.
		 * @param {string} origin list, map or pc.
		 */
		function show(obj, origin) {
			if (!dlg || !obj) {
				return;
			}
			var label = 'map' === origin ? t('backMap', 'Back to the map') : t('backList', 'Back to the list');
			back.setAttribute('title', label);
			back.querySelector('.mvweb-om__sr').textContent = label;
			if (current) {
				current.gallery.destroy();
				current.gallery = fillObject(obj);
				current.id = obj.id;
				current.origin = origin;
				opener = null;
				return;
			}
			ctx.focus.remember(opener || undefined);
			opener = null;
			current = { id: obj.id, origin: origin, gallery: fillObject(obj), pushed: false };
			dlg.showModal();
			ctx.lock();
			current.pushed = pushLayer('object');
		}

		/**
		 * Close the object dialog and clean up.
		 *
		 * @param {boolean} viaHistory Closed by the Back button.
		 * @param {boolean} silent     Closed by the core: keep the selection as it is.
		 */
		function finishObject(viaHistory, silent) {
			if (!current) {
				return;
			}
			var done = current;
			current = null;
			if (dlg.open) {
				dlg.close();
			}
			done.gallery.destroy();
			ctx.unlock();
			if (done.pushed && !viaHistory) {
				popLayer('object');
			}
			ctx.focus.restore();
			if (!silent && 'map' !== done.origin) {
				ctx.select(null, 'mobile');
			}
		}

		/**
		 * Close button of the object page: back to the page with the list, the
		 * full-screen map included when the object was opened from it.
		 */
		function closeAll() {
			if (!current || 'map' !== current.origin || !mapOpen) {
				finishObject(false);
				return;
			}
			var steps = 0;
			['object', 'map'].forEach(function (name) {
				var at = layers.lastIndexOf(name);
				if (at !== -1) {
					layers.splice(at, 1);
					steps++;
				}
			});
			if (steps) {
				skipPop++;
				history.go(-steps);
			}
			finishObject(true);
			collapseMap(true);
		}

		return {
			minMap: null,

			/**
			 * Build the page list and both dialogs and apply the layout.
			 */
			mount: function () {
				host = root.querySelector('.mvweb-om__map');
				canvas = root.querySelector('.mvweb-om__canvas');
				if (!host || !canvas) {
					throw new Error('mobile/fab: no map container');
				}
				if ('IntersectionObserver' in window) {
					observer = new IntersectionObserver(onNear, { rootMargin: '400px 0px' });
				}
				buildPage();
				buildDialogs();
				render();

				handlers.filter = render;
				handlers.select = function (p) {
					lastSource = p.source;
				};
				handlers.deselect = function () {
					hideCard();
					cardObj = null;
				};
				handlers.visible = function (p) {
					visible = (p && p.objects) || ctx.objects || [];
					needFit = !mapOpen;
				};
				Object.keys(handlers).forEach(function (name) {
					ctx.on(name, handlers[name]);
				});
				canvas.addEventListener('touchend', keepDrag, { passive: true });
				canvas.addEventListener('touchcancel', keepDrag, { passive: true });
				window.addEventListener('popstate', onPop);
				phoneQuery.addEventListener('change', applyLayout);
				applyLayout();
			},

			/**
			 * Phone: a marker in the full-screen map shows the short card, any
			 * other selection opens the object page.
			 *
			 * @param {Object} obj Object data.
			 */
			open: function (obj) {
				if (mapOpen && 'marker' === lastSource && !current) {
					showCard(obj);
					return;
				}
				show(obj, mapOpen ? 'map' : 'list');
			},

			/**
			 * Desktop: open the almost full-screen object window.
			 *
			 * @param {Object} obj Object data.
			 */
			detailPc: function (obj) {
				show(obj, 'pc');
			},

			/**
			 * Close the object window and the short card (called by the core).
			 */
			close: function () {
				finishObject(false, true);
				hideCard();
				cardObj = null;
			},

			/**
			 * Remove everything this module added.
			 */
			destroy: function () {
				clearTimeout(timer);
				finishObject(true, true);
				collapseMap(true);
				if (observer) {
					observer.disconnect();
				}
				galleries.forEach(function (gal) {
					gal.destroy();
				});
				galleries = [];
				Object.keys(handlers).forEach(function (name) {
					ctx.off(name, handlers[name]);
				});
				canvas.removeEventListener('touchend', keepDrag, { passive: true });
				canvas.removeEventListener('touchcancel', keepDrag, { passive: true });
				window.removeEventListener('popstate', onPop);
				phoneQuery.removeEventListener('change', applyLayout);
				[page, full, dlg].forEach(function (el) {
					if (el && el.parentNode) {
						el.parentNode.removeChild(el);
					}
				});
				root.classList.remove(B + '--phone');
				chipRows = [];
				layers = [];
			}
		};
	});
})();
