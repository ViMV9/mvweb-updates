/**
 * Balloon variant "hint": a dark tooltip that expands into a card.
 *
 * Desktop: hovering a marker shows a tooltip with the title and the first
 * characteristic flagged for the marker. A click expands it into a card next
 * to the marker; the cross collapses the card back into the tooltip. Phone or
 * a narrow map: the first tap shows the tooltip, the second one (or a tap on
 * the tooltip) opens the card in a bottom sheet.
 *
 * The tooltip and the card live in their own map markers at the object
 * coordinates, so the map moves them itself.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var BLOCK = 'mvweb-om-balloon-hint';
	var OWNER = 'balloon';
	var NARROW = 560;
	var EDGE = 12;
	var EDGE_BOTTOM = 36;
	var GAP_X = 20;
	var LIFT_Y = 20;
	var Z = 1000000;
	var PHOTOS = 3;
	var CLICK_SLOP = 6;
	var FLY_WAIT = 360;
	var HOVER_QUERY = '(hover: hover)';
	var MOTION_QUERY = '(prefers-reduced-motion: reduce)';
	var SHIELD = ['pointerdown', 'mousedown', 'touchstart', 'wheel', 'dblclick', 'click', 'contextmenu'];

	var uid = 0;

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		if (cls) {
			el.className = cls;
		}
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * Whether a media query matches.
	 *
	 * @param {string} query Media query.
	 * @return {boolean}
	 */
	function matches(query) {
		return !!window.matchMedia && window.matchMedia(query).matches;
	}

	/**
	 * Keep map gestures off an element that sits inside a map marker.
	 *
	 * @param {HTMLElement} el Element.
	 */
	function shield(el) {
		SHIELD.forEach(function (name) {
			el.addEventListener(name, function (e) {
				e.stopPropagation();
			}, 'wheel' === name || 'touchstart' === name ? { passive: true } : false);
		});
	}

	/**
	 * Mercator Y of a latitude.
	 *
	 * @param {number} lat Latitude in degrees.
	 * @return {number}
	 */
	function mercY(lat) {
		return Math.log(Math.tan(Math.PI / 4 + lat * Math.PI / 360));
	}

	/**
	 * Latitude of a Mercator Y.
	 *
	 * @param {number} y Mercator Y.
	 * @return {number}
	 */
	function mercLat(y) {
		return (2 * Math.atan(Math.exp(y)) - Math.PI / 2) * 180 / Math.PI;
	}

	api.register('balloon', 'hint', function (ctx) {
		var shared = api.shared || {};
		var parts = shared.parts;
		if (!parts || typeof shared.sheet !== 'function' || typeof ymaps3 === 'undefined' || !ymaps3.YMapMarker) {
			return null;
		}

		var i18n = ctx.i18n || {};
		var host = ctx.root.querySelector('.mvweb-om__map') || ctx.root;
		var canvas = ctx.root.querySelector('.mvweb-om__canvas') || host;

		var current = null;
		var state = '';
		var source = '';
		var tip = null;
		var sel = null;
		var sheet = null;
		var closing = false;
		var press = null;
		var frame = 0;
		var fitTimer = 0;

		/**
		 * The characteristic shown in the tooltip: the first spec with a value
		 * whose schema field carries the marker flag.
		 *
		 * @param {Object} obj Object data.
		 * @return {Object|null} Spec row.
		 */
		function tipSpec(obj) {
			var ids = {};
			(ctx.schema || []).forEach(function (field) {
				if (field.show && field.show.indexOf('marker') !== -1) {
					ids[field.id] = true;
				}
			});
			var found = null;
			(obj.specs || []).some(function (spec) {
				if (undefined !== spec.id && ids[spec.id] === true && spec.value) {
					found = spec;
				}
				return !!found;
			});
			return found;
		}

		/**
		 * Fill an element with the title and the tooltip value of an object.
		 *
		 * @param {HTMLElement} el  Container.
		 * @param {Object}      obj Object data.
		 */
		function label(el, obj) {
			var spec = tipSpec(obj);
			el.appendChild(make('span', BLOCK + '__name', obj.title || ''));
			if (spec) {
				el.appendChild(make('span', BLOCK + '__area', spec.value));
			}
		}

		/**
		 * Whether the card goes into the bottom sheet.
		 *
		 * @return {boolean}
		 */
		function useSheet() {
			return ctx.isPhone() || host.clientWidth < NARROW;
		}

		/**
		 * Ask the core to clear the selection (it closes this module).
		 */
		function dismiss() {
			if (current) {
				ctx.select(null);
			}
		}

		/**
		 * Place an element in a map marker at the object coordinates.
		 *
		 * @param {Object}      obj Object data.
		 * @param {HTMLElement} el  Marker content.
		 * @param {number}      z   Stacking order.
		 * @return {Object} { marker, el }
		 */
		function pin(obj, el, z) {
			var marker = new ymaps3.YMapMarker({ coordinates: [obj.lng, obj.lat], zIndex: z }, el);
			ctx.map.addChild(marker);
			return { marker: marker, el: el };
		}

		/**
		 * Remove a placed marker.
		 *
		 * @param {Object|null} item Result of pin().
		 */
		function unpin(item) {
			if (item && ctx.map) {
				try {
					ctx.map.removeChild(item.marker);
				} catch (err) {
					return;
				}
			}
		}

		/**
		 * Offsets of the marker drawn for an object, measured from the point.
		 *
		 * @param {HTMLElement} anchor Zero-size element at the object point.
		 * @param {string}      cls    State class of the marker: hover or selected.
		 * @return {Object} { lift, gap, gapLeft, top } in px.
		 */
		function markerBox(anchor, cls) {
			var out = { lift: 16, gap: GAP_X, gapLeft: GAP_X, top: -LIFT_Y };
			var el = ctx.root.querySelector('.mvweb-om__marker--' + cls);
			if (!el || !anchor.isConnected) {
				return out;
			}
			var a = anchor.getBoundingClientRect();
			var m = el.getBoundingClientRect();
			m = { left: m.left, top: m.top, right: m.right, bottom: m.bottom, width: m.width };
			Array.prototype.forEach.call(el.querySelectorAll('*'), function (node) {
				var r = node.getBoundingClientRect();
				if (r.width && r.height) {
					m.left = Math.min(m.left, r.left);
					m.top = Math.min(m.top, r.top);
					m.right = Math.max(m.right, r.right);
					m.bottom = Math.max(m.bottom, r.bottom);
				}
			});
			m.width = m.right - m.left;
			if (!m.width || a.left < m.left - 8 || a.left > m.right + 8 || m.top > a.top + 24 || m.bottom < a.top - 24) {
				return out;
			}
			out.lift = Math.max(8, Math.round(a.top - m.top + 6));
			out.gap = Math.max(GAP_X, Math.round(m.right - a.left + 8));
			out.gapLeft = Math.max(GAP_X, Math.round(a.left - m.left + 8));
			out.top = Math.min(-LIFT_Y, Math.round(m.top - a.top - 4));
			return out;
		}

		/**
		 * Keep a tooltip or a pill inside the map: shift it sideways at the
		 * left and right edges, put it under the marker at the top edge.
		 *
		 * @param {HTMLElement} el Tooltip or pill.
		 */
		function nudge(el) {
			el.style.removeProperty('--mvweb-om-balloon-hint-shift');
			el.classList.remove(BLOCK + '__below');
			if (!el.isConnected || !el.offsetWidth) {
				return;
			}
			var r = el.getBoundingClientRect();
			var h = host.getBoundingClientRect();
			var shift = 0;
			if (r.top < h.top + EDGE) {
				el.classList.add(BLOCK + '__below');
			}
			if (r.left < h.left + EDGE) {
				shift = h.left + EDGE - r.left;
			} else if (r.right > h.right - EDGE) {
				shift = h.right - EDGE - r.right;
			}
			if (shift) {
				el.style.setProperty('--mvweb-om-balloon-hint-shift', Math.round(shift) + 'px');
			}
		}

		/**
		 * Run a callback once an element is in the document.
		 *
		 * @param {HTMLElement} el Element.
		 * @param {Function}    fn Callback.
		 */
		function whenMounted(el, fn) {
			var tries = 0;
			var step = function () {
				if (el.isConnected || ++tries > 10) {
					fn();
				} else {
					requestAnimationFrame(step);
				}
			};
			step();
		}

		/**
		 * Show the hover tooltip of an object.
		 *
		 * @param {Object} obj Object data.
		 */
		function showTip(obj) {
			hideTip();
			var anchor = make('div', BLOCK + '__anchor ' + BLOCK + '__anchor--tip');
			var bubble = make('div', BLOCK + '__tip');
			bubble.setAttribute('aria-hidden', 'true');
			label(bubble, obj);
			anchor.appendChild(bubble);
			tip = pin(obj, anchor, Z + 2);
			tip.id = obj.id;
			whenMounted(anchor, function () {
				if (!tip || tip.el !== anchor) {
					return;
				}
				anchor.style.setProperty('--mvweb-om-balloon-hint-lift', markerBox(anchor, 'hover').lift + 'px');
				nudge(bubble);
				anchor.classList.add(BLOCK + '__anchor--on');
			});
		}

		/**
		 * Remove the hover tooltip.
		 */
		function hideTip() {
			unpin(tip);
			tip = null;
		}

		/**
		 * Build the card of an object.
		 *
		 * @param {Object}  obj     Object data.
		 * @param {boolean} inSheet Whether the card goes into the sheet.
		 * @return {HTMLElement}
		 */
		function buildCard(obj, inSheet) {
			var urls = parts.photoUrls(obj).slice(0, PHOTOS);
			var card = make(inSheet ? 'div' : 'article', BLOCK + '__card' + (urls.length ? '' : ' ' + BLOCK + '__card--bare') + (inSheet ? ' ' + BLOCK + '__card--sheet' : ''));
			var head = make('div', BLOCK + '__head');
			var title = make('div', BLOCK + '__title', obj.title || '');
			var spec = tipSpec(obj);
			var titleId = BLOCK + '-title-' + (++uid);

			title.id = titleId;
			title.setAttribute('data-sheet-title', '');
			head.appendChild(title);
			if (spec) {
				head.appendChild(make('span', BLOCK + '__area', spec.value));
			}
			head.appendChild(parts.close(i18n.collapse || 'Collapse', collapse, BLOCK + '__close'));
			card.appendChild(head);

			if (urls.length) {
				var mosaic = make('div', BLOCK + '__mosaic ' + BLOCK + '__mosaic--n' + urls.length);
				urls.forEach(function (url, index) {
					var img = make('img', BLOCK + '__photo');
					img.setAttribute('src', url);
					img.setAttribute('alt', index ? '' : (obj.title || ''));
					img.setAttribute('decoding', 'async');
					if (index) {
						img.setAttribute('loading', 'lazy');
					}
					mosaic.appendChild(img);
				});
				card.appendChild(mosaic);
			}

			var body = make('div', BLOCK + '__body');
			var cat = parts.cat(obj, ctx);
			if (cat) {
				body.appendChild(cat);
			}
			var address = parts.rows(obj, ctx, { phone: false, hours: false });
			if (address) {
				body.appendChild(address);
			}
			if (obj.excerpt) {
				body.appendChild(make('p', BLOCK + '__excerpt', obj.excerpt));
			}
			var specs = parts.specs(obj, ctx, { flag: 'balloon' });
			if (specs && spec) {
				Array.prototype.slice.call(specs.children).forEach(function (item) {
					if (item.firstChild.textContent === spec.label && item.lastChild.textContent === spec.value) {
						specs.removeChild(item);
					}
				});
			}
			if (specs && specs.children.length) {
				specs.classList.add(BLOCK + '__specs');
				body.appendChild(specs);
			}
			var meta = parts.rows(obj, ctx, { address: false });
			if (meta) {
				meta.classList.add(BLOCK + '__meta');
				body.appendChild(meta);
			}
			var links = parts.links(obj);
			if (links) {
				body.appendChild(links);
			}
			if (body.childNodes.length) {
				card.appendChild(body);
			}

			var actions = parts.actions(obj, ctx, { call: false });
			if (actions) {
				actions.classList.add(BLOCK + '__actions');
				card.appendChild(actions);
			}
			card.setAttribute('data-title-id', titleId);
			return card;
		}

		/**
		 * Build the pill that stands for the collapsed card.
		 *
		 * @param {Object} obj Object data.
		 * @return {HTMLButtonElement}
		 */
		function buildPill(obj) {
			var pill = make('button', BLOCK + '__pill');
			var chev = parts.icon('chev-r', 'sm');
			pill.type = 'button';
			pill.setAttribute('aria-expanded', 'false');
			pill.setAttribute('title', i18n.expand || 'Expand');
			label(pill, obj);
			if (chev) {
				pill.appendChild(chev);
			}
			pill.addEventListener('click', function () {
				if (current) {
					expand(true);
				}
			});
			pill.addEventListener('keydown', function (e) {
				if ('Escape' === e.key) {
					e.stopPropagation();
					dismiss();
				}
			});
			return pill;
		}

		/**
		 * Mount the marker that holds the pill and the card of the current object.
		 */
		function mountSel() {
			if (sel && sel.id === current.id) {
				return;
			}
			unmountSel();
			var anchor = make('div', BLOCK + '__anchor ' + BLOCK + '__anchor--sel');
			var pill = buildPill(current);
			anchor.setAttribute('data-state', 'pill');
			anchor.appendChild(pill);
			shield(anchor);
			sel = pin(current, anchor, Z);
			sel.id = current.id;
			sel.pill = pill;
			sel.card = null;
			whenMounted(anchor, function () {
				if (!sel || sel.el !== anchor) {
					return;
				}
				anchor.style.setProperty('--mvweb-om-balloon-hint-lift', markerBox(anchor, 'selected').lift + 'px');
				nudge(pill);
				anchor.classList.add(BLOCK + '__anchor--on');
			});
		}

		/**
		 * Remove the pill and the card marker.
		 */
		function unmountSel() {
			clearTimeout(fitTimer);
			unpin(sel);
			sel = null;
		}

		/**
		 * Whether focus is inside the card, the pill or the sheet.
		 *
		 * @return {boolean}
		 */
		function hasFocus() {
			var active = document.activeElement;
			return !!active && ((sel && sel.el.contains(active)) || (sheet && sheet.el.contains(active)));
		}

		/**
		 * Move the map content by a number of pixels.
		 *
		 * @param {number} dx Right, px.
		 * @param {number} dy Down, px.
		 */
		function panBy(dx, dy) {
			var map = ctx.map;
			var center = map && map.center;
			if (!center || (!dx && !dy)) {
				return;
			}
			var w = canvas.clientWidth || 1;
			var h = canvas.clientHeight || 1;
			var b = map.bounds;
			var lngPx;
			var yPx;
			if (b && b[0] && b[1]) {
				lngPx = Math.abs(b[1][0] - b[0][0]) / w;
				yPx = Math.abs(mercY(b[0][1]) - mercY(b[1][1])) / h;
			} else {
				lngPx = 360 / (256 * Math.pow(2, map.zoom || 10));
				yPx = lngPx * Math.PI / 180;
			}
			ctx.flyTo({ lng: center[0] - dx * lngPx, lat: mercLat(mercY(center[1]) + dy * yPx) }, { duration: matches(MOTION_QUERY) ? 0 : 300 });
		}

		/**
		 * Choose the card side and height, and pan the map when the card does
		 * not fit next to the marker.
		 */
		function fit() {
			if (!sel || !sel.card || !sel.el.isConnected) {
				return;
			}
			var anchor = sel.el;
			var card = sel.card;
			var a = anchor.getBoundingClientRect();
			var hr = host.getBoundingClientRect();
			var ins = ctx.insets(OWNER);
			var box = markerBox(anchor, 'selected');
			var area = {
				l: ins.l + EDGE,
				t: ins.t + EDGE,
				r: hr.width - ins.r - EDGE,
				b: hr.height - ins.b - EDGE_BOTTOM
			};
			var x = a.left - hr.left;
			var y = a.top - hr.top;
			var dx = 0;
			var dy = 0;

			anchor.style.setProperty('--mvweb-om-balloon-hint-gap', box.gap + 'px');
			anchor.style.setProperty('--mvweb-om-balloon-hint-gap-left', box.gapLeft + 'px');
			anchor.style.setProperty('--mvweb-om-balloon-hint-top', box.top + 'px');
			card.style.removeProperty('--mvweb-om-balloon-hint-max');
			var cw = card.offsetWidth;
			var ch = card.scrollHeight;
			var left = x + box.gap + cw > area.r && x - box.gapLeft - cw >= area.l;
			if (!left && x + box.gap + cw > area.r) {
				dx = area.r - (x + box.gap + cw);
			}
			if (!left && x - box.gapLeft + dx < area.l) {
				dx = area.l - x + box.gapLeft;
			}
			var top = y + box.top;
			var room = area.b - area.t;
			if (top < area.t) {
				dy = area.t - top;
			} else if (top + Math.min(ch, room) > area.b) {
				dy = Math.max(area.t - top, area.b - top - Math.min(ch, room));
			}
			card.classList.toggle(BLOCK + '__card--left', left);
			card.style.setProperty('--mvweb-om-balloon-hint-max', Math.max(160, Math.floor(area.b - (top + dy))) + 'px');
			panBy(Math.round(dx), Math.round(dy));
		}

		/**
		 * Show the current object in the card next to its marker.
		 *
		 * @param {boolean} focus Move focus into the card.
		 */
		function openCard(focus) {
			mountSel();
			var anchor = sel.el;
			if (!sel.card) {
				var card = buildCard(current, false);
				card.setAttribute('role', 'dialog');
				card.setAttribute('tabindex', '-1');
				card.setAttribute('aria-labelledby', card.getAttribute('data-title-id'));
				card.addEventListener('keydown', function (e) {
					if ('Escape' === e.key) {
						e.stopPropagation();
						dismiss();
					}
				});
				anchor.appendChild(card);
				sel.card = card;
			}
			anchor.setAttribute('data-state', 'card');
			sel.pill.setAttribute('aria-expanded', 'true');
			var fromList = source && 'marker' !== source && 'api' !== source && 'balloon' !== source;
			whenMounted(anchor, function () {
				if (!sel || sel.el !== anchor) {
					return;
				}
				if (fromList) {
					clearTimeout(fitTimer);
					fitTimer = setTimeout(fit, FLY_WAIT);
				} else {
					fit();
				}
				if (focus) {
					sel.card.focus({ preventScroll: true });
				}
			});
		}

		/**
		 * Lazily create the bottom sheet.
		 *
		 * @return {Object} Sheet API.
		 */
		function getSheet() {
			if (!sheet) {
				sheet = shared.sheet(ctx, {
					host: host,
					owner: OWNER,
					positions: ['open'],
					initial: 'open',
					modal: false,
					onClose: function () {
						if (!closing) {
							dismiss();
						}
					}
				});
				sheet.el.classList.add(BLOCK + '__sheet');
			}
			return sheet;
		}

		/**
		 * Show the current object in the bottom sheet.
		 */
		function openSheet() {
			var s = getSheet();
			while (s.body.firstChild) {
				s.body.removeChild(s.body.firstChild);
			}
			s.body.appendChild(buildCard(current, true));
			s.body.scrollTop = 0;
			s.relabel();
			s.open('open');
			if (sel) {
				sel.el.setAttribute('data-state', 'hidden');
				sel.pill.setAttribute('aria-expanded', 'true');
			}
			ctx.flyTo(current, null);
		}

		/**
		 * Close the sheet without clearing the selection.
		 */
		function closeSheet() {
			if (sheet && sheet.position()) {
				closing = true;
				sheet.close();
				closing = false;
			}
		}

		/**
		 * Expand the current object: card on desktop, sheet on a phone.
		 *
		 * @param {boolean} focus Move focus into the card.
		 */
		function expand(focus) {
			if (!hasFocus()) {
				ctx.focus.remember();
			}
			hideTip();
			if (useSheet()) {
				mountSel();
				state = 'sheet';
				openSheet();
			} else {
				closeSheet();
				state = 'card';
				openCard(focus);
			}
		}

		/**
		 * Collapse the card or the sheet back into the pill at the marker.
		 */
		function collapse() {
			if (!current) {
				return;
			}
			closeSheet();
			mountSel();
			if (sel.card) {
				sel.el.removeChild(sel.card);
				sel.card = null;
			}
			clearTimeout(fitTimer);
			sel.el.setAttribute('data-state', 'pill');
			sel.pill.setAttribute('aria-expanded', 'false');
			state = 'pill';
			nudge(sel.pill);
			sel.pill.focus({ preventScroll: true });
		}

		/**
		 * Open an object. On a phone the first tap on a marker shows the pill,
		 * the second one expands it.
		 *
		 * @param {Object} obj Object data.
		 */
		function open(obj) {
			if (!obj) {
				return;
			}
			var same = current && String(current.id) === String(obj.id);
			var phoneTap = 'marker' === source && (ctx.isPhone() || !matches(HOVER_QUERY));
			if (!same) {
				closeSheet();
				unmountSel();
			}
			current = obj;
			if (phoneTap && !(same && 'pill' === state)) {
				hideTip();
				mountSel();
				state = 'pill';
			} else {
				expand(!phoneTap);
			}
			source = '';
		}

		/**
		 * Close everything. Safe to call when nothing is open.
		 */
		function close() {
			if (!current && !sel && !state) {
				return;
			}
			var refocus = hasFocus();
			current = null;
			state = '';
			closeSheet();
			unmountSel();
			if (refocus) {
				ctx.focus.restore();
			}
		}

		var onSelect = function (e) {
			source = (e && e.source) || '';
		};
		var onDeselect = function () {
			close();
		};
		var onHover = function (e) {
			var obj = e && e.obj;
			if (!obj || !matches(HOVER_QUERY) || ctx.isPhone() || (current && String(current.id) === String(obj.id) && state)) {
				hideTip();
				return;
			}
			if (!tip || String(tip.id) !== String(obj.id)) {
				showTip(obj);
			}
		};
		var onPointerDown = function (e) {
			press = { x: e.clientX, y: e.clientY };
		};
		var onCanvasClick = function (e) {
			var p = press;
			press = null;
			if (!current || !p || Math.abs(e.clientX - p.x) > CLICK_SLOP || Math.abs(e.clientY - p.y) > CLICK_SLOP) {
				return;
			}
			if (e.target.closest && e.target.closest('a, button, [role="button"], [class*="cluster"], .' + BLOCK + '__anchor')) {
				return;
			}
			dismiss();
		};
		var onResize = function () {
			if (frame) {
				return;
			}
			frame = requestAnimationFrame(function () {
				frame = 0;
				if (!current) {
					return;
				}
				if ('card' === state && useSheet()) {
					expand(hasFocus());
				} else if ('sheet' === state && !useSheet()) {
					expand(hasFocus());
				} else if ('card' === state) {
					fit();
				}
			});
		};

		ctx.on('select', onSelect);
		ctx.on('deselect', onDeselect);
		ctx.on('hover', onHover);
		canvas.addEventListener('pointerdown', onPointerDown, true);
		canvas.addEventListener('click', onCanvasClick);
		window.addEventListener('resize', onResize);

		return {
			minMap: { width: 280, height: 260 },
			open: open,
			close: close,
			destroy: function () {
				close();
				hideTip();
				ctx.off('select', onSelect);
				ctx.off('deselect', onDeselect);
				ctx.off('hover', onHover);
				canvas.removeEventListener('pointerdown', onPointerDown, true);
				canvas.removeEventListener('click', onCanvasClick);
				window.removeEventListener('resize', onResize);
				if (frame) {
					cancelAnimationFrame(frame);
					frame = 0;
				}
				if (sheet) {
					sheet.destroy();
					sheet = null;
				}
			}
		};
	});
})();
