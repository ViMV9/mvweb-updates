/**
 * Marker variant "label": a small category dot with the object name next to
 * it. Names that would overlap their neighbours are hidden in one pass after
 * the map stops; the cluster is a donut of category shares.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var COLOR = /^#[0-9a-f]{3,8}$/i;
	var B = 'mvweb-om-marker-label';
	var SETTLE = 150;
	var SLICES = 5;
	var GAP = 11;
	var SHIFT = 8;
	var DOT = 7;
	var DOT_SELECTED = 14;
	var IMG = 12;
	var EDGE = 4;

	/**
	 * Whether a URL is safe to place into src (http(s) or root-relative).
	 *
	 * @param {string} url URL to test.
	 * @return {boolean}
	 */
	function isSafeUrl(url) {
		if (typeof url !== 'string') {
			return false;
		}
		var s = url.trim().toLowerCase();
		return s.indexOf('http://') === 0 || s.indexOf('https://') === 0 || s.indexOf('/') === 0;
	}

	/**
	 * Readable icon color on top of a category color (WCAG relative luminance,
	 * same rule as the accent ink in PHP).
	 *
	 * @param {string} hex Background color, #rgb, #rgba, #rrggbb or #rrggbbaa.
	 * @return {string} '#ffffff' or '#111827'.
	 */
	function inkFor(hex) {
		var h = hex.replace('#', '');
		if (h.length < 6) {
			h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
		}
		var lum = 0;
		[0.2126, 0.7152, 0.0722].forEach(function (weight, i) {
			var c = parseInt(h.substr(i * 2, 2), 16) / 255;
			c = c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
			lum += weight * c;
		});
		return lum > 0.179 ? '#111827' : '#ffffff';
	}

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		el.className = cls;
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * The object's first category from the payload.
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} ctx Map context.
	 * @return {Object|null}
	 */
	function firstCategory(obj, ctx) {
		var slug = (obj.categories || [])[0];
		var found = null;
		(ctx.categories || []).some(function (cat) {
			if (cat.slug === slug) {
				found = cat;
			}
			return !!found;
		});
		return found;
	}

	/**
	 * Icon shown inside the selected dot: object preset, category icon, home.
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} ctx Map context.
	 * @return {Element|null}
	 */
	function dotIcon(obj, ctx) {
		var cat = firstCategory(obj, ctx);
		var preset = (obj.icon || {}).preset;
		var svg = (preset && ctx.icon(preset)) || (cat && cat.icon && ctx.icon(cat.icon)) || ctx.icon('home');
		if (svg) {
			svg.setAttribute('class', 'mvweb-om-ui__icon ' + B + '__ico');
		}
		return svg;
	}

	/**
	 * Whether two boxes intersect.
	 *
	 * @param {Object} a Box { l, t, r, b }.
	 * @param {Object} b Box { l, t, r, b }.
	 * @return {boolean}
	 */
	function hits(a, b) {
		return a.l < b.r && a.r > b.l && a.t < b.b && a.b > b.t;
	}

	/**
	 * Whether a box intersects any box of the list.
	 *
	 * @param {Object} box  Box to test.
	 * @param {Array}  list Placed boxes.
	 * @param {Object} own  Box of the marker itself, skipped.
	 * @return {boolean}
	 */
	function hitsAny(box, list, own) {
		for (var i = 0; i < list.length; i++) {
			if (list[i] !== own && hits(box, list[i])) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Conic gradient of category shares in a cluster: up to five colors by
	 * size, the rest as one "other" slice.
	 *
	 * @param {Array}  features Clustered features.
	 * @param {Object} ctx      Map context.
	 * @return {string}
	 */
	function donut(features, ctx) {
		var colors = Object.create(null);
		(ctx.categories || []).forEach(function (cat) {
			if (COLOR.test(cat.color || '')) {
				colors[cat.slug] = cat.color;
			}
		});
		var counts = Object.create(null);
		var groups = [];
		features.forEach(function (f) {
			var slug = ((f.properties.obj || {}).categories || [])[0];
			var key = slug && colors[slug] ? slug : '';
			if (!(key in counts)) {
				counts[key] = { color: key ? colors[key] : 'var(--mvweb-om-accent)', n: 0 };
				groups.push(counts[key]);
			}
			counts[key].n++;
		});
		groups.sort(function (a, b) {
			return b.n - a.n;
		});
		if (groups.length > SLICES) {
			var rest = 0;
			groups.slice(SLICES).forEach(function (g) {
				rest += g.n;
			});
			groups = groups.slice(0, SLICES).concat({ color: 'var(--mvweb-om-ink-dim)', n: rest });
		}
		var total = features.length || 1;
		var acc = 0;
		var stops = groups.map(function (g) {
			var from = acc / total * 100;
			acc += g.n;
			return g.color + ' ' + from.toFixed(2) + '% ' + (acc / total * 100).toFixed(2) + '%';
		});
		return 'conic-gradient(' + stops.join(', ') + ')';
	}

	/**
	 * Make a cluster element reachable from the keyboard.
	 *
	 * @param {HTMLElement} el    Cluster element.
	 * @param {number}      count Objects in the cluster.
	 * @param {Object}      ctx   Map context.
	 */
	function clusterA11y(el, count, ctx) {
		var label = (ctx.i18n.clusterLabel || 'Objects: %d. Zoom in').replace('%d', String(count));
		el.appendChild(make('span', 'mvweb-om__sr', label));
		el.setAttribute('role', 'button');
		el.setAttribute('tabindex', '0');
		el.setAttribute('title', label);
		el.addEventListener('keydown', function (e) {
			if ('Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key) {
				e.preventDefault();
				e.stopPropagation();
				el.click();
			}
		});
	}

	api.register('marker', 'label', function (ctx) {
		var els = Object.create(null);
		var objs = Object.create(null);
		var order = Object.create(null);
		var clusters = [];
		var selectedId = null;
		var moving = false;
		var timer = 0;
		var frame = 0;
		var lineH = 0;

		(ctx.objects || []).forEach(function (obj, i) {
			order[String(obj.id)] = i;
		});

		/**
		 * Show or hide names so that no two of them overlap: all reads, then
		 * the layout, then all writes. Selected and hovered names go first;
		 * a hidden name still shows while its marker is hovered (CSS).
		 */
		function layout() {
			frame = 0;
			var canvas = ctx.root.querySelector('.mvweb-om__canvas') || ctx.root;
			var area = canvas.getBoundingClientRect();
			var items = [];
			var obstacles = [];

			Object.keys(els).forEach(function (id) {
				var el = els[id];
				if (!el.isConnected) {
					delete els[id];
					return;
				}
				var selected = el.classList.contains('mvweb-om__marker--selected');
				var text = el.mvwebOmLabel;
				var r = el.getBoundingClientRect();
				var w = selected ? 0 : (el.mvwebOmW || 0);
				var h = lineH;
				if (!w) {
					w = text.offsetWidth;
					if (!selected) {
						el.mvwebOmW = w;
					}
				}
				if (!h || selected) {
					h = text.offsetHeight;
					if (!selected) {
						lineH = h;
					}
				}
				items.push({
					el: el,
					id: id,
					x: r.left + r.width / 2,
					y: r.top + r.height / 2,
					w: w,
					h: h,
					selected: selected,
					hover: el.classList.contains('mvweb-om__marker--hover'),
					img: el.classList.contains(B + '__m--img')
				});
			});
			clusters = clusters.filter(function (el) {
				return el.isConnected;
			});
			clusters.forEach(function (el) {
				var r = el.getBoundingClientRect();
				obstacles.push({ l: r.left, t: r.top, r: r.right, b: r.bottom });
			});

			items.forEach(function (it) {
				var d = it.img ? IMG : (it.selected ? DOT_SELECTED : DOT);
				it.dot = { l: it.x - d, t: it.y - d, r: it.x + d, b: it.y + d };
				obstacles.push(it.dot);
			});
			items.sort(function (a, b) {
				var ra = a.selected ? 0 : (a.hover ? 1 : 2);
				var rb = b.selected ? 0 : (b.hover ? 1 : 2);
				return ra - rb || (order[a.id] || 0) - (order[b.id] || 0);
			});

			var placed = obstacles;
			items.forEach(function (it) {
				var gap = GAP + (it.selected ? SHIFT : 0);
				var top = it.y - it.h / 2;
				var right = { l: it.x + gap, t: top, r: it.x + gap + it.w, b: top + it.h };
				var left = { l: it.x - gap - it.w, t: top, r: it.x - gap, b: top + it.h };
				var fitsRight = right.r <= area.right - EDGE;
				var fitsLeft = left.l >= area.left + EDGE;
				var inside = it.x >= area.left && it.x <= area.right && top >= area.top && top + it.h <= area.bottom;
				var box = null;

				it.left = !fitsRight && fitsLeft;
				if (inside) {
					if (fitsRight && !hitsAny(right, placed, it.dot)) {
						box = right;
						it.left = false;
					} else if (fitsLeft && !hitsAny(left, placed, it.dot)) {
						box = left;
						it.left = true;
					}
				}
				it.quiet = !box && !it.selected;
				if (inside && (box || it.selected)) {
					placed.push(box || (it.left ? left : right));
				}
			});

			items.forEach(function (it) {
				it.el.classList.toggle(B + '__m--quiet', it.quiet);
				it.el.classList.toggle(B + '__m--left', it.left);
			});
		}

		/**
		 * Run the layout once the map has been still for a moment.
		 */
		function schedule() {
			clearTimeout(timer);
			if (moving) {
				return;
			}
			timer = setTimeout(function () {
				if (!frame) {
					frame = requestAnimationFrame(layout);
				}
			}, SETTLE);
		}

		/**
		 * Put the category icon into the selected dot (built on demand).
		 *
		 * @param {string} id Object id.
		 */
		function addIcon(id) {
			var el = els[id];
			var obj = objs[id];
			if (!el || !obj || el.mvwebOmIcon || el.classList.contains(B + '__m--img')) {
				return;
			}
			var ico = dotIcon(obj, ctx);
			if (ico) {
				el.firstChild.appendChild(ico);
				el.mvwebOmIcon = true;
			}
		}

		ctx.on('select', function (payload) {
			selectedId = payload ? String(payload.id) : null;
			if (null !== selectedId) {
				addIcon(selectedId);
			}
			schedule();
		});
		ctx.on('deselect', function () {
			selectedId = null;
			schedule();
		});
		ctx.on('visible', schedule);
		ctx.on('viewport', function (payload) {
			moving = !!(payload && payload.inAction);
			if (moving) {
				clearTimeout(timer);
				return;
			}
			schedule();
		});

		return {
			gridSize: 64,

			/**
			 * Build the dot marker of an object with its name.
			 *
			 * @param {Object} obj Object data.
			 * @return {HTMLElement}
			 */
			create: function (obj) {
				var id = String(obj.id);
				var cat = firstCategory(obj, ctx);
				var own = obj.icon || {};
				var el = make('div', 'mvweb-om__marker ' + B + '__m ' + B + '__m--quiet');
				var text = make('span', B + '__label', obj.title || '');

				el.setAttribute('role', 'button');
				el.setAttribute('tabindex', '0');
				if (cat && COLOR.test(cat.color || '')) {
					el.style.setProperty('--mvweb-om-marker-c', cat.color);
					el.style.setProperty('--mvweb-om-marker-ink', inkFor(cat.color));
				}

				if ('image' === own.type && isSafeUrl(own.url)) {
					var img = make('img', B + '__img');
					img.setAttribute('src', own.url);
					img.setAttribute('alt', '');
					img.setAttribute('decoding', 'async');
					img.setAttribute('loading', 'lazy');
					el.classList.add(B + '__m--img');
					el.appendChild(img);
				} else {
					el.appendChild(make('span', B + '__dot'));
				}
				el.appendChild(text);
				el.mvwebOmLabel = text;

				els[id] = el;
				objs[id] = obj;
				if (id === selectedId) {
					addIcon(id);
				}
				schedule();
				return el;
			},

			/**
			 * Build a donut cluster: category shares around the number.
			 *
			 * @param {Array} features Clustered features.
			 * @return {HTMLElement}
			 */
			cluster: function (features) {
				var count = features.length;
				var size = count < 10 ? 's' : (count < 100 ? 'm' : 'l');
				var el = make('div', B + '__cl ' + B + '__cl--' + size);
				var num = make('span', B + '__num', String(count));
				el.style.setProperty('--mvweb-om-marker-g', donut(features, ctx));
				num.setAttribute('aria-hidden', 'true');
				el.appendChild(num);
				clusterA11y(el, count, ctx);
				clusters.push(el);
				schedule();
				return el;
			},

			/**
			 * Stop the pending layout pass.
			 */
			destroy: function () {
				clearTimeout(timer);
				if (frame) {
					cancelAnimationFrame(frame);
				}
				els = Object.create(null);
				clusters = [];
			}
		};
	});
})();
