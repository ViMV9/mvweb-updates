/**
 * Balloon variant "panel": the object card as a panel at the side of the map.
 *
 * Desktop: a full-height panel on the left of the map (on the right when the
 * list is the side panel), photo slider on top, details below, buttons pinned
 * to the bottom; the map centers in the free part. Phone or a narrow map: a
 * bottom sheet with two positions; expanding it moves the map up with the
 * marker.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var BLOCK = 'mvweb-om-balloon-panel';
	var OWNER = 'balloon';
	var NARROW = 640;
	var CLICK_SLOP = 6;
	var POSITIONS = ['peek', 'full'];

	var uid = 0;

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		if (cls) {
			el.className = cls;
		}
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	api.register('balloon', 'panel', function (ctx) {
		var shared = api.shared || {};
		var parts = shared.parts;
		if (!parts || typeof shared.sheet !== 'function' || typeof shared.gallery !== 'function') {
			return null;
		}

		var i18n = ctx.i18n || {};
		var variants = (ctx.config && ctx.config.variants) || {};
		var side = 'sidebar' === variants.list ? 'right' : 'left';
		var host = ctx.root.querySelector('.mvweb-om__map') || ctx.root;
		var canvas = ctx.root.querySelector('.mvweb-om__canvas');

		var current = null;
		var source = '';
		var mode = '';
		var sheets = {};
		var gallery = null;
		var closing = false;
		var opening = false;
		var press = null;
		var frame = 0;

		/**
		 * Whether the card goes into the side panel rather than the bottom sheet.
		 *
		 * @return {boolean}
		 */
		function useSide() {
			return !ctx.isPhone() && host.clientWidth >= NARROW;
		}

		/**
		 * Ask the core to clear the selection (it closes this module).
		 */
		function dismiss() {
			if (current) {
				ctx.select(null);
			}
		}

		/**
		 * Lazily create the side panel or the bottom sheet.
		 *
		 * @param {string} kind side or bottom.
		 * @return {Object} Sheet API.
		 */
		function getSheet(kind) {
			if (!sheets[kind]) {
				sheets[kind] = shared.sheet(ctx, {
					host: host,
					owner: OWNER,
					side: 'side' === kind ? side : false,
					positions: POSITIONS,
					initial: 'peek',
					modal: false,
					onChange: function () {
						if (!opening && current && 'bottom' === mode) {
							ctx.flyTo(current);
						}
					},
					onClose: function () {
						if (!closing) {
							dismiss();
						}
					}
				});
				sheets[kind].el.classList.add(BLOCK + '__sheet');
			}
			return sheets[kind];
		}

		/**
		 * Build the head: category, title, address and the close button.
		 *
		 * @param {Object} obj     Object data.
		 * @param {string} titleId Id for the title element.
		 * @return {HTMLElement}
		 */
		function buildHead(obj, titleId) {
			var head = make('div', BLOCK + '__head');
			var text = make('div', BLOCK + '__heading');
			var cat = parts.cat(obj, ctx);
			if (cat) {
				cat.classList.add(BLOCK + '__cat');
				text.appendChild(cat);
			}
			var title = parts.title(obj, BLOCK + '__title');
			title.id = titleId;
			title.setAttribute('data-sheet-title', '');
			text.appendChild(title);
			var address = parts.rows(obj, ctx, { phone: false, hours: false });
			if (address) {
				address.classList.add(BLOCK + '__address');
				text.appendChild(address);
			}
			head.appendChild(text);
			head.appendChild(parts.close(i18n.close || 'Close', dismiss, BLOCK + '__close mvweb-om-ui__icon-btn--plain'));
			return head;
		}

		/**
		 * Build the details: excerpt, characteristics, contacts and links.
		 *
		 * @param {Object} obj Object data.
		 * @return {HTMLElement|null} Null when there is nothing to show.
		 */
		function buildDetails(obj) {
			var details = make('div', BLOCK + '__details');
			if (obj.excerpt) {
				details.appendChild(make('p', BLOCK + '__excerpt', obj.excerpt));
			}
			var specs = parts.specs(obj, ctx, { flag: 'balloon', tiles: true });
			if (specs) {
				specs.classList.add(BLOCK + '__specs');
				details.appendChild(specs);
			}
			var rows = make('div', BLOCK + '__rows');
			[parts.rows(obj, ctx, { address: false }), parts.links(obj)].forEach(function (group) {
				while (group && group.firstChild) {
					rows.appendChild(group.firstChild);
				}
			});
			if (rows.childNodes.length) {
				details.appendChild(rows);
			}
			return details.childNodes.length ? details : null;
		}

		/**
		 * Build the card content of an object.
		 *
		 * @param {Object} obj Object data.
		 * @return {HTMLElement}
		 */
		function build(obj) {
			var urls = parts.photoUrls(obj);
			var box = make('div', BLOCK + (urls.length ? '' : ' ' + BLOCK + '--bare'));
			box.appendChild(buildHead(obj, BLOCK + '-title-' + (++uid)));
			var actions = parts.actions(obj, ctx, { call: false });
			if (actions) {
				actions.classList.add(BLOCK + '__actions');
				box.appendChild(actions);
			}
			if (urls.length) {
				gallery = shared.gallery(ctx, { urls: urls, counter: true, alt: obj.title || '' });
				gallery.el.classList.add(BLOCK + '__media');
				box.appendChild(gallery.el);
			}
			var details = buildDetails(obj);
			if (details) {
				box.appendChild(details);
			}
			return box;
		}

		/**
		 * Mark the root with the place of the open panel.
		 *
		 * @param {string} place left, right, bottom or empty.
		 */
		function markRoot(place) {
			if (place) {
				ctx.root.setAttribute('data-balloon-panel', place);
			} else {
				ctx.root.removeAttribute('data-balloon-panel');
			}
		}

		/**
		 * Remove the open view without touching the selection.
		 */
		function hide() {
			closing = true;
			if (gallery) {
				gallery.destroy();
				gallery = null;
			}
			Object.keys(sheets).forEach(function (kind) {
				if (sheets[kind].position()) {
					sheets[kind].close();
				}
			});
			markRoot('');
			closing = false;
			mode = '';
		}

		/**
		 * Open an object.
		 *
		 * @param {Object} obj Object data.
		 */
		function open(obj) {
			if (!obj) {
				return;
			}
			var next = useSide() ? 'side' : 'bottom';
			if (mode && mode !== next) {
				hide();
			}
			current = obj;
			mode = next;
			if (gallery) {
				gallery.destroy();
				gallery = null;
			}
			var s = getSheet(next);
			if (s.position() && !s.el.contains(document.activeElement)) {
				ctx.focus.remember();
			}
			while (s.body.firstChild) {
				s.body.removeChild(s.body.firstChild);
			}
			s.body.appendChild(build(obj));
			s.body.scrollTop = 0;
			opening = true;
			s.open();
			opening = false;
			markRoot('side' === next ? side : 'bottom');
			ctx.flyTo(obj, ('marker' === source || 'api' === source || !source) ? null : { zoom: 16 });
			source = '';
		}

		/**
		 * Close the card. Safe to call when nothing is open.
		 */
		function close() {
			if (!current && !mode) {
				return;
			}
			current = null;
			hide();
		}

		var onSelect = function (e) {
			source = (e && e.source) || '';
		};
		var onDeselect = function () {
			close();
		};
		var onPointerDown = function (e) {
			press = { x: e.clientX, y: e.clientY };
		};
		var onCanvasClick = function (e) {
			var p = press;
			press = null;
			if (!current || !p || Math.abs(e.clientX - p.x) > CLICK_SLOP || Math.abs(e.clientY - p.y) > CLICK_SLOP) {
				return;
			}
			if (e.target.closest && e.target.closest('a, button, [role="button"], [class*="cluster"]')) {
				return;
			}
			dismiss();
		};
		var onResize = function () {
			if (frame) {
				return;
			}
			frame = requestAnimationFrame(function () {
				frame = 0;
				if (current && mode !== (useSide() ? 'side' : 'bottom')) {
					var obj = current;
					hide();
					open(obj);
				}
			});
		};

		ctx.on('select', onSelect);
		ctx.on('deselect', onDeselect);
		if (canvas) {
			canvas.addEventListener('pointerdown', onPointerDown, true);
			canvas.addEventListener('click', onCanvasClick);
		}
		window.addEventListener('resize', onResize);

		return {
			minMap: 'right' === side ? { width: NARROW } : { width: 280, height: 360 },
			open: open,
			close: close,
			destroy: function () {
				close();
				ctx.off('select', onSelect);
				ctx.off('deselect', onDeselect);
				if (canvas) {
					canvas.removeEventListener('pointerdown', onPointerDown, true);
					canvas.removeEventListener('click', onCanvasClick);
				}
				window.removeEventListener('resize', onResize);
				if (frame) {
					cancelAnimationFrame(frame);
					frame = 0;
				}
				Object.keys(sheets).forEach(function (kind) {
					sheets[kind].destroy();
				});
				sheets = {};
			}
		};
	});
})();
