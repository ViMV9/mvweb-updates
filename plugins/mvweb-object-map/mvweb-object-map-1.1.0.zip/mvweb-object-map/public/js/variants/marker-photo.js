/**
 * Marker variant "photo": a round photo thumbnail in a category-colored ring,
 * the category icon when there is no photo, cluster as a fan of two thumbnails
 * with a counter.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var COLOR = /^#[0-9a-f]{3,8}$/i;
	var B = 'mvweb-om-marker-photo';
	var EDGE = 8;
	var SETTLE = 150;
	var MIN_TEXT = 64;
	var FACES = 2;

	/**
	 * Whether a URL is safe to place into src (http(s) or root-relative).
	 *
	 * @param {string} url URL to test.
	 * @return {boolean}
	 */
	function isSafeUrl(url) {
		if (typeof url !== 'string') {
			return false;
		}
		var s = url.trim().toLowerCase();
		return s.indexOf('http://') === 0 || s.indexOf('https://') === 0 || s.indexOf('/') === 0;
	}

	/**
	 * Readable icon color on top of a category color (WCAG relative luminance,
	 * same rule as the accent ink in PHP).
	 *
	 * @param {string} hex Background color, #rgb, #rgba, #rrggbb or #rrggbbaa.
	 * @return {string} '#ffffff' or '#111827'.
	 */
	function inkFor(hex) {
		var h = hex.replace('#', '');
		if (h.length < 6) {
			h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
		}
		var lum = 0;
		[0.2126, 0.7152, 0.0722].forEach(function (weight, i) {
			var c = parseInt(h.substr(i * 2, 2), 16) / 255;
			c = c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
			lum += weight * c;
		});
		return lum > 0.179 ? '#111827' : '#ffffff';
	}

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		el.className = cls;
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * The object's first category from the payload.
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} ctx Map context.
	 * @return {Object|null}
	 */
	function firstCategory(obj, ctx) {
		var slug = (obj.categories || [])[0];
		var found = null;
		(ctx.categories || []).some(function (cat) {
			if (cat.slug === slug) {
				found = cat;
			}
			return !!found;
		});
		return found;
	}

	/**
	 * Set the category color and its readable ink on an element.
	 *
	 * @param {HTMLElement} el  Element.
	 * @param {Object}      cat Category or null.
	 */
	function paint(el, cat) {
		if (cat && COLOR.test(cat.color || '')) {
			el.style.setProperty('--mvweb-om-marker-c', cat.color);
			el.style.setProperty('--mvweb-om-marker-ink', inkFor(cat.color));
		}
	}

	/**
	 * Picture URL of an object: the marker photo, then the object's own icon image.
	 *
	 * @param {Object} obj Object data.
	 * @return {string} URL or ''.
	 */
	function pictureUrl(obj) {
		if (isSafeUrl(obj.pin)) {
			return obj.pin;
		}
		var own = obj.icon || {};
		return 'image' === own.type && isSafeUrl(own.url) ? own.url : '';
	}

	/**
	 * An image element for a marker or a cluster face.
	 *
	 * @param {string} url URL.
	 * @param {string} cls Class name.
	 * @return {HTMLElement}
	 */
	function image(url, cls) {
		var img = make('img', cls);
		img.setAttribute('src', url);
		img.setAttribute('alt', '');
		img.setAttribute('decoding', 'async');
		img.setAttribute('loading', 'lazy');
		return img;
	}

	/**
	 * Icon by priority: object preset, category icon, home.
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} cat First category or null.
	 * @param {Object} ctx Map context.
	 * @return {Element|null}
	 */
	function markerIcon(obj, cat, ctx) {
		var own = obj.icon || {};
		var svg = (own.preset && ctx.icon(own.preset)) || (cat && cat.icon && ctx.icon(cat.icon)) || ctx.icon('home');
		if (svg) {
			svg.setAttribute('class', 'mvweb-om-ui__icon ' + B + '__ico');
		}
		return svg;
	}

	/**
	 * One face of the cluster fan: the photo or a colored square with the icon.
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} ctx Map context.
	 * @return {HTMLElement}
	 */
	function face(obj, ctx) {
		var url = pictureUrl(obj);
		if (url) {
			return image(url, B + '__face');
		}
		var cat = firstCategory(obj, ctx);
		var el = make('span', B + '__face ' + B + '__face--ico');
		var ico = markerIcon(obj, cat, ctx);
		paint(el, cat);
		if (ico) {
			el.appendChild(ico);
		}
		return el;
	}

	/**
	 * Objects for the cluster fan, the ones with a photo first.
	 *
	 * @param {Array} features Clustered features.
	 * @return {Array}
	 */
	function fanObjects(features) {
		var withPhoto = [];
		var rest = [];
		for (var i = 0; i < features.length && withPhoto.length < FACES; i++) {
			var obj = features[i].properties.obj;
			if (pictureUrl(obj)) {
				withPhoto.push(obj);
			} else if (rest.length < FACES) {
				rest.push(obj);
			}
		}
		return withPhoto.concat(rest).slice(0, FACES);
	}

	/**
	 * Keep the name under the selected marker inside the map: shift it away
	 * from the edge, shorten it when the map is narrower than the name.
	 *
	 * @param {HTMLElement} el  Marker element.
	 * @param {Object}      ctx Map context.
	 */
	function fitName(el, ctx) {
		if (!el.isConnected || !el.classList.contains('mvweb-om__marker--selected')) {
			return;
		}
		var name = el.querySelector('.' + B + '__name');
		if (!name) {
			return;
		}
		var area = (ctx.root.querySelector('.mvweb-om__canvas') || ctx.root).getBoundingClientRect();
		el.style.removeProperty('--mvweb-om-marker-shift');
		el.style.removeProperty('--mvweb-om-marker-text-max');

		var room = Math.floor(area.width - EDGE * 2);
		if (name.offsetWidth > room) {
			el.style.setProperty('--mvweb-om-marker-text-max', Math.max(MIN_TEXT, room) + 'px');
		}
		var r = name.getBoundingClientRect();
		var shift = 0;
		if (r.left < area.left + EDGE) {
			shift = area.left + EDGE - r.left;
		} else if (r.right > area.right - EDGE) {
			shift = area.right - EDGE - r.right;
		}
		if (shift) {
			el.style.setProperty('--mvweb-om-marker-shift', Math.round(shift) + 'px');
		}
	}

	/**
	 * Make a cluster element reachable from the keyboard.
	 *
	 * @param {HTMLElement} el    Cluster element.
	 * @param {number}      count Objects in the cluster.
	 * @param {Object}      ctx   Map context.
	 */
	function clusterA11y(el, count, ctx) {
		var label = (ctx.i18n.clusterLabel || 'Objects: %d. Zoom in').replace('%d', String(count));
		el.appendChild(make('span', 'mvweb-om__sr', label));
		el.setAttribute('role', 'button');
		el.setAttribute('tabindex', '0');
		el.setAttribute('title', label);
		el.addEventListener('keydown', function (e) {
			if ('Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key) {
				e.preventDefault();
				e.stopPropagation();
				el.click();
			}
		});
	}

	api.register('marker', 'photo', function (ctx) {
		var els = Object.create(null);
		var selectedId = null;
		var timer = 0;
		var refit = function () {
			clearTimeout(timer);
			timer = setTimeout(function () {
				var el = null !== selectedId ? els[selectedId] : null;
				if (el) {
					fitName(el, ctx);
				}
			}, SETTLE);
		};

		ctx.on('select', function (payload) {
			selectedId = payload ? String(payload.id) : null;
			refit();
		});
		ctx.on('deselect', function () {
			selectedId = null;
		});
		ctx.on('viewport', function (payload) {
			if (null !== selectedId && !(payload && payload.inAction)) {
				refit();
			}
		});

		return {
			gridSize: 88,

			/**
			 * Build the photo marker of an object.
			 *
			 * @param {Object} obj Object data.
			 * @return {HTMLElement}
			 */
			create: function (obj) {
				var cat = firstCategory(obj, ctx);
				var el = make('div', 'mvweb-om__marker ' + B + '__m');
				var pic = make('span', B + '__pic');
				var url = pictureUrl(obj);

				el.setAttribute('role', 'button');
				el.setAttribute('tabindex', '0');
				el.setAttribute('title', obj.title || '');
				paint(el, cat);

				if (url) {
					pic.appendChild(image(url, B + '__img'));
				} else {
					var ico = markerIcon(obj, cat, ctx);
					if (ico) {
						pic.appendChild(ico);
					}
				}
				el.appendChild(pic);
				el.appendChild(make('span', B + '__name', obj.title || ''));

				els[String(obj.id)] = el;
				if (String(obj.id) === selectedId) {
					refit();
				}
				return el;
			},

			/**
			 * Build a fan of two thumbnails with a counter, sized by the number of objects.
			 *
			 * @param {Array} features Clustered features.
			 * @return {HTMLElement}
			 */
			cluster: function (features) {
				var count = features.length;
				var size = count < 10 ? 's' : (count < 100 ? 'm' : 'l');
				var el = make('div', B + '__cl ' + B + '__cl--' + size);
				var num = make('span', B + '__count', String(count));
				fanObjects(features).forEach(function (obj) {
					el.appendChild(face(obj, ctx));
				});
				num.setAttribute('aria-hidden', 'true');
				el.appendChild(num);
				clusterA11y(el, count, ctx);
				return el;
			}
		};
	});
})();
