/**
 * List variant "grid": category tabs and a toolbar above the map, a grid of
 * large cards under it and a "Map / Grid / Both" view switch.
 *
 * Object text goes in via textContent, URLs via setAttribute (shared.parts).
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var B = 'mvweb-om-list-grid';
	var PAGE = 12;
	var EAGER = 3;
	var MAX_TABS = 5;
	var SEARCH_DELAY = 180;
	var COLOR = /^#[0-9a-f]{3,8}$/i;
	var SVG_NS = 'http://www.w3.org/2000/svg';
	var VIEWS = ['map', 'grid', 'both'];
	var VIEW_ICONS = {
		grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
		both: 'M3 4h18v8H3zM3 15h8v5H3zM13 15h8v5h-8z'
	};
	var uid = 0;

	api.register('list', 'grid', function (ctx) {
		var parts = null;
		var card = {};
		var reduced = false;
		var anyPhoto = false;
		var catsEl = null;
		var tabs = [];
		var items = [];
		var moreWrap = null;
		var moreBtn = null;
		var menu = null;
		var catSelect = null;
		var bar = null;
		var input = null;
		var select = null;
		var viewBtns = [];
		var results = null;
		var found = null;
		var grid = null;
		var empty = null;
		var emptyText = null;
		var emptyReset = null;
		var emptyAll = null;
		var showMore = null;
		var cardEls = Object.create(null);
		var objects = [];
		var shown = 0;
		var view = 'both';
		var activeCats = [];
		var selectedId = null;
		var hoverId = null;
		var timer = 0;
		var frame = 0;
		var observer = null;
		var handlers = {};

		/**
		 * Read a translated string.
		 *
		 * @param {string} key      Key in the i18n object.
		 * @param {string} fallback English text.
		 * @return {string}
		 */
		function t(key, fallback) {
			return (ctx.i18n && ctx.i18n[key]) || fallback;
		}

		/**
		 * Create an element with a class and optional text.
		 *
		 * @param {string} tag  Tag name.
		 * @param {string} cls  Class name.
		 * @param {string} body Text content (optional).
		 * @return {HTMLElement}
		 */
		function make(tag, cls, body) {
			var el = document.createElement(tag);
			if (cls) {
				el.className = cls;
			}
			if (body) {
				el.textContent = body;
			}
			return el;
		}

		/**
		 * Build a small stroke icon from a path (view switch icons).
		 *
		 * @param {string} d Path data, viewBox 0 0 24 24.
		 * @return {SVGElement}
		 */
		function pathIcon(d) {
			var svg = document.createElementNS(SVG_NS, 'svg');
			var path = document.createElementNS(SVG_NS, 'path');
			svg.setAttribute('class', 'mvweb-om-ui__icon mvweb-om-ui__icon--sm');
			svg.setAttribute('viewBox', '0 0 24 24');
			svg.setAttribute('fill', 'none');
			svg.setAttribute('stroke', 'currentColor');
			svg.setAttribute('stroke-width', '2');
			svg.setAttribute('stroke-linejoin', 'round');
			svg.setAttribute('aria-hidden', 'true');
			svg.setAttribute('focusable', 'false');
			path.setAttribute('d', d);
			svg.appendChild(path);
			return svg;
		}

		/**
		 * Number of loaded objects per category slug.
		 *
		 * @return {Object}
		 */
		function countCats() {
			var counts = Object.create(null);
			(ctx.objects || []).forEach(function (obj) {
				(obj.categories || []).forEach(function (slug) {
					counts[slug] = (counts[slug] || 0) + 1;
				});
			});
			return counts;
		}

		/**
		 * Categories that have objects: [{ slug, name, color, count }].
		 *
		 * @return {Array}
		 */
		function catList() {
			var counts = countCats();
			var out = [];
			(ctx.categories || []).forEach(function (cat) {
				if (cat && cat.slug && counts[cat.slug]) {
					out.push({ slug: String(cat.slug), name: cat.name || String(cat.slug), color: cat.color, count: counts[cat.slug] });
				}
			});
			return out;
		}

		/**
		 * Fill a category button: color dot, name and counter.
		 *
		 * @param {HTMLElement} btn  Button.
		 * @param {Object}      cat  { slug, name, color, count }.
		 */
		function fillCat(btn, cat) {
			btn.type = 'button';
			btn.setAttribute('data-slug', cat.slug);
			btn.setAttribute('aria-pressed', 'false');
			if (cat.slug) {
				var dot = make('span', B + '__swatch');
				dot.setAttribute('aria-hidden', 'true');
				btn.appendChild(dot);
				if (COLOR.test(cat.color || '')) {
					btn.style.setProperty('--mvweb-om-grid-c', cat.color);
				}
			}
			btn.appendChild(make('span', B + '__name', cat.name));
			btn.appendChild(make('span', B + '__count', String(cat.count)));
			btn.addEventListener('click', function () {
				pick(cat.slug);
				if (btn.classList.contains(B + '__item')) {
					setMenu(false);
					moreBtn.focus();
				}
			});
		}

		/**
		 * Choose a category (empty slug for all).
		 *
		 * @param {string} slug Category slug.
		 */
		function pick(slug) {
			ctx.setCats(slug ? [slug] : []);
		}

		/**
		 * Build the category tabs (computer) and the category select (phone).
		 */
		function buildCats() {
			var list = catList();
			if (!list.length) {
				return;
			}
			var all = { slug: '', name: t('all', 'All'), color: '', count: (ctx.objects || []).length };

			catsEl = make('div', B + '__cats');
			catsEl.setAttribute('role', 'group');
			catsEl.setAttribute('aria-label', t('categories', 'Categories'));

			[all].concat(list).forEach(function (cat) {
				var btn = make('button', B + '__tab');
				fillCat(btn, cat);
				tabs.push(btn);
				catsEl.appendChild(btn);
			});

			moreWrap = make('div', B + '__morewrap');
			moreBtn = make('button', B + '__tab ' + B + '__tab--more');
			moreBtn.type = 'button';
			moreBtn.setAttribute('aria-expanded', 'false');
			menu = make('div', B + '__menu');
			menu.id = B + '-menu-' + (++uid);
			menu.hidden = true;
			moreBtn.setAttribute('aria-controls', menu.id);
			moreBtn.appendChild(make('span', B + '__name'));
			var chev = parts.icon('chev-d', 'sm');
			if (chev) {
				moreBtn.appendChild(chev);
			}
			moreBtn.addEventListener('click', function () {
				setMenu(menu.hidden);
			});
			list.forEach(function (cat) {
				var item = make('button', B + '__item');
				fillCat(item, cat);
				items.push(item);
				menu.appendChild(item);
			});
			moreWrap.appendChild(moreBtn);
			moreWrap.appendChild(menu);
			catsEl.appendChild(moreWrap);
			catsEl.addEventListener('keydown', function (e) {
				if ('Escape' === e.key && !menu.hidden) {
					e.stopPropagation();
					setMenu(false);
					moreBtn.focus();
				}
			});

			catSelect = make('select', B + '__catselect');
			[all].concat(list).forEach(function (cat) {
				var opt = make('option', '', cat.name + ' · ' + cat.count);
				opt.value = cat.slug;
				catSelect.appendChild(opt);
			});
			catSelect.addEventListener('change', function () {
				pick(catSelect.value);
			});

			if (typeof ResizeObserver === 'function') {
				observer = new ResizeObserver(queueLayout);
				observer.observe(catsEl);
			} else {
				window.addEventListener('resize', queueLayout);
			}
		}

		/**
		 * Open or close the "More" menu.
		 *
		 * @param {boolean} open Open state.
		 */
		function setMenu(open) {
			if (!menu) {
				return;
			}
			menu.hidden = !open;
			moreBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
			if (open) {
				menu.classList.remove(B + '__menu--end');
				if (menu.getBoundingClientRect().right > catsEl.getBoundingClientRect().right) {
					menu.classList.add(B + '__menu--end');
				}
			}
		}

		/**
		 * Close the menu on a press outside of it.
		 *
		 * @param {Event} e Pointer event.
		 */
		function onOutside(e) {
			if (menu && !menu.hidden && moreWrap && !moreWrap.contains(e.target)) {
				setMenu(false);
			}
		}

		/**
		 * Fit the tabs on the next frame.
		 */
		function queueLayout() {
			if (frame) {
				return;
			}
			frame = requestAnimationFrame(function () {
				frame = 0;
				layoutTabs();
			});
		}

		/**
		 * Show as many category tabs as fit (at most five), the rest go to "More".
		 */
		function layoutTabs() {
			if (!catsEl || !catsEl.offsetParent) {
				return;
			}
			var style = window.getComputedStyle(catsEl);
			var gap = parseFloat(style.columnGap) || 0;
			var room = catsEl.clientWidth - (parseFloat(style.paddingLeft) || 0) - (parseFloat(style.paddingRight) || 0);
			var total = tabs.length - 1;

			tabs.forEach(function (tab) {
				tab.hidden = false;
			});
			moreWrap.hidden = false;
			setMoreLabel(total);
			var moreW = moreWrap.offsetWidth;
			var used = tabs[0].offsetWidth;
			var fit = 0;
			for (var i = 1; i <= total; i++) {
				var need = used + gap + tabs[i].offsetWidth;
				var tail = i < total ? gap + moreW : 0;
				if (i > MAX_TABS || need + tail > room) {
					break;
				}
				used = need;
				fit = i;
			}
			tabs.forEach(function (tab, index) {
				tab.hidden = index > fit;
			});
			items.forEach(function (item, index) {
				item.hidden = index + 1 <= fit;
			});
			moreWrap.hidden = fit >= total;
			if (moreWrap.hidden) {
				setMenu(false);
			}
			setMoreLabel(total - fit);
			syncMore();
		}

		/**
		 * Write "More N" on the menu button.
		 *
		 * @param {number} n Number of categories in the menu.
		 */
		function setMoreLabel(n) {
			moreBtn.firstChild.textContent = t('moreCount', 'More %d').replace('%d', String(n));
		}

		/**
		 * Underline the "More" button when the active category is in the menu.
		 */
		function syncMore() {
			if (!moreBtn) {
				return;
			}
			var inMenu = items.some(function (item) {
				return !item.hidden && 'true' === item.getAttribute('aria-pressed');
			});
			moreBtn.classList.toggle(B + '__tab--on', inMenu);
		}

		/**
		 * Mirror the active categories on the tabs, the menu and the select.
		 *
		 * @param {Array} cats Active category slugs.
		 */
		function syncCats(cats) {
			activeCats = cats;
			tabs.concat(items).forEach(function (btn) {
				var slug = btn.getAttribute('data-slug');
				var on = slug ? cats.indexOf(slug) !== -1 : !cats.length;
				btn.setAttribute('aria-pressed', on ? 'true' : 'false');
			});
			if (catSelect) {
				catSelect.value = cats.length ? cats[0] : '';
			}
			syncMore();
		}

		/**
		 * Build the toolbar: category select, search, sort and the view switch.
		 */
		function buildBar() {
			bar = make('div', B + '__bar');

			if (catSelect) {
				var catWrap = make('label', B + '__catwrap');
				catWrap.appendChild(make('span', 'mvweb-om__sr', t('category', 'Category')));
				catWrap.appendChild(catSelect);
				var chevCat = parts.icon('chev-d', 'sm');
				if (chevCat) {
					catWrap.appendChild(chevCat);
				}
				bar.appendChild(catWrap);
			}

			var search = make('label', B + '__search');
			var searchIcon = parts.icon('search', 'sm');
			if (searchIcon) {
				search.appendChild(searchIcon);
			}
			search.appendChild(make('span', 'mvweb-om__sr', t('searchLabel', 'Search objects')));
			input = make('input', B + '__input');
			input.type = 'search';
			input.setAttribute('placeholder', t('searchHint', 'Name or address'));
			input.setAttribute('autocomplete', 'off');
			input.setAttribute('enterkeyhint', 'search');
			search.appendChild(input);
			bar.appendChild(search);

			var sort = make('label', B + '__sort');
			sort.appendChild(make('span', 'mvweb-om__sr', t('sortLabel', 'Sort objects')));
			select = make('select', B + '__select');
			[['name', t('sortName', 'By name')], ['new', t('sortNew', 'Newest first')]].forEach(function (pair) {
				var opt = make('option', '', pair[1]);
				opt.value = pair[0];
				select.appendChild(opt);
			});
			sort.appendChild(select);
			var chev = parts.icon('chev-d', 'sm');
			if (chev) {
				sort.appendChild(chev);
			}
			bar.appendChild(sort);

			var views = make('div', B + '__views');
			views.setAttribute('role', 'group');
			views.setAttribute('aria-label', t('viewLabel', 'View'));
			var labels = {
				map: [t('mapTab', 'Map'), t('mapTab', 'Map')],
				grid: [t('viewGrid', 'Grid'), t('viewGrid', 'Grid')],
				both: [t('viewBoth', 'Both'), t('viewBothTitle', 'Map and grid')]
			};
			VIEWS.forEach(function (name) {
				var btn = make('button', B + '__view');
				btn.type = 'button';
				btn.setAttribute('data-view', name);
				btn.setAttribute('aria-pressed', 'false');
				btn.setAttribute('title', labels[name][1]);
				btn.appendChild('map' === name ? parts.icon('map', 'sm') : pathIcon(VIEW_ICONS[name]));
				btn.appendChild(make('span', B + '__vlabel', labels[name][0]));
				btn.addEventListener('click', function () {
					setView(name);
				});
				viewBtns.push(btn);
				views.appendChild(btn);
			});
			bar.appendChild(views);

			input.addEventListener('input', function () {
				clearTimeout(timer);
				timer = setTimeout(function () {
					ctx.setQuery(input.value);
				}, SEARCH_DELAY);
			});
			select.addEventListener('change', function () {
				ctx.setSort(select.value);
			});
		}

		/**
		 * Build the results: counter, card grid, empty state, "Show more".
		 */
		function buildResults() {
			results = make('div', B + '__results');
			var head = make('div', B + '__reshead');
			found = make('span', B + '__found');
			found.setAttribute('role', 'status');
			head.appendChild(found);
			results.appendChild(head);

			grid = make('ul', B + '__grid');
			grid.setAttribute('role', 'list');
			results.appendChild(grid);

			empty = make('div', B + '__empty');
			empty.hidden = true;
			var emptyIcon = make('span', B + '__empty-ico');
			var bigSearch = parts.icon('search');
			if (bigSearch) {
				emptyIcon.appendChild(bigSearch);
			}
			empty.appendChild(emptyIcon);
			empty.appendChild(make('span', B + '__empty-title', t('emptyTitle', 'Nothing found')));
			emptyText = make('span', B + '__empty-text');
			empty.appendChild(emptyText);
			var actions = make('span', B + '__empty-actions');
			emptyReset = make('button', B + '__reset', t('resetSearch', 'Clear search'));
			emptyReset.type = 'button';
			emptyAll = make('button', B + '__all', t('allCats', 'Search in all categories'));
			emptyAll.type = 'button';
			actions.appendChild(emptyReset);
			actions.appendChild(emptyAll);
			empty.appendChild(actions);
			results.appendChild(empty);

			showMore = make('button', 'mvweb-om-ui__btn mvweb-om-ui__btn--outline ' + B + '__showmore', t('showMore', 'Show more'));
			showMore.type = 'button';
			showMore.hidden = true;
			results.appendChild(showMore);

			emptyReset.addEventListener('click', function () {
				clearTimeout(timer);
				input.value = '';
				ctx.setQuery('');
				input.focus();
			});
			emptyAll.addEventListener('click', function () {
				ctx.setCats([]);
				input.focus();
			});
			showMore.addEventListener('click', function () {
				var from = shown;
				fill(Math.min(objects.length, shown + PAGE));
				var first = grid.children[from];
				if (first && first.firstChild) {
					first.firstChild.focus();
				}
			});
		}

		/**
		 * Icon slug for an object without a photo: object preset, first category icon, home.
		 *
		 * @param {Object} obj Object data.
		 * @return {string}
		 */
		function iconSlug(obj) {
			if (obj.icon && obj.icon.preset) {
				return String(obj.icon.preset);
			}
			var slug = '';
			(obj.categories || []).some(function (catSlug) {
				(ctx.categories || []).some(function (cat) {
					if (cat && cat.slug === catSlug && cat.icon) {
						slug = String(cat.icon);
					}
					return !!slug;
				});
				return !!slug;
			});
			return slug || 'home';
		}

		/**
		 * Spec rows of an object flagged "show in the list", at most three.
		 *
		 * @param {Object} obj Object data.
		 * @return {Array}
		 */
		function listSpecs(obj) {
			var ids = {};
			(ctx.schema || []).forEach(function (field) {
				if (field && field.show && field.show.indexOf('list') !== -1) {
					ids[field.id] = true;
				}
			});
			return (obj.specs || []).filter(function (s) {
				return s && undefined !== s.id && ids[s.id] === true && s.value;
			}).slice(0, 3);
		}

		/**
		 * Build one object card.
		 *
		 * @param {Object}  obj   Object data.
		 * @param {boolean} eager Load the photo without lazy loading.
		 * @return {HTMLElement} The list item.
		 */
		function buildCard(obj, eager) {
			var id = String(obj.id);
			var item = make('li', B + '__cell');
			var btn = make('button', B + '__card');
			btn.type = 'button';
			btn.setAttribute('data-id', id);

			var cat = parts.cat(obj, ctx);
			var img = false !== card.showPhoto ? parts.photo(obj, { size: 'photo', eager: eager, className: B + '__img' }) : null;
			if (img || (anyPhoto && false !== card.showPhoto)) {
				var media = make('span', B + '__media');
				if (img) {
					media.appendChild(img);
				} else {
					media.classList.add(B + '__media--empty');
					var ph = parts.icon(iconSlug(obj)) || parts.icon('home');
					if (ph) {
						media.appendChild(ph);
					}
				}
				if (cat) {
					cat.classList.add(B + '__badge');
					media.appendChild(cat);
					cat = null;
				}
				btn.appendChild(media);
			} else {
				btn.classList.add(B + '__card--nophoto');
			}

			var info = make('span', B + '__info');
			var text = make('span', B + '__text');
			if (cat) {
				cat.classList.add(B + '__cat');
				text.appendChild(cat);
			}
			text.appendChild(make('span', B + '__title', obj.title || ''));
			if (false !== card.showAddress && obj.address) {
				text.appendChild(make('span', B + '__addr', obj.address));
			}
			if (card.showExcerpt && obj.excerpt) {
				text.appendChild(make('span', B + '__excerpt', obj.excerpt));
			}
			info.appendChild(text);
			var specs = listSpecs(obj);
			if (specs.length) {
				var row = make('span', B + '__specs');
				specs.forEach(function (s) {
					var spec = make('span', B + '__spec', s.label || '');
					spec.appendChild(make('b', '', s.value));
					row.appendChild(spec);
				});
				info.appendChild(row);
			}
			btn.appendChild(info);

			if (null !== selectedId && String(selectedId) === id) {
				btn.setAttribute('aria-current', 'true');
			}
			if (null !== hoverId && String(hoverId) === id) {
				btn.setAttribute('data-hover', '');
			}

			btn.addEventListener('click', function () {
				ctx.select(obj.id, 'list');
			});
			btn.addEventListener('pointerenter', function (e) {
				if ('mouse' === e.pointerType) {
					ctx.hover(obj.id);
				}
			});
			btn.addEventListener('pointerleave', function (e) {
				if ('mouse' === e.pointerType && String(hoverId) === id) {
					ctx.hover(null);
				}
			});
			btn.addEventListener('focus', function () {
				ctx.hover(obj.id);
			});
			btn.addEventListener('blur', function () {
				if (String(hoverId) === id) {
					ctx.hover(null);
				}
			});

			cardEls[id] = btn;
			item.appendChild(btn);
			return item;
		}

		/**
		 * Append cards until the given count is shown.
		 *
		 * @param {number} upto Number of cards to show.
		 */
		function fill(upto) {
			var fragment = document.createDocumentFragment();
			for (var i = shown; i < upto; i++) {
				fragment.appendChild(buildCard(objects[i], i < EAGER));
			}
			grid.appendChild(fragment);
			shown = Math.max(shown, upto);
			showMore.hidden = shown >= objects.length;
		}

		/**
		 * Position of an object in the current list, or -1.
		 *
		 * @param {number|string} id Object id.
		 * @return {number}
		 */
		function indexOf(id) {
			for (var i = 0; i < objects.length; i++) {
				if (String(objects[i].id) === String(id)) {
					return i;
				}
			}
			return -1;
		}

		/**
		 * Write "Found: N" with the number in bold.
		 *
		 * @param {number} n Number of objects.
		 */
		function setFound(n) {
			var pattern = t('found', 'Found: %d');
			var at = pattern.indexOf('%d');
			found.textContent = at === -1 ? pattern + ' ' : pattern.slice(0, at);
			found.appendChild(make('b', '', String(n)));
			if (at !== -1) {
				found.appendChild(document.createTextNode(pattern.slice(at + 2)));
			}
		}

		/**
		 * Name of the first active category, or ''.
		 *
		 * @param {Array} cats Active category slugs.
		 * @return {string}
		 */
		function catName(cats) {
			var name = '';
			if (cats.length) {
				(ctx.categories || []).some(function (cat) {
					if (cat && String(cat.slug) === cats[0]) {
						name = cat.name || cat.slug;
					}
					return !!name;
				});
			}
			return name;
		}

		/**
		 * Fill the empty state for the current search and category.
		 *
		 * @param {Object} state List view.
		 */
		function setEmpty(state) {
			var name = catName(state.cats);
			var line = '';
			if (state.query && name) {
				line = t('emptyQueryCat', 'No objects match “%1$s” in “%2$s”.').split('%2$s').join(name).split('%1$s').join(state.query);
			} else if (state.query) {
				line = t('emptyQuery', 'No objects match “%s”.').split('%s').join(state.query);
			}
			emptyText.textContent = line;
			emptyText.hidden = !line;
			emptyReset.hidden = !state.query;
			emptyAll.hidden = !state.cats.length;
		}

		/**
		 * Switch the layout: map only, grid only or both.
		 *
		 * @param {string} name map, grid or both.
		 */
		function setView(name) {
			var prev = view;
			view = VIEWS.indexOf(name) !== -1 ? name : 'both';
			VIEWS.forEach(function (key) {
				ctx.root.classList.toggle(B + '--view-' + key, key === view);
			});
			viewBtns.forEach(function (btn) {
				btn.setAttribute('aria-pressed', btn.getAttribute('data-view') === view ? 'true' : 'false');
			});
			if (prev !== view && 'grid' !== view && ctx.map && typeof ctx.map.update === 'function') {
				ctx.map.update({});
			}
		}

		/**
		 * Bring the map into the viewport after a card was chosen.
		 */
		function showMap() {
			if ('grid' === view) {
				setView('both');
			}
			var map = ctx.root.querySelector('.mvweb-om__map');
			if (!map) {
				return;
			}
			var r = map.getBoundingClientRect();
			if (r.top < 0 || r.bottom > (window.innerHeight || document.documentElement.clientHeight)) {
				map.scrollIntoView({ block: 'nearest', behavior: reduced ? 'auto' : 'smooth' });
			}
		}

		/**
		 * Mark the selected card.
		 *
		 * @param {number|string|null} id Object id or null.
		 */
		function setSelected(id) {
			if (null !== selectedId && cardEls[String(selectedId)]) {
				cardEls[String(selectedId)].removeAttribute('aria-current');
			}
			selectedId = (null === id || undefined === id || '' === id) ? null : id;
			if (null === selectedId || !grid) {
				return;
			}
			var at = indexOf(selectedId);
			if (at >= shown) {
				fill(Math.min(objects.length, (Math.floor(at / PAGE) + 1) * PAGE));
			}
			if (cardEls[String(selectedId)]) {
				cardEls[String(selectedId)].setAttribute('aria-current', 'true');
			}
		}

		/**
		 * Mark the hovered card.
		 *
		 * @param {number|string|null} id Object id or null.
		 */
		function setHover(id) {
			if (null !== hoverId && cardEls[String(hoverId)]) {
				cardEls[String(hoverId)].removeAttribute('data-hover');
			}
			hoverId = (null === id || undefined === id || '' === id) ? null : id;
			if (null !== hoverId && cardEls[String(hoverId)]) {
				cardEls[String(hoverId)].setAttribute('data-hover', '');
			}
		}

		/**
		 * Draw the grid for a view.
		 *
		 * @param {Object} state { objects, total, cats, query, sort, selectedId, hoverId }.
		 */
		function render(state) {
			syncCats((state && state.cats) || []);
			if (!results) {
				return;
			}
			objects = (state && state.objects) || [];
			selectedId = state && undefined !== state.selectedId ? state.selectedId : selectedId;
			hoverId = state && undefined !== state.hoverId ? state.hoverId : hoverId;

			if (!state.query && input.value.trim() && document.activeElement !== input) {
				input.value = '';
			}
			if (select.value !== state.sort && ('name' === state.sort || 'new' === state.sort)) {
				select.value = state.sort;
			}

			cardEls = Object.create(null);
			grid.textContent = '';
			shown = 0;
			fill(Math.min(objects.length, PAGE));
			if (null !== selectedId) {
				setSelected(selectedId);
			}

			setFound(objects.length);
			grid.hidden = !objects.length;
			empty.hidden = !!objects.length;
			if (!objects.length) {
				setEmpty(state);
			}
		}

		return {
			/**
			 * Build the tabs, the toolbar and the grid and subscribe to the instance events.
			 */
			mount: function () {
				parts = api.shared && api.shared.parts;
				if (!parts) {
					throw new Error('mvwebOm.shared.parts is missing');
				}
				card = (ctx.data && ctx.data.card) || {};
				reduced = !!window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
				anyPhoto = (ctx.objects || []).some(function (obj) {
					return parts.isSafeUrl(obj.photo || obj.thumb || '');
				});

				var root = ctx.root;
				var body = root.querySelector('.mvweb-om__body');
				var anchor = body && body.parentNode === root ? body : root.firstChild;

				if (ctx.config && ctx.config.filter) {
					buildCats();
				}
				if (ctx.config && ctx.config.list) {
					buildBar();
					buildResults();
				} else if (catSelect) {
					bar = make('div', B + '__bar ' + B + '__bar--cats');
					var catWrap = make('label', B + '__catwrap');
					catWrap.appendChild(make('span', 'mvweb-om__sr', t('category', 'Category')));
					catWrap.appendChild(catSelect);
					var chev = parts.icon('chev-d', 'sm');
					if (chev) {
						catWrap.appendChild(chev);
					}
					bar.appendChild(catWrap);
				}

				if (catsEl) {
					root.insertBefore(catsEl, anchor);
				}
				if (bar) {
					root.insertBefore(bar, anchor);
				}
				if (results) {
					root.insertBefore(results, anchor ? anchor.nextSibling : null);
					setView('both');
				}
				if (catsEl) {
					document.addEventListener('pointerdown', onOutside, true);
					queueLayout();
				}

				handlers.select = function (p) {
					setSelected(p.id);
					if ('list' === p.source && results && !(ctx.data && ctx.data.modal)) {
						showMap();
					}
				};
				handlers.deselect = function () {
					setSelected(null);
				};
				handlers.hover = function (p) {
					setHover(p.id);
				};
				Object.keys(handlers).forEach(function (name) {
					ctx.on(name, handlers[name]);
				});
			},

			render: render,

			/**
			 * Remove the tabs, the toolbar and the grid and drop the subscriptions.
			 */
			destroy: function () {
				clearTimeout(timer);
				if (frame) {
					cancelAnimationFrame(frame);
				}
				if (observer) {
					observer.disconnect();
				} else {
					window.removeEventListener('resize', queueLayout);
				}
				document.removeEventListener('pointerdown', onOutside, true);
				Object.keys(handlers).forEach(function (name) {
					ctx.off(name, handlers[name]);
				});
				[catsEl, bar, results].forEach(function (el) {
					if (el && el.parentNode) {
						el.parentNode.removeChild(el);
					}
				});
				VIEWS.forEach(function (key) {
					ctx.root.classList.remove(B + '--view-' + key);
				});
				catsEl = bar = results = menu = null;
				tabs = [];
				items = [];
				cardEls = Object.create(null);
			}
		};
	});
})();
