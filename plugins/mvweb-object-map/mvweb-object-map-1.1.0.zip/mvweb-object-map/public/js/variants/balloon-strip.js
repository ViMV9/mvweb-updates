/**
 * Balloon variant "strip": a card at the bottom of the map with paging.
 *
 * Desktop: one horizontal card centred at the bottom of the map (photo on the
 * left, the essentials on the right) under a "‹ 1 of 12 ›" bar that pages
 * through the neighbouring objects in list order; the selected marker moves
 * with the card. A narrow map gets the compact card. Phone: a rail of compact
 * cards with the edges of the neighbours visible; the rail holds the selected
 * object and the nearest objects shown on the map (at most 30).
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var BLOCK = 'mvweb-om-balloon-strip';
	var OWNER = 'balloon';
	var SOURCE = 'balloon';
	var WIDE = 600;
	var RAIL_MAX = 30;
	var ZOOM = 16;
	var GAP = 8;
	var TOP_ROOM = 56;
	var CLICK_SLOP = 6;

	var uid = 0;

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		if (cls) {
			el.className = cls;
		}
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * Append an element with an extra class when it exists.
	 *
	 * @param {HTMLElement}      parent Parent.
	 * @param {HTMLElement|null} child  Child or null.
	 * @param {string}           cls    Extra class (optional).
	 */
	function add(parent, child, cls) {
		if (child) {
			if (cls) {
				child.classList.add(cls);
			}
			parent.appendChild(child);
		}
	}

	/**
	 * Squared distance between two objects on a flat projection.
	 *
	 * @param {Object} a Object data.
	 * @param {Object} b Object data.
	 * @return {number}
	 */
	function distance(a, b) {
		var k = Math.cos((Number(a.lat) || 0) * Math.PI / 180);
		var dx = ((Number(a.lng) || 0) - (Number(b.lng) || 0)) * k;
		var dy = (Number(a.lat) || 0) - (Number(b.lat) || 0);
		return dx * dx + dy * dy;
	}

	api.register('balloon', 'strip', function (ctx) {
		var shared = api.shared || {};
		var parts = shared.parts;
		if (!parts || typeof shared.rail !== 'function') {
			return null;
		}

		var i18n = ctx.i18n || {};
		var host = ctx.root.querySelector('.mvweb-om__map') || ctx.root;
		var canvas = ctx.root.querySelector('.mvweb-om__canvas');

		var current = null;
		var source = '';
		var mode = '';
		var dock = null;
		var bar = null;
		var count = null;
		var prev = null;
		var next = null;
		var slot = null;
		var rail = null;
		var items = [];
		var visible = null;
		var stepping = false;
		var press = null;
		var frame = 0;

		/**
		 * Translated "N of M".
		 *
		 * @param {number} n Position, 1-based.
		 * @param {number} m Total.
		 * @return {string}
		 */
		function position(n, m) {
			return (i18n.position || '%1$d of %2$d').replace('%1$d', String(n)).replace('%2$d', String(m));
		}

		/**
		 * Layout for the current screen: the phone rail or the desktop card.
		 *
		 * @return {string} phone or pc.
		 */
		function layout() {
			return ctx.isPhone() ? 'phone' : 'pc';
		}

		/**
		 * Ask the core to clear the selection (it closes this module).
		 */
		function dismiss() {
			if (current) {
				ctx.select(null);
			}
		}

		/**
		 * Select another object from inside the card.
		 *
		 * @param {Object} obj Object data.
		 */
		function go(obj) {
			if (!obj || (current && String(obj.id) === String(current.id))) {
				return;
			}
			stepping = true;
			try {
				ctx.select(obj.id, SOURCE);
			} finally {
				stepping = false;
			}
		}

		/**
		 * Build one card.
		 *
		 * @param {Object}  obj  Object data.
		 * @param {boolean} wide Desktop layout with the tall photo.
		 * @return {HTMLElement}
		 */
		function buildCard(obj, wide) {
			var titleId = BLOCK + '-title-' + (++uid);
			var photo = parts.photo(obj, { size: wide ? 'photo' : 'thumb', className: BLOCK + '__photo' });
			var card = make('article', BLOCK + '__card' + (photo ? '' : ' ' + BLOCK + '__card--bare'));
			var head = make('div', BLOCK + '__head');
			var body = make('div', BLOCK + '__body');

			card.setAttribute('aria-labelledby', titleId);
			card.setAttribute('data-id', String(obj.id));
			add(card, photo);

			add(head, parts.cat(obj, ctx), BLOCK + '__cat');
			var title = parts.title(obj, BLOCK + '__title');
			title.id = titleId;
			head.appendChild(title);
			add(head, parts.rows(obj, ctx, { phone: false, hours: false }), BLOCK + '__address');
			card.appendChild(head);

			add(body, parts.specs(obj, ctx, { flag: 'balloon' }), BLOCK + '__specs');
			if (obj.excerpt) {
				body.appendChild(make('p', BLOCK + '__excerpt', obj.excerpt));
			}
			add(body, parts.rows(obj, ctx, { address: false }), BLOCK + '__meta');
			add(body, parts.links(obj), BLOCK + '__links');
			add(body, parts.actions(obj, ctx, { call: false }), BLOCK + '__actions');
			if (body.childNodes.length) {
				card.appendChild(body);
			}

			card.appendChild(parts.close(i18n.close || 'Close', dismiss, 'mvweb-om-ui__icon-btn--plain ' + BLOCK + '__close'));
			return card;
		}

		/**
		 * Up to RAIL_MAX objects shown on the map: the given one first, then
		 * the nearest ones.
		 *
		 * @param {Object} obj Selected object.
		 * @return {Array}
		 */
		function railItems(obj) {
			var list = (visible || ctx.objects || []).filter(function (o) {
				return String(o.id) !== String(obj.id);
			});
			list.sort(function (a, b) {
				return distance(obj, a) - distance(obj, b);
			});
			return [obj].concat(list.slice(0, RAIL_MAX - 1));
		}

		/**
		 * Index of an object in the rail, -1 when it is not there.
		 *
		 * @param {Object} obj Object data.
		 * @return {number}
		 */
		function indexOf(obj) {
			for (var i = 0; i < items.length; i++) {
				if (String(items[i].id) === String(obj.id)) {
					return i;
				}
			}
			return -1;
		}

		/**
		 * Refresh the "‹ N of M ›" bar.
		 */
		function syncBar() {
			if (!dock || !current) {
				return;
			}
			var n = 0;
			var total = 0;
			var hasPrev = false;
			var hasNext = false;
			if ('phone' === mode) {
				n = rail ? rail.active() : 0;
				total = items.length;
				hasPrev = n > 0;
				hasNext = n < total - 1;
			} else {
				var near = ctx.neighbors(current.id);
				n = near.index;
				total = near.total;
				hasPrev = !!near.prev;
				hasNext = !!near.next;
			}
			bar.hidden = n < 0 || total < 2;
			count.textContent = bar.hidden ? '' : position(n + 1, total);
			prev.disabled = !hasPrev;
			next.disabled = !hasNext;
		}

		/**
		 * Step to the neighbour object.
		 *
		 * @param {number} delta -1 or 1.
		 */
		function step(delta) {
			if (!current) {
				return;
			}
			if ('phone' === mode) {
				var i = (rail ? rail.active() : 0) + delta;
				if (i >= 0 && i < items.length) {
					rail.scrollTo(i, true);
					go(items[i]);
				}
				return;
			}
			var near = ctx.neighbors(current.id);
			go(delta < 0 ? near.prev : near.next);
		}

		/**
		 * Space for the card: the map height minus the top controls and the bar.
		 */
		function measure() {
			if (!dock) {
				return;
			}
			var room = host.clientHeight - TOP_ROOM - (bar.hidden ? 0 : bar.offsetHeight + GAP);
			dock.style.setProperty('--mvweb-om-balloon-strip-room', Math.max(160, room) + 'px');
			dock.classList.toggle(BLOCK + '--wide', 'pc' === mode && host.clientWidth >= WIDE);
		}

		/**
		 * Phone rail: move the bar down onto the active card when the
		 * neighbours are taller.
		 *
		 * @return {number} Shift in px.
		 */
		function lift() {
			var shift = 0;
			if ('phone' === mode && rail) {
				var track = rail.el.firstElementChild;
				var top = Infinity;
				var on = 0;
				Array.prototype.forEach.call(track ? track.children : [], function (item) {
					top = Math.min(top, item.offsetTop);
					if (item.hasAttribute('data-on')) {
						on = item.offsetTop;
					}
				});
				shift = isFinite(top) ? Math.max(0, on - top) : 0;
			}
			dock.style.setProperty('--mvweb-om-balloon-strip-lift', shift + 'px');
			return shift;
		}

		/**
		 * Tell the core how much of the map bottom the card covers.
		 */
		function inset() {
			if (dock) {
				var side = typeof ctx.insets === 'function' ? ctx.insets(OWNER) : { l: 0, r: 0 };
				dock.style.setProperty('--mvweb-om-balloon-strip-l', side.l + 'px');
				dock.style.setProperty('--mvweb-om-balloon-strip-r', side.r + 'px');
				ctx.setInsets(OWNER, { b: host.clientHeight - dock.offsetTop - lift() + GAP });
			}
		}

		/**
		 * Create the dock with the bar.
		 */
		function buildDock() {
			dock = make('div', BLOCK);
			dock.setAttribute('role', 'dialog');
			dock.setAttribute('tabindex', '-1');
			dock.setAttribute('data-mode', mode);
			bar = make('div', BLOCK + '__bar');
			prev = parts.iconButton('chev-l', i18n.prevObject || 'Previous object', function () { step(-1); }, BLOCK + '__step');
			next = parts.iconButton('chev-r', i18n.nextObject || 'Next object', function () { step(1); }, BLOCK + '__step');
			count = make('span', BLOCK + '__count');
			count.setAttribute('aria-live', 'polite');
			bar.appendChild(prev);
			bar.appendChild(count);
			bar.appendChild(next);
			slot = make('div', BLOCK + '__slot');
			dock.appendChild(bar);
			dock.appendChild(slot);
			dock.addEventListener('keydown', onKey);
			host.appendChild(dock);
		}

		/**
		 * Show the object in the desktop card.
		 *
		 * @param {Object} obj Object data.
		 */
		function showCard(obj) {
			measure();
			var card = buildCard(obj, dock.classList.contains(BLOCK + '--wide'));
			slot.textContent = '';
			slot.appendChild(card);
			dock.setAttribute('aria-labelledby', card.getAttribute('aria-labelledby'));
		}

		/**
		 * Show the object in the phone rail, rebuilding the rail when the
		 * object is not in it.
		 *
		 * @param {Object} obj Object data.
		 */
		function showRail(obj) {
			var at = indexOf(obj);
			if (!rail || at < 0) {
				items = railItems(obj);
				at = 0;
				if (rail) {
					rail.setItems(items);
				} else {
					rail = shared.rail(ctx, {
						host: slot,
						items: items,
						label: i18n.objectsLabel || 'Objects',
						arrows: false,
						render: function (o) { return buildCard(o, false); },
						onActive: function (o) { go(o); }
					});
					rail.el.classList.add(BLOCK + '__rail');
				}
			} else if (rail.active() !== at) {
				rail.scrollTo(at, true);
			}
			var card = rail.el.querySelector('[data-index="' + at + '"] .' + BLOCK + '__card');
			if (card) {
				dock.setAttribute('aria-labelledby', card.getAttribute('aria-labelledby'));
			}
			measure();
		}

		/**
		 * Remove the dock without touching the selection.
		 */
		function hide() {
			var refocus = !!dock && dock.contains(document.activeElement);
			if (rail) {
				rail.destroy();
				rail = null;
			}
			items = [];
			if (dock) {
				dock.removeEventListener('keydown', onKey);
				if (dock.parentNode) {
					dock.parentNode.removeChild(dock);
				}
				dock = null;
				ctx.setInsets(OWNER, null);
				if (refocus) {
					ctx.focus.restore();
				}
			}
			mode = '';
		}

		/**
		 * Open an object.
		 *
		 * @param {Object} obj Object data.
		 */
		function open(obj) {
			if (!obj) {
				return;
			}
			var want = layout();
			var inside = !!dock && dock.contains(document.activeElement);
			if (dock && mode !== want) {
				hide();
			}
			if (!inside && !stepping) {
				ctx.focus.remember();
			}
			current = obj;
			mode = want;
			if (!dock) {
				buildDock();
			}
			if ('phone' === mode) {
				showRail(obj);
			} else {
				showCard(obj);
			}
			syncBar();
			measure();
			inset();
			if (!stepping && !dock.contains(document.activeElement)) {
				dock.focus({ preventScroll: true });
			}
			var fromMarker = 'marker' === source || 'api' === source || !source;
			var zoomIn = stepping ? !(ctx.map && ctx.map.zoom >= ZOOM) : !fromMarker;
			ctx.flyTo(obj, zoomIn ? { zoom: ZOOM } : null);
			source = '';
		}

		/**
		 * Close the card. Safe to call when nothing is open.
		 */
		function close() {
			if (!current && !dock) {
				return;
			}
			current = null;
			hide();
		}

		/**
		 * Keyboard inside the dock: Esc closes, arrows page on desktop.
		 *
		 * @param {KeyboardEvent} e Event.
		 */
		function onKey(e) {
			if ('Escape' === e.key) {
				e.stopPropagation();
				dismiss();
				return;
			}
			if ('pc' === mode && ('ArrowLeft' === e.key || 'ArrowRight' === e.key) && !/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) {
				e.preventDefault();
				step('ArrowLeft' === e.key ? -1 : 1);
			}
		}

		var onSelect = function (e) {
			source = (e && e.source) || '';
		};
		var onDeselect = function () {
			close();
		};
		var onVisible = function (e) {
			visible = (e && e.objects) || null;
			if (current && 'phone' === mode && rail) {
				items = railItems(current);
				rail.setItems(items);
				syncBar();
				inset();
			}
		};
		var onFilter = function () {
			if (current && 'pc' === mode) {
				syncBar();
			}
		};
		var onPointerDown = function (e) {
			press = { x: e.clientX, y: e.clientY };
		};
		var onCanvasClick = function (e) {
			var p = press;
			press = null;
			if (!current || !p || Math.abs(e.clientX - p.x) > CLICK_SLOP || Math.abs(e.clientY - p.y) > CLICK_SLOP) {
				return;
			}
			if (e.target.closest && e.target.closest('a, button, [role="button"], [class*="cluster"]')) {
				return;
			}
			dismiss();
		};
		var onResize = function () {
			if (frame) {
				return;
			}
			frame = requestAnimationFrame(function () {
				frame = 0;
				if (!current) {
					return;
				}
				var wasWide = dock && dock.classList.contains(BLOCK + '--wide');
				if (mode !== layout()) {
					var obj = current;
					hide();
					open(obj);
					return;
				}
				measure();
				if ('pc' === mode && wasWide !== dock.classList.contains(BLOCK + '--wide')) {
					showCard(current);
				}
				inset();
			});
		};

		ctx.on('select', onSelect);
		ctx.on('deselect', onDeselect);
		ctx.on('visible', onVisible);
		ctx.on('filter', onFilter);
		if (canvas) {
			canvas.addEventListener('pointerdown', onPointerDown, true);
			canvas.addEventListener('click', onCanvasClick);
		}
		window.addEventListener('resize', onResize);

		return {
			minMap: { width: 280, height: 300 },
			open: open,
			close: close,
			destroy: function () {
				close();
				ctx.off('select', onSelect);
				ctx.off('deselect', onDeselect);
				ctx.off('visible', onVisible);
				ctx.off('filter', onFilter);
				if (canvas) {
					canvas.removeEventListener('pointerdown', onPointerDown, true);
					canvas.removeEventListener('click', onCanvasClick);
				}
				window.removeEventListener('resize', onResize);
				if (frame) {
					cancelAnimationFrame(frame);
					frame = 0;
				}
			}
		};
	});
})();
