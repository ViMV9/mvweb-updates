/**
 * Balloon variant "popup": a compact card above the marker with a tail.
 *
 * The card is a map marker of its own at the object coordinates, so the map
 * moves it together with the object marker. Before it opens the map pans just
 * enough for the card to fit; at the side edges the card slides sideways and
 * the tail stays over the marker. A low map gets a height limit with a scroll
 * inside. Phone: the same card across the full map width.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var BLOCK = 'mvweb-om-balloon-popup';
	var OWNER = 'balloon';
	var Z = 1000000;
	var PAD = 12;
	var FOOT = 36;
	var TAIL = 8;
	var TAIL_EDGE = 24;
	var GAP = 4;
	var BELOW = 16;
	var MIN_HEIGHT = 160;
	var OFFSET = 12;
	var NUMS = 3;
	var FLY = 300;
	var SETTLE = 340;
	var SETTLE_MARKER = 200;
	var CLICK_SLOP = 6;

	var uid = 0;

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		if (cls) {
			el.className = cls;
		}
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * Append an element with an extra class when it exists.
	 *
	 * @param {HTMLElement}      parent Parent.
	 * @param {HTMLElement|null} child  Child or null.
	 * @param {string}           cls    Extra class (optional).
	 */
	function add(parent, child, cls) {
		if (child) {
			if (cls) {
				child.classList.add(cls);
			}
			parent.appendChild(child);
		}
	}

	/**
	 * Limit a number to a range.
	 *
	 * @param {number} value Value.
	 * @param {number} min   Lower bound.
	 * @param {number} max   Upper bound.
	 * @return {number}
	 */
	function clamp(value, min, max) {
		return Math.min(Math.max(value, min), max);
	}

	api.register('balloon', 'popup', function (ctx) {
		var shared = api.shared || {};
		var parts = shared.parts;
		if (!parts || !window.ymaps3 || typeof ymaps3.YMapMarker !== 'function') {
			return null;
		}

		var i18n = ctx.i18n || {};
		var canvas = ctx.root.querySelector('.mvweb-om__canvas');

		var current = null;
		var source = '';
		var marker = null;
		var anchor = null;
		var card = null;
		var timer = 0;
		var frame = 0;
		var press = null;

		/**
		 * Ask the core to clear the selection (it closes this module).
		 */
		function dismiss() {
			if (current) {
				ctx.select(null);
			}
		}

		/**
		 * Build the card of an object.
		 *
		 * @param {Object} obj Object data.
		 * @return {HTMLElement}
		 */
		function build(obj) {
			var titleId = BLOCK + '-title-' + (++uid);
			var photo = parts.photo(obj, { size: 'photo', className: BLOCK + '__photo' });
			var box = make('article', BLOCK + (photo ? '' : ' ' + BLOCK + '--bare'));
			var scroll = make('div', BLOCK + '__scroll');
			var body = make('div', BLOCK + '__body');
			var head = make('div', BLOCK + '__head');

			box.setAttribute('role', 'dialog');
			box.setAttribute('tabindex', '-1');
			box.setAttribute('aria-labelledby', titleId);
			box.appendChild(parts.close(i18n.close || 'Close', dismiss, BLOCK + '__close ' + (photo ? 'mvweb-om-ui__icon-btn--glass' : 'mvweb-om-ui__icon-btn--plain')));

			add(scroll, photo);
			add(head, parts.cat(obj, ctx));
			var title = parts.title(obj, BLOCK + '__title');
			title.id = titleId;
			head.appendChild(title);
			add(head, parts.rows(obj, ctx, { phone: false, hours: false }));
			body.appendChild(head);

			var nums = parts.specs(obj, ctx, { flag: 'balloon', tiles: true });
			if (nums) {
				while (nums.children.length > NUMS) {
					nums.removeChild(nums.lastElementChild);
				}
				add(body, nums, BLOCK + '__specs');
			}
			if (obj.excerpt) {
				body.appendChild(make('p', BLOCK + '__excerpt', obj.excerpt));
			}
			add(body, parts.rows(obj, ctx, { address: false }), BLOCK + '__meta');
			add(body, parts.links(obj));
			add(body, parts.actions(obj, ctx, { call: false }), BLOCK + '__actions');
			scroll.appendChild(body);
			box.appendChild(scroll);

			box.addEventListener('keydown', function (e) {
				if ('Escape' === e.key) {
					e.stopPropagation();
					dismiss();
				}
			});
			return box;
		}

		/**
		 * Distance from the object point up to the top of its marker.
		 *
		 * @param {DOMRect} point Anchor rectangle.
		 * @return {number} Pixels.
		 */
		function markerTop(point) {
			var el = canvas ? canvas.querySelector('.mvweb-om__marker--selected') : null;
			if (!el) {
				return OFFSET;
			}
			var box = el.getBoundingClientRect();
			return clamp(Math.round(point.top - box.top), 0, 96);
		}

		/**
		 * How far the classic category filter reaches down over the map.
		 *
		 * @param {DOMRect} area Canvas rectangle.
		 * @return {number} Pixels from the canvas top, 0 without the filter.
		 */
		function filterBottom(area) {
			var filter = ctx.root.querySelector('.mvweb-om__filter');
			if (!filter || filter.hidden || !filter.offsetHeight) {
				return 0;
			}
			var box = filter.getBoundingClientRect();
			if (box.bottom <= area.top || box.top >= area.bottom || box.right <= area.left || box.left >= area.right) {
				return 0;
			}
			return Math.round(box.bottom - area.top);
		}

		/**
		 * Pan the map so that the object point moves by the given pixels.
		 *
		 * @param {number} dx Shift to the right.
		 * @param {number} dy Shift down.
		 */
		function pan(dx, dy) {
			var map = ctx.map;
			var proj = map && map.projection;
			if (!proj || !map.center || (!dx && !dy)) {
				return;
			}
			var scale = Math.pow(2, map.zoom || 0) * 128;
			var world = proj.toWorldCoordinates(map.center);
			var center = proj.fromWorldCoordinates({ x: world.x - dx / scale, y: world.y + dy / scale });
			if (center && isFinite(center[0]) && isFinite(center[1])) {
				ctx.flyTo({ lng: center[0], lat: center[1] }, { duration: FLY });
			}
		}

		/**
		 * Fit the card into the free part of the map: width and height limits,
		 * a sideways slide at the edges and, when allowed, a map pan.
		 *
		 * @param {boolean} move Whether the map may pan.
		 */
		function layout(move) {
			if (!card || !anchor || !anchor.isConnected || !canvas) {
				return;
			}
			var area = canvas.getBoundingClientRect();
			var point = anchor.getBoundingClientRect();
			var side = typeof ctx.insets === 'function' ? ctx.insets(OWNER) : { t: 0, r: 0, b: 0, l: 0 };
			var left = side.l + PAD;
			var right = area.width - side.r - PAD;
			var top = Math.max(side.t, filterBottom(area)) + PAD;
			var bottom = area.height - side.b - FOOT;
			var lift = markerTop(point) + TAIL + GAP;
			var x = point.left - area.left;
			var y = point.top - area.top;

			card.style.setProperty('--mvweb-om-balloon-popup-lift', lift + 'px');
			card.style.setProperty('--mvweb-om-balloon-popup-max', Math.max(200, right - left) + 'px');
			card.style.setProperty('--mvweb-om-balloon-popup-max-h', Math.max(MIN_HEIGHT, bottom - top - lift - BELOW) + 'px');

			var w = card.offsetWidth;
			var h = card.offsetHeight;
			var need = 0;
			if (x - w / 2 < left) {
				need = left - (x - w / 2);
			} else if (x + w / 2 > right) {
				need = right - (x + w / 2);
			}
			var limit = Math.max(0, w / 2 - TAIL_EDGE);
			var slide = clamp(need, -limit, limit);
			card.style.setProperty('--mvweb-om-balloon-popup-shift', Math.round(slide) + 'px');

			if (!move) {
				return;
			}
			var dx = need - slide;
			var dy = 0;
			if (y - lift - h < top) {
				dy = top - (y - lift - h);
			} else if (y + BELOW > bottom) {
				dy = bottom - (y + BELOW);
			}
			pan(Math.round(dx), Math.round(dy));
		}

		/**
		 * Run the first layout once the card is on the map.
		 *
		 * The map pans after the selected marker has finished growing, so the
		 * card sits over its final size.
		 *
		 * @param {boolean} wait  Let the core finish its own flight first.
		 * @param {number}  tries Frames left to wait for the card.
		 */
		function settle(wait, tries) {
			frame = requestAnimationFrame(function () {
				frame = 0;
				if (!card) {
					return;
				}
				if (!anchor.isConnected) {
					if (tries > 0) {
						settle(wait, tries - 1);
					}
					return;
				}
				layout(false);
				card.focus({ preventScroll: true });
				timer = setTimeout(function () {
					timer = 0;
					layout(true);
				}, wait ? SETTLE : SETTLE_MARKER);
			});
		}

		/**
		 * Remove the card without touching the selection.
		 *
		 * @param {boolean} keep Leave the focus alone (another card follows).
		 */
		function hide(keep) {
			var refocus = !keep && !!card && card.contains(document.activeElement);
			if (timer) {
				clearTimeout(timer);
				timer = 0;
			}
			if (frame) {
				cancelAnimationFrame(frame);
				frame = 0;
			}
			if (marker) {
				try {
					ctx.map.removeChild(marker);
				} catch (err) {
					marker = null;
				}
			}
			marker = null;
			anchor = null;
			card = null;
			if (refocus) {
				ctx.focus.restore();
			}
		}

		/**
		 * Open an object.
		 *
		 * @param {Object} obj Object data.
		 */
		function open(obj) {
			if (!obj || !ctx.map) {
				return;
			}
			var inside = !!card && card.contains(document.activeElement);
			var fromList = !!source && 'marker' !== source && 'api' !== source && 'balloon' !== source;
			source = '';
			if (card) {
				hide(true);
			}
			if (!inside) {
				ctx.focus.remember();
			}
			current = obj;
			card = build(obj);
			anchor = make('div', BLOCK + '__anchor');
			anchor.appendChild(card);
			marker = new ymaps3.YMapMarker({
				coordinates: [obj.lng, obj.lat],
				zIndex: Z,
				blockBehaviors: true,
				blockEvents: true
			}, anchor);
			ctx.map.addChild(marker);
			settle(fromList, 30);
		}

		/**
		 * Close the card. Safe to call when nothing is open.
		 */
		function close() {
			if (!current && !card) {
				return;
			}
			current = null;
			hide();
		}

		var onSelect = function (e) {
			source = (e && e.source) || '';
		};
		var onPointerDown = function (e) {
			press = { x: e.clientX, y: e.clientY };
		};
		var onCanvasClick = function (e) {
			var p = press;
			press = null;
			if (!current || !p || Math.abs(e.clientX - p.x) > CLICK_SLOP || Math.abs(e.clientY - p.y) > CLICK_SLOP) {
				return;
			}
			if ((card && card.contains(e.target)) || (e.target.closest && e.target.closest('a, button, [role="button"], [class*="cluster"]'))) {
				return;
			}
			dismiss();
		};
		var onResize = function () {
			if (frame || !card) {
				return;
			}
			frame = requestAnimationFrame(function () {
				frame = 0;
				layout(false);
			});
		};

		ctx.on('select', onSelect);
		if (canvas) {
			canvas.addEventListener('pointerdown', onPointerDown, true);
			canvas.addEventListener('click', onCanvasClick);
		}
		window.addEventListener('resize', onResize);

		return {
			minMap: { width: 260, height: 240 },
			open: open,
			close: close,
			destroy: function () {
				close();
				ctx.off('select', onSelect);
				if (canvas) {
					canvas.removeEventListener('pointerdown', onPointerDown, true);
					canvas.removeEventListener('click', onCanvasClick);
				}
				window.removeEventListener('resize', onResize);
			}
		};
	});
})();
