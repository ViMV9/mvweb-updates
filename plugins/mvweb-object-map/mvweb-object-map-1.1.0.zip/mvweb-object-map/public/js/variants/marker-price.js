/**
 * Marker variant "price": a pill with the marker characteristic or the name,
 * a category dot and a tail; cluster as a stack of pills with a word count.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var COLOR = /^#[0-9a-f]{3,8}$/i;
	var B = 'mvweb-om-marker-price';
	var EDGE = 8;
	var SETTLE = 150;
	var TAIL = 16;
	var plurals = null;

	/**
	 * Whether a URL is safe to place into src (http(s) or root-relative).
	 *
	 * @param {string} url URL to test.
	 * @return {boolean}
	 */
	function isSafeUrl(url) {
		if (typeof url !== 'string') {
			return false;
		}
		var s = url.trim().toLowerCase();
		return s.indexOf('http://') === 0 || s.indexOf('https://') === 0 || s.indexOf('/') === 0;
	}

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		el.className = cls;
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * Color of the object's first category that has one.
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} ctx Map context.
	 * @return {string} Hex color or ''.
	 */
	function categoryColor(obj, ctx) {
		var slugs = obj.categories || [];
		var color = '';
		slugs.some(function (slug) {
			(ctx.categories || []).some(function (cat) {
				if (cat.slug === slug && COLOR.test(cat.color || '')) {
					color = cat.color;
				}
				return !!color;
			});
			return !!color;
		});
		return color;
	}

	/**
	 * Value of the first characteristic flagged "show on the marker".
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} ctx Map context.
	 * @return {string}
	 */
	function markerFact(obj, ctx) {
		var ids = {};
		(ctx.schema || []).forEach(function (field) {
			if (field.show && field.show.indexOf('marker') !== -1) {
				ids[field.id] = true;
			}
		});
		var value = '';
		(obj.specs || []).some(function (s) {
			if (undefined !== s.id && true === ids[s.id] && s.value) {
				value = String(s.value);
			}
			return !!value;
		});
		return value;
	}

	/**
	 * "N objects" in the page language plural form.
	 *
	 * @param {Object} i18n Strings.
	 * @param {number} n    Count.
	 * @return {string}
	 */
	function countText(i18n, n) {
		var form = 'other';
		try {
			plurals = plurals || new Intl.PluralRules(document.documentElement.lang || 'en');
			form = plurals.select(n);
		} catch (err) {
			form = 1 === n ? 'one' : 'other';
		}
		var key = 'objects' + form.charAt(0).toUpperCase() + form.slice(1);
		var tpl = i18n[key] || i18n.objectsOther || (1 === n ? '%d object' : '%d objects');
		return tpl.replace('%d', String(n));
	}

	/**
	 * Keep the open pill of the selected marker inside the map: narrow it to
	 * the map width and shift it away from the edge, the tail stays on the point.
	 *
	 * @param {HTMLElement} el  Marker element.
	 * @param {Object}      ctx Map context.
	 */
	function fitPill(el, ctx) {
		if (!el.isConnected || !el.classList.contains('mvweb-om__marker--selected')) {
			return;
		}
		var pill = el.querySelector('.' + B + '__pill');
		if (!pill) {
			return;
		}
		var area = (ctx.root.querySelector('.mvweb-om__canvas') || ctx.root).getBoundingClientRect();
		el.style.removeProperty('--mvweb-om-marker-dx');
		el.style.removeProperty('--mvweb-om-marker-max');

		var r = pill.getBoundingClientRect();
		var width = pill.offsetWidth;
		var scale = width ? r.width / width : 1;
		var anchor = r.left + r.width / 2;
		var room = (area.width - 2 * EDGE) / scale;
		if (width > room) {
			el.style.setProperty('--mvweb-om-marker-max', Math.max(TAIL * 2, Math.floor(room)) + 'px');
			width = pill.offsetWidth;
		}

		var half = width * scale / 2;
		var dx = 0;
		if (anchor - half < area.left + EDGE) {
			dx = area.left + EDGE - (anchor - half);
		} else if (anchor + half > area.right - EDGE) {
			dx = area.right - EDGE - (anchor + half);
		}
		var limit = width / 2 - TAIL;
		dx = Math.max(-limit, Math.min(limit, dx / scale));
		if (Math.abs(dx) >= 0.5) {
			el.style.setProperty('--mvweb-om-marker-dx', Math.round(dx) + 'px');
		}
	}

	/**
	 * Make a cluster element reachable from the keyboard.
	 *
	 * @param {HTMLElement} el    Cluster element.
	 * @param {number}      count Objects in the cluster.
	 * @param {Object}      ctx   Map context.
	 */
	function clusterA11y(el, count, ctx) {
		var label = (ctx.i18n.clusterLabel || 'Objects: %d. Zoom in').replace('%d', String(count));
		el.appendChild(make('span', 'mvweb-om__sr', label));
		el.setAttribute('role', 'button');
		el.setAttribute('tabindex', '0');
		el.setAttribute('title', label);
		el.addEventListener('keydown', function (e) {
			if ('Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key) {
				e.preventDefault();
				e.stopPropagation();
				el.click();
			}
		});
	}

	api.register('marker', 'price', function (ctx) {
		var els = Object.create(null);
		var selectedId = null;
		var timer = 0;
		var refit = function () {
			clearTimeout(timer);
			timer = setTimeout(function () {
				var el = null !== selectedId ? els[selectedId] : null;
				if (el) {
					fitPill(el, ctx);
				}
			}, SETTLE);
		};

		ctx.on('select', function (payload) {
			selectedId = payload ? String(payload.id) : null;
			refit();
		});
		ctx.on('deselect', function () {
			selectedId = null;
		});
		ctx.on('viewport', function (payload) {
			if (null !== selectedId && !(payload && payload.inAction)) {
				refit();
			}
		});

		return {
			gridSize: 120,

			/**
			 * Build the price pill of an object.
			 *
			 * @param {Object} obj Object data.
			 * @return {HTMLElement}
			 */
			create: function (obj) {
				var title = obj.title || '';
				var fact = markerFact(obj, ctx);
				var color = categoryColor(obj, ctx);
				var own = obj.icon || {};
				var el = make('div', 'mvweb-om__marker ' + B + '__m');
				var pill = make('span', B + '__pill');

				el.setAttribute('role', 'button');
				el.setAttribute('tabindex', '0');
				el.setAttribute('title', title);
				if (color) {
					el.style.setProperty('--mvweb-om-marker-c', color);
				}

				if ('image' === own.type && isSafeUrl(own.url)) {
					var img = make('img', B + '__img');
					img.setAttribute('src', own.url);
					img.setAttribute('alt', '');
					img.setAttribute('decoding', 'async');
					img.setAttribute('loading', 'lazy');
					pill.appendChild(img);
				} else {
					pill.appendChild(make('span', B + '__dot'));
				}

				if (fact && title) {
					pill.appendChild(make('span', 'mvweb-om__sr', title + ', '));
				}
				pill.appendChild(make('span', B + '__text', fact || title));
				el.appendChild(pill);

				els[String(obj.id)] = el;
				if (String(obj.id) === selectedId) {
					refit();
				}
				return el;
			},

			/**
			 * Build a stack of pills with the number of objects in words.
			 *
			 * @param {Array} features Clustered features.
			 * @return {HTMLElement}
			 */
			cluster: function (features) {
				var count = features.length;
				var size = count < 10 ? 's' : (count < 100 ? 'm' : 'l');
				var el = make('div', B + '__cl ' + B + '__cl--' + size);
				var stack = make('span', B + '__stack', countText(ctx.i18n || {}, count));
				stack.setAttribute('aria-hidden', 'true');
				el.appendChild(stack);
				clusterA11y(el, count, ctx);
				return el;
			}
		};
	});
})();
