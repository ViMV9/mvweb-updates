/**
 * Phone and object window variant "sheet" (D1).
 *
 * Phone: the map fills the block and a sheet lies over its bottom. Lowered,
 * the sheet shows "12 objects"; at half height the search and the list;
 * pulled up, the list fills the map. An object opens in the same sheet: title
 * and address first, then photos, contacts, characteristics as tiles and a
 * bar with Call, Directions and More. Closing the card returns to the list.
 * The classic tabs and the classic list are hidden. Desktop: the object
 * window is centred over the page, a photo strip across the top, the text and
 * the characteristic tiles in two columns.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var B = 'mvweb-om-mobile-sheet';
	var OWNER = 'sheet';
	var PHONE_QUERY = '(max-width: 782px)';
	var PAGE = 30;
	var CATS_SHOWN = 5;
	var SEARCH_DELAY = 200;
	var SVG_NS = 'http://www.w3.org/2000/svg';
	var COLOR = /^#[0-9a-f]{3,8}$/i;
	var uid = 0;
	var plurals = null;

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		if (cls) {
			el.className = cls;
		}
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * Append a node when it exists.
	 *
	 * @param {HTMLElement}      parent Parent element.
	 * @param {HTMLElement|null} child  Child or null.
	 * @param {string}           cls    Extra class for the child (optional).
	 */
	function add(parent, child, cls) {
		if (!child) {
			return;
		}
		if (cls) {
			child.classList.add(cls);
		}
		parent.appendChild(child);
	}

	/**
	 * Remove all children of an element.
	 *
	 * @param {HTMLElement} el Element.
	 */
	function empty(el) {
		while (el.firstChild) {
			el.removeChild(el.firstChild);
		}
	}

	/**
	 * Same object id.
	 *
	 * @param {*} a Id.
	 * @param {*} b Id.
	 * @return {boolean}
	 */
	function same(a, b) {
		return null !== a && null !== b && undefined !== a && undefined !== b && String(a) === String(b);
	}

	/**
	 * Object count text with the plural form of the page language.
	 *
	 * @param {Object} i18n Translated strings.
	 * @param {number} n    Count.
	 * @return {string}
	 */
	function countText(i18n, n) {
		var form = 'other';
		try {
			plurals = plurals || new Intl.PluralRules(document.documentElement.lang || 'en');
			form = plurals.select(n);
		} catch (err) {
			form = 1 === n ? 'one' : 'other';
		}
		var key = 'objects' + form.charAt(0).toUpperCase() + form.slice(1);
		var tpl = i18n[key] || i18n.objectsOther || (1 === n ? '%d object' : '%d objects');
		return tpl.replace('%d', String(n));
	}

	/**
	 * Check mark for the category boxes.
	 *
	 * @return {SVGElement}
	 */
	function checkIcon() {
		var svg = document.createElementNS(SVG_NS, 'svg');
		var path = document.createElementNS(SVG_NS, 'path');
		svg.setAttribute('class', 'mvweb-om-ui__icon ' + B + '__check');
		svg.setAttribute('viewBox', '0 0 24 24');
		svg.setAttribute('fill', 'none');
		svg.setAttribute('stroke', 'currentColor');
		svg.setAttribute('stroke-width', '3');
		svg.setAttribute('stroke-linecap', 'round');
		svg.setAttribute('stroke-linejoin', 'round');
		svg.setAttribute('aria-hidden', 'true');
		svg.setAttribute('focusable', 'false');
		path.setAttribute('d', 'm5 12.5 4.5 4.5L19 7');
		svg.appendChild(path);
		return svg;
	}

	api.register('mobile', 'sheet', function (ctx) {
		var shared = api.shared || {};
		var parts = shared.parts;
		if (!parts || typeof shared.sheet !== 'function' || typeof shared.gallery !== 'function') {
			return null;
		}

		var i18n = ctx.i18n || {};
		var data = ctx.data || {};
		var root = ctx.root;
		var config = ctx.config || {};
		var variants = config.variants || {};
		var useCats = !!config.filter && 'sidebar' === variants.list;
		var phoneQuery = window.matchMedia(PHONE_QUERY);
		var sheetCtx = Object.create(ctx);

		var host = null;
		var sheet = null;
		var listView = null;
		var cardView = null;
		var head = null;
		var countEl = null;
		var subEl = null;
		var input = null;
		var cats = null;
		var listEl = null;
		var moreWrap = null;
		var emptyEl = null;
		var emptyText = null;
		var dlg = null;

		var viewList = [];
		var shown = 0;
		var card = null;
		var cardHead = null;
		var gallery = null;
		var listPos = 'peek';
		var listScroll = 0;
		var selectedId = null;
		var lastSource = '';
		var pc = null;
		var silent = false;
		var inerted = [];
		var frame = 0;
		var searchTimer = 0;
		var quietFocus = false;

		/**
		 * Text with a fallback.
		 *
		 * @param {string} key      i18n key.
		 * @param {string} fallback English text.
		 * @return {string}
		 */
		function t(key, fallback) {
			return i18n[key] || fallback;
		}

		/**
		 * Map insets for the sheet: phone only, and the pulled-up sheet keeps
		 * the inset of the lower position so the map does not shrink to nothing.
		 *
		 * @param {string}      owner Owner key.
		 * @param {Object|null} inset Inset from the sheet.
		 */
		sheetCtx.setInsets = function (owner, inset) {
			if (!inset || !ctx.isPhone()) {
				ctx.setInsets(owner, null);
				return;
			}
			if (inset.b && sheet && 'full' === sheet.position()) {
				return;
			}
			ctx.setInsets(owner, inset);
		};

		sheetCtx.focus = {
			remember: function () {},
			restore: function () {}
		};

		/**
		 * Object by id from all loaded objects.
		 *
		 * @param {*} id Object id.
		 * @return {Object|null}
		 */
		function byId(id) {
			var list = ctx.objects || [];
			for (var i = 0; i < list.length; i++) {
				if (same(list[i].id, id)) {
					return list[i];
				}
			}
			return null;
		}

		/**
		 * The map under a pulled-up sheet is inert.
		 *
		 * @param {boolean} on Whether to make it inert.
		 */
		function setInert(on) {
			if (on && !inerted.length && host) {
				Array.prototype.forEach.call(host.children, function (child) {
					if (child !== sheet.el && !child.hasAttribute('inert')) {
						child.setAttribute('inert', '');
						inerted.push(child);
					}
				});
			} else if (!on) {
				inerted.forEach(function (child) { child.removeAttribute('inert'); });
				inerted = [];
			}
		}

		/**
		 * Height of the lowered sheet: the handle and the head of the list or
		 * of the card.
		 */
		function measure() {
			if (!sheet || sheet.el.hidden) {
				return;
			}
			var top = sheet.el.getBoundingClientRect().top;
			var edge = (card ? cardHead : head).getBoundingClientRect().bottom;
			sheet.el.style.setProperty('--mvweb-om-sheet-peek', Math.ceil(edge - top) + 'px');
		}

		/**
		 * Open the sheet without taking the focus, unless asked to focus the handle.
		 *
		 * @param {string}  position    Sheet position.
		 * @param {boolean} focusHandle Move the focus to the handle.
		 */
		function openSheet(position, focusHandle) {
			var before = document.activeElement;
			sheet.el.hidden = false;
			measure();
			sheet.open(position);
			measure();
			sheet.set(sheet.position());
			var handle = sheet.el.querySelector('.mvweb-om-ui__sheet-handle');
			if (focusHandle && handle) {
				handle.focus({ preventScroll: true });
			} else if (document.activeElement !== before) {
				if (before && before !== document.body && typeof before.focus === 'function') {
					before.focus({ preventScroll: true });
				} else if (document.activeElement && typeof document.activeElement.blur === 'function') {
					document.activeElement.blur();
				}
			}
		}

		/**
		 * Close the sheet without the reopen logic (desktop layout, destroy).
		 */
		function closeSheet() {
			if (sheet && sheet.position()) {
				silent = true;
				sheet.close();
				silent = false;
			}
			setInert(false);
			ctx.setInsets(OWNER, null);
		}

		/**
		 * The sheet changed its position.
		 *
		 * @param {string} position Position name.
		 */
		function onPosition(position) {
			setInert('full' === position);
			if ('full' !== position && input && document.activeElement === input) {
				input.blur();
			}
		}

		/**
		 * Esc closed the sheet: leave the card and lower the sheet, the focus
		 * goes to the handle.
		 */
		function onSheetClose() {
			setInert(false);
			if (silent || !ctx.isPhone()) {
				return;
			}
			if (card) {
				ctx.select(null, 'mobile');
			}
			openSheet('peek', true);
		}

		/**
		 * Raise the sheet when the focus lands below its visible part.
		 *
		 * @param {FocusEvent} e Focus event.
		 */
		function onFocusIn(e) {
			if (quietFocus || !ctx.isPhone() || !sheet.position() || 'full' === sheet.position()) {
				return;
			}
			if (e.target === input || e.target.getBoundingClientRect().bottom > host.getBoundingClientRect().bottom) {
				sheet.set('full');
			}
		}

		/**
		 * Mark the selected object in the list.
		 */
		function markCurrent() {
			if (!listEl) {
				return;
			}
			Array.prototype.forEach.call(listEl.querySelectorAll('.' + B + '__item'), function (btn) {
				if (same(btn.getAttribute('data-id'), selectedId)) {
					btn.setAttribute('aria-current', 'true');
				} else {
					btn.removeAttribute('aria-current');
				}
			});
		}

		/**
		 * Icon for a row without a photo: the object preset, its first
		 * category icon, else the house.
		 *
		 * @param {Object} obj Object data.
		 * @return {Element|null}
		 */
		function placeholderIcon(obj) {
			var own = obj.icon && obj.icon.preset ? ctx.icon(obj.icon.preset) : null;
			if (own) {
				return own;
			}
			var list = ctx.categories || [];
			var slug = (obj.categories || [])[0];
			for (var i = 0; i < list.length; i++) {
				if (list[i].slug === slug && list[i].icon) {
					var svg = ctx.icon(list[i].icon);
					if (svg) {
						return svg;
					}
				}
			}
			return ctx.icon('home') || parts.icon('pin');
		}

		/**
		 * One list row.
		 *
		 * @param {Object} obj Object data.
		 * @return {HTMLElement}
		 */
		function item(obj) {
			var li = make('li', B + '__li');
			var btn = make('button', B + '__item');
			var body = make('span', B + '__item-body');
			var img = parts.photo(obj, { size: 'thumb', className: B + '__img' }) || parts.photo(obj, { size: 'photo', className: B + '__img' });
			btn.type = 'button';
			btn.setAttribute('data-id', String(obj.id));
			if (same(obj.id, selectedId)) {
				btn.setAttribute('aria-current', 'true');
			}
			if (img) {
				btn.appendChild(img);
			} else {
				var none = make('span', B + '__img ' + B + '__img--none');
				add(none, placeholderIcon(obj));
				btn.appendChild(none);
			}
			add(body, parts.cat(obj, ctx));
			body.appendChild(make('span', B + '__item-title', obj.title || ''));
			if (obj.address) {
				body.appendChild(make('span', B + '__item-sub', obj.address));
			}
			btn.appendChild(body);
			btn.addEventListener('click', function () {
				ctx.select(obj.id, 'list');
			});
			li.appendChild(btn);
			return li;
		}

		/**
		 * Add the next portion of rows.
		 */
		function appendPage() {
			var frag = document.createDocumentFragment();
			var end = Math.min(viewList.length, shown + PAGE);
			for (var i = shown; i < end; i++) {
				frag.appendChild(item(viewList[i]));
			}
			listEl.appendChild(frag);
			shown = end;
			moreWrap.hidden = shown >= viewList.length;
		}

		/**
		 * Names of the categories present in the list, for the line under the count.
		 *
		 * @param {Array} list Objects.
		 * @return {string}
		 */
		function catSummary(list) {
			var present = {};
			list.forEach(function (obj) {
				(obj.categories || []).forEach(function (slug) {
					present[slug] = true;
				});
			});
			var names = (ctx.categories || []).filter(function (cat) {
				return present[cat.slug] && cat.name;
			}).map(function (cat) {
				return cat.name;
			});
			return names.length > 3 ? names.slice(0, 3).join(', ') + ', …' : names.join(', ');
		}

		/**
		 * Update the category boxes from the core filter.
		 *
		 * @param {Array} active Active category slugs.
		 */
		function syncCats(active) {
			if (!cats) {
				return;
			}
			var names = [];
			cats.inputs.forEach(function (box) {
				box.checked = active.indexOf(box.value) !== -1;
				if (box.checked) {
					names.push(box.getAttribute('data-name'));
				}
			});
			cats.picked.textContent = String(names.length);
			cats.picked.hidden = !names.length;
			cats.summary.textContent = names.join(', ');
		}

		/**
		 * Render the list for the current filter, search and sort.
		 */
		function render() {
			frame = 0;
			if (!listEl) {
				return;
			}
			var view = ctx.view();
			viewList = view.objects || [];
			countEl.textContent = countText(i18n, viewList.length);
			subEl.textContent = catSummary(viewList);
			subEl.hidden = !subEl.textContent;
			empty(listEl);
			shown = 0;
			appendPage();
			emptyEl.hidden = viewList.length > 0;
			if (!viewList.length) {
				var tpl = (view.cats && view.cats.length) ? t('emptyQueryCats', 'No objects match “%s” in the selected categories.') : t('emptyQuery', 'No objects match “%s”.');
				emptyText.textContent = tpl.split('%s').join(view.query || '');
			}
			syncCats(view.cats || []);
			if (!card) {
				measure();
				if (sheet.position()) {
					sheet.set(sheet.position());
				}
			}
		}

		/**
		 * Render on the next frame (filter and marker events come in pairs).
		 */
		function schedule() {
			if (!frame) {
				frame = requestAnimationFrame(render);
			}
		}

		/**
		 * Build the category block: one collapsed line, boxes with colour and count.
		 *
		 * @return {HTMLElement|null}
		 */
		function buildCats() {
			var counts = {};
			(ctx.objects || []).forEach(function (obj) {
				(obj.categories || []).forEach(function (slug) {
					counts[slug] = (counts[slug] || 0) + 1;
				});
			});
			var list = (ctx.categories || []).filter(function (cat) {
				return counts[cat.slug];
			});
			if (list.length < 2) {
				return null;
			}
			var wrap = make('div', B + '__cats');
			var toggle = make('button', B + '__catshead');
			var bodyId = B + '-' + (++uid) + '-cats';
			var body = make('div', B + '__catbody');
			var ul = make('ul', B + '__catlist');
			var picked = make('span', B + '__picked');
			var summary = make('span', B + '__summary');
			var extra = [];
			var inputs = [];

			toggle.type = 'button';
			toggle.setAttribute('aria-expanded', 'false');
			toggle.setAttribute('aria-controls', bodyId);
			toggle.appendChild(make('span', B + '__catsname', t('categories', 'Categories')));
			picked.hidden = true;
			toggle.appendChild(picked);
			toggle.appendChild(summary);
			add(toggle, parts.icon('chev-d', 'sm'), B + '__chev');
			body.id = bodyId;
			body.hidden = true;
			toggle.addEventListener('click', function () {
				var open = 'true' !== toggle.getAttribute('aria-expanded');
				toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
				body.hidden = !open;
				if (open && ctx.isPhone() && sheet.position() && 'full' !== sheet.position()) {
					sheet.set('full');
				}
			});

			list.forEach(function (cat, i) {
				var li = make('li', '');
				var label = make('label', B + '__cat');
				var box = document.createElement('input');
				var mark = make('span', B + '__box');
				box.type = 'checkbox';
				box.value = cat.slug;
				box.setAttribute('data-name', cat.name || cat.slug);
				if (COLOR.test(cat.color || '')) {
					label.style.setProperty('--mvweb-om-ui-c', cat.color);
				}
				mark.appendChild(checkIcon());
				label.appendChild(box);
				label.appendChild(mark);
				label.appendChild(make('span', B + '__catname', cat.name || cat.slug));
				label.appendChild(make('span', B + '__catcount', String(counts[cat.slug])));
				li.appendChild(label);
				if (i >= CATS_SHOWN) {
					li.hidden = true;
					extra.push(li);
				}
				ul.appendChild(li);
				inputs.push(box);
			});
			ul.addEventListener('change', function () {
				ctx.setCats(inputs.filter(function (box) {
					return box.checked;
				}).map(function (box) {
					return box.value;
				}));
			});
			body.appendChild(ul);

			if (extra.length) {
				var more = make('button', B + '__catmore', t('moreCats', 'More categories') + ' · ' + extra.length);
				more.type = 'button';
				more.addEventListener('click', function () {
					extra.forEach(function (li) { li.hidden = false; });
					more.parentNode.removeChild(more);
					var first = extra[0].querySelector('input');
					if (first) {
						first.focus();
					}
				});
				body.appendChild(more);
			}

			wrap.appendChild(toggle);
			wrap.appendChild(body);
			cats = { inputs: inputs, picked: picked, summary: summary };
			return wrap;
		}

		/**
		 * Action links: Call, Directions, More. The first one present is the main one.
		 *
		 * @param {Object} obj Object data.
		 * @return {HTMLElement|null}
		 */
		function actions(obj) {
			var bar = make('div', B + '__bar');
			var primary = obj.phone ? 'call' : (data.showRoute ? 'route' : 'more');
			['call', 'route', 'more'].forEach(function (key) {
				var opts = { call: false, route: false, more: false };
				opts[key] = true;
				var wrap = parts.actions(obj, ctx, opts);
				var link = wrap ? wrap.firstChild : null;
				if (!link) {
					return;
				}
				link.className = B + '__act mvweb-om-ui__focus' + (key === primary ? ' ' + B + '__act--main' : '');
				if (!link.querySelector('svg')) {
					var arrow = parts.icon('arrow');
					if (arrow) {
						link.insertBefore(arrow, link.firstChild);
					}
				}
				bar.appendChild(link);
			});
			return bar.childNodes.length ? bar : null;
		}

		/**
		 * Build the object card (phone sheet and desktop window share it).
		 *
		 * @param {Object}   obj     Object data.
		 * @param {Function} onClose Close button handler.
		 * @return {Object} { el, head, close, gallery, titleId }
		 */
		function buildCard(obj, onClose) {
			var el = make('div', B + '__card');
			var scroll = make('div', B + '__scroll');
			var top = make('div', B + '__chead');
			var title = parts.title(obj, B + '__title');
			var closeBtn = parts.close(t('close', 'Close'), onClose, 'mvweb-om-ui__icon-btn--plain ' + B + '__close');
			var gal = null;

			add(top, parts.cat(obj, ctx));
			title.id = B + '-title-' + (++uid);
			title.setAttribute('data-sheet-title', '');
			top.appendChild(title);
			add(top, parts.rows(obj, ctx, { phone: false, hours: false }), B + '__addr');
			top.appendChild(closeBtn);
			scroll.appendChild(top);

			var urls = parts.photoUrls(obj);
			if (urls.length) {
				gal = shared.gallery(ctx, { urls: urls, counter: true, dots: true, alt: obj.title || '' });
				add(scroll, gal.el, B + '__gal');
			}

			var body = make('div', B + '__cbody');
			var info = make('div', B + '__info');
			var facts = make('div', B + '__facts');
			add(info, parts.rows(obj, ctx, { address: false }), B + '__meta');
			if (obj.excerpt) {
				info.appendChild(make('p', B + '__excerpt', obj.excerpt));
			}
			add(info, parts.links(obj), B + '__links');
			var specs = parts.specs(obj, ctx, { tiles: true });
			if (specs) {
				facts.appendChild(make('div', B + '__label', t('specs', 'Characteristics')));
				add(facts, specs, B + '__specs');
			}
			[info, facts].forEach(function (part) {
				if (part.firstChild) {
					body.appendChild(part);
				}
			});
			if (body.childNodes.length) {
				body.classList.toggle(B + '__cbody--one', 1 === body.childNodes.length);
				scroll.appendChild(body);
			}
			el.appendChild(scroll);
			add(el, actions(obj));
			return { el: el, head: top, close: closeBtn, gallery: gal, titleId: title.id };
		}

		/**
		 * Visible height of the half position in px.
		 *
		 * @return {number}
		 */
		function halfHeight() {
			var raw = getComputedStyle(sheet.el).getPropertyValue('--mvweb-om-sheet-half').trim();
			var n = parseFloat(raw);
			if (isNaN(n)) {
				return 0;
			}
			if (/%$/.test(raw)) {
				return host.clientHeight * n / 100;
			}
			return /px$/.test(raw) ? n : 0;
		}

		/**
		 * Phone: show an object in the sheet.
		 *
		 * @param {Object} obj      Object data.
		 * @param {string} position Sheet position.
		 */
		function showCard(obj, position) {
			if (!sheet.position()) {
				openSheet('peek', false);
			}
			if (!card) {
				listPos = sheet.position() || 'peek';
				listScroll = sheet.body.scrollTop;
			}
			if (gallery) {
				gallery.destroy();
				gallery = null;
			}
			var built = buildCard(obj, function () {
				ctx.select(null, 'mobile');
			});
			empty(cardView);
			cardView.appendChild(built.el);
			gallery = built.gallery;
			cardHead = built.head;
			card = obj;
			listView.hidden = true;
			cardView.hidden = false;
			sheet.body.scrollTop = 0;
			sheet.relabel();
			measure();
			if ('full' === position && built.el.offsetHeight + sheet.body.offsetTop <= halfHeight()) {
				position = 'half';
			}
			sheet.set(position);
			quietFocus = true;
			built.close.focus({ preventScroll: true });
			quietFocus = false;
		}

		/**
		 * Phone: back from the card to the list.
		 */
		function hideCard() {
			if (!card) {
				return;
			}
			var id = card.id;
			var hadFocus = cardView.contains(document.activeElement);
			if (gallery) {
				gallery.destroy();
				gallery = null;
			}
			card = null;
			cardHead = null;
			empty(cardView);
			cardView.hidden = true;
			listView.hidden = false;
			sheet.relabel();
			markCurrent();
			if (sheet.position()) {
				measure();
				sheet.set(listPos);
				sheet.body.scrollTop = listScroll;
			}
			if (hadFocus) {
				var row = listEl.querySelector('.' + B + '__item[data-id="' + String(id).replace(/"/g, '') + '"]');
				var target = row || sheet.el.querySelector('.mvweb-om-ui__sheet-handle');
				if (target) {
					target.focus({ preventScroll: true });
				}
			}
		}

		/**
		 * Desktop: close the window on a click on the backdrop.
		 *
		 * @param {MouseEvent} e Click.
		 */
		function onBackdrop(e) {
			if (e.target !== dlg) {
				return;
			}
			var r = dlg.getBoundingClientRect();
			if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) {
				finishPc(true);
			}
		}

		/**
		 * Desktop: open the object window, or swap its content.
		 *
		 * @param {Object} obj Object data.
		 */
		function showPc(obj) {
			if (pc) {
				if (pc.gallery) {
					pc.gallery.destroy();
				}
			} else {
				ctx.focus.remember();
			}
			var built = buildCard(obj, function () {
				finishPc(true);
			});
			empty(dlg);
			dlg.appendChild(built.el);
			dlg.setAttribute('aria-labelledby', built.titleId);
			dlg.classList.toggle(B + '__dlg--plain', !built.gallery);
			var first = !pc;
			pc = { id: obj.id, gallery: built.gallery };
			if (first) {
				dlg.showModal();
				ctx.lock();
			}
			built.close.focus();
		}

		/**
		 * Desktop: close the object window.
		 *
		 * @param {boolean} fromUser Closed on screen: clear the selection in the core.
		 */
		function finishPc(fromUser) {
			if (!pc) {
				return;
			}
			var done = pc;
			pc = null;
			if (dlg.open) {
				dlg.close();
			}
			if (done.gallery) {
				done.gallery.destroy();
			}
			empty(dlg);
			ctx.unlock();
			ctx.focus.restore();
			if (fromUser) {
				ctx.select(null, 'mobile');
			}
		}

		/**
		 * Build the sheet with the list view and the card slot, and the desktop window.
		 */
		function build() {
			listView = make('div', B + '__list-view');
			cardView = make('div', B + '__card-view');
			cardView.hidden = true;

			var top = make('div', B + '__top');
			head = make('div', B + '__head');
			head.setAttribute('data-sheet-drag', '');
			countEl = make('div', B + '__count');
			countEl.setAttribute('role', 'status');
			countEl.setAttribute('data-sheet-title', '');
			subEl = make('div', B + '__sub');
			head.appendChild(countEl);
			head.appendChild(subEl);
			top.appendChild(head);

			var search = make('div', B + '__search');
			var label = make('label', B + '__field');
			input = document.createElement('input');
			input.type = 'search';
			input.className = B + '__input';
			input.setAttribute('autocomplete', 'off');
			input.setAttribute('enterkeyhint', 'search');
			input.setAttribute('placeholder', 'classic' === variants.list ? t('search', 'Search objects…') : t('searchHint', 'Name or address'));
			add(label, parts.icon('search', 'sm'), B + '__field-icon');
			label.appendChild(parts.sr(t('searchLabel', 'Search objects')));
			label.appendChild(input);
			search.appendChild(label);
			top.appendChild(search);
			input.addEventListener('input', function () {
				clearTimeout(searchTimer);
				searchTimer = setTimeout(function () {
					ctx.setQuery(input.value);
				}, SEARCH_DELAY);
			});
			input.addEventListener('keydown', function (e) {
				if ('Enter' === e.key) {
					input.blur();
				}
			});
			listView.appendChild(top);

			if (useCats) {
				add(listView, buildCats());
			}

			listEl = make('ul', B + '__items');
			listEl.setAttribute('aria-label', t('objectsLabel', 'Objects'));
			listView.appendChild(listEl);

			moreWrap = make('div', B + '__more');
			var more = make('button', 'mvweb-om-ui__btn mvweb-om-ui__btn--outline ' + B + '__more-btn', t('showMore', 'Show more'));
			more.type = 'button';
			more.addEventListener('click', function () {
				var from = shown;
				appendPage();
				var row = listEl.children[from];
				var btn = row ? row.querySelector('button') : null;
				if (btn) {
					btn.focus({ preventScroll: true });
				}
			});
			moreWrap.appendChild(more);
			listView.appendChild(moreWrap);

			emptyEl = make('div', B + '__empty');
			emptyEl.hidden = true;
			add(emptyEl, parts.icon('search'), B + '__empty-icon');
			emptyEl.appendChild(make('div', B + '__empty-title', t('emptyTitle', 'Nothing found')));
			emptyText = make('div', B + '__empty-text');
			emptyEl.appendChild(emptyText);
			var reset = make('button', 'mvweb-om-ui__btn mvweb-om-ui__btn--outline', t('resetSearch', 'Clear search'));
			reset.type = 'button';
			reset.addEventListener('click', function () {
				input.value = '';
				ctx.setQuery('');
				if (cats && ctx.view().cats.length) {
					ctx.setCats([]);
				}
				input.focus();
			});
			emptyEl.appendChild(reset);
			listView.appendChild(emptyEl);

			sheet = shared.sheet(sheetCtx, {
				host: host,
				owner: OWNER,
				positions: ['peek', 'half', 'full'],
				initial: 'peek',
				modal: false,
				onChange: onPosition,
				onClose: onSheetClose
			});
			sheet.el.classList.add(B + '__sheet');
			sheet.body.appendChild(cardView);
			sheet.body.appendChild(listView);
			sheet.body.addEventListener('focusin', onFocusIn);

			dlg = make('dialog', B + '__dlg');
			dlg.addEventListener('click', onBackdrop);
			dlg.addEventListener('close', function () {
				if (!dlg.open) {
					finishPc(true);
				}
			});
			root.appendChild(dlg);
		}

		/**
		 * Remember who selected an object.
		 *
		 * @param {Object} payload Select event: { id, source }.
		 */
		function onSelect(payload) {
			selectedId = payload ? payload.id : null;
			lastSource = payload ? payload.source : '';
			markCurrent();
		}

		/**
		 * The selection was cleared.
		 */
		function onDeselect() {
			selectedId = null;
			markCurrent();
		}

		/**
		 * Switch between the phone sheet and the desktop window.
		 */
		function applyLayout() {
			var phone = ctx.isPhone();
			root.classList.toggle(B + '--phone', phone);
			if (phone) {
				var keep = pc ? byId(pc.id) : null;
				finishPc(false);
				if (!sheet.position()) {
					openSheet('peek', false);
				}
				if (keep) {
					showCard(keep, 'half');
				}
			} else {
				var obj = card;
				if (card) {
					hideCard();
				}
				closeSheet();
				if (obj && same(obj.id, selectedId)) {
					showPc(obj);
				}
			}
		}

		return {
			minMap: null,

			/**
			 * Build the sheet and the window, subscribe to the core.
			 */
			mount: function () {
				host = root.querySelector('.mvweb-om__map');
				if (!host) {
					throw new Error('mobile/sheet: no map container');
				}
				build();
				ctx.on('select', onSelect);
				ctx.on('deselect', onDeselect);
				ctx.on('filter', schedule);
				ctx.on('visible', schedule);
				phoneQuery.addEventListener('change', applyLayout);
				render();
				applyLayout();
			},

			/**
			 * Phone: open the object in the sheet. A marker raises the sheet to
			 * half height, the list and other sources to the top.
			 *
			 * @param {Object} obj Object data.
			 */
			open: function (obj) {
				if (!obj || !sheet) {
					return;
				}
				var fromMarker = 'marker' === lastSource;
				lastSource = '';
				var position = 'full';
				if (fromMarker) {
					position = (card && 'full' === sheet.position()) ? 'full' : 'half';
				}
				showCard(obj, position);
				if (fromMarker) {
					ctx.flyTo(obj, null);
				}
			},

			/**
			 * Desktop: the object window centred over the page.
			 *
			 * @param {Object} obj Object data.
			 */
			detailPc: function (obj) {
				if (obj && dlg) {
					showPc(obj);
				}
			},

			/**
			 * Close the object view (called by the core). Safe to call repeatedly.
			 */
			close: function () {
				finishPc(false);
				hideCard();
			},

			/**
			 * Remove everything this module added.
			 */
			destroy: function () {
				finishPc(false);
				clearTimeout(searchTimer);
				if (frame) {
					cancelAnimationFrame(frame);
					frame = 0;
				}
				ctx.off('select', onSelect);
				ctx.off('deselect', onDeselect);
				ctx.off('filter', schedule);
				ctx.off('visible', schedule);
				phoneQuery.removeEventListener('change', applyLayout);
				if (gallery) {
					gallery.destroy();
					gallery = null;
				}
				card = null;
				closeSheet();
				if (sheet) {
					sheet.body.removeEventListener('focusin', onFocusIn);
					sheet.destroy();
					sheet = null;
				}
				if (dlg && dlg.parentNode) {
					dlg.parentNode.removeChild(dlg);
				}
				root.classList.remove(B + '--phone');
			}
		};
	});
})();
