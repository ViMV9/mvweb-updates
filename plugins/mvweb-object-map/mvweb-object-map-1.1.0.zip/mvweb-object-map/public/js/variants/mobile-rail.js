/**
 * Phone and object window variant "rail" (D2).
 *
 * Phone: a rail of object cards lies over the bottom of the map and is tied
 * to the markers. The centre card highlights its marker and brings it into
 * the free part of the map; a tap on a marker scrolls the rail to its card.
 * A tap on a card opens the object full screen: title, address and an
 * "On the map" button, photos in a row, details and a bottom bar with Call,
 * Directions and More. The classic tabs and the classic list are hidden.
 * Desktop: the same object window centred over the page with a column of
 * buttons on the right.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var B = 'mvweb-om-mobile-rail';
	var OWNER = 'rail';
	var PHONE_QUERY = '(max-width: 782px)';
	var LIMIT = 30;
	var SETTLE = 250;
	var QUIET = 900;
	var ZOOM = 16;
	var EDGE = 16;
	var uid = 0;

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		if (cls) {
			el.className = cls;
		}
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * Append a node when it exists.
	 *
	 * @param {HTMLElement}      parent Parent element.
	 * @param {HTMLElement|null} child  Child or null.
	 * @param {string}           cls    Extra class for the child (optional).
	 */
	function add(parent, child, cls) {
		if (!child) {
			return;
		}
		if (cls) {
			child.classList.add(cls);
		}
		parent.appendChild(child);
	}

	/**
	 * Same object id.
	 *
	 * @param {*} a Id.
	 * @param {*} b Id.
	 * @return {boolean}
	 */
	function same(a, b) {
		return null !== a && null !== b && undefined !== a && undefined !== b && String(a) === String(b);
	}

	/**
	 * Index of an object in a list by id.
	 *
	 * @param {Array} list Objects.
	 * @param {*}     id   Object id.
	 * @return {number}
	 */
	function indexOf(list, id) {
		for (var i = 0; i < list.length; i++) {
			if (same(list[i].id, id)) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Normalise map bounds to { w, e, s, n }.
	 *
	 * @param {Array} bounds Two [lng, lat] corners.
	 * @return {Object|null}
	 */
	function box(bounds) {
		if (!bounds || !bounds[0] || !bounds[1]) {
			return null;
		}
		var a = bounds[0];
		var b = bounds[1];
		if (isNaN(a[0]) || isNaN(a[1]) || isNaN(b[0]) || isNaN(b[1])) {
			return null;
		}
		return {
			w: Math.min(a[0], b[0]),
			e: Math.max(a[0], b[0]),
			s: Math.min(a[1], b[1]),
			n: Math.max(a[1], b[1])
		};
	}

	api.register('mobile', 'rail', function (ctx) {
		var shared = api.shared || {};
		var parts = shared.parts;
		if (!parts || typeof shared.rail !== 'function' || typeof shared.gallery !== 'function') {
			return null;
		}

		var i18n = ctx.i18n || {};
		var data = ctx.data || {};
		var root = ctx.root;
		var phoneQuery = window.matchMedia(PHONE_QUERY);
		var titleId = B + '-' + (++uid) + '-title';

		var host = null;
		var canvas = null;
		var dock = null;
		var found = null;
		var rail = null;
		var dlg = null;
		var closeBtn = null;
		var scroller = null;
		var bar = null;

		var items = [];
		var itemsKey = '';
		var total = 0;
		var activeId = null;
		var selectedId = null;
		var lastSource = '';
		var bounds = null;
		var hovered = false;
		var quietUntil = 0;
		var timer = 0;
		var current = null;
		var layers = [];
		var skipPop = 0;

		/**
		 * Text with a fallback.
		 *
		 * @param {string} key      i18n key.
		 * @param {string} fallback English text.
		 * @return {string}
		 */
		function t(key, fallback) {
			return i18n[key] || fallback;
		}

		/**
		 * Object by id from all loaded objects.
		 *
		 * @param {*} id Object id.
		 * @return {Object|null}
		 */
		function byId(id) {
			var list = ctx.objects || [];
			var at = indexOf(list, id);
			return at === -1 ? null : list[at];
		}

		/**
		 * Current map bounds: the last viewport event, else the map itself.
		 *
		 * @return {Object|null}
		 */
		function mapBounds() {
			if (bounds) {
				return bounds;
			}
			try {
				return box(ctx.map && ctx.map.bounds);
			} catch (err) {
				return null;
			}
		}

		/**
		 * Objects for the rail: the list as filtered and sorted by the core.
		 * Above LIMIT only the objects inside the map bounds nearest to the
		 * centre are kept. The active object always stays.
		 *
		 * @return {Array}
		 */
		function collect() {
			var list = ctx.view().objects || [];
			total = list.length;
			if (list.length <= LIMIT) {
				return list.slice();
			}
			var area = mapBounds();
			var cx = area ? (area.w + area.e) / 2 : 0;
			var cy = area ? (area.s + area.n) / 2 : 0;
			var rows = [];
			list.forEach(function (obj, i) {
				var keep = same(obj.id, activeId);
				if (area && !keep && (obj.lng < area.w || obj.lng > area.e || obj.lat < area.s || obj.lat > area.n)) {
					return;
				}
				rows.push({ obj: obj, i: i, d: keep ? -1 : (area ? Math.pow(obj.lng - cx, 2) + Math.pow(obj.lat - cy, 2) : i) });
			});
			rows.sort(function (a, b) {
				return a.d - b.d;
			});
			return rows.slice(0, LIMIT).sort(function (a, b) {
				return a.i - b.i;
			}).map(function (row) {
				return row.obj;
			});
		}

		/**
		 * Highlight the marker of the active object (phone only).
		 */
		function light() {
			if (!ctx.isPhone() || null === activeId) {
				return;
			}
			hovered = true;
			ctx.hover(activeId);
		}

		/**
		 * Clear the highlight this module set.
		 */
		function unlight() {
			if (hovered) {
				hovered = false;
				ctx.hover(null);
			}
		}

		/**
		 * Reserve the bottom of the map under the rail so the map centres
		 * objects above it.
		 */
		function insets() {
			if (!ctx.isPhone() || !dock || dock.hidden) {
				ctx.setInsets(OWNER, null);
				return;
			}
			ctx.setInsets(OWNER, { b: Math.max(0, host.clientHeight - dock.offsetTop) });
		}

		/**
		 * Rebuild the rail when its objects changed and keep the active card in
		 * the centre.
		 *
		 * @param {boolean} force Rebuild even when the objects are the same.
		 */
		function refresh(force) {
			if (!rail) {
				return;
			}
			var next = collect();
			var key = next.map(function (obj) { return obj.id; }).join(',');
			var text = t('found', 'Found: %d').replace('%d', String(total));
			if (found.textContent !== text) {
				found.textContent = text;
			}
			dock.hidden = !total;
			rail.el.hidden = !next.length;
			if (force || key !== itemsKey) {
				items = next;
				itemsKey = key;
				rail.setItems(items);
				var at = indexOf(items, activeId);
				if (at === -1) {
					activeId = items.length ? items[0].id : null;
					light();
				} else if (at > 0) {
					rail.scrollTo(at, false);
				}
			}
			insets();
		}

		/**
		 * Move the map without letting the move rebuild the rail.
		 *
		 * @param {Object} obj  Object data.
		 * @param {Object} opts flyTo options.
		 */
		function move(obj, opts) {
			quietUntil = Date.now() + QUIET;
			ctx.flyTo(obj, opts || {});
		}

		/**
		 * Bring the active marker into the free part of the map when it is
		 * hidden: inside a cluster it zooms in, off screen or under the rail it
		 * pans.
		 *
		 * @param {Object} obj Object data.
		 */
		function reveal(obj) {
			var el = root.querySelector('.mvweb-om__marker--hover');
			var zoom = (ctx.map && ctx.map.zoom) || 0;
			if (!el) {
				move(obj, zoom < ZOOM ? { zoom: ZOOM } : {});
				return;
			}
			var r = el.getBoundingClientRect();
			var m = canvas.getBoundingClientRect();
			var bottom = dock.hidden ? m.bottom : dock.getBoundingClientRect().top;
			var x = r.left + r.width / 2;
			var y = r.top + r.height / 2;
			if (x < m.left + EDGE || x > m.right - EDGE || y < m.top + EDGE || y > bottom - EDGE) {
				move(obj);
			}
		}

		/**
		 * A new card came to the centre of the rail.
		 *
		 * @param {Object} obj Object data.
		 */
		function onActive(obj) {
			activeId = obj.id;
			if (null !== selectedId && !same(selectedId, obj.id)) {
				ctx.select(null);
			}
			if (!ctx.isPhone()) {
				return;
			}
			light();
			reveal(obj);
		}

		/**
		 * Scroll the rail to an object and highlight its marker.
		 *
		 * @param {Object}  obj    Object data.
		 * @param {boolean} smooth Animate the rail.
		 */
		function focusCard(obj, smooth) {
			activeId = obj.id;
			refresh(false);
			var at = indexOf(items, obj.id);
			if (at !== -1) {
				rail.scrollTo(at, smooth);
			}
			light();
		}

		/**
		 * Build one rail card.
		 *
		 * @param {Object} obj Object data.
		 * @return {HTMLElement}
		 */
		function card(obj) {
			var btn = make('button', B + '__card');
			var body = make('span', B + '__body');
			var img = parts.photo(obj, { size: 'thumb', className: B + '__img' }) || parts.photo(obj, { size: 'photo', className: B + '__img' });
			btn.type = 'button';
			if (img) {
				btn.appendChild(img);
			} else {
				var none = make('span', B + '__img ' + B + '__img--none');
				add(none, placeholderIcon(obj));
				btn.appendChild(none);
			}
			add(body, parts.cat(obj, ctx));
			body.appendChild(make('span', B + '__name', obj.title || ''));
			if (obj.address) {
				body.appendChild(make('span', B + '__sub', obj.address));
			}
			add(body, parts.facts(obj, ctx, { flag: 'balloon', max: 3 }));
			btn.appendChild(body);
			btn.addEventListener('click', function () {
				ctx.select(obj.id, 'api');
			});
			return btn;
		}

		/**
		 * Icon for a card without a photo: the object preset, its first
		 * category icon, else the house.
		 *
		 * @param {Object} obj Object data.
		 * @return {SVGElement|null}
		 */
		function placeholderIcon(obj) {
			var own = obj.icon && obj.icon.preset ? ctx.icon(obj.icon.preset) : null;
			if (own) {
				return own;
			}
			var cats = ctx.categories || [];
			var slug = (obj.categories || [])[0];
			for (var i = 0; i < cats.length; i++) {
				if (cats[i].slug === slug && cats[i].icon) {
					var svg = ctx.icon(cats[i].icon);
					if (svg) {
						return svg;
					}
				}
			}
			return ctx.icon('home') || parts.icon('pin');
		}

		/**
		 * Put a history entry so the system Back button closes the object (phone).
		 *
		 * @return {boolean} Whether an entry was added.
		 */
		function pushLayer() {
			if (!ctx.isPhone() || !window.history || typeof history.pushState !== 'function') {
				return false;
			}
			history.pushState({ mvwebOm: 'object' }, '');
			layers.push('object');
			return true;
		}

		/**
		 * Remove the history entry of an object closed on screen.
		 */
		function popLayer() {
			var at = layers.lastIndexOf('object');
			if (at === -1) {
				return;
			}
			layers.splice(at, 1);
			skipPop++;
			history.back();
		}

		/**
		 * Back button: close the object.
		 */
		function onPop() {
			if (skipPop > 0) {
				skipPop--;
				return;
			}
			if ('object' === layers.pop()) {
				finish(true, true);
			}
		}

		/**
		 * Close the object window on a click on the backdrop (desktop window).
		 *
		 * @param {MouseEvent} e Click.
		 */
		function onBackdrop(e) {
			if (e.target !== dlg) {
				return;
			}
			var r = dlg.getBoundingClientRect();
			if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) {
				finish(true, false);
			}
		}

		/**
		 * Close the object and show it on the map.
		 */
		function toMap() {
			var obj = current ? byId(current.id) : null;
			finish(true, false);
			if (!obj) {
				return;
			}
			if (ctx.isPhone()) {
				focusCard(obj, false);
			}
			move(obj, { zoom: ZOOM });
		}

		/**
		 * Build the rail over the map and the object window.
		 */
		function build() {
			dock = make('div', B + '__dock');
			found = make('span', B + '__found');
			found.setAttribute('role', 'status');
			dock.appendChild(found);
			rail = shared.rail(ctx, {
				host: dock,
				items: [],
				render: card,
				onActive: onActive,
				label: t('railLabel', 'Objects on the map'),
				arrows: false
			});
			rail.el.classList.add(B + '__rail');
			host.appendChild(dock);

			dlg = make('dialog', B + '__dlg');
			dlg.setAttribute('aria-labelledby', titleId);
			closeBtn = parts.iconButton('close', t('close', 'Close'), function () {
				finish(true, false);
			}, 'mvweb-om-ui__icon-btn--plain ' + B + '__close');
			scroller = make('div', B + '__scroll');
			bar = make('div', B + '__bar');
			dlg.appendChild(closeBtn);
			dlg.appendChild(scroller);
			dlg.appendChild(bar);
			dlg.addEventListener('click', onBackdrop);
			dlg.addEventListener('close', function () {
				if (!dlg.open) {
					finish(true, false);
				}
			});
			root.appendChild(dlg);
		}

		/**
		 * Action buttons in the order Call, Directions, More. The first one
		 * present is the filled button.
		 *
		 * @param {Object} obj Object data.
		 * @return {HTMLElement|null}
		 */
		function actions(obj) {
			var keys = ['call', 'route', 'more'];
			var wrap = make('div', 'mvweb-om-ui__actions ' + B + '__acts');
			var primary = obj.phone ? 'call' : (data.showRoute ? 'route' : 'more');
			keys.forEach(function (key) {
				var opts = { call: false, route: false, more: false, primary: primary };
				opts[key] = true;
				var one = parts.actions(obj, ctx, opts);
				var link = one ? one.firstChild : null;
				if (!link) {
					return;
				}
				link.classList.add(B + '__act', B + '__act--' + key);
				if ('call' === key) {
					link.appendChild(make('span', B + '__num', obj.phone));
				} else if ('more' === key && !link.querySelector('svg')) {
					var arrow = parts.icon('arrow', 'sm');
					if (arrow) {
						link.insertBefore(arrow, link.firstChild);
					}
				}
				wrap.appendChild(link);
			});
			return wrap.childNodes.length ? wrap : null;
		}

		/**
		 * Fill the object window.
		 *
		 * @param {Object} obj Object data.
		 * @return {Object|null} Gallery instance.
		 */
		function fill(obj) {
			scroller.textContent = '';
			bar.textContent = '';

			var intro = make('div', B + '__intro');
			var head = make('div', B + '__head');
			add(head, parts.cat(obj, ctx));
			var title = parts.title(obj, B + '__title');
			title.id = titleId;
			head.appendChild(title);
			add(head, parts.rows(obj, ctx, { phone: false, hours: false }), B + '__addr');
			intro.appendChild(head);

			var onMap = make('button', 'mvweb-om-ui__btn mvweb-om-ui__btn--outline ' + B + '__onmap');
			onMap.type = 'button';
			add(onMap, parts.icon('map', 'sm'));
			onMap.appendChild(make('span', '', t('onMap', 'On the map')));
			onMap.addEventListener('click', toMap);
			intro.appendChild(onMap);
			scroller.appendChild(intro);

			var urls = (obj.gallery && obj.gallery.length) ? obj.gallery : [obj.photo || obj.thumb || ''];
			var gal = shared.gallery(ctx, { urls: urls, ratio: '4 / 3', counter: true, alt: obj.title || '' });
			if (gal.count) {
				var media = make('div', B + '__media' + (1 === gal.count ? ' ' + B + '__media--one' : ''));
				media.appendChild(gal.el);
				scroller.appendChild(media);
			}

			var main = make('div', B + '__main');
			add(main, parts.rows(obj, ctx, { address: false }), B + '__meta');
			if (obj.excerpt) {
				main.appendChild(make('p', B + '__excerpt', obj.excerpt));
			}
			var specs = parts.specs(obj, ctx, {});
			if (specs) {
				main.appendChild(make('div', B + '__label', t('specs', 'Characteristics')));
				main.appendChild(specs);
			}
			add(main, parts.links(obj));
			if (main.childNodes.length) {
				scroller.appendChild(main);
			}

			var acts = actions(obj);
			bar.hidden = !acts;
			add(bar, acts);
			dlg.classList.toggle(B + '__dlg--bare', !acts);
			scroller.scrollTop = 0;
			return gal;
		}

		/**
		 * Open the object window, or swap its content when it is open.
		 *
		 * @param {Object} obj Object data.
		 */
		function show(obj) {
			if (!dlg || !obj) {
				return;
			}
			if (current) {
				current.gallery.destroy();
				current.gallery = fill(obj);
				current.id = obj.id;
				closeBtn.focus();
				return;
			}
			ctx.focus.remember();
			current = { id: obj.id, gallery: fill(obj), pushed: false };
			dlg.showModal();
			ctx.lock();
			current.pushed = pushLayer();
		}

		/**
		 * Close the object window and clean up.
		 *
		 * @param {boolean} fromUser   Closed on screen: clear the selection in the core.
		 * @param {boolean} viaHistory Closed by the Back button.
		 */
		function finish(fromUser, viaHistory) {
			if (!current) {
				return;
			}
			var done = current;
			current = null;
			if (dlg.open) {
				dlg.close();
			}
			done.gallery.destroy();
			ctx.unlock();
			if (done.pushed && !viaHistory) {
				popLayer();
			}
			ctx.focus.restore();
			if (fromUser) {
				ctx.select(null, 'mobile');
			}
		}

		/**
		 * Remember who selected an object.
		 *
		 * @param {Object} payload Select event: { id, source }.
		 */
		function onSelect(payload) {
			selectedId = payload ? payload.id : null;
			lastSource = payload ? payload.source : '';
		}

		/**
		 * The selection was cleared.
		 */
		function onDeselect() {
			selectedId = null;
		}

		/**
		 * The list changed: filter, search, sort or redrawn markers.
		 */
		function onChange() {
			if (ctx.isPhone()) {
				refresh(false);
			}
		}

		/**
		 * The map stopped: rebuild the rail from the objects in view.
		 *
		 * @param {Object} payload Viewport event: { bounds, inAction }.
		 */
		function onViewport(payload) {
			var next = box(payload && payload.bounds);
			if (next) {
				bounds = next;
			}
			if (!payload || payload.inAction || !ctx.isPhone() || total <= LIMIT) {
				return;
			}
			clearTimeout(timer);
			timer = setTimeout(function () {
				if (Date.now() < quietUntil || current) {
					return;
				}
				refresh(false);
			}, SETTLE);
		}

		/**
		 * Switch between the phone and the desktop layout.
		 */
		function applyLayout() {
			var phone = ctx.isPhone();
			root.classList.toggle(B + '--phone', phone);
			if (phone) {
				refresh(true);
				light();
			} else {
				unlight();
				ctx.setInsets(OWNER, null);
			}
		}

		return {
			minMap: null,

			/**
			 * Build the rail and the object window, subscribe to the core.
			 */
			mount: function () {
				host = root.querySelector('.mvweb-om__map');
				canvas = root.querySelector('.mvweb-om__canvas');
				if (!host || !canvas) {
					throw new Error('mobile/rail: no map container');
				}
				build();
				ctx.on('select', onSelect);
				ctx.on('deselect', onDeselect);
				ctx.on('visible', onChange);
				ctx.on('filter', onChange);
				ctx.on('viewport', onViewport);
				window.addEventListener('popstate', onPop);
				phoneQuery.addEventListener('change', applyLayout);
				applyLayout();
			},

			/**
			 * Phone: a marker scrolls the rail to its card, anything else opens
			 * the object full screen.
			 *
			 * @param {Object} obj Object data.
			 */
			open: function (obj) {
				if (!obj) {
					return;
				}
				var fromMarker = 'marker' === lastSource;
				lastSource = '';
				focusCard(obj, fromMarker && !current);
				if (!fromMarker) {
					show(obj);
				}
			},

			/**
			 * Desktop: the object window with the button column.
			 *
			 * @param {Object} obj Object data.
			 */
			detailPc: function (obj) {
				show(obj);
			},

			/**
			 * Close the object window (called by the core).
			 */
			close: function () {
				finish(false, false);
			},

			/**
			 * Remove everything this module added.
			 */
			destroy: function () {
				finish(false, true);
				clearTimeout(timer);
				ctx.off('select', onSelect);
				ctx.off('deselect', onDeselect);
				ctx.off('visible', onChange);
				ctx.off('filter', onChange);
				ctx.off('viewport', onViewport);
				window.removeEventListener('popstate', onPop);
				phoneQuery.removeEventListener('change', applyLayout);
				unlight();
				ctx.setInsets(OWNER, null);
				if (rail) {
					rail.destroy();
					rail = null;
				}
				[dock, dlg].forEach(function (el) {
					if (el && el.parentNode) {
						el.parentNode.removeChild(el);
					}
				});
				root.classList.remove(B + '--phone');
				layers = [];
			}
		};
	});
})();
