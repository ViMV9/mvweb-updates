/**
 * List variant "table": a comparison table beside the map (under it on
 * narrow blocks and phones). Columns: the object, up to four characteristics
 * flagged for the list, the address. Number columns sort through the core.
 *
 * Object text goes in via textContent, URLs via setAttribute (shared.parts).
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var B = 'mvweb-om-list-table';
	var PAGE = 50;
	var EAGER = 4;
	var MAX_COLS = 4;
	var SPLIT_MIN = 760;
	var SEARCH_DELAY = 180;
	var COLOR = /^#[0-9a-f]{3,8}$/i;
	var SPEC_SORT = /^spec:(.+):(asc|desc)$/;
	var SVG_NS = 'http://www.w3.org/2000/svg';
	var PATHS = {
		filter: 'M4 5h16l-6 8v6l-4-2v-4z',
		sort: 'm8 9 4-4 4 4M8 15l4 4 4-4',
		dir: 'M12 5v14M6 13l6 6 6-6'
	};
	var uid = 0;

	api.register('list', 'table', function (ctx) {
		var parts = null;
		var card = {};
		var reduced = false;
		var anyPhoto = false;
		var cols = [];
		var withAddress = false;
		var byId = Object.create(null);
		var bar = null;
		var input = null;
		var found = null;
		var hint = null;
		var pop = null;
		var boxes = [];
		var toggles = [];
		var opener = null;
		var wrap = null;
		var table = null;
		var tbody = null;
		var sortThs = [];
		var empty = null;
		var emptyText = null;
		var emptyReset = null;
		var emptyAll = null;
		var showMore = null;
		var rowEls = Object.create(null);
		var objects = [];
		var shown = 0;
		var sort = 'name';
		var selectedId = null;
		var hoverId = null;
		var split = false;
		var timer = 0;
		var frame = 0;
		var observer = null;
		var handlers = {};

		/**
		 * Read a translated string.
		 *
		 * @param {string} key      Key in the i18n object.
		 * @param {string} fallback English text.
		 * @return {string}
		 */
		function t(key, fallback) {
			return (ctx.i18n && ctx.i18n[key]) || fallback;
		}

		/**
		 * Create an element with a class and optional text.
		 *
		 * @param {string} tag  Tag name.
		 * @param {string} cls  Class name.
		 * @param {string} body Text content (optional).
		 * @return {HTMLElement}
		 */
		function make(tag, cls, body) {
			var el = document.createElement(tag);
			if (cls) {
				el.className = cls;
			}
			if (body) {
				el.textContent = body;
			}
			return el;
		}

		/**
		 * Build a small stroke icon from a path.
		 *
		 * @param {string} d   Path data, viewBox 0 0 24 24.
		 * @param {string} cls Extra class.
		 * @return {SVGElement}
		 */
		function pathIcon(d, cls) {
			var svg = document.createElementNS(SVG_NS, 'svg');
			var path = document.createElementNS(SVG_NS, 'path');
			svg.setAttribute('class', 'mvweb-om-ui__icon mvweb-om-ui__icon--sm' + (cls ? ' ' + cls : ''));
			svg.setAttribute('viewBox', '0 0 24 24');
			svg.setAttribute('fill', 'none');
			svg.setAttribute('stroke', 'currentColor');
			svg.setAttribute('stroke-width', '2');
			svg.setAttribute('stroke-linecap', 'round');
			svg.setAttribute('stroke-linejoin', 'round');
			svg.setAttribute('aria-hidden', 'true');
			svg.setAttribute('focusable', 'false');
			path.setAttribute('d', d);
			svg.appendChild(path);
			return svg;
		}

		/**
		 * Filled spec row of an object by field id.
		 *
		 * @param {Object} obj Object data.
		 * @param {string} id  Field id.
		 * @return {Object|null}
		 */
		function specOf(obj, id) {
			var specs = obj.specs || [];
			for (var i = 0; i < specs.length; i++) {
				if (specs[i] && specs[i].id === id && specs[i].value) {
					return specs[i];
				}
			}
			return null;
		}

		/**
		 * Table columns: up to four fields flagged for the list that at least
		 * one object fills. A number column sorts when some value is numeric.
		 *
		 * @return {Array} [{ id, label, unit, number }]
		 */
		function buildCols() {
			var out = [];
			(ctx.schema || []).forEach(function (field) {
				if (out.length >= MAX_COLS || !field || !field.id || !field.show || field.show.indexOf('list') === -1) {
					return;
				}
				var filled = false;
				var numeric = false;
				(ctx.objects || []).forEach(function (obj) {
					var spec = specOf(obj, field.id);
					if (spec) {
						filled = true;
						numeric = numeric || 'number' === typeof spec.raw;
					}
				});
				if (filled) {
					out.push({
						id: String(field.id),
						label: field.label || String(field.id),
						unit: field.unit || '',
						number: 'number' === field.type && numeric
					});
				}
			});
			return out;
		}

		/**
		 * Text of a characteristic cell; the unit is in the column header.
		 *
		 * @param {Object} spec Spec row.
		 * @param {Object} col  Column.
		 * @return {string}
		 */
		function cellText(spec, col) {
			var value = String(spec.value);
			var tail = ' ' + col.unit;
			if (col.unit && value.length > tail.length && value.slice(-tail.length) === tail) {
				return value.slice(0, -tail.length);
			}
			return value;
		}

		/**
		 * Number of loaded objects per category slug.
		 *
		 * @return {Object}
		 */
		function countCats() {
			var counts = Object.create(null);
			(ctx.objects || []).forEach(function (obj) {
				(obj.categories || []).forEach(function (slug) {
					counts[slug] = (counts[slug] || 0) + 1;
				});
			});
			return counts;
		}

		/**
		 * Categories that have objects: [{ slug, name, color, count }].
		 *
		 * @return {Array}
		 */
		function catList() {
			var counts = countCats();
			var out = [];
			(ctx.categories || []).forEach(function (cat) {
				if (cat && cat.slug && counts[cat.slug]) {
					out.push({ slug: String(cat.slug), name: cat.name || String(cat.slug), color: cat.color, count: counts[cat.slug] });
				}
			});
			return out;
		}

		/**
		 * Icon slug for an object without a photo: object preset, first category icon, home.
		 *
		 * @param {Object} obj Object data.
		 * @return {string}
		 */
		function iconSlug(obj) {
			if (obj.icon && obj.icon.preset) {
				return String(obj.icon.preset);
			}
			var slug = '';
			(obj.categories || []).some(function (catSlug) {
				(ctx.categories || []).some(function (cat) {
					if (cat && cat.slug === catSlug && cat.icon) {
						slug = String(cat.icon);
					}
					return !!slug;
				});
				return !!slug;
			});
			return slug || 'home';
		}

		/**
		 * Build a filter toggle: the funnel icon, a label and the counter of
		 * chosen categories.
		 *
		 * @param {string}  cls     Class name.
		 * @param {boolean} visible Show the label as text.
		 * @return {HTMLButtonElement}
		 */
		function buildToggle(cls, visible) {
			var label = visible ? t('categories', 'Categories') : t('filterCats', 'Filter by category');
			var btn = make('button', cls);
			btn.type = 'button';
			btn.setAttribute('aria-expanded', 'false');
			btn.setAttribute('aria-controls', pop.id);
			btn.appendChild(pathIcon(PATHS.filter));
			btn.appendChild(make('span', visible ? B + '__toglabel' : 'mvweb-om__sr', label));
			if (!visible) {
				btn.setAttribute('title', label);
			}
			var badge = make('span', B + '__badge');
			badge.setAttribute('aria-hidden', 'true');
			badge.hidden = true;
			btn.appendChild(badge);
			btn.addEventListener('click', function () {
				setPop(pop.hidden, btn);
			});
			toggles.push(btn);
			return btn;
		}

		/**
		 * Build the category popover with check boxes.
		 *
		 * @param {Array} list Categories with objects.
		 */
		function buildPop(list) {
			pop = make('div', B + '__pop');
			pop.id = B + '-pop-' + (++uid);
			pop.hidden = true;
			var head = make('div', B + '__pophead', t('showCats', 'Show categories'));
			head.id = pop.id + '-head';
			pop.appendChild(head);
			var opts = make('ul', B + '__opts');
			opts.setAttribute('role', 'group');
			opts.setAttribute('aria-labelledby', head.id);
			list.forEach(function (cat) {
				var li = make('li', B + '__optitem');
				var label = make('label', B + '__opt');
				var box = make('input', B + '__check');
				box.type = 'checkbox';
				box.value = cat.slug;
				box.addEventListener('change', function () {
					ctx.setCats(boxes.filter(function (b) {
						return b.checked;
					}).map(function (b) {
						return b.value;
					}));
				});
				boxes.push(box);
				var dot = make('span', B + '__swatch');
				dot.setAttribute('aria-hidden', 'true');
				if (COLOR.test(cat.color || '')) {
					dot.style.setProperty('--mvweb-om-table-c', cat.color);
				}
				label.appendChild(box);
				label.appendChild(dot);
				label.appendChild(make('span', B + '__optname', cat.name));
				label.appendChild(make('span', B + '__count', String(cat.count)));
				li.appendChild(label);
				opts.appendChild(li);
			});
			pop.appendChild(opts);

			var foot = make('div', B + '__popfoot');
			var all = make('button', B + '__link', t('allCategories', 'All categories'));
			all.type = 'button';
			all.addEventListener('click', function () {
				ctx.setCats([]);
			});
			var done = make('button', 'mvweb-om-ui__btn ' + B + '__done', t('done', 'Done'));
			done.type = 'button';
			done.addEventListener('click', function () {
				setPop(false);
			});
			foot.appendChild(all);
			foot.appendChild(done);
			pop.appendChild(foot);
			pop.addEventListener('keydown', onPopKey);
		}

		/**
		 * Open or close the category popover.
		 *
		 * @param {boolean}     open Open state.
		 * @param {HTMLElement} from Toggle that opened it.
		 */
		function setPop(open, from) {
			if (!pop) {
				return;
			}
			var back = !open && !pop.hidden && opener && pop.contains(document.activeElement);
			pop.hidden = !open;
			if (open) {
				opener = from || opener;
			}
			toggles.forEach(function (btn) {
				btn.setAttribute('aria-expanded', open ? 'true' : 'false');
			});
			if (open && boxes[0]) {
				boxes[0].focus();
			}
			if (back) {
				opener.focus();
			}
			if (!open) {
				opener = null;
			}
		}

		/**
		 * Close the popover on Escape.
		 *
		 * @param {KeyboardEvent} e Key event.
		 */
		function onPopKey(e) {
			if ('Escape' === e.key && !pop.hidden) {
				e.stopPropagation();
				setPop(false);
			}
		}

		/**
		 * Close the popover on a press outside of it and of its toggles.
		 *
		 * @param {Event} e Pointer event.
		 */
		function onOutside(e) {
			if (!pop || pop.hidden || pop.contains(e.target)) {
				return;
			}
			for (var i = 0; i < toggles.length; i++) {
				if (toggles[i].contains(e.target)) {
					return;
				}
			}
			setPop(false);
		}

		/**
		 * Mirror the active categories on the check boxes and the counters.
		 *
		 * @param {Array} cats Active category slugs.
		 */
		function syncCats(cats) {
			boxes.forEach(function (box) {
				box.checked = cats.indexOf(box.value) !== -1;
			});
			toggles.forEach(function (btn) {
				var badge = btn.querySelector('.' + B + '__badge');
				badge.textContent = String(cats.length);
				badge.hidden = !cats.length;
			});
		}

		/**
		 * Build the bar: search, the category toggle and the counter.
		 *
		 * @param {boolean} withList Show the search and the counter.
		 * @param {Array}   list     Categories with objects (may be empty).
		 */
		function buildBar(withList, list) {
			bar = make('div', B + '__bar');
			if (withList) {
				var search = make('label', B + '__search');
				var searchIcon = parts.icon('search', 'sm');
				if (searchIcon) {
					search.appendChild(searchIcon);
				}
				search.appendChild(make('span', 'mvweb-om__sr', t('searchLabel', 'Search objects')));
				input = make('input', B + '__input');
				input.type = 'search';
				input.setAttribute('placeholder', t('searchHint', 'Name or address'));
				input.setAttribute('autocomplete', 'off');
				input.setAttribute('enterkeyhint', 'search');
				search.appendChild(input);
				bar.appendChild(search);
				input.addEventListener('input', function () {
					clearTimeout(timer);
					timer = setTimeout(function () {
						ctx.setQuery(input.value);
					}, SEARCH_DELAY);
				});
			}
			if (list.length) {
				buildPop(list);
				bar.appendChild(buildToggle(B + '__toggle', true));
				bar.appendChild(pop);
			}
			if (withList) {
				var status = make('span', B + '__status');
				found = make('span', B + '__found');
				found.setAttribute('role', 'status');
				hint = make('span', B + '__hint', t('tableScroll', 'scroll the table sideways'));
				hint.hidden = true;
				status.appendChild(found);
				status.appendChild(hint);
				bar.appendChild(status);
			}
		}

		/**
		 * Build a sortable header button with the sort icons.
		 *
		 * @param {string}   text    Header text.
		 * @param {Function} onClick Click handler.
		 * @return {HTMLButtonElement}
		 */
		function sortButton(text, onClick) {
			var btn = make('button', B + '__sortbtn');
			btn.type = 'button';
			btn.appendChild(make('span', B + '__sortlabel', text));
			btn.appendChild(pathIcon(PATHS.sort, B + '__si'));
			btn.appendChild(pathIcon(PATHS.dir, B + '__sd'));
			btn.addEventListener('click', onClick);
			return btn;
		}

		/**
		 * Build the table with its header, the empty state and "Show more".
		 *
		 * @param {boolean} withFilter Put the category toggle in the object column.
		 */
		function buildTable(withFilter) {
			wrap = make('div', B + '__wrap');
			table = make('table', B + '__table');
			table.appendChild(make('caption', 'mvweb-om__sr', t('tableCaption', 'Objects: comparison of characteristics')));
			var thead = make('thead', B + '__head');
			var tr = make('tr', '');

			var thObj = make('th', B + '__th ' + B + '__th--obj');
			thObj.setAttribute('scope', 'col');
			thObj.setAttribute('data-sort', 'name');
			var thWrap = make('div', B + '__thobj');
			thWrap.appendChild(sortButton(t('tableObject', 'Object'), function () {
				ctx.setSort('name');
			}));
			if (withFilter) {
				thWrap.appendChild(buildToggle(B + '__filter', false));
			}
			thObj.appendChild(thWrap);
			tr.appendChild(thObj);
			sortThs.push(thObj);

			cols.forEach(function (col) {
				var th = make('th', B + '__th' + (col.number ? ' ' + B + '__num' : ''));
				th.setAttribute('scope', 'col');
				var text = col.label + (col.unit ? ', ' + col.unit : '');
				if (col.number) {
					th.setAttribute('data-sort', col.id);
					th.appendChild(sortButton(text, function () {
						var asc = 'spec:' + col.id + ':asc';
						ctx.setSort(sort === asc ? 'spec:' + col.id + ':desc' : asc);
					}));
					sortThs.push(th);
				} else {
					th.appendChild(make('span', B + '__thtext', text));
				}
				tr.appendChild(th);
			});

			if (withAddress) {
				var thAddr = make('th', B + '__th');
				thAddr.setAttribute('scope', 'col');
				thAddr.appendChild(make('span', B + '__thtext', t('tableAddress', 'Address')));
				tr.appendChild(thAddr);
			}
			thead.appendChild(tr);
			table.appendChild(thead);

			tbody = make('tbody', B + '__rows');
			table.appendChild(tbody);
			wrap.appendChild(table);

			empty = make('div', B + '__empty');
			empty.hidden = true;
			var emptyIcon = make('span', B + '__empty-ico');
			var bigSearch = parts.icon('search');
			if (bigSearch) {
				emptyIcon.appendChild(bigSearch);
			}
			empty.appendChild(emptyIcon);
			empty.appendChild(make('span', B + '__empty-title', t('emptyTitle', 'Nothing found')));
			emptyText = make('span', B + '__empty-text');
			empty.appendChild(emptyText);
			var actions = make('span', B + '__empty-actions');
			emptyReset = make('button', B + '__reset', t('resetSearch', 'Clear search'));
			emptyReset.type = 'button';
			emptyAll = make('button', B + '__link', t('allCats', 'Search in all categories'));
			emptyAll.type = 'button';
			actions.appendChild(emptyReset);
			actions.appendChild(emptyAll);
			empty.appendChild(actions);
			wrap.appendChild(empty);

			showMore = make('button', 'mvweb-om-ui__btn mvweb-om-ui__btn--outline ' + B + '__showmore', t('showMore', 'Show more'));
			showMore.type = 'button';
			showMore.hidden = true;
			wrap.appendChild(showMore);

			emptyReset.addEventListener('click', function () {
				clearTimeout(timer);
				input.value = '';
				ctx.setQuery('');
				input.focus();
			});
			emptyAll.addEventListener('click', function () {
				ctx.setCats([]);
				input.focus();
			});
			showMore.addEventListener('click', function () {
				var from = shown;
				fill(Math.min(objects.length, shown + PAGE));
				var row = tbody.children[from];
				var btn = row && row.querySelector('.' + B + '__obj');
				if (btn) {
					btn.focus();
				}
			});

			tbody.addEventListener('click', onRowClick);
			tbody.addEventListener('pointerover', onRowOver);
			tbody.addEventListener('pointerleave', onRowLeave);
			tbody.addEventListener('focusin', onRowFocus);
			tbody.addEventListener('focusout', onRowBlur);
		}

		/**
		 * Object of the row an event happened in, or null.
		 *
		 * @param {Event} e Event.
		 * @return {Object|null}
		 */
		function rowObj(e) {
			var row = e.target && e.target.closest ? e.target.closest('tr[data-id]') : null;
			return row ? (byId[row.getAttribute('data-id')] || null) : null;
		}

		/**
		 * Select the object of the clicked row.
		 *
		 * @param {MouseEvent} e Click event.
		 */
		function onRowClick(e) {
			var obj = rowObj(e);
			if (obj) {
				ctx.select(obj.id, 'list');
			}
		}

		/**
		 * Hover the object of the row under the mouse.
		 *
		 * @param {PointerEvent} e Pointer event.
		 */
		function onRowOver(e) {
			if ('mouse' !== e.pointerType) {
				return;
			}
			var obj = rowObj(e);
			var id = obj ? obj.id : null;
			if (String(id) !== String(hoverId)) {
				ctx.hover(id);
			}
		}

		/**
		 * Clear the hover when the mouse leaves the table body.
		 *
		 * @param {PointerEvent} e Pointer event.
		 */
		function onRowLeave(e) {
			if ('mouse' === e.pointerType && null !== hoverId && rowEls[String(hoverId)]) {
				ctx.hover(null);
			}
		}

		/**
		 * Hover the object whose row got the keyboard focus.
		 *
		 * @param {FocusEvent} e Focus event.
		 */
		function onRowFocus(e) {
			if (!e.target.matches || !e.target.matches(':focus-visible')) {
				return;
			}
			var obj = rowObj(e);
			if (obj) {
				ctx.hover(obj.id);
			}
		}

		/**
		 * Clear the keyboard hover when the focus leaves a row.
		 *
		 * @param {FocusEvent} e Focus event.
		 */
		function onRowBlur(e) {
			var obj = rowObj(e);
			if (obj && String(obj.id) === String(hoverId)) {
				ctx.hover(null);
			}
		}

		/**
		 * Build one table row.
		 *
		 * @param {Object}  obj   Object data.
		 * @param {boolean} eager Load the photo without lazy loading.
		 * @return {HTMLElement}
		 */
		function buildRow(obj, eager) {
			var id = String(obj.id);
			var tr = make('tr', B + '__row');
			tr.setAttribute('data-id', id);

			var td = make('td', B + '__cell ' + B + '__objcell');
			var btn = make('button', B + '__obj');
			btn.type = 'button';
			if (anyPhoto && false !== card.showPhoto) {
				var media = make('span', B + '__media');
				var img = parts.photo(obj, { size: 'pin', eager: eager, className: B + '__img' });
				if (img) {
					img.setAttribute('width', '44');
					img.setAttribute('height', '44');
					media.appendChild(img);
				} else {
					media.classList.add(B + '__media--empty');
					var ph = parts.icon(iconSlug(obj), 'sm') || parts.icon('home', 'sm');
					if (ph) {
						media.appendChild(ph);
					}
				}
				btn.appendChild(media);
			}
			var text = make('span', B + '__objtext');
			text.appendChild(make('span', B + '__objtitle', obj.title || ''));
			var cat = parts.cat(obj, ctx);
			if (cat) {
				cat.classList.add(B + '__cat');
				text.appendChild(cat);
			}
			btn.appendChild(text);
			td.appendChild(btn);
			tr.appendChild(td);

			cols.forEach(function (col) {
				var spec = specOf(obj, col.id);
				var cell = make('td', B + '__cell' + (col.number ? ' ' + B + '__num' : ''));
				if (spec) {
					cell.textContent = cellText(spec, col);
				} else {
					var dash = make('span', B + '__none', '—');
					dash.setAttribute('aria-hidden', 'true');
					cell.appendChild(dash);
				}
				tr.appendChild(cell);
			});

			if (withAddress) {
				tr.appendChild(make('td', B + '__cell ' + B + '__addr', obj.address || ''));
			}

			if (null !== selectedId && String(selectedId) === id) {
				tr.classList.add(B + '__row--current');
				btn.setAttribute('aria-current', 'true');
			}
			if (null !== hoverId && String(hoverId) === id) {
				tr.setAttribute('data-hover', '');
			}
			rowEls[id] = tr;
			return tr;
		}

		/**
		 * Append rows until the given count is shown.
		 *
		 * @param {number} upto Number of rows to show.
		 */
		function fill(upto) {
			var fragment = document.createDocumentFragment();
			for (var i = shown; i < upto; i++) {
				fragment.appendChild(buildRow(objects[i], i < EAGER));
			}
			tbody.appendChild(fragment);
			shown = Math.max(shown, upto);
			showMore.hidden = shown >= objects.length;
		}

		/**
		 * Position of an object in the current list, or -1.
		 *
		 * @param {number|string} id Object id.
		 * @return {number}
		 */
		function indexOf(id) {
			for (var i = 0; i < objects.length; i++) {
				if (String(objects[i].id) === String(id)) {
					return i;
				}
			}
			return -1;
		}

		/**
		 * Write "Found: N" with the number in bold.
		 *
		 * @param {number} n Number of objects.
		 */
		function setFound(n) {
			var pattern = t('found', 'Found: %d');
			var at = pattern.indexOf('%d');
			found.textContent = at === -1 ? pattern + ' ' : pattern.slice(0, at);
			found.appendChild(make('b', '', String(n)));
			if (at !== -1) {
				found.appendChild(document.createTextNode(pattern.slice(at + 2)));
			}
		}

		/**
		 * Fill the empty state for the current search and categories.
		 *
		 * @param {string} query Search query.
		 * @param {Array}  cats  Active category slugs.
		 */
		function setEmpty(query, cats) {
			var line = '';
			if (query && cats.length) {
				line = t('emptyQueryCats', 'No objects match “%s” in the selected categories.').split('%s').join(query);
			} else if (query) {
				line = t('emptyQuery', 'No objects match “%s”.').split('%s').join(query);
			}
			emptyText.textContent = line;
			emptyText.hidden = !line;
			emptyReset.hidden = !query;
			emptyAll.hidden = !cats.length;
		}

		/**
		 * Mark the sorted column header.
		 */
		function syncSort() {
			var parsed = String(sort).match(SPEC_SORT);
			sortThs.forEach(function (th) {
				var key = th.getAttribute('data-sort');
				var dir = '';
				if ('name' === key && 'name' === sort) {
					dir = 'ascending';
				} else if (parsed && parsed[1] === key) {
					dir = 'asc' === parsed[2] ? 'ascending' : 'descending';
				}
				if (dir) {
					th.setAttribute('aria-sort', dir);
				} else {
					th.removeAttribute('aria-sort');
				}
			});
		}

		/**
		 * Show the "scroll sideways" hint when the stacked table is wider than its box.
		 */
		function queueHint() {
			if (frame || !hint || !wrap) {
				return;
			}
			frame = requestAnimationFrame(function () {
				frame = 0;
				if (hint && wrap) {
					hint.hidden = split || !objects.length || wrap.scrollWidth <= wrap.clientWidth + 1;
				}
			});
		}

		/**
		 * Switch between the side-by-side and the stacked layout by the block width.
		 */
		function layout() {
			var next = !!wrap && !ctx.isPhone() && ctx.root.clientWidth >= SPLIT_MIN;
			if (next !== split) {
				split = next;
				ctx.root.classList.toggle(B + '--split', split);
				if (ctx.map && typeof ctx.map.update === 'function') {
					ctx.map.update({});
				}
			}
			queueHint();
		}

		/**
		 * Bring the map into the viewport after a row was chosen (stacked layout).
		 */
		function showMap() {
			if (split) {
				return;
			}
			var map = ctx.root.querySelector('.mvweb-om__map');
			if (!map) {
				return;
			}
			var r = map.getBoundingClientRect();
			if (r.top < 0 || r.bottom > (window.innerHeight || document.documentElement.clientHeight)) {
				map.scrollIntoView({ block: 'nearest', behavior: reduced ? 'auto' : 'smooth' });
			}
		}

		/**
		 * Scroll the side-by-side table so that a row is visible.
		 *
		 * @param {HTMLElement} row Row element.
		 */
		function reveal(row) {
			if (!split || !wrap) {
				return;
			}
			var box = wrap.getBoundingClientRect();
			var r = row.getBoundingClientRect();
			var top = box.top + (table.tHead ? table.tHead.offsetHeight : 0);
			var delta = r.top - top - 8;
			if (r.top < top || r.bottom > box.bottom) {
				wrap.scrollBy({ top: delta, behavior: reduced || Math.abs(delta) > box.height ? 'auto' : 'smooth' });
			}
		}

		/**
		 * Mark the selected row.
		 *
		 * @param {number|string|null} id     Object id or null.
		 * @param {string}             source Who selected it.
		 */
		function setSelected(id, source) {
			var prev = null === selectedId ? null : rowEls[String(selectedId)];
			if (prev) {
				prev.classList.remove(B + '__row--current');
				prev.querySelector('.' + B + '__obj').removeAttribute('aria-current');
			}
			selectedId = (null === id || undefined === id || '' === id) ? null : id;
			if (null === selectedId || !tbody) {
				return;
			}
			var at = indexOf(selectedId);
			if (at >= shown) {
				fill(Math.min(objects.length, (Math.floor(at / PAGE) + 1) * PAGE));
			}
			var row = rowEls[String(selectedId)];
			if (!row) {
				return;
			}
			row.classList.add(B + '__row--current');
			row.querySelector('.' + B + '__obj').setAttribute('aria-current', 'true');
			if (source && 'list' !== source) {
				reveal(row);
			}
		}

		/**
		 * Mark the hovered row.
		 *
		 * @param {number|string|null} id Object id or null.
		 */
		function setHover(id) {
			if (null !== hoverId && rowEls[String(hoverId)]) {
				rowEls[String(hoverId)].removeAttribute('data-hover');
			}
			hoverId = (null === id || undefined === id || '' === id) ? null : id;
			if (null !== hoverId && rowEls[String(hoverId)]) {
				rowEls[String(hoverId)].setAttribute('data-hover', '');
			}
		}

		/**
		 * Draw the table for a view.
		 *
		 * @param {Object} state { objects, total, cats, query, sort, selectedId, hoverId }.
		 */
		function render(state) {
			state = state || {};
			var cats = state.cats || [];
			syncCats(cats);
			if (!tbody) {
				return;
			}
			objects = state.objects || [];
			sort = state.sort || 'name';
			selectedId = undefined !== state.selectedId ? state.selectedId : selectedId;
			hoverId = undefined !== state.hoverId ? state.hoverId : hoverId;

			if (!state.query && input.value.trim() && document.activeElement !== input) {
				input.value = '';
			}

			rowEls = Object.create(null);
			tbody.textContent = '';
			shown = 0;
			fill(Math.min(objects.length, PAGE));
			if (null !== selectedId) {
				setSelected(selectedId);
			}
			syncSort();

			setFound(objects.length);
			empty.hidden = !!objects.length;
			if (!objects.length) {
				setEmpty(state.query || '', cats);
			}
			queueHint();
		}

		return {
			/**
			 * Build the bar and the table and subscribe to the instance events.
			 */
			mount: function () {
				parts = api.shared && api.shared.parts;
				if (!parts) {
					throw new Error('mvwebOm.shared.parts is missing');
				}
				card = (ctx.data && ctx.data.card) || {};
				reduced = !!window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
				(ctx.objects || []).forEach(function (obj) {
					byId[String(obj.id)] = obj;
					anyPhoto = anyPhoto || parts.isSafeUrl(obj.pin || obj.thumb || '');
					withAddress = withAddress || !!obj.address;
				});

				var withList = !!(ctx.config && ctx.config.list);
				var list = (ctx.config && ctx.config.filter) ? catList() : [];
				if (!withList && !list.length) {
					return;
				}
				cols = withList ? buildCols() : [];

				var root = ctx.root;
				var body = root.querySelector('.mvweb-om__body');
				var anchor = body && body.parentNode === root ? body : root.firstChild;

				buildBar(withList, list);
				root.insertBefore(bar, anchor);
				if (withList && body) {
					buildTable(list.length > 0);
					body.appendChild(wrap);
				}
				root.classList.add(B + '--on');
				root.classList.toggle(B + '--nolist', !wrap);

				if (pop) {
					document.addEventListener('pointerdown', onOutside, true);
				}
				if (wrap) {
					if (typeof ResizeObserver === 'function') {
						observer = new ResizeObserver(layout);
						observer.observe(root);
					} else {
						window.addEventListener('resize', layout);
					}
					layout();
				}

				handlers.select = function (p) {
					setSelected(p.id, p.source);
					if ('list' === p.source && wrap && !(ctx.data && ctx.data.modal)) {
						showMap();
					}
				};
				handlers.deselect = function () {
					setSelected(null);
				};
				handlers.hover = function (p) {
					setHover(p.id);
				};
				Object.keys(handlers).forEach(function (name) {
					ctx.on(name, handlers[name]);
				});
			},

			render: render,

			/**
			 * Remove the bar and the table and drop the subscriptions.
			 */
			destroy: function () {
				clearTimeout(timer);
				if (frame) {
					cancelAnimationFrame(frame);
					frame = 0;
				}
				if (observer) {
					observer.disconnect();
					observer = null;
				} else {
					window.removeEventListener('resize', layout);
				}
				document.removeEventListener('pointerdown', onOutside, true);
				Object.keys(handlers).forEach(function (name) {
					ctx.off(name, handlers[name]);
				});
				[bar, wrap].forEach(function (el) {
					if (el && el.parentNode) {
						el.parentNode.removeChild(el);
					}
				});
				ctx.root.classList.remove(B + '--on', B + '--nolist', B + '--split');
				bar = wrap = table = tbody = pop = input = found = hint = null;
				boxes = [];
				toggles = [];
				sortThs = [];
				rowEls = Object.create(null);
			}
		};
	});
})();
