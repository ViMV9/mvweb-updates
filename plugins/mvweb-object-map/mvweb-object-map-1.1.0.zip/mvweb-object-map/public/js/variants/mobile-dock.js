/**
 * Phone and object window variant "dock" (D5).
 *
 * Phone: a tap on a marker slides up a short card from the bottom of the
 * screen (thumbnail, title, address, pill buttons). Pulled up by the handle,
 * the sheet opens the full card (photos, phone, hours, characteristics in
 * striped rows) and dims the page. Desktop: the object window is a panel on
 * the right of the map, the map stays visible and working, and "‹ 1 of 12 ›"
 * steps through the objects in the order of the current filter.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var B = 'mvweb-om-mobile-dock';
	var OWNER = 'mobile';
	var PHONE_QUERY = '(max-width: 782px)';
	var GAP = 16;
	var uid = 0;

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		if (cls) {
			el.className = cls;
		}
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * Append a node when it exists.
	 *
	 * @param {HTMLElement}      parent Parent element.
	 * @param {HTMLElement|null} child  Child or null.
	 * @param {string}           cls    Extra class for the child (optional).
	 */
	function add(parent, child, cls) {
		if (!child) {
			return;
		}
		if (cls) {
			child.classList.add(cls);
		}
		parent.appendChild(child);
	}

	/**
	 * Remove all children of an element.
	 *
	 * @param {HTMLElement} el Element.
	 */
	function empty(el) {
		while (el.firstChild) {
			el.removeChild(el.firstChild);
		}
	}

	api.register('mobile', 'dock', function (ctx) {
		var shared = api.shared || {};
		var parts = shared.parts;
		if (!parts || typeof shared.sheet !== 'function' || typeof shared.gallery !== 'function') {
			return null;
		}

		var i18n = ctx.i18n || {};
		var root = ctx.root;
		var phoneQuery = window.matchMedia(PHONE_QUERY);
		var sheetCtx = Object.create(ctx);

		var host = null;
		var sheet = null;
		var gallery = null;
		var watch = null;

		var card = null;
		var head = null;
		var thumbSlot = null;
		var info = null;
		var nav = null;
		var count = null;
		var prev = null;
		var next = null;
		var quick = null;
		var more = null;

		var current = null;
		var around = null;
		var side = false;
		var source = '';
		var closing = false;

		/**
		 * Map insets for the sheet: the floating panel adds its margins, the
		 * phone sheet keeps the inset of its short position when pulled up.
		 *
		 * @param {string}      owner Owner key.
		 * @param {Object|null} inset Inset from the sheet.
		 */
		sheetCtx.setInsets = function (owner, inset) {
			if (inset && inset.r) {
				ctx.setInsets(owner, { r: inset.r + GAP * 2 });
			} else if (inset && inset.b) {
				if (!sheet || 'full' !== sheet.position()) {
					ctx.setInsets(owner, { b: inset.b });
				}
			} else {
				ctx.setInsets(owner, inset);
			}
		};

		/**
		 * Ask the core to clear the selection (it closes this module).
		 */
		function dismiss() {
			if (current) {
				ctx.select(null, OWNER);
			}
		}

		/**
		 * Phone sheet only: dim the page and mark the sheet modal while it is pulled up.
		 *
		 * @param {string} position Sheet position.
		 */
		function syncState(position) {
			var dim = !side && 'full' === position;
			sheet.el.classList.toggle(B + '__sheet--dim', dim);
			sheet.el.setAttribute('aria-modal', dim ? 'true' : 'false');
		}

		/**
		 * A tap on the dimmed page above the pulled-up sheet lowers it.
		 *
		 * @param {MouseEvent} e Click.
		 */
		function onScrim(e) {
			if (e.target === sheet.el && !side && 'full' === sheet.position() && e.clientY < sheet.el.getBoundingClientRect().top) {
				sheet.set('peek');
			}
		}

		/**
		 * Phone: close the short card once the map block has left the screen.
		 *
		 * @param {Array} entries Intersection entries.
		 */
		function onSight(entries) {
			var entry = entries[entries.length - 1];
			if (entry && !entry.isIntersecting && current && !side && 'peek' === sheet.position()) {
				dismiss();
			}
		}

		/**
		 * Build the card skeleton once: head with the persistent buttons, the
		 * quick actions and the details.
		 */
		function build() {
			card = make('div', B + '__card');
			head = make('div', B + '__head');
			head.setAttribute('data-sheet-drag', '');
			thumbSlot = make('div', B + '__thumb');
			info = make('div', B + '__info');
			var tools = make('div', B + '__tools');
			nav = make('div', B + '__nav');
			prev = parts.iconButton('chev-l', i18n.prevObject || 'Previous object', function () {
				if (around && around.prev) {
					ctx.select(around.prev.id, OWNER);
				}
			}, B + '__step');
			next = parts.iconButton('chev-r', i18n.nextObject || 'Next object', function () {
				if (around && around.next) {
					ctx.select(around.next.id, OWNER);
				}
			}, B + '__step');
			count = make('span', B + '__count');
			nav.appendChild(prev);
			nav.appendChild(count);
			nav.appendChild(next);
			tools.appendChild(nav);
			tools.appendChild(parts.close(i18n.close || 'Close', dismiss, 'mvweb-om-ui__icon-btn--plain ' + B + '__close'));
			head.appendChild(thumbSlot);
			head.appendChild(info);
			head.appendChild(tools);

			quick = make('div', B + '__quick');
			more = make('div', B + '__more');
			card.appendChild(head);
			card.appendChild(quick);
			card.appendChild(more);
		}

		/**
		 * Lazily create the sheet.
		 *
		 * @return {Object} Sheet API.
		 */
		function getSheet() {
			if (!sheet) {
				build();
				sheet = shared.sheet(sheetCtx, {
					host: root,
					owner: OWNER,
					positions: ['peek', 'full'],
					initial: 'peek',
					modal: true,
					side: 'right',
					onChange: syncState,
					onClose: function () {
						if (!closing) {
							dismiss();
						}
					}
				});
				sheet.el.classList.add(B + '__sheet');
				sheet.body.appendChild(card);
				sheet.el.addEventListener('click', onScrim);
			}
			return sheet;
		}

		/**
		 * One quick action link.
		 *
		 * @param {Object}  obj     Object data.
		 * @param {string}  key     route, call or more.
		 * @param {boolean} primary Whether it is the filled button.
		 * @return {HTMLElement|null}
		 */
		function action(obj, key, primary) {
			var opts = { more: false, call: false, route: false, primary: primary ? key : 'none' };
			opts[key] = true;
			var wrap = parts.actions(obj, ctx, opts);
			var link = wrap ? wrap.firstChild : null;
			if (link && 'more' === key) {
				add(link, parts.icon('arrow', 'sm'));
				link.insertBefore(link.lastChild, link.firstChild);
			}
			return link;
		}

		/**
		 * Fill the card with an object.
		 *
		 * @param {Object} obj Object data.
		 */
		function fill(obj) {
			if (gallery) {
				gallery.destroy();
				gallery = null;
			}

			empty(thumbSlot);
			add(thumbSlot, parts.photo(obj, { size: 'pin', eager: true }) || parts.photo(obj, { eager: true }));
			thumbSlot.hidden = !thumbSlot.firstChild;

			empty(info);
			add(info, parts.cat(obj, ctx));
			var title = parts.title(obj, B + '__title');
			title.id = B + '-title-' + (++uid);
			title.setAttribute('data-sheet-title', '');
			info.appendChild(title);
			add(info, parts.rows(obj, ctx, { phone: false, hours: false }), B + '__address');

			syncNav(obj);

			empty(quick);
			var primary = true;
			['route', 'call', 'more'].forEach(function (key) {
				var link = action(obj, key, primary);
				if (link) {
					primary = false;
					quick.appendChild(link);
				}
			});
			quick.hidden = !quick.firstChild;

			empty(more);
			var urls = parts.photoUrls(obj);
			if (urls.length) {
				gallery = shared.gallery(ctx, { urls: urls, ratio: '3 / 2', dots: true, alt: obj.title || '' });
				add(more, gallery.el, B + '__gallery');
			}
			add(more, parts.rows(obj, ctx, { address: false }), B + '__meta');
			if (obj.excerpt) {
				more.appendChild(make('p', B + '__excerpt', obj.excerpt));
			}
			var specs = parts.specs(obj, ctx, {});
			if (specs) {
				more.appendChild(make('div', B + '__label', i18n.specs || 'Characteristics'));
				add(more, specs, B + '__specs');
			}
			add(more, parts.links(obj));
			more.hidden = !more.firstChild;
		}

		/**
		 * Measure the short position: handle, head and quick actions.
		 */
		function measurePeek() {
			var top = sheet.el.getBoundingClientRect().top;
			var edge = (quick.hidden ? head : quick).getBoundingClientRect().bottom;
			sheet.el.style.setProperty('--mvweb-om-sheet-peek', Math.ceil(edge - top) + 'px');
		}

		/**
		 * Remove the open view without touching the selection.
		 */
		function hide() {
			closing = true;
			if (watch) {
				watch.disconnect();
			}
			if (sheet) {
				sheet.el.classList.remove(B + '__sheet--dim');
				if (sheet.position()) {
					sheet.close();
				}
			}
			if (gallery) {
				gallery.destroy();
				gallery = null;
			}
			closing = false;
			current = null;
			around = null;
		}

		/**
		 * Open an object: bottom sheet on a phone, right panel on a desktop.
		 *
		 * @param {Object} obj Object data.
		 */
		function show(obj) {
			if (!obj) {
				return;
			}
			var s = getSheet();
			var asSide = !ctx.isPhone();
			var target = asSide ? host : root;
			if (s.el.parentNode !== target || (current && side !== asSide)) {
				if (s.position()) {
					var keep = current;
					hide();
					current = keep;
				}
				target.appendChild(s.el);
			}
			side = asSide;
			current = obj;
			s.el.classList.toggle(B + '__sheet--side', asSide);
			fill(obj);
			s.body.scrollTop = 0;

			var position = s.position();
			if (asSide) {
				s.open('full');
			} else {
				s.el.classList.toggle(B + '__sheet--short', more.hidden);
				if (!position) {
					s.el.hidden = false;
				}
				measurePeek();
				s.open(position || 'peek');
				if (watch) {
					watch.observe(root);
				}
			}
			syncState(s.position());
			ctx.flyTo(obj, ('marker' === source || 'api' === source || !source) ? null : { zoom: 16 });
			source = '';
		}

		/**
		 * Close the object view. Safe to call when nothing is open.
		 */
		function close() {
			if (!current) {
				return;
			}
			hide();
		}

		/**
		 * Position "N of M" and the arrows in the current filter order.
		 *
		 * @param {Object} obj Object data.
		 */
		function syncNav(obj) {
			around = ctx.neighbors(obj.id);
			nav.hidden = !around || around.index < 0 || around.total < 2;
			if (!nav.hidden) {
				count.textContent = (i18n.counter || '%1$d of %2$d').replace('%1$d', String(around.index + 1)).replace('%2$d', String(around.total));
			}
		}

		var onFilter = function () {
			if (current) {
				syncNav(current);
			}
		};
		var onSelect = function (e) {
			source = (e && e.source) || '';
		};
		var onMedia = function () {
			if (current) {
				var obj = current;
				hide();
				source = 'api';
				show(obj);
			}
		};

		return {
			minMap: { width: 600, height: 320 },

			/**
			 * Find the map container and start listening.
			 */
			mount: function () {
				host = root.querySelector('.mvweb-om__map');
				if (!host) {
					throw new Error('mobile/dock: no map container');
				}
				if ('IntersectionObserver' in window) {
					watch = new IntersectionObserver(onSight);
				}
				ctx.on('select', onSelect);
				ctx.on('filter', onFilter);
				phoneQuery.addEventListener('change', onMedia);
			},

			/**
			 * Phone: slide up the short card.
			 *
			 * @param {Object} obj Object data.
			 */
			open: function (obj) {
				show(obj);
			},

			/**
			 * Desktop: open the panel on the right of the map.
			 *
			 * @param {Object} obj Object data.
			 */
			detailPc: function (obj) {
				show(obj);
			},

			close: close,

			/**
			 * Remove everything this module added.
			 */
			destroy: function () {
				close();
				ctx.off('select', onSelect);
				ctx.off('filter', onFilter);
				phoneQuery.removeEventListener('change', onMedia);
				if (watch) {
					watch.disconnect();
					watch = null;
				}
				if (sheet) {
					sheet.el.removeEventListener('click', onScrim);
					sheet.destroy();
					sheet = null;
				}
			}
		};
	});
})();
