/**
 * Balloon variant "showcase": a photo-first object card.
 *
 * Desktop: a card floating at the top right of the map, the photo across its
 * full width with the category, title and address on a shade, three key
 * figures, contacts, links and pinned buttons. Phone or a narrow map: the
 * same card in a bottom sheet with the photo on top.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var BLOCK = 'mvweb-om-balloon-showcase';
	var OWNER = 'balloon';
	var NARROW = 600;
	var GAP = 16;
	var NUMS = 3;
	var CLICK_SLOP = 6;

	var uid = 0;

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		if (cls) {
			el.className = cls;
		}
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	api.register('balloon', 'showcase', function (ctx) {
		var shared = api.shared || {};
		var parts = shared.parts;
		if (!parts || typeof shared.sheet !== 'function' || typeof shared.gallery !== 'function') {
			return null;
		}

		var i18n = ctx.i18n || {};
		var host = ctx.root.querySelector('.mvweb-om__map') || ctx.root;
		var canvas = ctx.root.querySelector('.mvweb-om__canvas');

		var current = null;
		var source = '';
		var mode = '';
		var card = null;
		var sheet = null;
		var gallery = null;
		var closing = false;
		var press = null;
		var frame = 0;

		/**
		 * Whether the card goes into the bottom sheet.
		 *
		 * @return {boolean}
		 */
		function useSheet() {
			return ctx.isPhone() || host.clientWidth < NARROW;
		}

		/**
		 * Ask the core to clear the selection (it closes this module).
		 */
		function dismiss() {
			if (current) {
				ctx.select(null);
			}
		}

		/**
		 * Build the photo header: gallery, close button, category, title, address.
		 *
		 * @param {Object}  obj      Object data.
		 * @param {boolean} inSheet  Whether the card is in the bottom sheet.
		 * @param {string}  titleId  Id for the title element.
		 * @return {HTMLElement}
		 */
		function buildHero(obj, inSheet, titleId) {
			var urls = parts.photoUrls(obj);
			var hero = make('div', BLOCK + '__hero ' + BLOCK + '__hero--' + (urls.length ? 'photo' : 'bare'));
			var caption = make('div', BLOCK + '__caption');
			var label = i18n.close || 'Close';

			hero.appendChild(parts.close(label, dismiss, BLOCK + '__close ' + (urls.length ? 'mvweb-om-ui__icon-btn--glass' : 'mvweb-om-ui__icon-btn--plain')));

			if (urls.length) {
				gallery = shared.gallery(ctx, { urls: urls, counter: true, alt: obj.title || '' });
				gallery.el.classList.add(BLOCK + '__gallery');
				hero.appendChild(gallery.el);
			}
			if (inSheet) {
				var grip = make('span', BLOCK + '__grip');
				grip.setAttribute('aria-hidden', 'true');
				hero.appendChild(grip);
			}

			var cat = parts.cat(obj, ctx);
			if (cat) {
				cat.classList.add(BLOCK + '__cat');
				caption.appendChild(cat);
			}
			var title = parts.title(obj, BLOCK + '__title');
			title.id = titleId;
			title.setAttribute('data-sheet-title', '');
			caption.appendChild(title);
			var address = parts.rows(obj, ctx, { phone: false, hours: false });
			if (address) {
				address.classList.add(BLOCK + '__address');
				caption.appendChild(address);
			}
			hero.appendChild(caption);
			return hero;
		}

		/**
		 * Build the details under the photo: key figures, excerpt, contacts, links.
		 *
		 * @param {Object} obj Object data.
		 * @return {HTMLElement|null} Null when there is nothing to show.
		 */
		function buildBody(obj) {
			var body = make('div', BLOCK + '__body');
			var nums = parts.specs(obj, ctx, { flag: 'balloon' });
			if (nums) {
				while (nums.children.length > NUMS) {
					nums.removeChild(nums.lastElementChild);
				}
				nums.classList.add(BLOCK + '__nums');
				body.appendChild(nums);
			}
			if (obj.excerpt) {
				body.appendChild(make('p', BLOCK + '__excerpt', obj.excerpt));
			}
			var contacts = parts.rows(obj, ctx, { address: false });
			if (contacts) {
				contacts.classList.add(BLOCK + '__contacts');
				body.appendChild(contacts);
			}
			var links = parts.links(obj);
			if (links) {
				body.appendChild(links);
			}
			return body.childNodes.length ? body : null;
		}

		/**
		 * Fill a container with the card content of an object.
		 *
		 * @param {HTMLElement} box     Container.
		 * @param {Object}      obj     Object data.
		 * @param {boolean}     inSheet Whether the card is in the bottom sheet.
		 * @return {string} Id of the title element.
		 */
		function fill(box, obj, inSheet) {
			var titleId = BLOCK + '-title-' + (++uid);
			if (gallery) {
				gallery.destroy();
				gallery = null;
			}
			while (box.firstChild) {
				box.removeChild(box.firstChild);
			}
			box.appendChild(buildHero(obj, inSheet, titleId));
			var body = buildBody(obj);
			if (body) {
				box.appendChild(body);
			}
			var actions = parts.actions(obj, ctx, { call: false });
			if (actions) {
				actions.classList.add(BLOCK + '__actions');
				box.appendChild(actions);
			}
			return titleId;
		}

		/**
		 * Whether focus is inside the open card or sheet.
		 *
		 * @return {boolean}
		 */
		function hasFocus() {
			var active = document.activeElement;
			return !!active && ((card && card.contains(active)) || (sheet && sheet.el.contains(active)));
		}

		/**
		 * Lazily create the bottom sheet.
		 *
		 * @return {Object} Sheet API.
		 */
		function getSheet() {
			if (!sheet) {
				sheet = shared.sheet(ctx, {
					host: host,
					owner: OWNER,
					positions: ['open'],
					initial: 'open',
					modal: false,
					onClose: function () {
						if (!closing) {
							dismiss();
						}
					}
				});
				sheet.el.classList.add(BLOCK + '__sheet');
			}
			return sheet;
		}

		/**
		 * Show the object in the bottom sheet.
		 *
		 * @param {Object} obj Object data.
		 */
		function openSheet(obj) {
			var s = getSheet();
			var content = make('div', BLOCK + ' ' + BLOCK + '--sheet');
			fill(content, obj, true);
			while (s.body.firstChild) {
				s.body.removeChild(s.body.firstChild);
			}
			s.body.appendChild(content);
			s.body.scrollTop = 0;
			s.open('open');
		}

		/**
		 * Show the object in the floating card.
		 *
		 * @param {Object} obj Object data.
		 */
		function openCard(obj) {
			if (!card) {
				card = make('article', BLOCK + ' ' + BLOCK + '--card');
				card.setAttribute('role', 'dialog');
				card.setAttribute('tabindex', '-1');
				card.addEventListener('keydown', function (e) {
					if ('Escape' === e.key) {
						e.stopPropagation();
						dismiss();
					}
				});
				host.appendChild(card);
			}
			card.setAttribute('aria-labelledby', fill(card, obj, false));
			card.scrollTop = 0;
			ctx.setInsets(OWNER, { r: card.offsetWidth + GAP });
			card.focus({ preventScroll: true });
		}

		/**
		 * Remove the open view without touching the selection.
		 */
		function hide() {
			var refocus = hasFocus();
			closing = true;
			if (gallery) {
				gallery.destroy();
				gallery = null;
			}
			if (card) {
				if (card.parentNode) {
					card.parentNode.removeChild(card);
				}
				card = null;
				ctx.setInsets(OWNER, null);
				if (refocus) {
					ctx.focus.restore();
				}
			}
			if (sheet && sheet.position()) {
				sheet.close();
			}
			closing = false;
			mode = '';
		}

		/**
		 * Open an object.
		 *
		 * @param {Object} obj Object data.
		 */
		function open(obj) {
			if (!obj) {
				return;
			}
			var next = useSheet() ? 'sheet' : 'card';
			if (mode && mode !== next) {
				hide();
			}
			if (!hasFocus()) {
				ctx.focus.remember();
			}
			current = obj;
			mode = next;
			if ('sheet' === next) {
				openSheet(obj);
			} else {
				openCard(obj);
			}
			ctx.flyTo(obj, ('marker' === source || 'api' === source || !source) ? null : { zoom: 16 });
			source = '';
		}

		/**
		 * Close the card. Safe to call when nothing is open.
		 */
		function close() {
			if (!current && !mode) {
				return;
			}
			current = null;
			hide();
		}

		var onSelect = function (e) {
			source = (e && e.source) || '';
		};
		var onDeselect = function () {
			close();
		};
		var onPointerDown = function (e) {
			press = { x: e.clientX, y: e.clientY };
		};
		var onCanvasClick = function (e) {
			var p = press;
			press = null;
			if (!current || !p || Math.abs(e.clientX - p.x) > CLICK_SLOP || Math.abs(e.clientY - p.y) > CLICK_SLOP) {
				return;
			}
			if (e.target.closest && e.target.closest('a, button, [role="button"], [class*="cluster"]')) {
				return;
			}
			dismiss();
		};
		var onResize = function () {
			if (frame) {
				return;
			}
			frame = requestAnimationFrame(function () {
				frame = 0;
				if (current && mode !== (useSheet() ? 'sheet' : 'card')) {
					var obj = current;
					var keep = hasFocus();
					hide();
					if (keep) {
						ctx.focus.remember();
					}
					open(obj);
				} else if (card) {
					ctx.setInsets(OWNER, { r: card.offsetWidth + GAP });
				}
			});
		};

		ctx.on('select', onSelect);
		ctx.on('deselect', onDeselect);
		if (canvas) {
			canvas.addEventListener('pointerdown', onPointerDown, true);
			canvas.addEventListener('click', onCanvasClick);
		}
		window.addEventListener('resize', onResize);

		return {
			minMap: { width: 280, height: 260 },
			open: open,
			close: close,
			destroy: function () {
				close();
				ctx.off('select', onSelect);
				ctx.off('deselect', onDeselect);
				if (canvas) {
					canvas.removeEventListener('pointerdown', onPointerDown, true);
					canvas.removeEventListener('click', onCanvasClick);
				}
				window.removeEventListener('resize', onResize);
				if (frame) {
					cancelAnimationFrame(frame);
					frame = 0;
				}
				if (sheet) {
					sheet.destroy();
					sheet = null;
				}
			}
		};
	});
})();
