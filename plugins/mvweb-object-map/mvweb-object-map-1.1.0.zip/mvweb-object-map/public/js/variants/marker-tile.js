/**
 * Marker variant "tile": a rounded icon tile that opens into a name card
 * when selected, cluster as a hexagon with a denser accent for more objects.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm;
	if (!api || typeof api.register !== 'function') {
		return;
	}

	var COLOR = /^#[0-9a-f]{3,8}$/i;
	var B = 'mvweb-om-marker-tile';
	var EDGE = 8;
	var SETTLE = 150;
	var ANCHOR = 22;
	var MIN_TEXT = 48;

	/**
	 * Whether a URL is safe to place into src (http(s) or root-relative).
	 *
	 * @param {string} url URL to test.
	 * @return {boolean}
	 */
	function isSafeUrl(url) {
		if (typeof url !== 'string') {
			return false;
		}
		var s = url.trim().toLowerCase();
		return s.indexOf('http://') === 0 || s.indexOf('https://') === 0 || s.indexOf('/') === 0;
	}

	/**
	 * Readable icon color on top of a category color (WCAG relative luminance,
	 * same rule as the accent ink in PHP).
	 *
	 * @param {string} hex Background color, #rgb, #rgba, #rrggbb or #rrggbbaa.
	 * @return {string} '#ffffff' or '#111827'.
	 */
	function inkFor(hex) {
		var h = hex.replace('#', '');
		if (h.length < 6) {
			h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
		}
		var lum = 0;
		[0.2126, 0.7152, 0.0722].forEach(function (weight, i) {
			var c = parseInt(h.substr(i * 2, 2), 16) / 255;
			c = c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
			lum += weight * c;
		});
		return lum > 0.179 ? '#111827' : '#ffffff';
	}

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		el.className = cls;
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * The object's first category from the payload.
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} ctx Map context.
	 * @return {Object|null}
	 */
	function firstCategory(obj, ctx) {
		var slug = (obj.categories || [])[0];
		var found = null;
		(ctx.categories || []).some(function (cat) {
			if (cat.slug === slug) {
				found = cat;
			}
			return !!found;
		});
		return found;
	}

	/**
	 * Marker icon by priority: own image, object preset, category icon, home.
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} cat First category or null.
	 * @param {Object} ctx Map context.
	 * @return {Element|null}
	 */
	function markerIcon(obj, cat, ctx) {
		var own = obj.icon || {};
		if ('image' === own.type && isSafeUrl(own.url)) {
			var img = make('img', B + '__img');
			img.setAttribute('src', own.url);
			img.setAttribute('alt', '');
			img.setAttribute('decoding', 'async');
			img.setAttribute('loading', 'lazy');
			return img;
		}
		var svg = (own.preset && ctx.icon(own.preset)) || (cat && cat.icon && ctx.icon(cat.icon)) || ctx.icon('home');
		if (svg) {
			svg.setAttribute('class', 'mvweb-om-ui__icon ' + B + '__ico');
		}
		return svg;
	}

	/**
	 * Value of the first characteristic flagged "show on the marker".
	 *
	 * @param {Object} obj Object data.
	 * @param {Object} ctx Map context.
	 * @return {string}
	 */
	function markerFact(obj, ctx) {
		var ids = {};
		(ctx.schema || []).forEach(function (field) {
			if (field.show && field.show.indexOf('marker') !== -1) {
				ids[field.id] = true;
			}
		});
		var value = '';
		(obj.specs || []).some(function (s) {
			if (undefined !== s.id && true === ids[s.id] && s.value) {
				value = String(s.value);
			}
			return !!value;
		});
		return value;
	}

	/**
	 * Keep the name card inside the map: open it to the left when it would
	 * cross the right edge, shorten the text when neither side has room.
	 *
	 * @param {HTMLElement} el  Marker element.
	 * @param {Object}      ctx Map context.
	 */
	function fitCard(el, ctx) {
		if (!el.isConnected || !el.classList.contains('mvweb-om__marker--selected')) {
			return;
		}
		var area = (ctx.root.querySelector('.mvweb-om__canvas') || ctx.root).getBoundingClientRect();
		var text = el.querySelector('.' + B + '__text');
		el.classList.remove(B + '__m--flip');
		el.style.removeProperty('--mvweb-om-marker-text-max');

		var r = el.getBoundingClientRect();
		var width = el.offsetWidth;
		var scale = width ? r.width / width : 1;
		var anchor = r.left + ANCHOR * scale;
		var right = (area.right - EDGE - anchor) / scale + ANCHOR;
		var left = (anchor - area.left - EDGE) / scale + ANCHOR;
		if (width <= right) {
			return;
		}
		if (left > right) {
			el.classList.add(B + '__m--flip');
		}
		if (width > Math.max(left, right) && text) {
			var room = Math.max(left, right) - (width - text.offsetWidth);
			el.style.setProperty('--mvweb-om-marker-text-max', Math.max(MIN_TEXT, Math.floor(room)) + 'px');
		}
	}

	/**
	 * Make a cluster element reachable from the keyboard.
	 *
	 * @param {HTMLElement} el    Cluster element.
	 * @param {number}      count Objects in the cluster.
	 * @param {Object}      ctx   Map context.
	 */
	function clusterA11y(el, count, ctx) {
		var label = (ctx.i18n.clusterLabel || 'Objects: %d. Zoom in').replace('%d', String(count));
		el.appendChild(make('span', 'mvweb-om__sr', label));
		el.setAttribute('role', 'button');
		el.setAttribute('tabindex', '0');
		el.setAttribute('title', label);
		el.addEventListener('keydown', function (e) {
			if ('Enter' === e.key || ' ' === e.key || 'Spacebar' === e.key) {
				e.preventDefault();
				e.stopPropagation();
				el.click();
			}
		});
	}

	api.register('marker', 'tile', function (ctx) {
		var els = Object.create(null);
		var selectedId = null;
		var timer = 0;
		var refit = function () {
			clearTimeout(timer);
			timer = setTimeout(function () {
				var el = null !== selectedId ? els[selectedId] : null;
				if (el) {
					fitCard(el, ctx);
				}
			}, SETTLE);
		};

		ctx.on('select', function (payload) {
			selectedId = payload ? String(payload.id) : null;
			refit();
		});
		ctx.on('deselect', function () {
			selectedId = null;
		});
		ctx.on('viewport', function (payload) {
			if (null !== selectedId && !(payload && payload.inAction)) {
				refit();
			}
		});

		return {
			gridSize: 64,

			/**
			 * Build the tile marker of an object.
			 *
			 * @param {Object} obj Object data.
			 * @return {HTMLElement}
			 */
			create: function (obj) {
				var cat = firstCategory(obj, ctx);
				var el = make('div', 'mvweb-om__marker ' + B + '__m');
				var tile = make('span', B + '__tile');
				var text = make('span', B + '__text');
				var fact = markerFact(obj, ctx);

				el.setAttribute('role', 'button');
				el.setAttribute('tabindex', '0');
				el.setAttribute('title', obj.title || '');
				if (cat && COLOR.test(cat.color || '')) {
					el.style.setProperty('--mvweb-om-marker-c', cat.color);
					el.style.setProperty('--mvweb-om-marker-ink', inkFor(cat.color));
				}

				var ico = markerIcon(obj, cat, ctx);
				if (ico) {
					tile.appendChild(ico);
				}
				el.appendChild(tile);

				text.appendChild(make('span', B + '__name', obj.title || ''));
				if (fact) {
					text.appendChild(make('span', B + '__sub', fact));
				}
				el.appendChild(text);

				els[String(obj.id)] = el;
				if (String(obj.id) === selectedId) {
					refit();
				}
				return el;
			},

			/**
			 * Build a hexagon cluster sized and tinted by the number of objects.
			 *
			 * @param {Array} features Clustered features.
			 * @return {HTMLElement}
			 */
			cluster: function (features) {
				var count = features.length;
				var size = count < 10 ? 's' : (count < 100 ? 'm' : 'l');
				var el = make('div', B + '__cl ' + B + '__cl--' + size);
				var hex = make('span', B + '__hex', String(count));
				hex.setAttribute('aria-hidden', 'true');
				el.appendChild(hex);
				clusterA11y(el, count, ctx);
				return el;
			}
		};
	});
})();
