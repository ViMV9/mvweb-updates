/**
 * Photo gallery on native scroll-snap.
 *
 * Swipe is the browser's own scroll. Arrows (desktop), the counter, dots and
 * thumbnails are optional. One photo gives a plain picture without controls.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm = window.mvwebOm || {};
	var shared = api.shared = api.shared || {};

	/**
	 * Create a gallery.
	 *
	 * @param {Object} ctx  Map context.
	 * @param {Object} opts {
	 *     urls: string[],
	 *     ratio: string, for example "4 / 3",
	 *     counter: boolean, show "1 / 6",
	 *     dots: boolean,
	 *     thumbs: boolean, row of thumbnails,
	 *     alt: string, alternative text of every photo
	 * }
	 * @return {Object} { el, go, index, count, destroy }
	 */
	shared.gallery = function (ctx, opts) {
		opts = opts || {};
		var parts = shared.parts;
		var i18n = ctx.i18n || {};
		var urls = (opts.urls || []).filter(parts.isSafeUrl);
		var reduced = window.matchMedia('(prefers-reduced-motion: reduce)');

		var el = document.createElement('div');
		var track = document.createElement('div');
		var stage = document.createElement('div');
		var imgs = [];
		var thumbs = [];
		var dots = [];
		var prev = null;
		var next = null;
		var count = null;
		var frame = 0;

		el.className = 'mvweb-om-ui__gal';
		stage.className = 'mvweb-om-ui__gal-stage';
		track.className = 'mvweb-om-ui__gal-track';
		if (opts.ratio) {
			el.style.setProperty('--mvweb-om-gal-ratio', opts.ratio);
		}
		stage.appendChild(track);
		el.appendChild(stage);

		urls.forEach(function (url, i) {
			var img = document.createElement('img');
			img.className = 'mvweb-om-ui__gal-img';
			img.setAttribute('src', url);
			img.setAttribute('alt', opts.alt || '');
			if (i > 0) {
				img.setAttribute('loading', 'lazy');
				img.setAttribute('decoding', 'async');
			}
			track.appendChild(img);
			imgs.push(img);
		});

		if (!urls.length) {
			el.hidden = true;
		}

		/**
		 * Distance between two slides, gap included.
		 *
		 * @return {number}
		 */
		function stepWidth() {
			return imgs.length > 1 ? imgs[1].offsetLeft - imgs[0].offsetLeft : track.clientWidth;
		}

		/**
		 * Index of the slide in view.
		 *
		 * @return {number}
		 */
		function current() {
			return Math.max(0, Math.min(imgs.length - 1, Math.round(track.scrollLeft / (stepWidth() || 1))));
		}

		/**
		 * Refresh the counter, dots, thumbnails and arrow state.
		 */
		function paint() {
			frame = 0;
			var i = current();
			if (count) {
				count.textContent = (i + 1) + ' / ' + imgs.length;
			}
			dots.forEach(function (dot, n) {
				if (n === i) {
					dot.setAttribute('data-on', '');
				} else {
					dot.removeAttribute('data-on');
				}
			});
			thumbs.forEach(function (thumb, n) {
				thumb.setAttribute('aria-current', n === i ? 'true' : 'false');
			});
			if (prev) {
				prev.disabled = i === 0;
				next.disabled = i === imgs.length - 1;
			}
		}

		/**
		 * Scroll to a slide.
		 *
		 * @param {number} i Slide index.
		 */
		function go(i) {
			var target = Math.max(0, Math.min(imgs.length - 1, i));
			track.scrollTo({ left: target * stepWidth(), behavior: reduced.matches ? 'auto' : 'smooth' });
		}

		var onScroll = function () {
			if (!frame) {
				frame = requestAnimationFrame(paint);
			}
		};
		var onKey = function (e) {
			if ('ArrowLeft' === e.key) {
				e.preventDefault();
				go(current() - 1);
			} else if ('ArrowRight' === e.key) {
				e.preventDefault();
				go(current() + 1);
			}
		};

		if (imgs.length > 1) {
			track.setAttribute('tabindex', '0');
			track.setAttribute('role', 'group');
			if (opts.alt) {
				track.setAttribute('aria-label', opts.alt);
			}
			prev = parts.iconButton('chev-l', i18n.prev || 'Previous', function () { go(current() - 1); }, 'mvweb-om-ui__icon-btn--glass mvweb-om-ui__gal-btn mvweb-om-ui__gal-btn--prev');
			next = parts.iconButton('chev-r', i18n.next || 'Next', function () { go(current() + 1); }, 'mvweb-om-ui__icon-btn--glass mvweb-om-ui__gal-btn mvweb-om-ui__gal-btn--next');
			stage.appendChild(prev);
			stage.appendChild(next);

			if (opts.counter) {
				count = document.createElement('span');
				count.className = 'mvweb-om-ui__gal-count';
				stage.appendChild(count);
			}
			if (opts.dots) {
				var wrap = document.createElement('div');
				wrap.className = 'mvweb-om-ui__gal-dots';
				wrap.setAttribute('aria-hidden', 'true');
				imgs.forEach(function () {
					var dot = document.createElement('i');
					wrap.appendChild(dot);
					dots.push(dot);
				});
				stage.appendChild(wrap);
			}
			if (opts.thumbs) {
				var row = document.createElement('div');
				row.className = 'mvweb-om-ui__gal-thumbs';
				urls.forEach(function (url, n) {
					var thumb = document.createElement('button');
					var pic = document.createElement('img');
					var label = (i18n.photo || 'Photo') + ' ' + (n + 1);
					thumb.type = 'button';
					thumb.className = 'mvweb-om-ui__gal-thumb';
					thumb.setAttribute('title', label);
					pic.setAttribute('src', url);
					pic.setAttribute('alt', '');
					pic.setAttribute('loading', 'lazy');
					pic.setAttribute('decoding', 'async');
					thumb.appendChild(pic);
					thumb.appendChild(parts.sr(label));
					thumb.addEventListener('click', function () { go(n); });
					row.appendChild(thumb);
					thumbs.push(thumb);
				});
				el.appendChild(row);
			}

			track.addEventListener('scroll', onScroll, { passive: true });
			track.addEventListener('keydown', onKey);
			paint();
		}

		return {
			el: el,
			go: go,
			index: current,
			count: imgs.length,
			destroy: function () {
				if (frame) {
					cancelAnimationFrame(frame);
					frame = 0;
				}
				track.removeEventListener('scroll', onScroll);
				track.removeEventListener('keydown', onKey);
				if (el.parentNode) {
					el.parentNode.removeChild(el);
				}
			}
		};
	};
})();
