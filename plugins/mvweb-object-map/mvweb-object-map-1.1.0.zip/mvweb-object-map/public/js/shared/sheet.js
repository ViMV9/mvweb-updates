/**
 * Bottom sheet with snap positions, or a side panel on desktop.
 *
 * The sheet is as tall as its largest position. A position is a translateY
 * offset; heights come from the CSS variables --mvweb-om-sheet-<position>
 * (px, rem, em, %, vh, dvh). Drag uses Pointer Events on the handle and on
 * elements marked with data-sheet-drag; touch-action is none only there.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm = window.mvwebOm || {};
	var shared = api.shared = api.shared || {};

	var PHONE_QUERY = '(max-width: 782px)';
	var LENGTH = /^\s*(-?[\d.]+)\s*(px|rem|em|%|vh|dvh|svh|lvh)?\s*$/;
	var THRESHOLD = 6;
	var HIDE_DELAY = 250;
	var FOCUSABLE = 'button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

	var uid = 0;

	/**
	 * Convert a CSS length to pixels.
	 *
	 * @param {string} raw       Length such as 7.5rem, 50% or 320px.
	 * @param {number} percentOf What 100% means, in px.
	 * @return {number} NaN when the value cannot be read.
	 */
	function toPx(raw, percentOf) {
		var m = String(raw).match(LENGTH);
		if (!m) {
			return NaN;
		}
		var n = parseFloat(m[1]);
		switch (m[2]) {
			case 'rem':
			case 'em':
				return n * (parseFloat(getComputedStyle(document.documentElement).fontSize) || 16);
			case '%':
				return n / 100 * percentOf;
			case 'vh':
			case 'dvh':
			case 'svh':
			case 'lvh':
				return n / 100 * window.innerHeight;
			default:
				return n;
		}
	}

	/**
	 * Create a sheet.
	 *
	 * @param {Object} ctx  Map context.
	 * @param {Object} opts {
	 *     host: HTMLElement,
	 *     positions: string[] from lowest to highest,
	 *     initial: string,
	 *     modal: boolean, inert background and page scroll lock at the highest position,
	 *     side: boolean|'left'|'right', side panel on desktop instead of a bottom sheet,
	 *     owner: string, key for ctx.setInsets (default sheet),
	 *     onChange: function (position),
	 *     onClose: function ()
	 * }
	 * @return {Object} { el, body, open, set, close, position, relabel, destroy }
	 */
	shared.sheet = function (ctx, opts) {
		opts = opts || {};
		var host = opts.host || ctx.root.querySelector('.mvweb-om__map') || ctx.root;
		var positions = (opts.positions && opts.positions.length) ? opts.positions.slice() : ['peek', 'half', 'full'];
		var last = positions[positions.length - 1];
		var side = 'right' === opts.side ? 'right' : (opts.side ? 'left' : '');
		var owner = opts.owner || 'sheet';
		var i18n = ctx.i18n || {};
		var phoneQuery = window.matchMedia(PHONE_QUERY);

		var el = document.createElement('div');
		var handle = document.createElement('button');
		var handleText = document.createElement('span');
		var body = document.createElement('div');

		var opened = false;
		var current = null;
		var offset = 0;
		var drag = null;
		var touch = null;
		var frame = 0;
		var suppress = false;
		var hideTimer = 0;
		var inerted = [];
		var locked = false;

		el.className = 'mvweb-om-ui__sheet';
		el.hidden = true;
		el.setAttribute('role', opts.modal ? 'dialog' : 'region');
		if (opts.modal) {
			el.setAttribute('aria-modal', 'true');
		}
		handle.type = 'button';
		handle.className = 'mvweb-om-ui__handle mvweb-om-ui__sheet-handle';
		handleText.className = 'mvweb-om__sr';
		handle.appendChild(handleText);
		body.className = 'mvweb-om-ui__sheet-body';
		el.appendChild(handle);
		el.appendChild(body);
		host.appendChild(el);

		/**
		 * Whether the side panel layout is active.
		 *
		 * @return {boolean}
		 */
		function isSide() {
			return !!side && !ctx.isPhone();
		}

		/**
		 * Measure the sheet: full height and the visible height of every position.
		 *
		 * @return {Object} { height, visible, min }
		 */
		function metrics() {
			var style = getComputedStyle(el);
			var height = el.offsetHeight;
			var hostHeight = host.clientHeight || height;
			var safe = parseFloat(style.paddingBottom) || 0;
			var visible = {};
			var min = height;
			positions.forEach(function (name, index) {
				var px;
				if (name === last) {
					px = height;
				} else {
					px = toPx(style.getPropertyValue('--mvweb-om-sheet-' + name), hostHeight);
					px = isNaN(px) ? height * (index + 1) / positions.length : Math.min(height, px + safe);
				}
				visible[name] = px;
				min = Math.min(min, px);
			});
			return { height: height, visible: visible, min: min };
		}

		/**
		 * Write the translateY offset on the next frame.
		 *
		 * @param {number} value Offset in px.
		 */
		function paint(value) {
			offset = value;
			if (!frame) {
				frame = requestAnimationFrame(function () {
					frame = 0;
					el.style.transform = 'translateY(' + offset + 'px)';
				});
			}
		}

		/**
		 * Set the transform right away.
		 *
		 * @param {number|null} value Offset in px, or null to clear it.
		 */
		function place(value) {
			if (frame) {
				cancelAnimationFrame(frame);
				frame = 0;
			}
			offset = value || 0;
			el.style.transform = null === value ? '' : 'translateY(' + value + 'px)';
		}

		/**
		 * Tell the map how much of its bottom (or side) the sheet covers.
		 *
		 * @param {Object} m Measurements, used for the bottom sheet.
		 */
		function updateInsets(m) {
			if (!opened) {
				ctx.setInsets(owner, null);
			} else if (isSide()) {
				var width = el.offsetWidth;
				ctx.setInsets(owner, 'right' === side ? { r: width } : { l: width });
			} else {
				ctx.setInsets(owner, { b: m.visible[current] });
			}
		}

		/**
		 * Make the background inert and lock page scroll while a modal sheet is at its highest position.
		 */
		function syncModal() {
			var trap = !!opts.modal && opened && current === last && !isSide();
			if (trap && !locked) {
				locked = true;
				ctx.lock();
				Array.prototype.forEach.call(host.children, function (child) {
					if (child !== el && !child.hasAttribute('inert')) {
						child.setAttribute('inert', '');
						inerted.push(child);
					}
				});
			} else if (!trap && locked) {
				locked = false;
				ctx.unlock();
				inerted.forEach(function (child) { child.removeAttribute('inert'); });
				inerted = [];
			}
		}

		/**
		 * Update the handle label, the state attributes and the modal trap.
		 */
		function syncState() {
			var sideMode = isSide();
			var label = current === last ? (i18n.collapse || 'Collapse the card') : (i18n.expand || 'Expand the card');
			el.setAttribute('data-mode', sideMode ? 'side' : 'sheet');
			el.setAttribute('data-side', sideMode ? side : '');
			el.setAttribute('data-position', current || '');
			el.setAttribute('data-state', current === last ? 'full' : 'partial');
			handle.setAttribute('aria-expanded', current === last ? 'true' : 'false');
			handle.setAttribute('title', label);
			handleText.textContent = label;
			syncModal();
		}

		/**
		 * Move to a position.
		 *
		 * @param {string}  name   Position name.
		 * @param {boolean} notify Whether to call onChange.
		 */
		function goTo(name, notify) {
			var changed = name !== current;
			current = name;
			syncState();
			if (isSide()) {
				place(null);
				updateInsets();
			} else {
				var m = metrics();
				place(Math.max(0, m.height - m.visible[name]));
				updateInsets(m);
			}
			if (changed && notify && typeof opts.onChange === 'function') {
				opts.onChange(name);
			}
		}

		/**
		 * Point aria-labelledby at the first title inside the body.
		 */
		function relabel() {
			var title = body.querySelector('[data-sheet-title], .mvweb-om-ui__title, h1, h2, h3');
			if (!title) {
				el.removeAttribute('aria-labelledby');
				return;
			}
			if (!title.id) {
				title.id = 'mvweb-om-sheet-title-' + (++uid);
			}
			el.setAttribute('aria-labelledby', title.id);
		}

		/**
		 * Whether a name is one of the positions.
		 *
		 * @param {string} name Position name.
		 * @return {boolean}
		 */
		function known(name) {
			return positions.indexOf(name) !== -1;
		}

		/**
		 * Open the sheet, or change its position when it is already open.
		 *
		 * @param {string} position Position name, defaults to the initial one.
		 */
		function open(position) {
			var name = known(position) ? position : (current || (known(opts.initial) ? opts.initial : positions[0]));
			var first = !opened;
			clearTimeout(hideTimer);
			relabel();
			if (first) {
				opened = true;
				ctx.focus.remember();
				el.classList.add('mvweb-om-ui__sheet--still');
				el.hidden = false;
				if (!isSide()) {
					place(metrics().height);
				}
				void el.offsetHeight;
				el.classList.remove('mvweb-om-ui__sheet--still');
			}
			goTo(name, true);
			if (first) {
				var target = Array.prototype.filter.call(el.querySelectorAll(FOCUSABLE), function (node) {
					return node.getClientRects().length > 0;
				})[0];
				if (target) {
					target.focus({ preventScroll: true });
				}
			}
		}

		/**
		 * Close the sheet.
		 *
		 * @param {boolean} silent Skip focus restore and onClose (used by destroy).
		 */
		function close(silent) {
			if (!opened) {
				return;
			}
			opened = false;
			current = null;
			if (drag) {
				drag.moved = false;
				dragEnd();
			}
			touch = null;
			syncModal();
			ctx.setInsets(owner, null);
			if (isSide()) {
				el.hidden = true;
			} else {
				place(el.offsetHeight);
				hideTimer = setTimeout(function () {
					if (!opened) {
						el.hidden = true;
					}
				}, HIDE_DELAY);
			}
			if (!silent) {
				ctx.focus.restore();
				if (typeof opts.onClose === 'function') {
					opts.onClose();
				}
			}
		}

		/**
		 * The position whose offset is nearest to a value.
		 *
		 * @param {number} value Offset in px.
		 * @param {Object} m     Measurements.
		 * @return {string} Position name.
		 */
		function nearest(value, m) {
			var best = last;
			var gap = Infinity;
			positions.forEach(function (name) {
				var d = Math.abs(m.height - m.visible[name] - value);
				if (d < gap) {
					gap = d;
					best = name;
				}
			});
			return best;
		}

		/**
		 * Begin a drag gesture.
		 *
		 * @param {number} y  Pointer Y.
		 * @param {number} id Pointer id, or -1 for touch events.
		 */
		function dragStart(y, id) {
			drag = { y: y, id: id, from: offset, m: metrics(), moved: false, samples: [[performance.now(), y]] };
			if (id >= 0) {
				document.addEventListener('pointermove', onPointerMove);
				document.addEventListener('pointerup', onPointerEnd);
				document.addEventListener('pointercancel', onPointerEnd);
			}
		}

		/**
		 * Follow the pointer.
		 *
		 * @param {number} y Pointer Y.
		 */
		function dragMove(y) {
			var dy = y - drag.y;
			if (!drag.moved) {
				if (Math.abs(dy) < THRESHOLD) {
					return;
				}
				drag.moved = true;
				el.classList.add('mvweb-om-ui__sheet--drag');
			}
			var limit = Math.max(0, drag.m.height - drag.m.min);
			paint(Math.min(limit, Math.max(0, drag.from + dy)));
			var now = performance.now();
			drag.samples.push([now, y]);
			while (drag.samples.length > 2 && now - drag.samples[0][0] > 120) {
				drag.samples.shift();
			}
		}

		/**
		 * Finish the gesture and settle on the nearest position.
		 */
		function dragEnd() {
			var d = drag;
			drag = null;
			document.removeEventListener('pointermove', onPointerMove);
			document.removeEventListener('pointerup', onPointerEnd);
			document.removeEventListener('pointercancel', onPointerEnd);
			el.classList.remove('mvweb-om-ui__sheet--drag');
			if (!d || !d.moved) {
				return;
			}
			suppress = true;
			setTimeout(function () { suppress = false; }, 60);
			var first = d.samples[0];
			var end = d.samples[d.samples.length - 1];
			var span = end[0] - first[0];
			var velocity = (span > 0 && performance.now() - end[0] < 100) ? (end[1] - first[1]) / span : 0;
			goTo(nearest(offset + velocity * 120, d.m), true);
		}

		/**
		 * Whether a pointer press on this element can start a drag.
		 *
		 * @param {Element} target Event target.
		 * @return {boolean}
		 */
		function dragOrigin(target) {
			var zone = target.closest('[data-sheet-drag]');
			return handle.contains(target) ||
				!!(zone && el.contains(zone)) ||
				('partial' === el.getAttribute('data-state') && body.contains(target));
		}

		/**
		 * Go to the next position, wrapping from the highest to the lowest.
		 */
		function cycle() {
			goTo(positions[(positions.indexOf(current) + 1) % positions.length], true);
		}

		function onPointerMove(e) {
			if (drag && drag.id === e.pointerId) {
				dragMove(e.clientY);
			}
		}

		function onPointerEnd(e) {
			if (drag && drag.id === e.pointerId) {
				dragEnd();
			}
		}

		el.addEventListener('pointerdown', function (e) {
			if (!opened || isSide() || drag || (e.pointerType === 'mouse' && e.button !== 0)) {
				return;
			}
			if (dragOrigin(e.target)) {
				dragStart(e.clientY, e.pointerId);
			}
		});
		el.addEventListener('click', function (e) {
			if (suppress) {
				e.preventDefault();
				e.stopPropagation();
				suppress = false;
			}
		}, true);
		handle.addEventListener('click', function () {
			if (opened) {
				cycle();
			}
		});
		el.addEventListener('keydown', function (e) {
			if ('Escape' === e.key && opened) {
				e.stopPropagation();
				close(false);
			}
		});
		var onDocKey = function (e) {
			if ('Escape' !== e.key || !opened || e.defaultPrevented) {
				return;
			}
			var active = document.activeElement;
			if (active && active !== document.body && !ctx.root.contains(active)) {
				return;
			}
			if (active && el.contains(active)) {
				return;
			}
			e.preventDefault();
			close(false);
		};
		document.addEventListener('keydown', onDocKey);

		body.addEventListener('touchstart', function (e) {
			touch = (opened && !isSide() && 'full' === el.getAttribute('data-state') && body.scrollTop <= 0 && e.touches.length === 1)
				? { y: e.touches[0].clientY, started: false }
				: null;
		}, { passive: true });
		body.addEventListener('touchmove', function (e) {
			if (!touch) {
				return;
			}
			var y = e.touches[0].clientY;
			if (!touch.started) {
				if (body.scrollTop > 0 || y - touch.y < -THRESHOLD) {
					touch = null;
					return;
				}
				if (y - touch.y < THRESHOLD) {
					return;
				}
				touch.started = true;
				dragStart(touch.y, -1);
			}
			e.preventDefault();
			dragMove(y);
		}, { passive: false });
		var touchEnd = function () {
			if (touch && touch.started) {
				dragEnd();
			}
			touch = null;
		};
		body.addEventListener('touchend', touchEnd);
		body.addEventListener('touchcancel', touchEnd);

		var relayout = function () {
			if (opened && !drag) {
				goTo(current, false);
			}
		};
		window.addEventListener('resize', relayout);
		phoneQuery.addEventListener('change', relayout);

		return {
			el: el,
			body: body,
			open: open,
			set: open,
			close: function () { close(false); },
			position: function () { return opened ? current : null; },
			relabel: relabel,
			destroy: function () {
				close(true);
				clearTimeout(hideTimer);
				window.removeEventListener('resize', relayout);
				phoneQuery.removeEventListener('change', relayout);
				document.removeEventListener('keydown', onDocKey);
				if (el.parentNode) {
					el.parentNode.removeChild(el);
				}
			}
		};
	};
})();
