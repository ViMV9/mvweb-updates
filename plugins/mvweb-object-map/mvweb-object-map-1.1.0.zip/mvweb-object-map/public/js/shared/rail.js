/**
 * Horizontal card rail on native scroll-snap.
 *
 * No custom swipe: the browser scrolls and snaps. The active card is the one
 * nearest the rail centre once scrolling has stopped. The caller passes a
 * limited list (visible objects, at most about 30).
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm = window.mvwebOm || {};
	var shared = api.shared = api.shared || {};

	var SETTLE_DELAY = 100;

	/**
	 * Create a rail.
	 *
	 * @param {Object} ctx  Map context.
	 * @param {Object} opts {
	 *     host: HTMLElement,
	 *     items: Array of objects,
	 *     render: function (obj) returning an element,
	 *     onActive: function (obj, index) called when the user brings another card to the centre,
	 *     label: string, accessible name of the region,
	 *     counter: boolean, show "1 / 12",
	 *     arrows: boolean, show the buttons on desktop (default true)
	 * }
	 * @return {Object} { el, scrollTo, setItems, active, destroy }
	 */
	shared.rail = function (ctx, opts) {
		opts = opts || {};
		var parts = shared.parts;
		var i18n = ctx.i18n || {};
		var items = (opts.items || []).slice();
		var reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
		var arrows = false !== opts.arrows;

		var el = document.createElement('div');
		var track = document.createElement('div');
		var prev = null;
		var next = null;
		var count = null;
		var timer = 0;
		var index = 0;

		el.className = 'mvweb-om-ui__rail';
		el.setAttribute('role', 'region');
		if (opts.label) {
			el.setAttribute('aria-label', opts.label);
		}
		track.className = 'mvweb-om-ui__rail-track';
		track.setAttribute('tabindex', '0');
		el.appendChild(track);

		if (arrows) {
			prev = parts.iconButton('chev-l', i18n.prev || 'Previous', function () { step(-1); }, 'mvweb-om-ui__icon-btn--glass mvweb-om-ui__rail-btn mvweb-om-ui__rail-btn--prev');
			next = parts.iconButton('chev-r', i18n.next || 'Next', function () { step(1); }, 'mvweb-om-ui__icon-btn--glass mvweb-om-ui__rail-btn mvweb-om-ui__rail-btn--next');
			el.appendChild(prev);
			el.appendChild(next);
		}
		if (opts.counter) {
			count = document.createElement('span');
			count.className = 'mvweb-om-ui__rail-count';
			el.appendChild(count);
		}
		(opts.host || ctx.root).appendChild(el);

		/**
		 * Draw all cards.
		 */
		function build() {
			var fragment = document.createDocumentFragment();
			items.forEach(function (obj, i) {
				var item = document.createElement('div');
				item.className = 'mvweb-om-ui__rail-item';
				item.setAttribute('data-index', String(i));
				item.appendChild(opts.render(obj));
				fragment.appendChild(item);
			});
			track.textContent = '';
			track.appendChild(fragment);
		}

		/**
		 * Mark the active card and refresh the counter and the buttons.
		 *
		 * @param {number} i Active index.
		 */
		function mark(i) {
			index = i;
			Array.prototype.forEach.call(track.children, function (item, n) {
				if (n === i) {
					item.setAttribute('data-on', '');
				} else {
					item.removeAttribute('data-on');
				}
			});
			if (count) {
				count.textContent = items.length ? (i + 1) + ' / ' + items.length : '';
			}
			if (prev) {
				prev.disabled = i <= 0;
				next.disabled = i >= items.length - 1;
			}
		}

		/**
		 * Scroll offset that centres a card.
		 *
		 * @param {number} i Card index.
		 * @return {number}
		 */
		function leftFor(i) {
			var item = track.children[i];
			return item.offsetLeft - (track.clientWidth - item.offsetWidth) / 2;
		}

		/**
		 * The card nearest the centre of the visible part.
		 *
		 * @return {number}
		 */
		function nearest() {
			var middle = track.scrollLeft + track.clientWidth / 2;
			var best = 0;
			var gap = Infinity;
			Array.prototype.forEach.call(track.children, function (item, n) {
				var d = Math.abs(item.offsetLeft + item.offsetWidth / 2 - middle);
				if (d < gap) {
					gap = d;
					best = n;
				}
			});
			return best;
		}

		/**
		 * Scrolling has stopped: report a new centre card.
		 */
		function settle() {
			clearTimeout(timer);
			if (!items.length) {
				return;
			}
			var i = nearest();
			if (i === index) {
				return;
			}
			mark(i);
			if (typeof opts.onActive === 'function') {
				opts.onActive(items[i], i);
			}
		}

		/**
		 * Bring a card to the centre.
		 *
		 * @param {number}  i      Card index.
		 * @param {boolean} smooth Animate (default true, off with reduced motion).
		 * @param {boolean} notify Call onActive for it.
		 */
		function move(i, smooth, notify) {
			if (!items.length) {
				return;
			}
			var target = Math.max(0, Math.min(items.length - 1, i));
			var changed = target !== index;
			mark(target);
			track.scrollTo({ left: leftFor(target), behavior: (false === smooth || reduced.matches) ? 'auto' : 'smooth' });
			if (notify && changed && typeof opts.onActive === 'function') {
				opts.onActive(items[target], target);
			}
		}

		/**
		 * Step to the neighbour card because the user asked for it.
		 *
		 * @param {number} delta -1 or 1.
		 */
		function step(delta) {
			move(index + delta, true, true);
		}

		var onScroll = function () {
			clearTimeout(timer);
			timer = setTimeout(settle, SETTLE_DELAY);
		};
		var onKey = function (e) {
			if (e.target !== track) {
				return;
			}
			if ('ArrowLeft' === e.key) {
				e.preventDefault();
				step(-1);
			} else if ('ArrowRight' === e.key) {
				e.preventDefault();
				step(1);
			}
		};
		track.addEventListener('scroll', onScroll, { passive: true });
		track.addEventListener('scrollend', settle);
		track.addEventListener('keydown', onKey);

		build();
		mark(0);

		return {
			el: el,
			scrollTo: function (i, smooth) { move(i, smooth, false); },
			setItems: function (list) {
				items = (list || []).slice();
				build();
				track.scrollLeft = 0;
				mark(0);
			},
			active: function () { return index; },
			destroy: function () {
				clearTimeout(timer);
				track.removeEventListener('scroll', onScroll);
				track.removeEventListener('scrollend', settle);
				track.removeEventListener('keydown', onKey);
				if (el.parentNode) {
					el.parentNode.removeChild(el);
				}
			}
		};
	};
})();
