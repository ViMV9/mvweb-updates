/**
 * Card building blocks shared by the balloon and object-window variants.
 *
 * Pure functions that return DOM elements. Object text goes in via
 * textContent and URLs via setAttribute after a scheme check — never innerHTML.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	var api = window.mvwebOm = window.mvwebOm || {};
	var shared = api.shared = api.shared || {};

	var SVG_NS = 'http://www.w3.org/2000/svg';
	var COLOR = /^#[0-9a-f]{3,8}$/i;
	var SIZES = { photo: ['photo', 'thumb'], thumb: ['thumb'], pin: ['pin', 'thumb'] };

	var ICONS = {
		pin: [['path', 'M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z'], ['circle', 12, 9.5, 2.5]],
		phone: [['path', 'M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2']],
		clock: [['circle', 12, 12, 9], ['path', 'M12 7v5l3 2']],
		route: [['path', 'M3 11l18-8-8 18-2-8z']],
		close: [['path', 'M6 6l12 12M18 6L6 18']],
		search: [['circle', 11, 11, 7], ['path', 'm20 20-3.5-3.5']],
		'chev-l': [['path', 'm15 6-6 6 6 6']],
		'chev-r': [['path', 'm9 6 6 6-6 6']],
		'chev-d': [['path', 'm6 9 6 6 6-6']],
		'chev-u': [['path', 'm6 15 6-6 6 6']],
		list: [['path', 'M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01']],
		map: [['path', 'M9 4 3 6v14l6-2 6 2 6-2V4l-6 2z'], ['path', 'M9 4v14M15 6v14']],
		ext: [['path', 'M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5']],
		arrow: [['path', 'M5 12h14M13 6l6 6-6 6']]
	};

	/**
	 * Read a translated string.
	 *
	 * @param {Object} ctx      Map context (may be empty).
	 * @param {string} key      Key in the i18n object.
	 * @param {string} fallback English text.
	 * @return {string}
	 */
	function text(ctx, key, fallback) {
		var i18n = (ctx && ctx.i18n) || (window.mvwebOmData && window.mvwebOmData.i18n) || {};
		return i18n[key] || fallback;
	}

	/**
	 * Whether a URL is safe to place into src/href (http(s) or root-relative).
	 *
	 * @param {string} url URL to test.
	 * @return {boolean}
	 */
	function isSafeUrl(url) {
		if (typeof url !== 'string') {
			return false;
		}
		var s = url.trim().toLowerCase();
		return s.indexOf('http://') === 0 || s.indexOf('https://') === 0 || s.indexOf('/') === 0;
	}

	/**
	 * Value of a characteristic: a link for the "url" type, text otherwise.
	 *
	 * @param {Object} spec Spec row ({ type, value }).
	 * @param {string} cls  Class name of the link.
	 * @return {Node}
	 */
	function specValue(spec, cls) {
		if ('url' === spec.type && isSafeUrl(spec.value)) {
			var a = document.createElement('a');
			a.className = cls;
			a.setAttribute('href', spec.value);
			a.setAttribute('target', '_blank');
			a.setAttribute('rel', 'noopener noreferrer');
			a.textContent = spec.value.replace(/^https?:\/\/(www\.)?/i, '').replace(/\/$/, '');
			return a;
		}
		return document.createTextNode(String(spec.value));
	}

	/**
	 * Create an element with a class and optional text.
	 *
	 * @param {string} tag  Tag name.
	 * @param {string} cls  Class name.
	 * @param {string} body Text content (optional).
	 * @return {HTMLElement}
	 */
	function make(tag, cls, body) {
		var el = document.createElement(tag);
		if (cls) {
			el.className = cls;
		}
		if (body) {
			el.textContent = body;
		}
		return el;
	}

	/**
	 * Build a visually hidden text node.
	 *
	 * @param {string} body Text.
	 * @return {HTMLElement}
	 */
	function sr(body) {
		return make('span', 'mvweb-om__sr', body);
	}

	/**
	 * Build an SVG icon from the built-in UI set or an object icon preset.
	 *
	 * @param {string} name Icon name (pin, phone, clock, route, close, chev-l, ...) or preset slug.
	 * @param {string} size Optional: sm for the small size.
	 * @return {SVGElement|null} Null when the name is unknown.
	 */
	function icon(name, size) {
		var shapes = ICONS.hasOwnProperty(name) ? ICONS[name] : null;
		var presets = (window.mvwebOmData && window.mvwebOmData.icons) || {};
		if (!shapes && presets.hasOwnProperty(name) && 'string' === typeof presets[name]) {
			shapes = [['path', presets[name]]];
		}
		if (!shapes) {
			return null;
		}
		var svg = document.createElementNS(SVG_NS, 'svg');
		svg.setAttribute('class', 'mvweb-om-ui__icon' + ('sm' === size ? ' mvweb-om-ui__icon--sm' : ''));
		svg.setAttribute('viewBox', '0 0 24 24');
		svg.setAttribute('fill', 'none');
		svg.setAttribute('stroke', 'currentColor');
		svg.setAttribute('stroke-width', '2');
		svg.setAttribute('stroke-linecap', 'round');
		svg.setAttribute('stroke-linejoin', 'round');
		svg.setAttribute('aria-hidden', 'true');
		svg.setAttribute('focusable', 'false');
		shapes.forEach(function (shape) {
			var node = document.createElementNS(SVG_NS, shape[0]);
			if ('circle' === shape[0]) {
				node.setAttribute('cx', shape[1]);
				node.setAttribute('cy', shape[2]);
				node.setAttribute('r', shape[3]);
			} else {
				node.setAttribute('d', shape[1]);
			}
			svg.appendChild(node);
		});
		return svg;
	}

	/**
	 * Build a tel: link target from a phone string.
	 *
	 * @param {string} phone Phone as typed by the owner.
	 * @return {string}
	 */
	function telHref(phone) {
		var plus = phone.trim().charAt(0) === '+';
		return 'tel:' + (plus ? '+' : '') + phone.replace(/[^0-9]/g, '');
	}

	/**
	 * Whether an option is on: everything is on unless set to false.
	 *
	 * @param {Object} opts Options (may be empty).
	 * @param {string} key  Option name.
	 * @return {boolean}
	 */
	function on(opts, key) {
		return !opts || false !== opts[key];
	}

	/**
	 * Build a row with an icon and text, or a link row.
	 *
	 * @param {string} name Icon name.
	 * @param {string} body Text.
	 * @param {string} href Optional link target.
	 * @return {HTMLElement}
	 */
	function row(name, body, href) {
		var el = make(href ? 'a' : 'div', 'mvweb-om-ui__row' + (href ? ' mvweb-om-ui__row--link' : ''));
		var ico = icon(name, 'sm');
		if (href) {
			el.setAttribute('href', href);
		}
		if (ico) {
			el.appendChild(ico);
		}
		el.appendChild(make('span', '', body));
		return el;
	}

	/**
	 * Spec rows of an object that carry a display flag.
	 *
	 * Uses the schema from the REST payload. Without a schema (or without spec
	 * ids) the balloon flag falls back to the spec's own inBalloon field.
	 *
	 * @param {Object} obj  Object data.
	 * @param {Object} ctx  Map context.
	 * @param {string} flag balloon, list or marker; empty for all specs.
	 * @return {Array}
	 */
	function flagged(obj, ctx, flag) {
		var specs = obj.specs || [];
		if (!flag) {
			return specs;
		}
		var schema = (ctx && ctx.schema) || [];
		if (!schema.length) {
			return 'balloon' === flag ? specs.filter(function (s) { return s.inBalloon; }) : [];
		}
		var ids = {};
		schema.forEach(function (field) {
			if (field.show && field.show.indexOf(flag) !== -1) {
				ids[field.id] = true;
			}
		});
		return specs.filter(function (s) {
			return undefined !== s.id && ids[s.id] === true;
		});
	}

	var parts = {
		icon: icon,
		sr: sr,
		isSafeUrl: isSafeUrl,

		/**
		 * Photo URLs of an object: the main photo first, then the gallery without
		 * other sizes of the same file.
		 *
		 * @param {Object} obj Object data.
		 * @return {string[]}
		 */
		photoUrls: function (obj) {
			var out = [];
			var seen = {};
			[obj.photo || obj.thumb].concat(obj.gallery || []).forEach(function (url) {
				if (!isSafeUrl(url)) {
					return;
				}
				var key = url.replace(/-\d+x\d+(?=\.[a-z0-9]+(\?|$))/i, '');
				if (!seen[key]) {
					seen[key] = true;
					out.push(url);
				}
			});
			return out;
		},

		/**
		 * Object photo.
		 *
		 * @param {Object} obj  Object data.
		 * @param {Object} opts { size: photo|thumb|pin, ratio, eager, className }.
		 * @return {HTMLImageElement|null} Null when the object has no safe photo URL.
		 */
		photo: function (obj, opts) {
			opts = opts || {};
			var url = '';
			(SIZES[opts.size] || SIZES.photo).some(function (key) {
				url = obj[key] || '';
				return !!url;
			});
			if (!isSafeUrl(url)) {
				return null;
			}
			var img = make('img', 'mvweb-om-ui__photo' + (opts.className ? ' ' + opts.className : ''));
			img.setAttribute('src', url);
			img.setAttribute('alt', '');
			img.setAttribute('decoding', 'async');
			if (!opts.eager) {
				img.setAttribute('loading', 'lazy');
			}
			if (opts.ratio) {
				img.style.setProperty('--mvweb-om-ratio', opts.ratio);
			}
			return img;
		},

		/**
		 * Category tag: color dot and name of the object's first known category.
		 *
		 * @param {Object} obj Object data.
		 * @param {Object} ctx Map context.
		 * @return {HTMLElement|null}
		 */
		cat: function (obj, ctx) {
			var cats = (ctx && ctx.categories) || [];
			var found = null;
			(obj.categories || []).some(function (slug) {
				cats.some(function (cat) {
					if (cat.slug === slug) {
						found = cat;
					}
					return !!found;
				});
				return !!found;
			});
			if (!found || !found.name) {
				return null;
			}
			var el = make('span', 'mvweb-om-ui__cat', found.name);
			if (COLOR.test(found.color || '')) {
				el.style.setProperty('--mvweb-om-ui-c', found.color);
			}
			return el;
		},

		/**
		 * Object title.
		 *
		 * @param {Object} obj       Object data.
		 * @param {string} className Extra class.
		 * @return {HTMLElement}
		 */
		title: function (obj, className) {
			return make('div', 'mvweb-om-ui__title' + (className ? ' ' + className : ''), obj.title || '');
		},

		/**
		 * Address, phone and hours rows with icons. Each is on unless set to false.
		 *
		 * @param {Object} obj  Object data.
		 * @param {Object} ctx  Map context.
		 * @param {Object} opts { address, phone, hours }.
		 * @return {HTMLElement|null} Null when there is nothing to show.
		 */
		rows: function (obj, ctx, opts) {
			var wrap = make('div', 'mvweb-om-ui__rows');
			if (on(opts, 'address') && obj.address) {
				wrap.appendChild(row('pin', obj.address));
			}
			if (on(opts, 'phone') && obj.phone) {
				wrap.appendChild(row('phone', obj.phone, telHref(obj.phone)));
			}
			if (on(opts, 'hours') && obj.hours) {
				wrap.appendChild(row('clock', obj.hours));
			}
			return wrap.childNodes.length ? wrap : null;
		},

		/**
		 * One line of key figures, "142 m2 · 2 floors · 2025".
		 *
		 * @param {Object} obj  Object data.
		 * @param {Object} ctx  Map context.
		 * @param {Object} opts { flag: list|marker|balloon, max }.
		 * @return {HTMLElement|null} Null when no field carries the flag.
		 */
		facts: function (obj, ctx, opts) {
			opts = opts || {};
			var max = opts.max || 3;
			var values = flagged(obj, ctx, opts.flag || 'list')
				.map(function (s) { return s.value; })
				.filter(function (value) { return !!value; })
				.slice(0, max);
			return values.length ? make('span', 'mvweb-om-ui__facts', values.join(' · ')) : null;
		},

		/**
		 * Characteristics as tiles or as a plain list.
		 *
		 * @param {Object} obj  Object data.
		 * @param {Object} ctx  Map context.
		 * @param {Object} opts { flag: null|balloon|list|marker, tiles }.
		 * @return {HTMLElement|null}
		 */
		specs: function (obj, ctx, opts) {
			opts = opts || {};
			var list = flagged(obj, ctx, opts.flag || '');
			if (!list.length) {
				return null;
			}
			var dl = make('dl', 'mvweb-om-ui__specs' + (opts.tiles ? ' mvweb-om-ui__specs--tiles' : ''));
			list.forEach(function (s) {
				var item = document.createElement('div');
				item.appendChild(make('dt', '', s.label));
				var dd = make('dd');
				dd.appendChild(specValue(s, 'mvweb-om-ui__link'));
				item.appendChild(dd);
				dl.appendChild(item);
			});
			return dl;
		},

		/**
		 * Object links.
		 *
		 * @param {Object} obj Object data.
		 * @return {HTMLElement|null} Null when no link has a safe URL.
		 */
		links: function (obj) {
			var wrap = make('div', 'mvweb-om-ui__links');
			(obj.links || []).forEach(function (link) {
				if (!link || !isSafeUrl(link.url)) {
					return;
				}
				var a = make('a', 'mvweb-om-ui__link');
				a.setAttribute('href', link.url);
				a.setAttribute('target', '_blank');
				a.setAttribute('rel', 'noopener noreferrer');
				a.appendChild(make('span', '', link.label || link.url));
				var ext = icon('ext', 'sm');
				if (ext) {
					a.appendChild(ext);
				}
				wrap.appendChild(a);
			});
			return wrap.childNodes.length ? wrap : null;
		},

		/**
		 * Action buttons: details, call, directions.
		 *
		 * @param {Object} obj  Object data.
		 * @param {Object} ctx  Map context.
		 * @param {Object} opts { more, call, route, primary: more|call|route }; each is on unless false.
		 * @return {HTMLElement|null} Null when there is no action.
		 */
		actions: function (obj, ctx, opts) {
			opts = opts || {};
			var data = (ctx && ctx.data) || window.mvwebOmData || {};
			var primary = opts.primary || 'more';
			var wrap = make('div', 'mvweb-om-ui__actions');

			var add = function (key, label, href, ico, external) {
				var a = make('a', 'mvweb-om-ui__btn' + (key === primary ? '' : ' mvweb-om-ui__btn--outline'));
				a.setAttribute('href', href);
				if (external) {
					a.setAttribute('target', '_blank');
					a.setAttribute('rel', 'noopener noreferrer');
				}
				var svg = ico ? icon(ico, 'sm') : null;
				if (svg) {
					a.appendChild(svg);
				}
				a.appendChild(make('span', '', label));
				wrap.appendChild(a);
			};

			if (on(opts, 'more') && obj.moreUrl && isSafeUrl(obj.moreUrl)) {
				add('more', text(ctx, 'more', 'More details'), obj.moreUrl, '', true);
			}
			if (on(opts, 'call') && obj.phone) {
				add('call', text(ctx, 'call', 'Call'), telHref(obj.phone), 'phone', false);
			}
			if (on(opts, 'route') && data.showRoute) {
				var lat = ('number' === typeof obj.routeLat) ? obj.routeLat : obj.lat;
				var lng = ('number' === typeof obj.routeLng) ? obj.routeLng : obj.lng;
				add('route', text(ctx, 'route', 'Get directions'), 'https://yandex.ru/maps/?rtext=~' + encodeURIComponent(lat) + ',' + encodeURIComponent(lng), 'route', true);
			}
			return wrap.childNodes.length ? wrap : null;
		},

		/**
		 * Round close button.
		 *
		 * @param {string}   label     Accessible label.
		 * @param {Function} onClick   Click handler.
		 * @param {string}   className Extra class, for example mvweb-om-ui__icon-btn--glass.
		 * @return {HTMLButtonElement}
		 */
		close: function (label, onClick, className) {
			return parts.iconButton('close', label, onClick, 'mvweb-om-ui__icon-btn--compact' + (className ? ' ' + className : ''));
		},

		/**
		 * Round icon button with a hidden text label and a title.
		 *
		 * @param {string}   iconName  Icon name.
		 * @param {string}   label     Accessible label.
		 * @param {Function} onClick   Click handler.
		 * @param {string}   className Extra class.
		 * @return {HTMLButtonElement}
		 */
		iconButton: function (iconName, label, onClick, className) {
			var btn = make('button', 'mvweb-om-ui__icon-btn' + (className ? ' ' + className : ''));
			var svg = icon(iconName);
			btn.type = 'button';
			if (svg) {
				btn.appendChild(svg);
			}
			btn.appendChild(sr(label));
			btn.setAttribute('title', label);
			if (typeof onClick === 'function') {
				btn.addEventListener('click', onClick);
			}
			return btn;
		}
	};

	shared.parts = parts;
})();
