/**
 * Design block on the Appearance tab of MVweb Object Map.
 *
 * Ready-made sets fill the four design choices, any manual change switches the
 * set to "Custom". Shows the resulting phone layout and a shortcode to try the
 * combination on a hidden page.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var block = document.querySelector('.mvweb-om-design');
		if (!block) {
			return;
		}

		var cfg;
		try {
			cfg = JSON.parse(block.getAttribute('data-design') || '{}');
		} catch (err) {
			return;
		}

		var preset = block.querySelector('.mvweb-om-design__preset');
		var phone = block.querySelector('.mvweb-om-design__phone');
		var code = block.querySelector('.mvweb-om-design__code');
		var scheme = document.getElementById('mvweb_om_color_scheme');

		/**
		 * Current value of every design axis.
		 *
		 * @return {Object} Axis → slug.
		 */
		function chosen() {
			var out = {};
			block.querySelectorAll('input[type="radio"][data-axis]:checked').forEach(function (input) {
				out[input.getAttribute('data-axis')] = input.value;
			});
			return out;
		}

		/**
		 * Phone layout owner, mirrors MVweb_OM_Variants::resolve().
		 *
		 * @param {Object} values Axis → slug.
		 * @return {string}
		 */
		function phoneOwner(values) {
			if (values.mobile && 'classic' !== values.mobile) {
				return values.mobile;
			}
			return (cfg.listToPhone || {})[values.list] || 'classic';
		}

		/**
		 * Name of the set that matches the values, or "custom".
		 *
		 * @param {Object} values Axis → slug.
		 * @return {string}
		 */
		function matchPreset(values) {
			var presets = cfg.presets || {};
			var found = 'custom';
			Object.keys(presets).some(function (slug) {
				var set = presets[slug];
				var same = Object.keys(set).every(function (axis) {
					return set[axis] === values[axis];
				});
				if (same) {
					found = slug;
				}
				return same;
			});
			return found;
		}

		/**
		 * Refresh the phone line and the try-it shortcode.
		 */
		function refresh() {
			var values = chosen();
			if (phone) {
				phone.textContent = (cfg.phoneLabels || {})[phoneOwner(values)] || '';
			}
			if (code) {
				var parts = ['mvweb_map'];
				Object.keys(cfg.attrs || {}).forEach(function (axis) {
					if (values[axis]) {
						parts.push(cfg.attrs[axis] + '="' + values[axis] + '"');
					}
				});
				if (scheme) {
					parts.push('scheme="' + scheme.value + '"');
				}
				code.value = '[' + parts.join(' ') + ']';
			}
		}

		if (preset) {
			preset.addEventListener('change', function () {
				var set = (cfg.presets || {})[preset.value];
				if (!set) {
					return;
				}
				Object.keys(set).forEach(function (axis) {
					var input = block.querySelector('input[data-axis="' + axis + '"][value="' + set[axis] + '"]');
					if (input) {
						input.checked = true;
					}
				});
				refresh();
			});
		}

		block.addEventListener('change', function (e) {
			if (e.target.matches('input[type="radio"][data-axis]')) {
				if (preset) {
					preset.value = matchPreset(chosen());
				}
				refresh();
			}
		});

		if (scheme) {
			scheme.addEventListener('change', refresh);
		}

		if (code) {
			code.addEventListener('focus', function () {
				code.select();
			});
		}

		refresh();
	});
})();
