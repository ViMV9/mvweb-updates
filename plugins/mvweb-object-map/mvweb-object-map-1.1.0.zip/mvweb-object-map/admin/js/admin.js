/**
 * Admin JavaScript for MVweb Object Map.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
		initSpecsRepeater();
		initColorPickers();
		initOptionalColors();
	});

	/**
	 * Sync every color-picker's value label with its swatch input.
	 */
	function initColorPickers() {
		document.querySelectorAll('.mvweb-color-picker').forEach(function (picker) {
			var input = picker.querySelector('.mvweb-color-picker__swatch');
			var value = picker.querySelector('.mvweb-color-picker__value');
			if (!input || !value) {
				return;
			}
			input.addEventListener('input', function () {
				value.textContent = input.value;
			});
		});
	}

	/**
	 * Optional color fields: a "Custom color" checkbox enables the color input.
	 * When off, the input is disabled so the browser omits it from the submitted
	 * form and the setting is saved empty (native color inputs cannot express an
	 * unset state on their own).
	 *
	 * Uses a delegated listener on the document so it works regardless of when
	 * the fields are parsed relative to this script.
	 */
	function initOptionalColors() {
		document.addEventListener('change', function (event) {
			var checkbox = event.target;
			if (!checkbox.classList || !checkbox.classList.contains('mvweb-om-color-enable')) {
				return;
			}
			var input = document.getElementById(checkbox.getAttribute('data-target'));
			if (!input) {
				return;
			}
			input.disabled = !checkbox.checked;
			var picker = input.closest('.mvweb-color-picker');
			var value = picker ? picker.querySelector('.mvweb-color-picker__value') : null;
			if (value) {
				var defaultLabel = input.getAttribute('data-default-label') || 'Default';
				value.textContent = checkbox.checked ? input.value : defaultLabel;
			}
		});
	}

	/**
	 * Tab navigation for the UI Kit sidebar layout.
	 */
	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length || !panels.length) {
			return;
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();
				var target = link.getAttribute('data-tab');

				links.forEach(function (l) { l.classList.remove('mvweb-nav__link--active'); });
				panels.forEach(function (p) { p.classList.remove('active'); });

				link.classList.add('mvweb-nav__link--active');
				var panel = document.getElementById(target);
				if (panel) {
					panel.classList.add('active');
				}
				rememberTab(target);
			});
		});
	}

	/**
	 * Put the open tab into the address and into the form referer, so the
	 * page comes back to it after "Save".
	 *
	 * @param {string} tab Tab id.
	 */
	function rememberTab(tab) {
		var url = new URL(window.location.href);
		url.searchParams.set('tab', tab);
		url.searchParams.delete('settings-updated');
		window.history.replaceState(null, '', url.toString());

		var referer = document.querySelector('input[name="_wp_http_referer"]');
		if (referer) {
			referer.value = url.pathname + url.search;
		}
	}

	/**
	 * Characteristics schema repeater: add, remove, toggle type-specific rows.
	 */
	function initSpecsRepeater() {
		var repeater = document.getElementById('mvweb-om-specs');
		var addBtn = document.querySelector('.mvweb-om-spec-add');
		var template = document.getElementById('mvweb-om-spec-template');

		if (!repeater || !addBtn || !template) {
			return;
		}

		var i18n = (window.mvwebOmAdmin && window.mvwebOmAdmin.i18n) || {};
		var max = parseInt(repeater.getAttribute('data-max'), 10) || 0;

		/**
		 * Disable the add button when the field limit is reached.
		 */
		function syncAddButton() {
			if (max > 0) {
				addBtn.disabled = repeater.querySelectorAll('.mvweb-repeater__item').length >= max;
			}
		}

		addBtn.addEventListener('click', function () {
			if (max > 0 && repeater.querySelectorAll('.mvweb-repeater__item').length >= max) {
				return;
			}
			var index = parseInt(repeater.getAttribute('data-next-index'), 10) || 0;
			var fragment = template.content.cloneNode(true);
			replaceIndexTokens(fragment, index);
			var item = fragment.querySelector('.mvweb-repeater__item');
			repeater.appendChild(fragment);
			repeater.setAttribute('data-next-index', String(index + 1));
			if (item) {
				syncTypeRows(item);
			}
			syncAddButton();
		});

		repeater.addEventListener('click', function (event) {
			var removeBtn = event.target.closest('.mvweb-om-spec-remove');
			if (!removeBtn) {
				return;
			}
			var item = removeBtn.closest('.mvweb-repeater__item');
			if (!item) {
				return;
			}
			if (window.confirm(i18n.confirmRemove || 'Remove this field?')) {
				item.parentNode.removeChild(item);
				syncAddButton();
			}
		});

		repeater.addEventListener('change', function (event) {
			if (!event.target.classList.contains('mvweb-om-spec-type')) {
				return;
			}
			var item = event.target.closest('.mvweb-repeater__item');
			if (item) {
				syncTypeRows(item);
			}
		});

		repeater.querySelectorAll('.mvweb-repeater__item').forEach(syncTypeRows);
		syncAddButton();
	}

	/**
	 * Replace the __INDEX__ placeholder in name, id, aria-labelledby and data attributes of a fragment.
	 *
	 * @param {DocumentFragment} fragment Cloned template fragment.
	 * @param {number}           index    Row index to inject.
	 */
	function replaceIndexTokens(fragment, index) {
		var token = '__INDEX__';
		var idx = String(index);

		['name', 'id', 'aria-labelledby'].forEach(function (attr) {
			fragment.querySelectorAll('[' + attr + ']').forEach(function (el) {
				el.setAttribute(attr, el.getAttribute(attr).split(token).join(idx));
			});
		});

		var item = fragment.querySelector('[data-index]');
		if (item) {
			item.setAttribute('data-index', idx);
		}
	}

	/**
	 * Show or hide the unit/options rows based on the selected field type.
	 *
	 * @param {HTMLElement} item Repeater row element.
	 */
	function syncTypeRows(item) {
		var typeSelect = item.querySelector('.mvweb-om-spec-type');
		var unitRow = item.querySelector('.mvweb-om-spec-unit');
		var optionsRow = item.querySelector('.mvweb-om-spec-options');
		if (!typeSelect) {
			return;
		}
		var type = typeSelect.value;
		if (unitRow) {
			unitRow.style.display = ('number' === type) ? '' : 'none';
		}
		if (optionsRow) {
			optionsRow.style.display = ('select' === type) ? '' : 'none';
		}
	}
})();
