<?php
/**
 * List appearance settings tab.
 *
 * Global look of the catalog list cards, applied on the frontend via CSS
 * variables and modifier classes. Fields are namespaced under
 * `mvweb_om_settings[...]` and saved via the Settings API form.
 *
 * @package mvweb_om
 * @since   1.0.0
 *
 * @var array $settings Current settings (provided by settings-page.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$opt = 'mvweb_om_settings';

/**
 * Render a color-picker form row.
 *
 * @param string $opt      Option name.
 * @param string $key      Setting key.
 * @param string $label    Field label.
 * @param string $value    Current value.
 * @param string $desc     Optional description.
 * @param bool   $optional Whether the field supports an empty "default" state.
 *                         When true, a "Custom color" checkbox toggles the
 *                         color input; leaving it off disables the input so it
 *                         is not submitted and the value stays empty (native
 *                         color inputs cannot express "unset" on their own).
 * @return void
 */
$mvweb_om_color_row = function ( $opt, $key, $label, $value, $desc = '', $optional = false ) {
	$has_value = ( '' !== $value );
	?>
	<div class="mvweb-form-row">
		<label for="mvweb_om_<?php echo esc_attr( $key ); ?>" class="mvweb-form-row__label"><?php echo esc_html( $label ); ?></label>
		<div class="mvweb-form-row__field">
			<?php if ( $optional ) : ?>
			<div class="mvweb-om-color-optional">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							class="mvweb-om-color-enable"
							data-target="mvweb_om_<?php echo esc_attr( $key ); ?>"
							<?php checked( $has_value ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Custom color', 'mvweb-object-map' ); ?></span>
				</div>
			<?php endif; ?>
				<label class="mvweb-color-picker">
					<input type="color"
						id="mvweb_om_<?php echo esc_attr( $key ); ?>"
						name="<?php echo esc_attr( $opt ); ?>[<?php echo esc_attr( $key ); ?>]"
						class="mvweb-color-picker__swatch"
						data-default-label="<?php esc_attr_e( 'Default', 'mvweb-object-map' ); ?>"
						value="<?php echo esc_attr( $has_value ? $value : '#ffffff' ); ?>"
						<?php disabled( $optional && ! $has_value ); ?>>
					<span class="mvweb-color-picker__value"><?php echo esc_html( $has_value ? $value : __( 'Default', 'mvweb-object-map' ) ); ?></span>
				</label>
			<?php if ( $optional ) : ?>
			</div>
			<?php endif; ?>
			<?php if ( '' !== $desc ) : ?>
				<p class="mvweb-form-row__desc"><?php echo esc_html( $desc ); ?></p>
			<?php endif; ?>
		</div>
	</div>
	<?php
};

/**
 * Render a toggle form row.
 *
 * @param string $opt     Option name.
 * @param string $key     Setting key.
 * @param string $label   Field label.
 * @param bool   $checked Whether checked.
 * @param string $text    Toggle description text.
 * @return void
 */
$mvweb_om_toggle_row = function ( $opt, $key, $label, $checked, $text ) {
	?>
	<div class="mvweb-form-row">
		<label for="mvweb_om_<?php echo esc_attr( $key ); ?>" class="mvweb-form-row__label"><?php echo esc_html( $label ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox"
						id="mvweb_om_<?php echo esc_attr( $key ); ?>"
						name="<?php echo esc_attr( $opt ); ?>[<?php echo esc_attr( $key ); ?>]"
						value="1"
						<?php checked( $checked ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php echo esc_html( $text ); ?></span>
			</div>
		</div>
	</div>
	<?php
};

$mvweb_om_axes    = MVweb_OM_Variants::axes();
$mvweb_om_chosen  = array();
foreach ( $mvweb_om_axes as $mvweb_om_axis => $mvweb_om_axis_def ) {
	$mvweb_om_chosen[ $mvweb_om_axis ] = MVweb_OM_Variants::sanitize( $mvweb_om_axis, $settings[ $mvweb_om_axis_def['setting'] ] ?? 'classic' );
}
$mvweb_om_resolved  = MVweb_OM_Variants::resolve( $mvweb_om_chosen );
$mvweb_om_conflicts = MVweb_OM_Variants::conflicts( $mvweb_om_chosen );
$mvweb_om_presets   = MVweb_OM_Variants::presets();
$mvweb_om_preset    = 'custom';
foreach ( $mvweb_om_presets as $mvweb_om_preset_slug => $mvweb_om_preset_def ) {
	if ( ! array_diff_assoc( $mvweb_om_chosen, $mvweb_om_preset_def['values'] ) ) {
		$mvweb_om_preset = $mvweb_om_preset_slug;
		break;
	}
}
$mvweb_om_phone_labels = array(
	'classic'    => __( 'tabs "Map / List" and the balloon and list chosen above', 'mvweb-object-map' ),
	'list-grid'  => __( 'map on top and cards below (from "Map with a card grid")', 'mvweb-object-map' ),
	'list-table' => __( 'scrollable comparison table (from "Comparison table")', 'mvweb-object-map' ),
);
foreach ( $mvweb_om_axes['mobile']['values'] as $mvweb_om_slug => $mvweb_om_value ) {
	if ( 'classic' !== $mvweb_om_slug ) {
		$mvweb_om_phone_labels[ $mvweb_om_slug ] = $mvweb_om_value['label'];
	}
}
$mvweb_om_design_data = array(
	'presets'     => array_map(
		static function ( $preset ) {
			return $preset['values'];
		},
		$mvweb_om_presets
	),
	'attrs'       => array_map(
		static function ( $axis ) {
			return $axis['attr'];
		},
		$mvweb_om_axes
	),
	'listToPhone' => MVweb_OM_Variants::PHONE_BY_LIST,
	'phoneLabels' => $mvweb_om_phone_labels,
);
?>

<div class="mvweb-block mvweb-om-design" data-design="<?php echo esc_attr( (string) wp_json_encode( $mvweb_om_design_data ) ); ?>">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Design', 'mvweb-object-map' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'How the map, the object card, the list and the phone layout look. "Classic" keeps the look of earlier versions.', 'mvweb-object-map' ); ?>
	</p>

	<div class="mvweb-form-row">
		<label for="mvweb_om_design_preset" class="mvweb-form-row__label"><?php esc_html_e( 'Ready-made set', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_om_design_preset" class="mvweb-select mvweb-om-design__preset">
				<?php foreach ( $mvweb_om_presets as $mvweb_om_preset_slug => $mvweb_om_preset_def ) : ?>
					<option value="<?php echo esc_attr( $mvweb_om_preset_slug ); ?>" <?php selected( $mvweb_om_preset, $mvweb_om_preset_slug ); ?>><?php echo esc_html( $mvweb_om_preset_def['label'] ); ?></option>
				<?php endforeach; ?>
				<option value="custom" <?php selected( $mvweb_om_preset, 'custom' ); ?>><?php esc_html_e( 'Custom', 'mvweb-object-map' ); ?></option>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'A set fills in the four choices below. Change any of them to make your own combination.', 'mvweb-object-map' ); ?></p>
		</div>
	</div>

	<?php foreach ( $mvweb_om_axes as $mvweb_om_axis => $mvweb_om_axis_def ) : ?>
		<div class="mvweb-form-row mvweb-om-design__axis" role="radiogroup" aria-labelledby="mvweb_om_axis_<?php echo esc_attr( $mvweb_om_axis ); ?>">
			<span id="mvweb_om_axis_<?php echo esc_attr( $mvweb_om_axis ); ?>" class="mvweb-form-row__label"><?php echo esc_html( $mvweb_om_axis_def['label'] ); ?></span>
			<div class="mvweb-form-row__field">
				<div class="mvweb-radio-cards mvweb-om-design__cards">
					<?php foreach ( $mvweb_om_axis_def['values'] as $mvweb_om_slug => $mvweb_om_value ) : ?>
						<?php $mvweb_om_id = 'mvweb_om_' . $mvweb_om_axis . '_' . $mvweb_om_slug; ?>
						<div class="mvweb-radio-card mvweb-om-design__card">
							<input type="radio"
								id="<?php echo esc_attr( $mvweb_om_id ); ?>"
								name="<?php echo esc_attr( $opt ); ?>[<?php echo esc_attr( $mvweb_om_axis_def['setting'] ); ?>]"
								value="<?php echo esc_attr( $mvweb_om_slug ); ?>"
								data-axis="<?php echo esc_attr( $mvweb_om_axis ); ?>"
								<?php checked( $mvweb_om_chosen[ $mvweb_om_axis ], $mvweb_om_slug ); ?>>
							<label for="<?php echo esc_attr( $mvweb_om_id ); ?>">
								<?php $mvweb_om_preview = 'admin/images/variants/' . $mvweb_om_axis . '-' . $mvweb_om_slug . '.webp'; ?>
								<?php if ( file_exists( MVWEB_OM_PATH . $mvweb_om_preview ) ) : ?>
									<img class="mvweb-om-design__img" src="<?php echo esc_url( MVWEB_OM_URL . $mvweb_om_preview . '?ver=' . MVWEB_OM_VERSION ); ?>" alt="" width="320" height="200" loading="lazy" decoding="async">
								<?php endif; ?>
								<span class="mvweb-om-design__name"><?php echo esc_html( $mvweb_om_value['label'] ); ?></span>
								<?php if ( ! empty( $mvweb_om_value['desc'] ) ) : ?>
									<span class="mvweb-om-design__desc"><?php echo esc_html( $mvweb_om_value['desc'] ); ?></span>
								<?php endif; ?>
							</label>
							<svg class="mvweb-radio-card__check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	<?php endforeach; ?>

	<div class="mvweb-form-row">
		<label for="mvweb_om_color_scheme" class="mvweb-form-row__label"><?php esc_html_e( 'Color scheme', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_om_color_scheme" class="mvweb-select" name="<?php echo esc_attr( $opt ); ?>[color_scheme]">
				<?php foreach ( MVweb_OM_Variants::schemes() as $mvweb_om_scheme => $mvweb_om_scheme_label ) : ?>
					<option value="<?php echo esc_attr( $mvweb_om_scheme ); ?>" <?php selected( $settings['color_scheme'] ?? 'light', $mvweb_om_scheme ); ?>><?php echo esc_html( $mvweb_om_scheme_label ); ?></option>
				<?php endforeach; ?>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Applies to the map and to the new designs. The Classic cards stay light.', 'mvweb-object-map' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_phone_bottom_offset" class="mvweb-form-row__label"><?php esc_html_e( 'Bottom offset on phones (px)', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_om_phone_bottom_offset" class="mvweb-input" min="0" max="200" step="1"
				name="<?php echo esc_attr( $opt ); ?>[phone_bottom_offset]"
				value="<?php echo esc_attr( (string) ( $settings['phone_bottom_offset'] ?? 0 ) ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'If the theme pins a bar to the bottom of the phone screen (phone, messengers), enter its height. The floating map buttons will sit above it.', 'mvweb-object-map' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'On phones', 'mvweb-object-map' ); ?></span>
		<div class="mvweb-form-row__field">
			<p class="mvweb-om-design__phone" aria-live="polite"><?php echo esc_html( $mvweb_om_phone_labels[ $mvweb_om_resolved['phone'] ] ?? '' ); ?></p>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'On phones the "Phone and object window" choice decides the layout. When it is Classic, the list design brings its own phone layout.', 'mvweb-object-map' ); ?></p>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Notes about combinations that do not fit together are updated after saving.', 'mvweb-object-map' ); ?></p>
		</div>
	</div>

	<?php if ( $mvweb_om_conflicts ) : ?>
		<div class="mvweb-alert mvweb-alert--warning mvweb-om-design__conflicts">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/></svg>
			<ul>
				<?php foreach ( $mvweb_om_conflicts as $mvweb_om_conflict ) : ?>
					<li><?php echo esc_html( $mvweb_om_conflict ); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endif; ?>

	<div class="mvweb-form-row">
		<label for="mvweb_om_design_code" class="mvweb-form-row__label"><?php esc_html_e( 'Try it on a page', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_om_design_code" class="mvweb-input mvweb-om-design__code" readonly value="[mvweb_map]">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Paste this shortcode on a hidden page to see the chosen design before saving it for the whole site.', 'mvweb-object-map' ); ?></p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Accent color', 'mvweb-object-map' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_accent_color" class="mvweb-form-row__label"><?php esc_html_e( 'Accent color', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-color-picker">
				<input type="color"
					id="mvweb_om_accent_color"
					name="<?php echo esc_attr( $opt ); ?>[accent_color]"
					class="mvweb-color-picker__swatch"
					value="<?php echo esc_attr( $settings['accent_color'] ); ?>">
				<span class="mvweb-color-picker__value"><?php echo esc_html( $settings['accent_color'] ); ?></span>
			</label>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Used for map markers, balloon buttons and links across the map.', 'mvweb-object-map' ); ?>
			</p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Card colors', 'mvweb-object-map' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Colors of the catalog list cards shown next to the map.', 'mvweb-object-map' ); ?>
	</p>

	<?php
	$mvweb_om_color_row( $opt, 'card_bg', __( 'Card background', 'mvweb-object-map' ), $settings['card_bg'] );
	$mvweb_om_color_row( $opt, 'card_border', __( 'Card border', 'mvweb-object-map' ), $settings['card_border'] );
	$mvweb_om_color_row( $opt, 'card_title_color', __( 'Title color', 'mvweb-object-map' ), $settings['card_title_color'], __( 'Leave "Custom color" off to inherit the theme text color.', 'mvweb-object-map' ), true );
	$mvweb_om_color_row( $opt, 'card_text_color', __( 'Address / text color', 'mvweb-object-map' ), $settings['card_text_color'] );
	$mvweb_om_color_row( $opt, 'card_hover_border', __( 'Hover border', 'mvweb-object-map' ), $settings['card_hover_border'], __( 'Leave "Custom color" off to use the accent color.', 'mvweb-object-map' ), true );
	?>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Card content', 'mvweb-object-map' ); ?></div>
	</div>

	<?php
	$mvweb_om_toggle_row( $opt, 'card_show_photo', __( 'Photo', 'mvweb-object-map' ), $settings['card_show_photo'], __( 'Show the object thumbnail in the card', 'mvweb-object-map' ) );
	$mvweb_om_toggle_row( $opt, 'card_show_address', __( 'Address', 'mvweb-object-map' ), $settings['card_show_address'], __( 'Show the address under the title', 'mvweb-object-map' ) );
	$mvweb_om_toggle_row( $opt, 'card_show_excerpt', __( 'Description', 'mvweb-object-map' ), $settings['card_show_excerpt'], __( 'Show a short description (two lines) in the card', 'mvweb-object-map' ) );
	?>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Shape & density', 'mvweb-object-map' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_radius" class="mvweb-form-row__label"><?php esc_html_e( 'Corner radius (px)', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_om_card_radius" class="mvweb-input" min="0" max="40" step="1"
				name="<?php echo esc_attr( $opt ); ?>[card_radius]"
				value="<?php echo esc_attr( (string) $settings['card_radius'] ); ?>">
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_border_width" class="mvweb-form-row__label"><?php esc_html_e( 'Border width (px)', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_om_card_border_width" class="mvweb-input" min="0" max="8" step="1"
				name="<?php echo esc_attr( $opt ); ?>[card_border_width]"
				value="<?php echo esc_attr( (string) $settings['card_border_width'] ); ?>">
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_density" class="mvweb-form-row__label"><?php esc_html_e( 'Density', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_om_card_density" class="mvweb-select" name="<?php echo esc_attr( $opt ); ?>[card_density]">
				<option value="comfortable" <?php selected( $settings['card_density'], 'comfortable' ); ?>><?php esc_html_e( 'Comfortable', 'mvweb-object-map' ); ?></option>
				<option value="compact" <?php selected( $settings['card_density'], 'compact' ); ?>><?php esc_html_e( 'Compact', 'mvweb-object-map' ); ?></option>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_shadow" class="mvweb-form-row__label"><?php esc_html_e( 'Shadow', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" id="mvweb_om_card_shadow" value="1"
						name="<?php echo esc_attr( $opt ); ?>[card_shadow]"
						<?php checked( $settings['card_shadow'] ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Add a soft drop shadow to cards', 'mvweb-object-map' ); ?></span>
			</div>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Photo', 'mvweb-object-map' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_photo_size" class="mvweb-form-row__label"><?php esc_html_e( 'Photo size (px)', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_om_card_photo_size" class="mvweb-input" min="32" max="160" step="1"
				name="<?php echo esc_attr( $opt ); ?>[card_photo_size]"
				value="<?php echo esc_attr( (string) $settings['card_photo_size'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Applies when the photo is on the left. On top, the photo is full width.', 'mvweb-object-map' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_photo_pos" class="mvweb-form-row__label"><?php esc_html_e( 'Photo position', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_om_card_photo_pos" class="mvweb-select" name="<?php echo esc_attr( $opt ); ?>[card_photo_pos]">
				<option value="left" <?php selected( $settings['card_photo_pos'], 'left' ); ?>><?php esc_html_e( 'Left', 'mvweb-object-map' ); ?></option>
				<option value="top" <?php selected( $settings['card_photo_pos'], 'top' ); ?>><?php esc_html_e( 'Top', 'mvweb-object-map' ); ?></option>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_card_photo_ratio" class="mvweb-form-row__label"><?php esc_html_e( 'Photo aspect ratio', 'mvweb-object-map' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_om_card_photo_ratio" class="mvweb-select" name="<?php echo esc_attr( $opt ); ?>[card_photo_ratio]">
				<?php
				$mvweb_om_ratios = array(
					'1 / 1'  => __( 'Square (1:1)', 'mvweb-object-map' ),
					'4 / 3'  => __( 'Landscape (4:3)', 'mvweb-object-map' ),
					'3 / 2'  => __( 'Landscape (3:2)', 'mvweb-object-map' ),
					'16 / 9' => __( 'Widescreen (16:9)', 'mvweb-object-map' ),
					'3 / 4'  => __( 'Portrait (3:4)', 'mvweb-object-map' ),
					'2 / 3'  => __( 'Portrait (2:3)', 'mvweb-object-map' ),
					'9 / 16' => __( 'Vertical (9:16)', 'mvweb-object-map' ),
				);
				foreach ( $mvweb_om_ratios as $ratio_value => $ratio_label ) :
					?>
					<option value="<?php echo esc_attr( $ratio_value ); ?>" <?php selected( $settings['card_photo_ratio'], $ratio_value ); ?>><?php echo esc_html( $ratio_label ); ?></option>
				<?php endforeach; ?>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'All object photos are cropped to this ratio so cards stay the same height.', 'mvweb-object-map' ); ?></p>
		</div>
	</div>
</div>
