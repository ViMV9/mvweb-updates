<?php
/**
 * Uninstall MVweb Object Map.
 *
 * Object posts, taxonomy terms and plugin options are removed only when the
 * "Delete all data on uninstall" setting is enabled. Otherwise everything is
 * preserved so the data survives a reinstall.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Remove all plugin data for the current site.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_om_uninstall_site() {
	$settings = get_option( 'mvweb_om_settings', array() );
	$delete   = is_array( $settings ) && ! empty( $settings['delete_data_on_uninstall'] );

	wp_clear_scheduled_hook( 'mvweb_om_warm_cache' );

	if ( ! $delete ) {
		return;
	}

	$objects = get_posts(
		array(
			'post_type'        => 'mvweb_object',
			'post_status'      => array( 'publish', 'pending', 'draft', 'auto-draft', 'future', 'private', 'trash' ),
			'numberposts'      => -1,
			'fields'           => 'ids',
			'suppress_filters' => true,
		)
	);
	foreach ( $objects as $object_id ) {
		wp_delete_post( $object_id, true );
	}

	// The plugin is inactive during uninstall, so its init hook never ran and
	// the taxonomy is unregistered — get_terms() would return a WP_Error.
	// Register it minimally so the term cleanup below actually runs.
	if ( ! taxonomy_exists( 'mvweb_object_category' ) ) {
		register_taxonomy( 'mvweb_object_category', 'mvweb_object' );
	}

	$terms = get_terms(
		array(
			'taxonomy'   => 'mvweb_object_category',
			'hide_empty' => false,
			'fields'     => 'ids',
		)
	);
	if ( is_array( $terms ) ) {
		foreach ( $terms as $term_id ) {
			wp_delete_term( $term_id, 'mvweb_object_category' );
		}
	}

	global $wpdb;

	$ver = get_option( 'mvweb_om_cache_ver', '' );
	delete_transient( 'mvweb_om_objects_v2_' . ( is_string( $ver ) && '' !== $ver ? $ver : '0' ) );

	$like = $wpdb->esc_like( '_transient_mvweb_om_objects_' ) . '%';
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-off cleanup of this plugin's transients on uninstall.
	$like = $wpdb->esc_like( '_transient_timeout_mvweb_om_objects_' ) . '%';
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-off cleanup of this plugin's transients on uninstall.

	delete_option( 'mvweb_om_settings' );
	delete_option( 'mvweb_om_cache_ver' );
	delete_option( 'mvweb_om_cache_keys' );
}

if ( is_multisite() ) {
	$sites = get_sites( array( 'number' => 0 ) );
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );
		mvweb_om_uninstall_site();
		restore_current_blog();
	}
} else {
	mvweb_om_uninstall_site();
}

wp_cache_flush();
