<?php
/**
 * Helper functions for MVweb Object Map.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sanitize a coordinate value within a range, kept as a string.
 *
 * A string preserves the exact entered precision (a float cast can drift).
 * A decimal comma is read as a point.
 *
 * @since 1.0.0
 * @param mixed $value Raw coordinate.
 * @param float $min   Lower bound (inclusive).
 * @param float $max   Upper bound (inclusive).
 * @return string
 */
function mvweb_om_sanitize_coordinate( $value, $min, $max ) {
	$value = is_scalar( $value ) ? str_replace( ',', '.', trim( (string) $value ) ) : '';
	if ( '' === $value || ! preg_match( '/^-?\d{1,3}(\.\d+)?$/', $value ) ) {
		return '';
	}
	$float = (float) $value;
	return ( $float >= $min && $float <= $max ) ? $value : '';
}

/**
 * Sanitize a latitude (-90..90).
 *
 * @since 1.0.0
 * @param mixed $value Raw latitude.
 * @return string
 */
function mvweb_om_sanitize_lat( $value ) {
	return mvweb_om_sanitize_coordinate( $value, -90.0, 90.0 );
}

/**
 * Sanitize a longitude (-180..180).
 *
 * @since 1.0.0
 * @param mixed $value Raw longitude.
 * @return string
 */
function mvweb_om_sanitize_lng( $value ) {
	return mvweb_om_sanitize_coordinate( $value, -180.0, 180.0 );
}

/**
 * Sanitize a URL for HTML output, allowing only http/https schemes.
 *
 * Unlike esc_url_raw(), this rejects javascript: and data: URIs so stored
 * values are safe to place into href attributes (still escape on output).
 *
 * @since 1.0.0
 * @param mixed $value Raw URL.
 * @return string
 */
function mvweb_om_sanitize_url( $value ) {
	$url = esc_url_raw( is_scalar( $value ) ? (string) $value : '' );
	if ( '' === $url ) {
		return '';
	}
	$scheme = wp_parse_url( $url, PHP_URL_SCHEME );
	if ( null !== $scheme && ! in_array( $scheme, array( 'http', 'https' ), true ) ) {
		return '';
	}
	return $url;
}

/**
 * Sanitize the gallery meta — a JSON array of attachment IDs.
 *
 * Keeps at most 30 IDs and only image attachments.
 *
 * @since 1.0.0
 * @param mixed $value Raw JSON string or array.
 * @return string JSON-encoded array of positive integers.
 */
function mvweb_om_sanitize_gallery_json( $value ) {
	$items = mvweb_om_decode_array( $value );
	$ids   = array();
	foreach ( $items as $item ) {
		if ( count( $ids ) >= MVWEB_OM_MAX_GALLERY ) {
			break;
		}
		$item = is_array( $item ) && isset( $item['id'] ) ? $item['id'] : $item;
		$id   = is_scalar( $item ) ? absint( $item ) : 0;
		if ( $id > 0 && ! in_array( $id, $ids, true ) && wp_attachment_is_image( $id ) ) {
			$ids[] = $id;
		}
	}
	return wp_json_encode( $ids, JSON_UNESCAPED_UNICODE );
}

/**
 * Sanitize the links meta — a JSON array of { label, url } objects.
 *
 * Keeps at most 20 links; a label is cut to 200 characters.
 *
 * @since 1.0.0
 * @param mixed $value Raw JSON string or array.
 * @return string JSON-encoded array.
 */
function mvweb_om_sanitize_links_json( $value ) {
	$items = mvweb_om_decode_array( $value );
	$out   = array();
	foreach ( $items as $item ) {
		if ( count( $out ) >= MVWEB_OM_MAX_LINKS ) {
			break;
		}
		if ( ! is_array( $item ) ) {
			continue;
		}
		$label = isset( $item['label'] ) && is_scalar( $item['label'] ) ? mb_substr( sanitize_text_field( (string) $item['label'] ), 0, 200 ) : '';
		$url   = isset( $item['url'] ) ? mvweb_om_sanitize_url( (string) $item['url'] ) : '';
		if ( '' === $url ) {
			continue;
		}
		$out[] = array(
			'label' => $label,
			'url'   => $url,
		);
	}
	return wp_json_encode( $out, JSON_UNESCAPED_UNICODE );
}

/**
 * Sanitize the specs meta — a JSON object of { field_id: value }.
 *
 * Values are kept as plain text; the field schema (types/units) lives in the
 * plugin settings and is applied on output. Unknown field IDs are dropped when
 * a non-empty whitelist of allowed IDs is provided.
 *
 * @since 1.0.0
 * @param mixed $value   Raw JSON string or associative array.
 * @param array $allowed Optional whitelist of allowed field IDs.
 * @return string JSON-encoded object.
 */
function mvweb_om_sanitize_specs_json( $value, $allowed = array() ) {
	$items = mvweb_om_decode_array( $value );
	$out   = array();
	foreach ( $items as $field_id => $raw_value ) {
		$field_id = sanitize_key( (string) $field_id );
		if ( '' === $field_id ) {
			continue;
		}
		if ( ! empty( $allowed ) && ! in_array( $field_id, $allowed, true ) ) {
			continue;
		}
		$raw_value        = is_scalar( $raw_value ) ? (string) $raw_value : '';
		$out[ $field_id ] = sanitize_text_field( mb_substr( $raw_value, 0, 500 ) );
	}
	return wp_json_encode( $out, JSON_UNESCAPED_UNICODE );
}

/**
 * Decode a meta value into an array (accepts a JSON string or an array).
 *
 * @since 1.0.0
 * @param mixed $value Raw value.
 * @return array
 */
function mvweb_om_decode_array( $value ) {
	if ( is_array( $value ) ) {
		return $value;
	}
	if ( is_string( $value ) && '' !== $value ) {
		$decoded = json_decode( $value, true );
		if ( is_array( $decoded ) ) {
			return $decoded;
		}
	}
	return array();
}

/**
 * Marker icon presets.
 *
 * Every path is the `d` attribute of a 24 x 24 SVG drawn with
 * stroke="currentColor", fill="none" and stroke-width="2".
 *
 * @since 1.1.0
 * @return array Slug => { label, path }.
 */
function mvweb_om_icon_presets() {
	return array(
		'home'      => array(
			'label' => __( 'Home', 'mvweb-object-map' ),
			'path'  => 'M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
		),
		'shop'      => array(
			'label' => __( 'Shop', 'mvweb-object-map' ),
			'path'  => 'M3 9l1.5-5h15L21 9M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0M5 12v8h14v-8M10 20v-5h4v5',
		),
		'service'   => array(
			'label' => __( 'Service', 'mvweb-object-map' ),
			'path'  => 'M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z',
		),
		'flag'      => array(
			'label' => __( 'Flag', 'mvweb-object-map' ),
			'path'  => 'M5 21V4M5 4h11l-2 4 2 4H5',
		),
		'house-2'   => array(
			'label' => __( 'Two-storey house', 'mvweb-object-map' ),
			'path'  => 'M3 21h18M5 21V9l7-6 7 6v12M9 14h6M10 21v-4h4v4',
		),
		'cabin'     => array(
			'label' => __( 'Cabin', 'mvweb-object-map' ),
			'path'  => 'M2 21h20M5 21L12 5l7 16M9.5 21l2.5-5 2.5 5',
		),
		'sauna'     => array(
			'label' => __( 'Sauna', 'mvweb-object-map' ),
			'path'  => 'M4 21h16M6 21v-4h12v4M8 13c0-1.5 1.5-1.5 1.5-3S8 7.5 8 6M12 13c0-1.5 1.5-1.5 1.5-3S12 7.5 12 6M16 13c0-1.5 1.5-1.5 1.5-3S16 7.5 16 6',
		),
		'building'  => array(
			'label' => __( 'Building', 'mvweb-object-map' ),
			'path'  => 'M4 21V5a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v16M14 10h5a1 1 0 0 1 1 1v10M2 21h20M8 8h2M8 12h2M8 16h2',
		),
		'apartment' => array(
			'label' => __( 'Apartment block', 'mvweb-object-map' ),
			'path'  => 'M5 21V3h14v18M2 21h20M9 7h2M13 7h2M9 11h2M13 11h2M9 15h2M13 15h2M10 21v-3h4v3',
		),
		'warehouse' => array(
			'label' => __( 'Warehouse', 'mvweb-object-map' ),
			'path'  => 'M3 21V9l9-5 9 5v12M3 21h18M7 21v-8h10v8M7 15h10M7 18h10',
		),
		'tools'     => array(
			'label' => __( 'Tools', 'mvweb-object-map' ),
			'path'  => 'M3 8h18v12H3zM9 8V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v3M3 13h18M11 13v2h2v-2',
		),
		'crane'     => array(
			'label' => __( 'Crane', 'mvweb-object-map' ),
			'path'  => 'M6 21h6M9 21V3M3 6h16M9 3l8 3M17 6v5M15 11h4v3h-4z',
		),
		'tree'      => array(
			'label' => __( 'Tree', 'mvweb-object-map' ),
			'path'  => 'M12 22v-5M12 17c-4 0-7-3-7-6.5C5 7 8 5 10 4.5 10.5 3 11.2 2 12 2s1.5 1 2 2.5c2 .5 5 2.5 5 6C19 14 16 17 12 17z',
		),
		'star'      => array(
			'label' => __( 'Star', 'mvweb-object-map' ),
			'path'  => 'M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21 7 14.2l-5-4.9 6.9-1z',
		),
		'pin'       => array(
			'label' => __( 'Pin', 'mvweb-object-map' ),
			'path'  => 'M12 22s7-6.2 7-12a7 7 0 0 0-14 0c0 5.8 7 12 7 12zM12 12.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z',
		),
		'office'    => array(
			'label' => __( 'Office', 'mvweb-object-map' ),
			'path'  => 'M3 5h18v11H3zM8 21h8M12 16v5',
		),
	);
}

/**
 * Sanitize a marker icon preset slug.
 *
 * @since 1.1.0
 * @param mixed $value Raw slug.
 * @return string A known preset slug, or an empty string.
 */
function mvweb_om_sanitize_icon_preset( $value ) {
	$slug = is_string( $value ) ? sanitize_key( $value ) : '';
	return ( '' !== $slug && array_key_exists( $slug, mvweb_om_icon_presets() ) ) ? $slug : '';
}
