<?php
/**
 * Design variants manifest for MVweb Object Map.
 *
 * The single source of truth for the four design axes (marker, balloon, list,
 * mobile), the colour scheme, ready-made presets, phone resolution, conflict
 * warnings and the asset files each chosen combination needs.
 *
 * @package mvweb_om
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Variants manifest.
 *
 * @since 1.1.0
 */
final class MVweb_OM_Variants {

	/**
	 * Axis keys in display order.
	 *
	 * @var array
	 */
	const AXES = array( 'marker', 'balloon', 'list', 'mobile' );

	/**
	 * Allowed slugs per axis. The first slug is always the default.
	 *
	 * @var array
	 */
	const SLUGS = array(
		'marker'  => array( 'classic', 'drop', 'price', 'photo', 'label', 'tile' ),
		'balloon' => array( 'classic', 'popup', 'panel', 'strip', 'hint', 'showcase' ),
		'list'    => array( 'classic', 'ribbon', 'sidebar', 'glass', 'grid', 'table' ),
		'mobile'  => array( 'classic', 'sheet', 'rail', 'fab', 'preview', 'dock' ),
	);

	/**
	 * Allowed colour schemes.
	 *
	 * @var array
	 */
	const SCHEMES = array( 'light', 'dark', 'auto' );

	/**
	 * Settings key and shortcode attribute per axis.
	 *
	 * @var array
	 */
	const KEYS = array(
		'marker'  => array(
			'setting' => 'variant_marker',
			'attr'    => 'marker',
		),
		'balloon' => array(
			'setting' => 'variant_balloon',
			'attr'    => 'balloon',
		),
		'list'    => array(
			'setting' => 'variant_list',
			'attr'    => 'list_view',
		),
		'mobile'  => array(
			'setting' => 'variant_mobile',
			'attr'    => 'mobile',
		),
	);

	/**
	 * Phone view that replaces the classic mobile view, by list variant.
	 *
	 * @var array
	 */
	const PHONE_BY_LIST = array(
		'ribbon'  => 'fab',
		'sidebar' => 'sheet',
		'glass'   => 'rail',
		'grid'    => 'list-grid',
		'table'   => 'list-table',
	);

	/**
	 * Shared JS modules and the "axis-slug" modules that use them.
	 *
	 * @var array
	 */
	const SHARED = array(
		'sheet'   => array( 'balloon-panel', 'balloon-hint', 'balloon-showcase', 'mobile-sheet', 'mobile-dock' ),
		'rail'    => array( 'balloon-strip', 'mobile-rail' ),
		'gallery' => array(
			'balloon-panel',
			'balloon-showcase',
			'mobile-sheet',
			'mobile-rail',
			'mobile-fab',
			'mobile-preview',
			'mobile-dock',
		),
		'parts'   => array(
			'balloon-popup',
			'balloon-panel',
			'balloon-strip',
			'balloon-hint',
			'balloon-showcase',
			'mobile-sheet',
			'mobile-rail',
			'mobile-fab',
			'mobile-preview',
			'mobile-dock',
			'list-ribbon',
			'list-glass',
			'list-sidebar',
			'list-grid',
			'list-table',
		),
	);

	/**
	 * Shared JS modules that need other shared modules.
	 *
	 * @var array
	 */
	const SHARED_DEPS = array(
		'sheet'   => array( 'parts' ),
		'rail'    => array( 'parts' ),
		'gallery' => array( 'parts' ),
	);

	/**
	 * Axes with labels, setting keys, shortcode attributes and values.
	 *
	 * @since 1.1.0
	 * @return array
	 */
	public static function axes(): array {
		$labels = array(
			'marker'  => __( 'Marker and cluster', 'mvweb-object-map' ),
			'balloon' => __( 'Card on the map', 'mvweb-object-map' ),
			'list'    => __( 'Filter and list', 'mvweb-object-map' ),
			'mobile'  => __( 'Phone and object window', 'mvweb-object-map' ),
		);

		$values = array(
			'marker'  => array(
				'classic' => array(
					'label' => __( 'Classic', 'mvweb-object-map' ),
					'desc'  => __( 'The round marker used so far.', 'mvweb-object-map' ),
				),
				'drop'    => array(
					'label' => __( 'Drop with category icon', 'mvweb-object-map' ),
					'desc'  => __( 'A pin drop with the category icon inside.', 'mvweb-object-map' ),
				),
				'price'   => array(
					'label' => __( 'Price tag label', 'mvweb-object-map' ),
					'desc'  => __( 'A label with the key characteristic, for example the price.', 'mvweb-object-map' ),
				),
				'photo'   => array(
					'label' => __( 'Photo marker', 'mvweb-object-map' ),
					'desc'  => __( 'A round marker with the object photo.', 'mvweb-object-map' ),
				),
				'label'   => array(
					'label' => __( 'Dot with label', 'mvweb-object-map' ),
					'desc'  => __( 'A small dot with the object name next to it.', 'mvweb-object-map' ),
				),
				'tile'    => array(
					'label' => __( 'Icon tile', 'mvweb-object-map' ),
					'desc'  => __( 'A rounded tile with the category icon.', 'mvweb-object-map' ),
				),
			),
			'balloon' => array(
				'classic'  => array(
					'label' => __( 'Classic', 'mvweb-object-map' ),
					'desc'  => __( 'The balloon used so far.', 'mvweb-object-map' ),
				),
				'popup'    => array(
					'label' => __( 'Popup at the marker', 'mvweb-object-map' ),
					'desc'  => __( 'A small card right next to the marker.', 'mvweb-object-map' ),
				),
				'panel'    => array(
					'label' => __( 'Side panel', 'mvweb-object-map' ),
					'desc'  => __( 'A card in a panel at the side of the map.', 'mvweb-object-map' ),
				),
				'strip'    => array(
					'label' => __( 'Card at the bottom', 'mvweb-object-map' ),
					'desc'  => __( 'A card at the bottom edge of the map with arrows to the neighbouring objects.', 'mvweb-object-map' ),
				),
				'hint'     => array(
					'label' => __( 'Tooltip that expands', 'mvweb-object-map' ),
					'desc'  => __( 'A short tooltip that expands into a full card.', 'mvweb-object-map' ),
				),
				'showcase' => array(
					'label' => __( 'Showcase', 'mvweb-object-map' ),
					'desc'  => __( 'A large card with a photo slider over the map.', 'mvweb-object-map' ),
				),
			),
			'list'    => array(
				'classic' => array(
					'label' => __( 'Classic', 'mvweb-object-map' ),
					'desc'  => __( 'The tabs and the card list used so far.', 'mvweb-object-map' ),
				),
				'ribbon'  => array(
					'label' => __( 'Category ribbon above the map', 'mvweb-object-map' ),
					'desc'  => __( 'A row of categories above the map.', 'mvweb-object-map' ),
				),
				'sidebar' => array(
					'label' => __( 'Side panel like a maps app', 'mvweb-object-map' ),
					'desc'  => __( 'Search and the list in a panel beside the map.', 'mvweb-object-map' ),
				),
				'glass'   => array(
					'label' => __( 'Glass panel over the map', 'mvweb-object-map' ),
					'desc'  => __( 'A translucent list panel over the map.', 'mvweb-object-map' ),
				),
				'grid'    => array(
					'label' => __( 'Map with a card grid', 'mvweb-object-map' ),
					'desc'  => __( 'The map on top and a grid of cards below.', 'mvweb-object-map' ),
				),
				'table'   => array(
					'label' => __( 'Comparison table', 'mvweb-object-map' ),
					'desc'  => __( 'A table to compare objects and sort them by columns.', 'mvweb-object-map' ),
				),
			),
			'mobile'  => array(
				'classic' => array(
					'label' => __( 'Classic (tabs and a dialog)', 'mvweb-object-map' ),
					'desc'  => __( 'Map and list tabs; the object opens in a dialog.', 'mvweb-object-map' ),
				),
				'sheet'   => array(
					'label' => __( 'Three-position sheet', 'mvweb-object-map' ),
					'desc'  => __( 'A bottom sheet that can be dragged to three heights.', 'mvweb-object-map' ),
				),
				'rail'    => array(
					'label' => __( 'Card carousel', 'mvweb-object-map' ),
					'desc'  => __( 'A carousel of cards over the map.', 'mvweb-object-map' ),
				),
				'fab'     => array(
					'label' => __( 'List/map button', 'mvweb-object-map' ),
					'desc'  => __( 'A floating button that switches between the map and the list.', 'mvweb-object-map' ),
				),
				'preview' => array(
					'label' => __( 'Full-screen photo and map preview', 'mvweb-object-map' ),
					'desc'  => __( 'A full-screen object page with a small map preview.', 'mvweb-object-map' ),
				),
				'dock'    => array(
					'label' => __( 'Bottom sheet and side panel', 'mvweb-object-map' ),
					'desc'  => __( 'A bottom sheet on a phone and a side panel on a computer.', 'mvweb-object-map' ),
				),
			),
		);

		$out = array();
		foreach ( self::AXES as $axis ) {
			$out[ $axis ] = array(
				'label'   => $labels[ $axis ],
				'setting' => self::KEYS[ $axis ]['setting'],
				'attr'    => self::KEYS[ $axis ]['attr'],
				'values'  => $values[ $axis ],
			);
		}
		return $out;
	}

	/**
	 * Colour schemes.
	 *
	 * @since 1.1.0
	 * @return array
	 */
	public static function schemes(): array {
		return array(
			'light' => __( 'Light', 'mvweb-object-map' ),
			'dark'  => __( 'Dark', 'mvweb-object-map' ),
			'auto'  => __( 'As the visitor\'s system', 'mvweb-object-map' ),
		);
	}

	/**
	 * Whether a slug is allowed on an axis.
	 *
	 * @since 1.1.0
	 * @param string $axis Axis key.
	 * @param string $slug Variant slug.
	 * @return bool
	 */
	public static function is_valid( string $axis, string $slug ): bool {
		return isset( self::SLUGS[ $axis ] ) && in_array( $slug, self::SLUGS[ $axis ], true );
	}

	/**
	 * Sanitize a variant slug.
	 *
	 * @since 1.1.0
	 * @param string $axis  Axis key.
	 * @param mixed  $value Raw value.
	 * @return string A valid slug, or `classic`.
	 */
	public static function sanitize( string $axis, $value ): string {
		$slug = is_string( $value ) ? sanitize_key( $value ) : '';
		return self::is_valid( $axis, $slug ) ? $slug : 'classic';
	}

	/**
	 * Sanitize a colour scheme.
	 *
	 * @since 1.1.0
	 * @param mixed $value Raw value.
	 * @return string A valid scheme, or `light`.
	 */
	public static function sanitize_scheme( $value ): string {
		$scheme = is_string( $value ) ? sanitize_key( $value ) : '';
		return in_array( $scheme, self::SCHEMES, true ) ? $scheme : 'light';
	}

	/**
	 * Resolve which view owns the phone for the chosen variants.
	 *
	 * @since 1.1.0
	 * @param array $chosen Valid slugs keyed by axis.
	 * @return array The same array plus `phone`.
	 */
	public static function resolve( array $chosen ): array {
		$mobile = isset( $chosen['mobile'] ) ? (string) $chosen['mobile'] : 'classic';
		$list   = isset( $chosen['list'] ) ? (string) $chosen['list'] : 'classic';

		if ( 'classic' !== $mobile ) {
			$phone = $mobile;
		} elseif ( isset( self::PHONE_BY_LIST[ $list ] ) ) {
			$phone = self::PHONE_BY_LIST[ $list ];
		} else {
			$phone = 'classic';
		}

		if ( isset( $chosen['balloon'], $chosen['list'] ) && 'panel' === $chosen['balloon'] && 'glass' === $chosen['list'] ) {
			$chosen['balloon'] = 'classic';
		}

		$chosen['phone'] = $phone;
		return $chosen;
	}

	/**
	 * Warnings for combinations that do not fit together on a computer.
	 *
	 * @since 1.1.0
	 * @param array $chosen Valid slugs keyed by axis.
	 * @return string[] Translated messages; empty when there is no conflict.
	 */
	public static function conflicts( array $chosen ): array {
		$marker  = isset( $chosen['marker'] ) ? (string) $chosen['marker'] : 'classic';
		$balloon = isset( $chosen['balloon'] ) ? (string) $chosen['balloon'] : 'classic';
		$list    = isset( $chosen['list'] ) ? (string) $chosen['list'] : 'classic';
		$mobile  = isset( $chosen['mobile'] ) ? (string) $chosen['mobile'] : 'classic';

		$out = array();

		if ( 'panel' === $balloon && 'glass' === $list ) {
			$out[] = __( 'The side panel covers the search of the glass list panel. The classic balloon is shown instead.', 'mvweb-object-map' );
		}
		if ( in_array( $balloon, array( 'panel', 'strip' ), true ) && 'grid' === $list ) {
			$out[] = __( 'The map with a card grid is too low for this card. The classic balloon is shown instead.', 'mvweb-object-map' );
		}
		if ( ( 'showcase' === $balloon || 'dock' === $mobile ) && 'glass' === $list ) {
			$out[] = __( 'While a card is open, the glass list panel collapses into a "List" button.', 'mvweb-object-map' );
		}
		if ( 'panel' === $balloon && 'sidebar' === $list ) {
			$out[] = __( 'The card panel opens on the right. On a map narrower than 640 px the classic balloon is shown instead.', 'mvweb-object-map' );
		}
		if ( 'hint' === $balloon && in_array( $marker, array( 'price', 'label', 'tile' ), true ) ) {
			$out[] = __( 'The marker already shows a name, so the tooltip repeats it.', 'mvweb-object-map' );
		}

		return $out;
	}

	/**
	 * Ready-made combinations of the four axes.
	 *
	 * @since 1.1.0
	 * @return array Preset slug => label and values keyed by axis.
	 */
	public static function presets(): array {
		return array(
			'classic' => array(
				'label'  => __( 'Classic', 'mvweb-object-map' ),
				'values' => array(
					'marker'  => 'classic',
					'balloon' => 'classic',
					'list'    => 'classic',
					'mobile'  => 'classic',
				),
			),
			'maps'    => array(
				'label'  => __( 'Like a maps app', 'mvweb-object-map' ),
				'values' => array(
					'marker'  => 'drop',
					'balloon' => 'panel',
					'list'    => 'sidebar',
					'mobile'  => 'sheet',
				),
			),
			'catalog' => array(
				'label'  => __( 'Catalog', 'mvweb-object-map' ),
				'values' => array(
					'marker'  => 'price',
					'balloon' => 'showcase',
					'list'    => 'grid',
					'mobile'  => 'fab',
				),
			),
			'compact' => array(
				'label'  => __( 'Compact', 'mvweb-object-map' ),
				'values' => array(
					'marker'  => 'label',
					'balloon' => 'popup',
					'list'    => 'ribbon',
					'mobile'  => 'preview',
				),
			),
		);
	}

	/**
	 * Style and script files needed for the resolved variants.
	 *
	 * Only files that exist are returned; a `.min` file wins over the source.
	 *
	 * @since 1.1.0
	 * @param array $resolved Result of resolve().
	 * @return array {
	 *     @type array $styles  Handle => { src, deps }.
	 *     @type array $scripts Handle => { src, deps }.
	 * }
	 */
	public static function assets( array $resolved ): array {
		$styles  = array();
		$scripts = array();
		$used    = array();

		foreach ( self::AXES as $axis ) {
			$slug = isset( $resolved[ $axis ] ) ? (string) $resolved[ $axis ] : 'classic';
			if ( 'classic' !== $slug && self::is_valid( $axis, $slug ) ) {
				$used[] = array( $axis, $slug );
			}
		}

		$phone = isset( $resolved['phone'] ) ? (string) $resolved['phone'] : 'classic';
		if ( 'classic' !== $phone && ! in_array( array( 'mobile', $phone ), $used, true ) && self::is_valid( 'mobile', $phone ) ) {
			$used[] = array( 'mobile', $phone );
		}

		if ( empty( $used ) ) {
			return array(
				'styles'  => $styles,
				'scripts' => $scripts,
			);
		}

		$base = self::locate( 'css', 'om-base', 'css' );
		if ( null !== $base ) {
			$styles['mvweb-om-base'] = array(
				'src'  => $base,
				'deps' => array( 'mvweb-om-public' ),
			);
		}

		$parent  = isset( $styles['mvweb-om-base'] ) ? 'mvweb-om-base' : 'mvweb-om-public';
		$modules = array();
		foreach ( $used as $pair ) {
			$name      = $pair[0] . '-' . $pair[1];
			$modules[] = $name;

			$css = self::locate( 'css', 'variants/' . $name, 'css' );
			if ( null !== $css ) {
				$styles[ 'mvweb-om-' . $name ] = array(
					'src'  => $css,
					'deps' => array( $parent ),
				);
			}
		}

		$needed = array();
		foreach ( self::SHARED as $shared => $users ) {
			if ( array_intersect( $users, $modules ) ) {
				$needed[ $shared ] = true;
			}
		}
		foreach ( array_keys( $needed ) as $shared ) {
			if ( isset( self::SHARED_DEPS[ $shared ] ) ) {
				foreach ( self::SHARED_DEPS[ $shared ] as $dependency ) {
					$needed[ $dependency ] = true;
				}
			}
		}

		$shared_handles = array();
		foreach ( array_keys( self::SHARED ) as $shared ) {
			if ( empty( $needed[ $shared ] ) ) {
				continue;
			}
			$src = self::locate( 'js', 'shared/' . $shared, 'js' );
			if ( null === $src ) {
				continue;
			}
			$deps = array( 'mvweb-om-public' );
			foreach ( self::SHARED_DEPS[ $shared ] ?? array() as $dependency ) {
				if ( null !== self::locate( 'js', 'shared/' . $dependency, 'js' ) ) {
					$deps[] = 'mvweb-om-shared-' . $dependency;
				}
			}
			$handle             = 'mvweb-om-shared-' . $shared;
			$scripts[ $handle ] = array(
				'src'  => $src,
				'deps' => $deps,
			);
			$shared_handles[]   = $handle;
		}

		foreach ( $modules as $name ) {
			$src = self::locate( 'js', 'variants/' . $name, 'js' );
			if ( null === $src ) {
				continue;
			}
			$deps = array( 'mvweb-om-public' );
			foreach ( $shared_handles as $handle ) {
				$shared_name = substr( $handle, strlen( 'mvweb-om-shared-' ) );
				if ( in_array( $name, self::SHARED[ $shared_name ], true ) ) {
					$deps[] = $handle;
				}
			}
			$scripts[ 'mvweb-om-' . $name ] = array(
				'src'  => $src,
				'deps' => $deps,
			);
		}

		return array(
			'styles'  => $styles,
			'scripts' => $scripts,
		);
	}

	/**
	 * Find a public asset file and return its URL.
	 *
	 * @since 1.1.0
	 * @param string $type Folder under public/: `css` or `js`.
	 * @param string $name File name without extension, may include a sub folder.
	 * @param string $ext  File extension: `css` or `js`.
	 * @return string|null URL of the `.min` file if present, else the source, else null.
	 */
	private static function locate( string $type, string $name, string $ext ): ?string {
		$rel = 'public/' . $type . '/' . $name;

		if ( file_exists( MVWEB_OM_PATH . $rel . '.min.' . $ext ) ) {
			return MVWEB_OM_URL . $rel . '.min.' . $ext;
		}
		if ( file_exists( MVWEB_OM_PATH . $rel . '.' . $ext ) ) {
			return MVWEB_OM_URL . $rel . '.' . $ext;
		}
		return null;
	}
}
