<?php
/**
 * Frontend shortcode for MVweb Object Map.
 *
 * Registers the [mvweb_map] shortcode that renders a Yandex map with the
 * published objects. Assets are registered up front and enqueued lazily only
 * when the shortcode is actually rendered on a page. Each shortcode instance
 * gets its own container so several maps can coexist on one page.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shortcode controller.
 *
 * @since 1.0.0
 */
final class MVweb_OM_Shortcode {

	/**
	 * Whether the core assets and frontend data have been enqueued.
	 *
	 * @var bool
	 */
	private static $enqueued = false;

	/**
	 * Incrementing instance counter for unique container IDs.
	 *
	 * @var int
	 */
	private static $instance = 0;

	/**
	 * Wire WordPress hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		add_filter( 'wp_resource_hints', array( __CLASS__, 'resource_hints' ), 10, 2 );
	}

	/**
	 * Register the shortcode.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_shortcode() {
		add_shortcode( 'mvweb_map', array( __CLASS__, 'render' ) );
	}

	/**
	 * Register (not enqueue) the frontend assets.
	 *
	 * On a singular page whose content holds the shortcode the stylesheets of
	 * the site-wide design are enqueued right away, so they print in the head
	 * and the block does not jump when it renders.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_assets() {
		wp_register_style(
			'mvweb-om-public',
			MVWEB_OM_URL . 'public/css/object-map.min.css',
			array(),
			MVWEB_OM_VERSION
		);

		$api_key = (string) MVweb_OM_Settings::get( 'api_key' );
		if ( '' !== $api_key ) {
			wp_register_script(
				'mvweb-om-ymaps',
				'https://api-maps.yandex.ru/v3/?apikey=' . rawurlencode( $api_key ) . '&lang=' . rawurlencode( self::map_lang() ),
				array(),
				null,
				true
			);
		}

		wp_register_script(
			'mvweb-om-public',
			MVWEB_OM_URL . 'public/js/object-map.min.js',
			'' !== $api_key ? array( 'mvweb-om-ymaps' ) : array(),
			MVWEB_OM_VERSION,
			true
		);

		if ( self::page_has_shortcode() ) {
			$settings = MVweb_OM_Settings::get();
			self::enqueue_assets( $settings );
			self::enqueue_variant_assets( MVweb_OM_Variants::resolve( self::chosen_variants( $settings, array() ) ), true );
		}
	}

	/**
	 * Whether the current singular post content holds the shortcode.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	private static function page_has_shortcode() {
		$post = is_singular() ? get_post() : null;
		return $post instanceof WP_Post && has_shortcode( (string) $post->post_content, 'mvweb_map' );
	}

	/**
	 * Preconnect to the Yandex Maps API host on pages with the map.
	 *
	 * @since 1.1.0
	 * @param array  $urls          URLs to print for resource hints.
	 * @param string $relation_type Relation type.
	 * @return array
	 */
	public static function resource_hints( $urls, $relation_type ) {
		if ( 'preconnect' === $relation_type && '' !== (string) MVweb_OM_Settings::get( 'api_key' ) && self::page_has_shortcode() ) {
			$urls[] = 'https://api-maps.yandex.ru';
		}
		return $urls;
	}

	/**
	 * Render the shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function render( $atts ): string {
		$atts = is_array( $atts ) ? $atts : array();
		$atts = shortcode_atts(
			array(
				'category'  => '',
				'ids'       => '',
				'list'      => 'no',
				'filter'    => 'yes',
				'height'    => '500px',
				'zoom'      => '',
				'center'    => '',
				'cluster'   => '',
				'marker'    => '',
				'balloon'   => '',
				'list_view' => '',
				'mobile'    => '',
				'scheme'    => '',
			),
			$atts,
			'mvweb_map'
		);

		$settings = MVweb_OM_Settings::get();
		$resolved = MVweb_OM_Variants::resolve( self::chosen_variants( $settings, $atts ) );
		$scheme   = MVweb_OM_Variants::sanitize_scheme( $settings['color_scheme'] ?? 'light' );
		$scheme   = in_array( sanitize_key( (string) $atts['scheme'] ), MVweb_OM_Variants::SCHEMES, true ) ? sanitize_key( (string) $atts['scheme'] ) : $scheme;

		self::enqueue_assets( $settings );
		self::enqueue_variant_assets( $resolved, false );
		++self::$instance;

		$config = array(
			'category' => sanitize_text_field( $atts['category'] ),
			'ids'      => sanitize_text_field( $atts['ids'] ),
			'list'     => 'yes' === strtolower( (string) $atts['list'] ),
			'filter'   => 'no' !== strtolower( (string) $atts['filter'] ),
			'zoom'     => '' !== $atts['zoom'] ? absint( $atts['zoom'] ) : null,
			'center'   => self::parse_center( (string) $atts['center'] ),
			'cluster'  => self::parse_tristate( (string) $atts['cluster'] ),
			'variants' => array(
				'marker'  => $resolved['marker'],
				'balloon' => $resolved['balloon'],
				'list'    => $resolved['list'],
				'mobile'  => $resolved['mobile'],
				'phone'   => $resolved['phone'],
			),
			'scheme'   => $scheme,
		);

		$root_classes = array( 'mvweb-om' );
		if ( $config['list'] ) {
			$root_classes[] = 'mvweb-om--with-list';
			$root_classes[] = 'mvweb-om--view-map';
		}
		foreach ( $config['variants'] as $axis => $slug ) {
			$root_classes[] = 'mvweb-om--' . $axis . '-' . $slug;
		}

		$dom_id = 'mvweb-om-map-' . self::$instance;
		$height = preg_replace( '/[^0-9a-z%.]/i', '', (string) $atts['height'] );
		if ( '' === $height ) {
			$height = '500px';
		}

		ob_start();
		require MVWEB_OM_PATH . 'public/templates/map.php';
		return ob_get_clean();
	}

	/**
	 * Design choices from the settings, overridden by valid shortcode attributes.
	 *
	 * @since 1.1.0
	 * @param array $settings Plugin settings.
	 * @param array $atts     Shortcode attributes.
	 * @return array Axis → slug.
	 */
	private static function chosen_variants( array $settings, array $atts ) {
		$chosen = array();
		foreach ( MVweb_OM_Variants::KEYS as $axis => $def ) {
			$value = MVweb_OM_Variants::sanitize( $axis, $settings[ $def['setting'] ] ?? 'classic' );
			$attr  = isset( $atts[ $def['attr'] ] ) ? sanitize_key( (string) $atts[ $def['attr'] ] ) : '';
			if ( '' !== $attr && MVweb_OM_Variants::is_valid( $axis, $attr ) ) {
				$value = $attr;
			}
			$chosen[ $axis ] = $value;
		}
		return $chosen;
	}

	/**
	 * Enqueue the core assets, the frontend data and the design tokens once.
	 *
	 * @since 1.0.0
	 * @param array $settings Plugin settings.
	 * @return void
	 */
	private static function enqueue_assets( array $settings ) {
		if ( self::$enqueued ) {
			return;
		}
		wp_enqueue_style( 'mvweb-om-public' );
		wp_add_inline_style( 'mvweb-om-public', self::tokens_css( $settings ) );
		wp_enqueue_script( 'mvweb-om-public' );
		wp_add_inline_script(
			'mvweb-om-public',
			'window.mvwebOmData = ' . wp_json_encode( self::frontend_data( $settings ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . ';',
			'before'
		);
		self::$enqueued = true;
	}

	/**
	 * Enqueue the stylesheets and scripts of the resolved design.
	 *
	 * @since 1.1.0
	 * @param array $resolved    Result of MVweb_OM_Variants::resolve().
	 * @param bool  $styles_only Enqueue only the stylesheets (head pass).
	 * @return void
	 */
	private static function enqueue_variant_assets( array $resolved, $styles_only ) {
		$assets = MVweb_OM_Variants::assets( $resolved );

		foreach ( $assets['styles'] as $handle => $style ) {
			wp_enqueue_style( $handle, $style['src'], array_merge( array( 'mvweb-om-public' ), $style['deps'] ), MVWEB_OM_VERSION );
		}
		if ( $styles_only ) {
			return;
		}
		foreach ( $assets['scripts'] as $handle => $script ) {
			wp_enqueue_script( $handle, $script['src'], $script['deps'], MVWEB_OM_VERSION, true );
		}
	}

	/**
	 * Data the frontend script reads from window.mvwebOmData.
	 *
	 * Printed as JSON before the script, so booleans and numbers keep their
	 * types (wp_localize_script would turn top-level scalars into strings).
	 *
	 * @since 1.1.0
	 * @param array $settings Plugin settings.
	 * @return array
	 */
	private static function frontend_data( array $settings ) {
		$icons = array();
		if ( function_exists( 'mvweb_om_icon_presets' ) ) {
			foreach ( mvweb_om_icon_presets() as $slug => $preset ) {
				$icons[ $slug ] = (string) $preset['path'];
			}
		}

		return array(
			'restUrl'       => esc_url_raw( add_query_arg( 'v', '2', rest_url( MVweb_OM_REST::NAMESPACE_V1 . '/objects' ) ) ),
			'hasKey'        => ( '' !== (string) $settings['api_key'] ),
			'cluster'       => (bool) $settings['cluster_enabled'],
			'modal'         => (bool) $settings['modal_enabled'],
			'showRoute'     => (bool) $settings['show_route'],
			'accent'        => (string) $settings['accent_color'],
			'defaultZoom'   => (int) $settings['default_zoom'],
			'defaultCenter' => (string) $settings['default_center'],
			'card'          => array(
				'bg'          => (string) $settings['card_bg'],
				'border'      => (string) $settings['card_border'],
				'titleColor'  => (string) $settings['card_title_color'],
				'textColor'   => (string) $settings['card_text_color'],
				'hoverBorder' => (string) $settings['card_hover_border'],
				'showPhoto'   => (bool) $settings['card_show_photo'],
				'showAddress' => (bool) $settings['card_show_address'],
				'showExcerpt' => (bool) $settings['card_show_excerpt'],
				'radius'      => (int) $settings['card_radius'],
				'borderWidth' => (int) $settings['card_border_width'],
				'density'     => (string) $settings['card_density'],
				'shadow'      => (bool) $settings['card_shadow'],
				'photoSize'   => (int) $settings['card_photo_size'],
				'photoPos'    => (string) $settings['card_photo_pos'],
				'photoRatio'  => (string) $settings['card_photo_ratio'],
			),
			'icons'         => $icons,
			'i18n'          => array(
				'loading'        => __( 'Loading map…', 'mvweb-object-map' ),
				'noKey'          => __( 'The map is not configured yet.', 'mvweb-object-map' ),
				'error'          => __( 'Could not load the map.', 'mvweb-object-map' ),
				'empty'          => __( 'No objects to show.', 'mvweb-object-map' ),
				'all'            => __( 'All', 'mvweb-object-map' ),
				'more'           => __( 'More details', 'mvweb-object-map' ),
				'route'          => __( 'Get directions', 'mvweb-object-map' ),
				'search'         => __( 'Search objects…', 'mvweb-object-map' ),
				'sortName'       => __( 'By name', 'mvweb-object-map' ),
				'sortNew'        => __( 'Newest first', 'mvweb-object-map' ),
				'mapTab'         => __( 'Map', 'mvweb-object-map' ),
				'listTab'        => __( 'List', 'mvweb-object-map' ),
				'close'          => __( 'Close', 'mvweb-object-map' ),
				'prev'           => __( 'Previous', 'mvweb-object-map' ),
				'next'           => __( 'Next', 'mvweb-object-map' ),
				'twoFingers'     => __( 'Use two fingers to move the map', 'mvweb-object-map' ),
				/* translators: %d: number of objects found. */
				'found'          => __( 'Found: %d', 'mvweb-object-map' ),
				/* translators: %d: number of objects in a map cluster. */
				'clusterLabel'   => __( 'Objects: %d. Zoom in', 'mvweb-object-map' ),
				'categories'     => __( 'Categories', 'mvweb-object-map' ),
				'moreCats'       => __( 'More categories', 'mvweb-object-map' ),
				'searchLabel'    => __( 'Search objects', 'mvweb-object-map' ),
				'searchHint'     => __( 'Name or address', 'mvweb-object-map' ),
				'sortLabel'      => __( 'Sort objects', 'mvweb-object-map' ),
				'emptyTitle'     => __( 'Nothing found', 'mvweb-object-map' ),
				/* translators: 1: search query, 2: category name. */
				'emptyQueryCat'  => __( 'No objects match “%1$s” in “%2$s”.', 'mvweb-object-map' ),
				/* translators: %s: search query. */
				'emptyQuery'     => __( 'No objects match “%s”.', 'mvweb-object-map' ),
				'resetSearch'    => __( 'Clear search', 'mvweb-object-map' ),
				'allCats'        => __( 'Search in all categories', 'mvweb-object-map' ),
				'showMore'       => __( 'Show more', 'mvweb-object-map' ),
				'expandMap'      => __( 'Expand the map', 'mvweb-object-map' ),
				'collapseMap'    => __( 'Collapse the map', 'mvweb-object-map' ),
				'specs'          => __( 'Characteristics', 'mvweb-object-map' ),
				'call'           => __( 'Call', 'mvweb-object-map' ),
				'expand'         => __( 'Expand', 'mvweb-object-map' ),
				'collapse'       => __( 'Collapse', 'mvweb-object-map' ),
				'photo'          => __( 'Photo', 'mvweb-object-map' ),
				/* translators: %d: number of objects (plural form "one"). */
				'objectsOne'     => _x( '%d object', 'objects count, plural form one', 'mvweb-object-map' ),
				/* translators: %d: number of objects (plural form "few"). */
				'objectsFew'     => _x( '%d objects', 'objects count, plural form few', 'mvweb-object-map' ),
				/* translators: %d: number of objects (plural form "many"). */
				'objectsMany'    => _x( '%d objects', 'objects count, plural form many', 'mvweb-object-map' ),
				/* translators: %d: number of objects (plural form "other"). */
				'objectsOther'   => _x( '%d objects', 'objects count, plural form other', 'mvweb-object-map' ),
				'showOnMap'      => __( 'Show on the map', 'mvweb-object-map' ),
				'resetCats'      => __( 'Reset', 'mvweb-object-map' ),
				/* translators: %d: number of objects to show. */
				'showCount'      => __( 'Show %d', 'mvweb-object-map' ),
				/* translators: %d: number of objects in the list. */
				'listCount'      => __( 'List · %d', 'mvweb-object-map' ),
				'hideList'       => __( 'Hide list', 'mvweb-object-map' ),
				/* translators: %s: search query. */
				'emptyQueryCats' => __( 'No objects match “%s” in the selected categories.', 'mvweb-object-map' ),
				'onMap'          => __( 'On the map', 'mvweb-object-map' ),
				'railLabel'      => __( 'Objects on the map', 'mvweb-object-map' ),
				'prevObject'     => __( 'Previous object', 'mvweb-object-map' ),
				'nextObject'     => __( 'Next object', 'mvweb-object-map' ),
				/* translators: 1: current object number, 2: total number of objects. */
				'position'       => __( '%1$d of %2$d', 'mvweb-object-map' ),
				/* translators: 1: current object number, 2: total number of objects. */
				'counter'        => __( '%1$d of %2$d', 'mvweb-object-map' ),
				'objectsLabel'   => __( 'Objects', 'mvweb-object-map' ),
				/* translators: %d: number of hidden categories. */
				'moreCatsCount'  => __( 'Show %d more', 'mvweb-object-map' ),
				'category'       => __( 'Category', 'mvweb-object-map' ),
				'viewLabel'      => __( 'View', 'mvweb-object-map' ),
				'viewGrid'       => __( 'Grid', 'mvweb-object-map' ),
				'viewBoth'       => __( 'Both', 'mvweb-object-map' ),
				'viewBothTitle'  => __( 'Map and grid', 'mvweb-object-map' ),
				/* translators: %d: number of categories in the "more" menu. */
				'moreCount'      => __( 'More %d', 'mvweb-object-map' ),
				'backList'       => __( 'Back to the list', 'mvweb-object-map' ),
				'backMap'        => __( 'Back to the map', 'mvweb-object-map' ),
				'contact'        => __( 'Contact', 'mvweb-object-map' ),
				'tableObject'    => __( 'Object', 'mvweb-object-map' ),
				'tableAddress'   => __( 'Address', 'mvweb-object-map' ),
				'tableCaption'   => __( 'Objects: comparison of characteristics', 'mvweb-object-map' ),
				'filterCats'     => __( 'Filter by category', 'mvweb-object-map' ),
				'showCats'       => __( 'Show categories', 'mvweb-object-map' ),
				'allCategories'  => __( 'All categories', 'mvweb-object-map' ),
				'done'           => __( 'Done', 'mvweb-object-map' ),
				'tableScroll'    => __( 'scroll the table sideways', 'mvweb-object-map' ),
			),
		);
	}

	/**
	 * CSS custom properties of the accent and the list cards.
	 *
	 * Printed on the root and on the object dialog (which lives in the body),
	 * so the colors are right on the first paint, before the script runs.
	 *
	 * @since 1.1.0
	 * @param array $settings Plugin settings.
	 * @return string
	 */
	private static function tokens_css( array $settings ) {
		$vars = array();

		$colors = array(
			'--mvweb-om-accent'      => 'accent_color',
			'--mvweb-om-card-bg'     => 'card_bg',
			'--mvweb-om-card-border' => 'card_border',
			'--mvweb-om-card-title'  => 'card_title_color',
			'--mvweb-om-card-text'   => 'card_text_color',
			'--mvweb-om-card-hover'  => 'card_hover_border',
		);
		foreach ( $colors as $var => $key ) {
			$color = sanitize_hex_color( (string) ( $settings[ $key ] ?? '' ) );
			if ( $color ) {
				$vars[] = $var . ':' . $color;
			}
		}

		$accent = sanitize_hex_color( (string) ( $settings['accent_color'] ?? '' ) );
		if ( $accent ) {
			$vars[] = '--mvweb-om-accent-ink:' . self::ink_for( $accent );
		}

		$vars[] = '--mvweb-om-phone-offset:' . absint( $settings['phone_bottom_offset'] ?? 0 ) . 'px';
		$vars[] = '--mvweb-om-card-radius:' . absint( $settings['card_radius'] ) . 'px';
		$vars[] = '--mvweb-om-card-border-width:' . absint( $settings['card_border_width'] ) . 'px';
		$vars[] = '--mvweb-om-card-photo:' . absint( $settings['card_photo_size'] ) . 'px';

		if ( in_array( $settings['card_photo_ratio'], MVweb_OM_Settings::ALLOWED_PHOTO_RATIOS, true ) ) {
			$vars[] = '--mvweb-om-card-ratio:' . $settings['card_photo_ratio'];
		}

		return '.mvweb-om,.mvweb-om__modal{' . implode( ';', $vars ) . '}';
	}

	/**
	 * Readable text color on top of a background color (WCAG relative luminance).
	 *
	 * @since 1.1.0
	 * @param string $hex Background color, #rgb or #rrggbb.
	 * @return string '#ffffff' or '#111827'.
	 */
	private static function ink_for( $hex ) {
		$hex = ltrim( $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		$lum = 0.0;
		foreach ( array( 0.2126, 0.7152, 0.0722 ) as $i => $weight ) {
			$c    = hexdec( substr( $hex, $i * 2, 2 ) ) / 255;
			$c    = $c <= 0.03928 ? $c / 12.92 : ( ( $c + 0.055 ) / 1.055 ) ** 2.4;
			$lum += $weight * $c;
		}
		return $lum > 0.179 ? '#111827' : '#ffffff';
	}

	/**
	 * Parse a "lat,lng" center attribute into a validated string or empty.
	 *
	 * @since 1.0.0
	 * @param string $raw Raw center value.
	 * @return string
	 */
	private static function parse_center( $raw ) {
		$raw = trim( $raw );
		if ( '' === $raw ) {
			return '';
		}
		$parts = array_map( 'trim', explode( ',', $raw ) );
		if ( 2 !== count( $parts ) ) {
			return '';
		}
		$lat = mvweb_om_sanitize_lat( $parts[0] );
		$lng = mvweb_om_sanitize_lng( $parts[1] );
		return ( '' !== $lat && '' !== $lng ) ? $lat . ',' . $lng : '';
	}

	/**
	 * Parse a yes/no override into true/false/null.
	 *
	 * @since 1.0.0
	 * @param string $raw Raw value.
	 * @return bool|null
	 */
	private static function parse_tristate( $raw ) {
		$raw = strtolower( trim( $raw ) );
		if ( 'yes' === $raw ) {
			return true;
		}
		if ( 'no' === $raw ) {
			return false;
		}
		return null;
	}

	/**
	 * Resolve the Yandex Maps language from the site locale.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function map_lang() {
		$locale = get_locale();
		return ( 0 === strpos( $locale, 'ru' ) ) ? 'ru_RU' : 'en_US';
	}
}
