<?php
/**
 * REST endpoint and object cache for MVweb Object Map.
 *
 * Exposes a read-only public endpoint that returns the published map objects
 * as JSON for the frontend map. One shared payload is cached in a transient
 * whose key carries a version; the version changes whenever an object, a
 * category or the settings change. The `ids` and `category` filters are
 * applied to the shared payload in PHP.
 *
 * Endpoint:
 *   GET /wp-json/mvweb-om/v1/objects  (args: category, ids)
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST controller and cache.
 *
 * @since 1.0.0
 */
final class MVweb_OM_REST {

	/**
	 * REST namespace.
	 */
	const NAMESPACE_V1 = 'mvweb-om/v1';

	/**
	 * Transient key prefix for the cached payload; the cache version follows it.
	 */
	const CACHE_PREFIX = 'mvweb_om_objects_v2_';

	/**
	 * Option holding the current cache version (not autoloaded).
	 */
	const CACHE_VER_OPTION = 'mvweb_om_cache_ver';

	/**
	 * Cron hook that rebuilds the unfiltered payload after a cache flush.
	 */
	const WARM_HOOK = 'mvweb_om_warm_cache';

	/**
	 * Seconds to wait before the warm-up runs, so a save in progress finishes first.
	 */
	const WARM_DELAY = 5;

	/**
	 * Cache lifetime.
	 */
	const CACHE_TTL = DAY_IN_SECONDS;

	/**
	 * Option that held the list of cache keys before 1.1.0. Removed on the first flush.
	 */
	const LEGACY_CACHE_INDEX = 'mvweb_om_cache_keys';

	/**
	 * Object IDs whose publish state changed during this request.
	 *
	 * @var array
	 */
	private static $touched = array();

	/**
	 * Wire WordPress hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( self::WARM_HOOK, array( __CLASS__, 'warm_cache' ) );
		add_action( 'transition_post_status', array( __CLASS__, 'flush_on_transition' ), 10, 3 );
		add_action( 'save_post_' . MVweb_OM_CPT::POST_TYPE, array( __CLASS__, 'flush_on_save' ), 99, 2 );
		add_action( 'deleted_post', array( __CLASS__, 'flush_on_delete' ), 10, 2 );
		add_action( 'add_option_' . MVweb_OM_Settings::OPTION_NAME, array( __CLASS__, 'flush_cache' ) );
		add_action( 'update_option_' . MVweb_OM_Settings::OPTION_NAME, array( __CLASS__, 'flush_cache' ) );
		add_action( 'delete_attachment', array( __CLASS__, 'flush_on_attachment' ) );
		add_action( 'created_' . MVweb_OM_CPT::TAXONOMY, array( __CLASS__, 'flush_cache' ) );
		add_action( 'edited_' . MVweb_OM_CPT::TAXONOMY, array( __CLASS__, 'flush_cache' ) );
		add_action( 'delete_' . MVweb_OM_CPT::TAXONOMY, array( __CLASS__, 'flush_cache' ) );
	}

	/**
	 * Register the objects route.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			self::NAMESPACE_V1,
			'/objects',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_objects' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'category' => array(
						'description'       => __( 'Category slugs, comma-separated.', 'mvweb-object-map' ),
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'ids'      => array(
						'description'       => __( 'Object IDs, comma-separated.', 'mvweb-object-map' ),
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);
	}

	/**
	 * Return the published objects matching the request.
	 *
	 * A `category` or `ids` filter that matches nothing known returns no
	 * objects rather than all of them.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function get_objects( $request ) {
		$payload = self::get_payload();

		$raw_categories = trim( (string) $request->get_param( 'category' ) );
		$raw_ids        = trim( (string) $request->get_param( 'ids' ) );
		$categories     = self::parse_slugs( $raw_categories );
		$ids            = self::parse_ids( $raw_ids );

		if ( ( '' !== $raw_categories && empty( $categories ) ) || ( '' !== $raw_ids && empty( $ids ) ) ) {
			$payload['objects'] = array();
		} elseif ( ! empty( $categories ) || ! empty( $ids ) ) {
			$payload['objects'] = self::filter_objects( $payload['objects'], $categories, $ids );
		}

		return rest_ensure_response( $payload );
	}

	/**
	 * Narrow the objects to the requested categories and IDs.
	 *
	 * Objects match a category when they sit in it or in one of its
	 * descendants. With `ids`, the result follows the ascending ID order.
	 *
	 * @since 1.1.0
	 * @param array $objects    Objects of the shared payload.
	 * @param array $categories Category slugs including descendants; empty for no filter.
	 * @param array $ids        Object IDs sorted ascending; empty for no filter.
	 * @return array
	 */
	public static function filter_objects( $objects, $categories, $ids ) {
		if ( ! empty( $categories ) ) {
			$objects = array_filter(
				$objects,
				static function ( $object ) use ( $categories ) {
					return (bool) array_intersect( $object['categories'], $categories );
				}
			);
		}

		if ( ! empty( $ids ) ) {
			$by_id = array();
			foreach ( $objects as $object ) {
				$by_id[ $object['id'] ] = $object;
			}
			$objects = array();
			foreach ( $ids as $id ) {
				if ( isset( $by_id[ $id ] ) ) {
					$objects[] = $by_id[ $id ];
				}
			}
		}

		return array_values( $objects );
	}

	/**
	 * Current cache version.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function cache_ver() {
		$ver = get_option( self::CACHE_VER_OPTION, '' );
		return ( is_string( $ver ) && '' !== $ver ) ? $ver : '0';
	}

	/**
	 * Get the shared payload from the cache, building it on a miss.
	 *
	 * @since 1.1.0
	 * @return array
	 */
	private static function get_payload() {
		$cache_key = self::CACHE_PREFIX . self::cache_ver();
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) && isset( $cached['objects'] ) ) {
			return $cached;
		}

		$payload = self::build_payload();
		set_transient( $cache_key, $payload, self::CACHE_TTL );
		return $payload;
	}

	/**
	 * Rebuild the shared payload (cron handler).
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function warm_cache() {
		$cache_key = self::CACHE_PREFIX . self::cache_ver();
		if ( false !== get_transient( $cache_key ) ) {
			return;
		}

		set_transient( $cache_key, self::build_payload(), self::CACHE_TTL );
	}

	/**
	 * Build the payload with every published object from the database.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private static function build_payload() {
		$args = array(
			'post_type'              => MVweb_OM_CPT::POST_TYPE,
			'post_status'            => 'publish',
			'has_password'           => false,
			'posts_per_page'         => -1,
			'no_found_rows'          => true,
			'update_post_meta_cache' => true,
			'update_post_term_cache' => true,
			'orderby'                => 'date',
			'order'                  => 'DESC',
		);

		$query   = new WP_Query( $args );
		$schema  = (array) MVweb_OM_Settings::get( 'specs_schema' );
		$objects = array();

		self::prime_attachment_cache( $query->posts );

		foreach ( $query->posts as $post ) {
			$item = self::format_object( $post, $schema );
			if ( null !== $item ) {
				$objects[] = $item;
			}
		}

		return array(
			'objects'    => $objects,
			'categories' => self::format_categories(),
			'schema'     => self::format_schema( $schema ),
		);
	}

	/**
	 * Format the specs schema once per response.
	 *
	 * @since 1.1.0
	 * @param array $schema Specs schema.
	 * @return array
	 */
	private static function format_schema( $schema ) {
		$out = array();
		foreach ( $schema as $field ) {
			if ( empty( $field['id'] ) ) {
				continue;
			}
			$out[] = array(
				'id'    => (string) $field['id'],
				'label' => wp_strip_all_tags( (string) $field['label'] ),
				'type'  => (string) $field['type'],
				'unit'  => wp_strip_all_tags( isset( $field['unit'] ) ? (string) $field['unit'] : '' ),
				'show'  => MVweb_OM_Settings::spec_show_in( $field ),
			);
		}
		return $out;
	}

	/**
	 * Prime the post/meta cache for all referenced attachments in one pass.
	 *
	 * Avoids per-attachment queries from wp_get_attachment_image_url() inside
	 * the formatting loop (matters on a cache miss with many galleries).
	 *
	 * @since 1.0.0
	 * @param WP_Post[] $posts Object posts.
	 * @return void
	 */
	private static function prime_attachment_cache( $posts ) {
		$att_ids = array();

		foreach ( $posts as $post ) {
			$thumb = (int) get_post_thumbnail_id( $post->ID );
			if ( $thumb > 0 ) {
				$att_ids[] = $thumb;
			}

			$icon = (int) get_post_meta( $post->ID, '_mvweb_om_icon_image', true );
			if ( $icon > 0 ) {
				$att_ids[] = $icon;
			}

			foreach ( array_map( 'absint', mvweb_om_decode_array( get_post_meta( $post->ID, '_mvweb_om_gallery', true ) ) ) as $gid ) {
				if ( $gid > 0 ) {
					$att_ids[] = $gid;
				}
			}
		}

		$att_ids = array_values( array_unique( $att_ids ) );
		if ( ! empty( $att_ids ) && function_exists( '_prime_post_caches' ) ) {
			_prime_post_caches( $att_ids, false, true );
		}
	}

	/**
	 * Format a single object for the frontend.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post   Object post.
	 * @param array   $schema Specs schema.
	 * @return array|null Null when the object has no coordinates.
	 */
	private static function format_object( $post, $schema ) {
		$lat = (string) get_post_meta( $post->ID, '_mvweb_om_lat', true );
		$lng = (string) get_post_meta( $post->ID, '_mvweb_om_lng', true );

		if ( '' === $lat || '' === $lng ) {
			return null;
		}

		$gallery_ids = array_map( 'absint', mvweb_om_decode_array( get_post_meta( $post->ID, '_mvweb_om_gallery', true ) ) );
		$thumb_id    = (int) get_post_thumbnail_id( $post->ID );

		$gallery = array();
		foreach ( $gallery_ids as $att_id ) {
			$url = wp_get_attachment_image_url( $att_id, 'large' );
			if ( $url ) {
				$gallery[] = $url;
			}
		}

		$more_url = mvweb_om_sanitize_url( (string) get_post_meta( $post->ID, '_mvweb_om_more_url', true ) );
		$specs    = self::format_specs( $post->ID, $schema );
		$terms    = get_the_terms( $post, MVweb_OM_CPT::TAXONOMY );
		$pin      = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'thumbnail' ) : '';
		$photo    = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'medium_large' ) : '';

		return array(
			'id'         => $post->ID,
			'title'      => html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' ),
			'lat'        => (float) $lat,
			'lng'        => (float) $lng,
			'address'    => wp_strip_all_tags( (string) get_post_meta( $post->ID, '_mvweb_om_address', true ) ),
			'excerpt'    => wp_strip_all_tags( (string) $post->post_excerpt ),
			'thumb'      => $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'medium' ) : '',
			'pin'        => $pin ? $pin : '',
			'photo'      => $photo ? $photo : '',
			'gallery'    => $gallery,
			'phone'      => wp_strip_all_tags( (string) get_post_meta( $post->ID, '_mvweb_om_phone', true ) ),
			'hours'      => wp_strip_all_tags( (string) get_post_meta( $post->ID, '_mvweb_om_hours', true ) ),
			'links'      => self::format_links( $post->ID ),
			'moreUrl'    => $more_url,
			'icon'       => self::format_icon( $post->ID ),
			'categories' => is_array( $terms ) ? array_values( wp_list_pluck( $terms, 'slug' ) ) : array(),
			'specs'      => $specs,
		);
	}

	/**
	 * Format object specs into label/value/balloon rows following the schema.
	 *
	 * @since 1.0.0
	 * @param int   $post_id Object ID.
	 * @param array $schema  Specs schema.
	 * @return array
	 */
	private static function format_specs( $post_id, $schema ) {
		$values = mvweb_om_decode_array( get_post_meta( $post_id, '_mvweb_om_specs', true ) );
		$out    = array();

		foreach ( $schema as $field ) {
			if ( empty( $field['id'] ) || ! isset( $values[ $field['id'] ] ) ) {
				continue;
			}
			$value = (string) $values[ $field['id'] ];
			if ( '' === $value ) {
				continue;
			}
			$raw = $value;
			if ( 'bool' === $field['type'] ) {
				$value = ( '1' === $value )
					? _x( 'Yes', 'object spec boolean value', 'mvweb-object-map' )
					: _x( 'No', 'object spec boolean value', 'mvweb-object-map' );
			} elseif ( 'number' === $field['type'] && ! empty( $field['unit'] ) ) {
				$value = $value . ' ' . $field['unit'];
			} elseif ( 'url' === $field['type'] ) {
				$value = esc_url_raw( $value, array( 'http', 'https' ) );
				if ( '' === $value ) {
					continue;
				}
			}

			$spec = array(
				'id'        => (string) $field['id'],
				'label'     => wp_strip_all_tags( (string) $field['label'] ),
				'value'     => wp_strip_all_tags( $value ),
				'type'      => $field['type'],
				'inBalloon' => in_array( 'balloon', MVweb_OM_Settings::spec_show_in( $field ), true ),
			);

			if ( 'number' === $field['type'] ) {
				$number = str_replace( ',', '.', (string) preg_replace( '/[\s\x{00A0}]+/u', '', $raw ) );
				if ( preg_match( '/^-?\d{1,15}(\.\d{1,6})?$/D', $number ) && is_finite( (float) $number ) ) {
					$spec['raw'] = (float) $number;
				}
			}

			$out[] = $spec;
		}

		return $out;
	}

	/**
	 * Format object links.
	 *
	 * @since 1.0.0
	 * @param int $post_id Object ID.
	 * @return array
	 */
	private static function format_links( $post_id ) {
		$links = mvweb_om_decode_array( get_post_meta( $post_id, '_mvweb_om_links', true ) );
		$out   = array();
		foreach ( $links as $link ) {
			if ( ! is_array( $link ) || empty( $link['url'] ) ) {
				continue;
			}
			$out[] = array(
				'label' => wp_strip_all_tags( isset( $link['label'] ) ? (string) $link['label'] : '' ),
				'url'   => mvweb_om_sanitize_url( (string) $link['url'] ),
			);
		}
		return $out;
	}

	/**
	 * Format the marker icon (custom image URL or preset key).
	 *
	 * @since 1.0.0
	 * @param int $post_id Object ID.
	 * @return array
	 */
	private static function format_icon( $post_id ) {
		$image_id = (int) get_post_meta( $post_id, '_mvweb_om_icon_image', true );
		if ( $image_id > 0 ) {
			$url = wp_get_attachment_image_url( $image_id, 'thumbnail' );
			if ( $url ) {
				return array(
					'type' => 'image',
					'url'  => $url,
				);
			}
		}

		return array(
			'type'   => 'preset',
			'preset' => mvweb_om_sanitize_icon_preset( get_post_meta( $post_id, '_mvweb_om_icon_preset', true ) ),
		);
	}

	/**
	 * Format the category list (slug + name) for the frontend filter.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private static function format_categories() {
		$terms = get_terms(
			array(
				'taxonomy'   => MVweb_OM_CPT::TAXONOMY,
				'hide_empty' => true,
			)
		);

		$out = array();
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$out[] = array(
					'slug'  => $term->slug,
					'name'  => wp_strip_all_tags( $term->name ),
					'color' => sanitize_hex_color( (string) get_term_meta( $term->term_id, MVweb_OM_CPT::TERM_COLOR_META, true ) ),
					'icon'  => mvweb_om_sanitize_icon_preset( get_term_meta( $term->term_id, MVweb_OM_CPT::TERM_ICON_META, true ) ),
				);
			}
		}
		return $out;
	}

	/**
	 * Parse a comma-separated list of taxonomy slugs and add their descendants.
	 *
	 * Unknown slugs are dropped. An empty result means no category filter.
	 *
	 * @since 1.0.0
	 * @param string $raw Raw value.
	 * @return array
	 */
	private static function parse_slugs( $raw ) {
		if ( '' === $raw ) {
			return array();
		}
		$slugs = array_map( 'sanitize_title', array_map( 'trim', explode( ',', $raw ) ) );
		$slugs = array_values( array_filter( array_unique( $slugs ) ) );
		$slugs = array_slice( $slugs, 0, 20 );

		$terms = get_terms(
			array(
				'taxonomy'   => MVweb_OM_CPT::TAXONOMY,
				'hide_empty' => false,
			)
		);
		if ( ! is_array( $terms ) ) {
			return array();
		}

		return self::with_descendants( $slugs, $terms );
	}

	/**
	 * Add the descendants of the requested slugs.
	 *
	 * @since 1.1.0
	 * @param array     $slugs Requested slugs.
	 * @param WP_Term[] $terms All terms of the taxonomy.
	 * @return array Existing requested slugs and all their descendant slugs.
	 */
	public static function with_descendants( $slugs, $terms ) {
		$children = array();
		$by_slug  = array();
		foreach ( $terms as $term ) {
			$children[ (int) $term->parent ][] = $term;
			$by_slug[ $term->slug ]            = $term;
		}

		$out   = array();
		$queue = array();
		foreach ( $slugs as $slug ) {
			if ( isset( $by_slug[ $slug ] ) ) {
				$queue[] = $by_slug[ $slug ];
			}
		}

		while ( $queue ) {
			$term = array_shift( $queue );
			if ( isset( $out[ $term->slug ] ) ) {
				continue;
			}
			$out[ $term->slug ] = true;
			if ( isset( $children[ (int) $term->term_id ] ) ) {
				foreach ( $children[ (int) $term->term_id ] as $child ) {
					$queue[] = $child;
				}
			}
		}

		return array_keys( $out );
	}

	/**
	 * Parse a comma-separated list of post IDs.
	 *
	 * @since 1.0.0
	 * @param string $raw Raw value.
	 * @return array
	 */
	private static function parse_ids( $raw ) {
		if ( '' === $raw ) {
			return array();
		}
		$ids = array_map( 'absint', array_map( 'trim', explode( ',', $raw ) ) );
		$ids = array_values( array_filter( array_unique( $ids ) ) );
		$ids = array_slice( $ids, 0, 100 );
		sort( $ids );
		return $ids;
	}

	/**
	 * Flush the cache when a map object is deleted.
	 *
	 * @since 1.0.0
	 * @param int     $post_id Deleted post ID.
	 * @param WP_Post $post    Deleted post object.
	 * @return void
	 */
	public static function flush_on_delete( $post_id, $post = null ) {
		if ( $post instanceof WP_Post && MVweb_OM_CPT::POST_TYPE === $post->post_type ) {
			self::flush_cache();
		}
	}

	/**
	 * Flush the cache when a deleted image is used by the cached payload.
	 *
	 * @since 1.1.0
	 * @param int $attachment_id Attachment ID.
	 * @return void
	 */
	public static function flush_on_attachment( $attachment_id ) {
		$payload = get_transient( self::CACHE_PREFIX . self::cache_ver() );
		$file    = (string) get_post_meta( (int) $attachment_id, '_wp_attached_file', true );
		if ( ! is_array( $payload ) || '' === $file ) {
			return;
		}
		$name = pathinfo( $file, PATHINFO_FILENAME );
		if ( '' !== $name && false !== strpos( (string) wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ), '/' . $name ) ) {
			self::flush_cache();
		}
	}

	/**
	 * Flush the cache when an object is or was published.
	 *
	 * Fires for publish to publish too, so a plain edit of a live object counts.
	 * Drafts and auto-drafts never touch the cache.
	 *
	 * @since 1.1.0
	 * @param string  $new_status New status.
	 * @param string  $old_status Old status.
	 * @param WP_Post $post       Post.
	 * @return void
	 */
	public static function flush_on_transition( $new_status, $old_status, $post ) {
		if ( ! ( $post instanceof WP_Post ) || MVweb_OM_CPT::POST_TYPE !== $post->post_type ) {
			return;
		}
		if ( 'publish' !== $new_status && 'publish' !== $old_status ) {
			return;
		}

		self::$touched[ $post->ID ] = true;
		self::flush_cache();
	}

	/**
	 * Flush again after the metabox has saved the object meta.
	 *
	 * The metabox saves on `save_post` at priority 10, after the status
	 * transition, so a request in between could cache the old values.
	 *
	 * @since 1.1.0
	 * @param int     $post_id Object ID.
	 * @param WP_Post $post    Object.
	 * @return void
	 */
	public static function flush_on_save( $post_id, $post ) {
		if ( isset( self::$touched[ $post_id ] ) || ( $post instanceof WP_Post && 'publish' === $post->post_status ) ) {
			self::flush_cache();
		}
	}

	/**
	 * Start a new cache version and schedule a warm-up of the payload.
	 *
	 * The first flush after the update to 1.1.0 also removes the old key index
	 * option and the transients it lists.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function flush_cache() {
		$old_ver = get_option( self::CACHE_VER_OPTION, '' );
		if ( is_string( $old_ver ) && '' !== $old_ver ) {
			delete_transient( self::CACHE_PREFIX . $old_ver );
		} else {
			delete_transient( self::CACHE_PREFIX . '0' );
		}

		$legacy = get_option( self::LEGACY_CACHE_INDEX, null );
		if ( null !== $legacy ) {
			if ( is_array( $legacy ) ) {
				foreach ( $legacy as $key ) {
					delete_transient( (string) $key );
				}
			}
			delete_option( self::LEGACY_CACHE_INDEX );
		}

		update_option( self::CACHE_VER_OPTION, wp_generate_password( 10, false ), false );

		if ( ! wp_next_scheduled( self::WARM_HOOK ) ) {
			wp_schedule_single_event( time() + self::WARM_DELAY, self::WARM_HOOK );
		}
	}
}
