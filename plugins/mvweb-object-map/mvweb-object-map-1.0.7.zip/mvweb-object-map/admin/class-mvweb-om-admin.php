<?php
/**
 * Admin settings page for MVweb Object Map.
 *
 * Registers a submenu under the MVweb Hub, enqueues admin assets and renders
 * the tabbed settings page (General · Specs · Help) backed by the Settings API.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin page controller.
 *
 * @since 1.0.0
 */
final class MVweb_OM_Admin {

	/**
	 * Settings page slug.
	 */
	const PAGE_SLUG = 'mvweb-object-map';

	/**
	 * Capability required to manage the plugin.
	 */
	const CAPABILITY = 'manage_options';

	/**
	 * Hook suffix of the settings page.
	 *
	 * @var string
	 */
	private static $hook_suffix = '';

	/**
	 * Wire WordPress hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 11 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Register the settings submenu under the MVweb Hub.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_menu() {
		$parent = class_exists( 'MVweb_Menu' ) && method_exists( 'MVweb_Menu', 'get_menu_slug' )
			? MVweb_Menu::get_menu_slug()
			: 'mvweb-hub';

		self::$hook_suffix = add_submenu_page(
			$parent,
			'Object Map',
			'Object Map',
			self::CAPABILITY,
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Enqueue admin styles and scripts on the settings page only.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook suffix.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( '' === self::$hook_suffix || $hook !== self::$hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'mvweb-om-admin',
			MVWEB_OM_URL . 'admin/css/admin.min.css',
			array(),
			MVWEB_OM_VERSION
		);
		wp_enqueue_style(
			'mvweb-om-plugin',
			MVWEB_OM_URL . 'admin/css/plugin.min.css',
			array( 'mvweb-om-admin' ),
			MVWEB_OM_VERSION
		);
		wp_enqueue_script(
			'mvweb-om-admin',
			MVWEB_OM_URL . 'admin/js/admin.min.js',
			array(),
			MVWEB_OM_VERSION,
			true
		);
		wp_localize_script(
			'mvweb-om-admin',
			'mvwebOmAdmin',
			array(
				'specTypes' => MVweb_OM_Settings::ALLOWED_SPEC_TYPES,
				'i18n'      => array(
					'confirmRemove' => __( 'Remove this field?', 'mvweb-object-map' ),
					'newField'      => __( 'New field', 'mvweb-object-map' ),
				),
			)
		);
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		require MVWEB_OM_PATH . 'admin/views/settings-page.php';
	}
}
