<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-object-map' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Add your Yandex Maps API key', 'mvweb-object-map' ); ?></strong>
			<p><?php esc_html_e( 'Open the General tab and paste a free Yandex Maps JavaScript API key. Without it the map will not render.', 'mvweb-object-map' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Define characteristics (optional)', 'mvweb-object-map' ); ?></strong>
			<p><?php esc_html_e( 'On the Characteristics tab create the fields your objects need (area, year, material, anything). Each object fills in only what applies.', 'mvweb-object-map' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Create map objects', 'mvweb-object-map' ); ?></strong>
			<p><?php esc_html_e( 'Go to Map Objects → Add New. Set the address (or pin it on the mini-map), add photos, contacts, links and characteristics, then publish.', 'mvweb-object-map' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Place the map', 'mvweb-object-map' ); ?></strong>
			<p><?php esc_html_e( 'Insert the [mvweb_map] shortcode on any page or post.', 'mvweb-object-map' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Shortcode', 'mvweb-object-map' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Attributes are optional. Combine them as needed.', 'mvweb-object-map' ); ?></p>
	<div class="mvweb-codeblock"><code>[mvweb_map category="houses" list="yes" filter="yes" height="600px"]</code></div>
	<ul>
		<li><code>category</code> — <?php esc_html_e( 'show only objects from these category slugs (comma-separated).', 'mvweb-object-map' ); ?></li>
		<li><code>ids</code> — <?php esc_html_e( 'show only specific object IDs (comma-separated).', 'mvweb-object-map' ); ?></li>
		<li><code>list</code> — <?php esc_html_e( '"yes" adds a catalog list with search and sort next to the map.', 'mvweb-object-map' ); ?></li>
		<li><code>filter</code> — <?php esc_html_e( '"no" hides the category toggles above the map.', 'mvweb-object-map' ); ?></li>
		<li><code>height</code> — <?php esc_html_e( 'map height, e.g. 500px.', 'mvweb-object-map' ); ?></li>
		<li><code>zoom</code>, <code>center</code>, <code>cluster</code>, <code>type</code> — <?php esc_html_e( 'override the defaults from the General tab.', 'mvweb-object-map' ); ?></li>
	</ul>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-object-map' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How do I get a Yandex Maps API key?', 'mvweb-object-map' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Open the Developer Dashboard at developer.tech.yandex.ru, click "Connect API" and choose the "JavaScript API" package. Then open the key, click Edit and fill in the "HTTP Referer restriction" with your site domain. The key activates in about 15 minutes. The free tier covers ~25,000 map loads per day.', 'mvweb-object-map' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The map does not appear on the page. Why?', 'mvweb-object-map' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Most often the API key is missing or the current domain is not added to the key\'s HTTP Referer restriction. Also make sure objects are published and have coordinates.', 'mvweb-object-map' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Do objects have their own pages on the site?', 'mvweb-object-map' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'No. Objects exist only in the admin as data for the map. Use the "More details" URL field to link a balloon button anywhere you like.', 'mvweb-object-map' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I show several maps on one page?', 'mvweb-object-map' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes. Add the [mvweb_map] shortcode multiple times with different attributes — each map works independently.', 'mvweb-object-map' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-object-map' ); ?></div>
	</div>
	<p>
		<?php
		printf(
			/* translators: %s: MVweb plugin URL */
			esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-object-map' ),
			'<a href="https://mvweb.ru/plugins/mvweb-object-map" target="_blank" rel="noopener noreferrer">mvweb.ru</a>'
		);
		?>
	</p>
</div>
