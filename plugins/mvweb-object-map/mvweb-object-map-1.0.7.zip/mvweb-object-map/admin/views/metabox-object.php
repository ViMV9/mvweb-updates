<?php
/**
 * Object details metabox view.
 *
 * @package mvweb_om
 * @since   1.0.0
 *
 * @var array $data Object meta (provided by MVweb_OM_Metabox::render()).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$gallery     = array_map( 'absint', (array) $data['gallery'] );
$links       = is_array( $data['links'] ) ? $data['links'] : array();
$spec_values = is_array( $data['specs'] ) ? $data['specs'] : array();
$schema      = is_array( $data['schema'] ) ? $data['schema'] : array();
?>

<div class="mvweb-om-meta">

	<section class="mvweb-om-meta__section">
		<h4 class="mvweb-om-meta__title"><?php esc_html_e( 'Location', 'mvweb-object-map' ); ?></h4>

		<p class="mvweb-om-field">
			<label for="mvweb_om_address"><?php esc_html_e( 'Address', 'mvweb-object-map' ); ?></label>
			<span class="mvweb-om-field__row">
				<input type="text" id="mvweb_om_address" name="mvweb_om_address" class="widefat"
					value="<?php echo esc_attr( $data['address'] ); ?>">
				<button type="button" class="button mvweb-om-geocode"><?php esc_html_e( 'Find on map', 'mvweb-object-map' ); ?></button>
			</span>
		</p>

		<div class="mvweb-om-map" id="mvweb-om-map"
			data-lat="<?php echo esc_attr( $data['lat'] ); ?>"
			data-lng="<?php echo esc_attr( $data['lng'] ); ?>"></div>
		<p class="mvweb-om-map__hint description"><?php esc_html_e( 'Click or drag the marker to set the exact position.', 'mvweb-object-map' ); ?></p>

		<p class="mvweb-om-field mvweb-om-field--coords">
			<span>
				<label for="mvweb_om_lat"><?php esc_html_e( 'Latitude', 'mvweb-object-map' ); ?></label>
				<input type="text" id="mvweb_om_lat" name="mvweb_om_lat" value="<?php echo esc_attr( $data['lat'] ); ?>">
			</span>
			<span>
				<label for="mvweb_om_lng"><?php esc_html_e( 'Longitude', 'mvweb-object-map' ); ?></label>
				<input type="text" id="mvweb_om_lng" name="mvweb_om_lng" value="<?php echo esc_attr( $data['lng'] ); ?>">
			</span>
		</p>
	</section>

	<section class="mvweb-om-meta__section">
		<h4 class="mvweb-om-meta__title"><?php esc_html_e( 'Gallery', 'mvweb-object-map' ); ?></h4>
		<p class="description"><?php esc_html_e( 'The featured image is the main photo. Add more photos for the slider here.', 'mvweb-object-map' ); ?></p>

		<?php $mvweb_om_gallery_json = wp_json_encode( $gallery ); ?>
		<input type="hidden" id="mvweb_om_gallery" name="mvweb_om_gallery" value="<?php echo esc_attr( $mvweb_om_gallery_json ? $mvweb_om_gallery_json : '[]' ); ?>">
		<div class="mvweb-om-gallery" id="mvweb-om-gallery">
			<?php foreach ( $gallery as $att_id ) : ?>
				<?php $thumb = wp_get_attachment_image_url( $att_id, 'thumbnail' ); ?>
				<?php if ( $thumb ) : ?>
					<span class="mvweb-om-gallery__item" data-id="<?php echo esc_attr( (string) $att_id ); ?>">
						<img src="<?php echo esc_url( $thumb ); ?>" alt="">
						<button type="button" class="mvweb-om-gallery__remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-object-map' ); ?>">&times;</button>
					</span>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<button type="button" class="button mvweb-om-gallery-add"><?php esc_html_e( 'Add photos', 'mvweb-object-map' ); ?></button>
	</section>

	<section class="mvweb-om-meta__section">
		<h4 class="mvweb-om-meta__title"><?php esc_html_e( 'Marker icon', 'mvweb-object-map' ); ?></h4>

		<p class="mvweb-om-field">
			<label for="mvweb_om_icon_preset"><?php esc_html_e( 'Preset', 'mvweb-object-map' ); ?></label>
			<select id="mvweb_om_icon_preset" name="mvweb_om_icon_preset" class="mvweb-om-select">
				<?php
				$presets = array(
					''        => __( 'Default', 'mvweb-object-map' ),
					'home'    => __( 'Home', 'mvweb-object-map' ),
					'shop'    => __( 'Shop', 'mvweb-object-map' ),
					'service' => __( 'Service', 'mvweb-object-map' ),
					'flag'    => __( 'Flag', 'mvweb-object-map' ),
				);
				foreach ( $presets as $value => $label ) :
					?>
					<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $data['icon_preset'], $value ); ?>>
						<?php echo esc_html( $label ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</p>

		<p class="mvweb-om-field">
			<label><?php esc_html_e( 'Or a custom image', 'mvweb-object-map' ); ?></label>
			<input type="hidden" id="mvweb_om_icon_image" name="mvweb_om_icon_image" value="<?php echo esc_attr( (string) $data['icon_image'] ); ?>">
			<span class="mvweb-om-icon-preview" id="mvweb-om-icon-preview">
				<?php
				$icon_url = $data['icon_image'] ? wp_get_attachment_image_url( $data['icon_image'], 'thumbnail' ) : '';
				if ( $icon_url ) :
					?>
					<img src="<?php echo esc_url( $icon_url ); ?>" alt="">
				<?php endif; ?>
			</span>
			<button type="button" class="button mvweb-om-icon-select"><?php esc_html_e( 'Select image', 'mvweb-object-map' ); ?></button>
			<button type="button" class="button mvweb-om-icon-clear<?php echo $data['icon_image'] ? '' : ' mvweb-om-hidden'; ?>"><?php esc_html_e( 'Clear', 'mvweb-object-map' ); ?></button>
		</p>
	</section>

	<section class="mvweb-om-meta__section">
		<h4 class="mvweb-om-meta__title"><?php esc_html_e( 'Contacts', 'mvweb-object-map' ); ?></h4>

		<p class="mvweb-om-field">
			<label for="mvweb_om_phone"><?php esc_html_e( 'Phone', 'mvweb-object-map' ); ?></label>
			<input type="text" id="mvweb_om_phone" name="mvweb_om_phone" class="widefat" value="<?php echo esc_attr( $data['phone'] ); ?>">
		</p>
		<p class="mvweb-om-field">
			<label for="mvweb_om_hours"><?php esc_html_e( 'Working hours', 'mvweb-object-map' ); ?></label>
			<input type="text" id="mvweb_om_hours" name="mvweb_om_hours" class="widefat" value="<?php echo esc_attr( $data['hours'] ); ?>">
		</p>
		<p class="mvweb-om-field">
			<label for="mvweb_om_more_url"><?php esc_html_e( '"More details" URL', 'mvweb-object-map' ); ?></label>
			<input type="url" id="mvweb_om_more_url" name="mvweb_om_more_url" class="widefat" value="<?php echo esc_attr( $data['more_url'] ); ?>">
			<span class="description"><?php esc_html_e( 'Leave empty to hide the button in the balloon.', 'mvweb-object-map' ); ?></span>
		</p>
	</section>

	<section class="mvweb-om-meta__section">
		<h4 class="mvweb-om-meta__title"><?php esc_html_e( 'Links', 'mvweb-object-map' ); ?></h4>

		<div class="mvweb-om-links" id="mvweb-om-links" data-next-index="<?php echo esc_attr( (string) count( $links ) ); ?>">
			<?php foreach ( $links as $i => $link ) : ?>
				<?php
				$link  = is_array( $link ) ? $link : array();
				$label = isset( $link['label'] ) ? $link['label'] : '';
				$url   = isset( $link['url'] ) ? $link['url'] : '';
				?>
				<span class="mvweb-om-link-row" data-index="<?php echo esc_attr( (string) $i ); ?>">
					<input type="text" placeholder="<?php esc_attr_e( 'Label', 'mvweb-object-map' ); ?>"
						name="mvweb_om_links[<?php echo esc_attr( (string) $i ); ?>][label]" value="<?php echo esc_attr( $label ); ?>">
					<input type="url" placeholder="https://"
						name="mvweb_om_links[<?php echo esc_attr( (string) $i ); ?>][url]" value="<?php echo esc_attr( $url ); ?>">
					<button type="button" class="button mvweb-om-link-remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-object-map' ); ?>">&times;</button>
				</span>
			<?php endforeach; ?>
		</div>
		<button type="button" class="button mvweb-om-link-add"><?php esc_html_e( 'Add link', 'mvweb-object-map' ); ?></button>

		<template id="mvweb-om-link-template">
			<span class="mvweb-om-link-row" data-index="__INDEX__">
				<input type="text" placeholder="<?php esc_attr_e( 'Label', 'mvweb-object-map' ); ?>" name="mvweb_om_links[__INDEX__][label]" value="">
				<input type="url" placeholder="https://" name="mvweb_om_links[__INDEX__][url]" value="">
				<button type="button" class="button mvweb-om-link-remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-object-map' ); ?>">&times;</button>
			</span>
		</template>
	</section>

	<?php if ( ! empty( $schema ) ) : ?>
		<section class="mvweb-om-meta__section">
			<h4 class="mvweb-om-meta__title"><?php esc_html_e( 'Characteristics', 'mvweb-object-map' ); ?></h4>

			<?php foreach ( $schema as $field ) : ?>
				<?php
				$fid    = isset( $field['id'] ) ? $field['id'] : '';
				$type   = isset( $field['type'] ) ? $field['type'] : 'text';
				$flabel = isset( $field['label'] ) ? $field['label'] : '';
				$unit   = isset( $field['unit'] ) ? $field['unit'] : '';
				$opts   = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
				$value  = isset( $spec_values[ $fid ] ) ? $spec_values[ $fid ] : '';
				if ( '' === $fid ) {
					continue;
				}
				$name = 'mvweb_om_specs[' . $fid . ']';
				?>
				<p class="mvweb-om-field">
					<label for="mvweb_om_spec_<?php echo esc_attr( $fid ); ?>">
						<?php echo esc_html( $flabel ); ?>
						<?php if ( 'number' === $type && '' !== $unit ) : ?>
							<span class="mvweb-om-field__unit">(<?php echo esc_html( $unit ); ?>)</span>
						<?php endif; ?>
					</label>

					<?php if ( 'select' === $type ) : ?>
						<select id="mvweb_om_spec_<?php echo esc_attr( $fid ); ?>" name="<?php echo esc_attr( $name ); ?>" class="mvweb-om-select">
							<option value=""><?php esc_html_e( '— none —', 'mvweb-object-map' ); ?></option>
							<?php foreach ( $opts as $opt ) : ?>
								<option value="<?php echo esc_attr( $opt ); ?>" <?php selected( $value, $opt ); ?>><?php echo esc_html( $opt ); ?></option>
							<?php endforeach; ?>
						</select>
					<?php elseif ( 'bool' === $type ) : ?>
						<label class="mvweb-om-bool">
							<input type="checkbox" id="mvweb_om_spec_<?php echo esc_attr( $fid ); ?>" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( '1', (string) $value ); ?>>
							<?php esc_html_e( 'Yes', 'mvweb-object-map' ); ?>
						</label>
					<?php elseif ( 'number' === $type ) : ?>
						<input type="number" step="any" id="mvweb_om_spec_<?php echo esc_attr( $fid ); ?>" name="<?php echo esc_attr( $name ); ?>" class="widefat" value="<?php echo esc_attr( $value ); ?>">
					<?php elseif ( 'url' === $type ) : ?>
						<input type="url" id="mvweb_om_spec_<?php echo esc_attr( $fid ); ?>" name="<?php echo esc_attr( $name ); ?>" class="widefat" value="<?php echo esc_attr( $value ); ?>">
					<?php else : ?>
						<input type="text" id="mvweb_om_spec_<?php echo esc_attr( $fid ); ?>" name="<?php echo esc_attr( $name ); ?>" class="widefat" value="<?php echo esc_attr( $value ); ?>">
					<?php endif; ?>
				</p>
			<?php endforeach; ?>
		</section>
	<?php else : ?>
		<section class="mvweb-om-meta__section">
			<h4 class="mvweb-om-meta__title"><?php esc_html_e( 'Characteristics', 'mvweb-object-map' ); ?></h4>
			<p class="description">
				<?php esc_html_e( 'No characteristic fields defined yet. Add them in the plugin settings (Characteristics tab).', 'mvweb-object-map' ); ?>
			</p>
		</section>
	<?php endif; ?>

</div>
