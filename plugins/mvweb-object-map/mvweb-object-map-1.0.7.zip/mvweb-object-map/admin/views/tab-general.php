<?php
/**
 * General settings tab.
 *
 * Fields are namespaced under `mvweb_om_settings[...]` and saved via the
 * Settings API form opened in settings-page.php.
 *
 * @package mvweb_om
 * @since   1.0.0
 *
 * @var array $settings Current settings (provided by settings-page.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$opt = 'mvweb_om_settings';
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Yandex Maps API', 'mvweb-object-map' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Each site owner uses their own free Yandex Maps API key. Without a key the map will not load.', 'mvweb-object-map' ); ?>
	</p>

	<div class="mvweb-form-row">
		<label for="mvweb_om_api_key" class="mvweb-form-row__label">
			<?php esc_html_e( 'API key', 'mvweb-object-map' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<input type="text"
				id="mvweb_om_api_key"
				name="<?php echo esc_attr( $opt ); ?>[api_key]"
				class="mvweb-input"
				autocomplete="off"
				value="<?php echo esc_attr( $settings['api_key'] ); ?>">
			<p class="mvweb-form-row__desc">
				<a href="https://developer.tech.yandex.ru/" target="_blank" rel="noopener noreferrer">
					<?php esc_html_e( 'Get a key', 'mvweb-object-map' ); ?>
				</a>
				&nbsp;·&nbsp;
				<?php esc_html_e( 'Free tier ~25,000 map loads per day.', 'mvweb-object-map' ); ?>
			</p>
		</div>
	</div>

	<details class="mvweb-faq mvweb-om-faq--block">
		<summary><?php esc_html_e( 'How to get the key', 'mvweb-object-map' ); ?></summary>
		<div class="mvweb-faq__body">
			<ol>
				<li><?php esc_html_e( 'Open the Developer Dashboard (developer.tech.yandex.ru) and sign in.', 'mvweb-object-map' ); ?></li>
				<li><?php esc_html_e( 'Click "Connect API" and choose the "JavaScript API" package (it draws the map and geocodes the address in the browser). The separate "Geocoder API" package is not needed.', 'mvweb-object-map' ); ?></li>
				<li><?php esc_html_e( 'Open the key, click Edit, and fill in "HTTP Referer restriction" with your site domain (e.g. example.com and *.example.com). The key will not work without it.', 'mvweb-object-map' ); ?></li>
				<li><?php esc_html_e( 'Wait ~15 minutes for activation, then paste the key here.', 'mvweb-object-map' ); ?></li>
			</ol>
			<p><?php esc_html_e( 'Note: the key is bound to the domain via the Referer restriction. On a new domain the map will not work until that domain is added to the key.', 'mvweb-object-map' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Map defaults', 'mvweb-object-map' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_default_center" class="mvweb-form-row__label">
			<?php esc_html_e( 'Default center', 'mvweb-object-map' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<input type="text"
				id="mvweb_om_default_center"
				name="<?php echo esc_attr( $opt ); ?>[default_center]"
				class="mvweb-input"
				placeholder="55.751244, 37.618423"
				value="<?php echo esc_attr( $settings['default_center'] ); ?>">
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Latitude, longitude. Leave empty to auto-fit all markers.', 'mvweb-object-map' ); ?>
			</p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_default_zoom" class="mvweb-form-row__label">
			<?php esc_html_e( 'Default zoom', 'mvweb-object-map' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<input type="number"
				id="mvweb_om_default_zoom"
				name="<?php echo esc_attr( $opt ); ?>[default_zoom]"
				class="mvweb-input"
				min="0" max="21" step="1"
				value="<?php echo esc_attr( (string) $settings['default_zoom'] ); ?>">
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_cluster_enabled" class="mvweb-form-row__label">
			<?php esc_html_e( 'Cluster markers', 'mvweb-object-map' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox"
						id="mvweb_om_cluster_enabled"
						name="<?php echo esc_attr( $opt ); ?>[cluster_enabled]"
						value="1"
						<?php checked( $settings['cluster_enabled'] ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Group nearby markers into clusters', 'mvweb-object-map' ); ?></span>
			</div>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Behavior & data', 'mvweb-object-map' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_modal_enabled" class="mvweb-form-row__label">
			<?php esc_html_e( 'Detail modal', 'mvweb-object-map' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox"
						id="mvweb_om_modal_enabled"
						name="<?php echo esc_attr( $opt ); ?>[modal_enabled]"
						value="1"
						<?php checked( $settings['modal_enabled'] ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Open a full object card in a modal window', 'mvweb-object-map' ); ?></span>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_show_route" class="mvweb-form-row__label">
			<?php esc_html_e( 'Route button', 'mvweb-object-map' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox"
						id="mvweb_om_show_route"
						name="<?php echo esc_attr( $opt ); ?>[show_route]"
						value="1"
						<?php checked( $settings['show_route'] ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Show the "Get directions" button in balloons and the modal', 'mvweb-object-map' ); ?></span>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_om_delete_data" class="mvweb-form-row__label">
			<?php esc_html_e( 'On uninstall', 'mvweb-object-map' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox"
						id="mvweb_om_delete_data"
						name="<?php echo esc_attr( $opt ); ?>[delete_data_on_uninstall]"
						value="1"
						<?php checked( $settings['delete_data_on_uninstall'] ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Delete all objects and settings when the plugin is deleted', 'mvweb-object-map' ); ?></span>
			</div>
		</div>
	</div>
</div>
