<?php
/**
 * Characteristics (specs) schema tab.
 *
 * A repeater that defines the global set of object characteristic fields.
 * Rows are namespaced under `mvweb_om_settings[specs_schema][i][...]`.
 *
 * @package mvweb_om
 * @since   1.0.0
 *
 * @var array $settings Current settings (provided by settings-page.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$opt    = 'mvweb_om_settings';
$schema = isset( $settings['specs_schema'] ) && is_array( $settings['specs_schema'] ) ? $settings['specs_schema'] : array();

$types = array(
	'text'   => __( 'Text / number', 'mvweb-object-map' ),
	'number' => __( 'Number (with unit)', 'mvweb-object-map' ),
	'select' => __( 'Select (list)', 'mvweb-object-map' ),
	'bool'   => __( 'Yes / no', 'mvweb-object-map' ),
	'url'    => __( 'Link', 'mvweb-object-map' ),
);
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Object characteristics', 'mvweb-object-map' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Define the fields available on every object. Each object fills in only the fields it needs.', 'mvweb-object-map' ); ?>
	</p>

	<div class="mvweb-repeater" id="mvweb-om-specs" data-next-index="<?php echo esc_attr( (string) count( $schema ) ); ?>">
		<?php foreach ( $schema as $i => $field ) : ?>
			<?php
			$field        = wp_parse_args(
				$field,
				array(
					'id'              => '',
					'label'           => '',
					'type'            => 'text',
					'unit'            => '',
					'options'         => array(),
					'show_in_balloon' => false,
				)
			);
			$options_text = is_array( $field['options'] ) ? implode( "\n", $field['options'] ) : '';
			?>
			<div class="mvweb-repeater__item" data-index="<?php echo esc_attr( (string) $i ); ?>">
				<input type="hidden"
					name="<?php echo esc_attr( $opt ); ?>[specs_schema][<?php echo esc_attr( (string) $i ); ?>][id]"
					value="<?php echo esc_attr( $field['id'] ); ?>">

				<div class="mvweb-form-row">
					<label class="mvweb-form-row__label"><?php esc_html_e( 'Label', 'mvweb-object-map' ); ?></label>
					<div class="mvweb-form-row__field">
						<input type="text"
							class="mvweb-input"
							name="<?php echo esc_attr( $opt ); ?>[specs_schema][<?php echo esc_attr( (string) $i ); ?>][label]"
							value="<?php echo esc_attr( $field['label'] ); ?>">
					</div>
				</div>

				<div class="mvweb-form-row">
					<label class="mvweb-form-row__label"><?php esc_html_e( 'Type', 'mvweb-object-map' ); ?></label>
					<div class="mvweb-form-row__field">
						<select class="mvweb-select mvweb-om-spec-type"
							name="<?php echo esc_attr( $opt ); ?>[specs_schema][<?php echo esc_attr( (string) $i ); ?>][type]">
							<?php foreach ( $types as $type_key => $type_label ) : ?>
								<option value="<?php echo esc_attr( $type_key ); ?>" <?php selected( $field['type'], $type_key ); ?>>
									<?php echo esc_html( $type_label ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>

				<div class="mvweb-form-row mvweb-om-spec-unit" <?php echo 'number' === $field['type'] ? '' : 'style="display:none"'; ?>>
					<label class="mvweb-form-row__label"><?php esc_html_e( 'Unit', 'mvweb-object-map' ); ?></label>
					<div class="mvweb-form-row__field">
						<input type="text"
							class="mvweb-input"
							placeholder="m², ₽, year…"
							name="<?php echo esc_attr( $opt ); ?>[specs_schema][<?php echo esc_attr( (string) $i ); ?>][unit]"
							value="<?php echo esc_attr( $field['unit'] ); ?>">
					</div>
				</div>

				<div class="mvweb-form-row mvweb-om-spec-options" <?php echo 'select' === $field['type'] ? '' : 'style="display:none"'; ?>>
					<label class="mvweb-form-row__label"><?php esc_html_e( 'Options', 'mvweb-object-map' ); ?></label>
					<div class="mvweb-form-row__field">
						<textarea class="mvweb-textarea" rows="3"
							placeholder="<?php esc_attr_e( 'One option per line', 'mvweb-object-map' ); ?>"
							name="<?php echo esc_attr( $opt ); ?>[specs_schema][<?php echo esc_attr( (string) $i ); ?>][options]"><?php echo esc_textarea( $options_text ); ?></textarea>
					</div>
				</div>

				<div class="mvweb-form-row">
					<label class="mvweb-form-row__label"><?php esc_html_e( 'Show in balloon', 'mvweb-object-map' ); ?></label>
					<div class="mvweb-form-row__field">
						<div class="mvweb-toggle-row">
							<label class="mvweb-toggle">
								<input type="checkbox" value="1"
									name="<?php echo esc_attr( $opt ); ?>[specs_schema][<?php echo esc_attr( (string) $i ); ?>][show_in_balloon]"
									<?php checked( ! empty( $field['show_in_balloon'] ) ); ?>>
								<span class="mvweb-toggle__slider"></span>
							</label>
							<span><?php esc_html_e( 'Display this field in the map balloon', 'mvweb-object-map' ); ?></span>
						</div>
					</div>
				</div>

				<div class="mvweb-repeater__actions">
					<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-btn--danger mvweb-om-spec-remove">
						<?php esc_html_e( 'Remove', 'mvweb-object-map' ); ?>
					</button>
				</div>
			</div>
		<?php endforeach; ?>
	</div>

	<button type="button" class="mvweb-btn mvweb-om-spec-add">
		<?php esc_html_e( 'Add field', 'mvweb-object-map' ); ?>
	</button>

	<template id="mvweb-om-spec-template">
		<div class="mvweb-repeater__item" data-index="__INDEX__">
			<input type="hidden" name="<?php echo esc_attr( $opt ); ?>[specs_schema][__INDEX__][id]" value="">

			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label"><?php esc_html_e( 'Label', 'mvweb-object-map' ); ?></label>
				<div class="mvweb-form-row__field">
					<input type="text" class="mvweb-input" name="<?php echo esc_attr( $opt ); ?>[specs_schema][__INDEX__][label]" value="">
				</div>
			</div>

			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label"><?php esc_html_e( 'Type', 'mvweb-object-map' ); ?></label>
				<div class="mvweb-form-row__field">
					<select class="mvweb-select mvweb-om-spec-type" name="<?php echo esc_attr( $opt ); ?>[specs_schema][__INDEX__][type]">
						<?php foreach ( $types as $type_key => $type_label ) : ?>
							<option value="<?php echo esc_attr( $type_key ); ?>"><?php echo esc_html( $type_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>

			<div class="mvweb-form-row mvweb-om-spec-unit" style="display:none">
				<label class="mvweb-form-row__label"><?php esc_html_e( 'Unit', 'mvweb-object-map' ); ?></label>
				<div class="mvweb-form-row__field">
					<input type="text" class="mvweb-input" placeholder="m², ₽, year…" name="<?php echo esc_attr( $opt ); ?>[specs_schema][__INDEX__][unit]" value="">
				</div>
			</div>

			<div class="mvweb-form-row mvweb-om-spec-options" style="display:none">
				<label class="mvweb-form-row__label"><?php esc_html_e( 'Options', 'mvweb-object-map' ); ?></label>
				<div class="mvweb-form-row__field">
					<textarea class="mvweb-textarea" rows="3" placeholder="<?php esc_attr_e( 'One option per line', 'mvweb-object-map' ); ?>" name="<?php echo esc_attr( $opt ); ?>[specs_schema][__INDEX__][options]"></textarea>
				</div>
			</div>

			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label"><?php esc_html_e( 'Show in balloon', 'mvweb-object-map' ); ?></label>
				<div class="mvweb-form-row__field">
					<div class="mvweb-toggle-row">
						<label class="mvweb-toggle">
							<input type="checkbox" value="1" name="<?php echo esc_attr( $opt ); ?>[specs_schema][__INDEX__][show_in_balloon]">
							<span class="mvweb-toggle__slider"></span>
						</label>
						<span><?php esc_html_e( 'Display this field in the map balloon', 'mvweb-object-map' ); ?></span>
					</div>
				</div>
			</div>

			<div class="mvweb-repeater__actions">
				<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-btn--danger mvweb-om-spec-remove">
					<?php esc_html_e( 'Remove', 'mvweb-object-map' ); ?>
				</button>
			</div>
		</div>
	</template>
</div>
