/**
 * Object editor JavaScript for MVweb Object Map.
 *
 * Mini map + geocoder (Yandex JS API 3.0), WP media gallery/icon pickers and
 * the links repeater.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

(function () {
	'use strict';

	var cfg = window.mvwebOmObject || {};
	var i18n = cfg.i18n || {};

	document.addEventListener('DOMContentLoaded', function () {
		initMap();
		initGallery();
		initIcon();
		initLinks();
	});

	/**
	 * Initialize the mini map and geocoder when the API is available.
	 */
	function initMap() {
		var el = document.getElementById('mvweb-om-map');
		if (!el) {
			return;
		}

		if (!cfg.hasKey || typeof ymaps3 === 'undefined') {
			el.classList.add('mvweb-om-map--disabled');
			el.textContent = i18n.noKey || '';
			return;
		}

		var latInput = document.getElementById('mvweb_om_lat');
		var lngInput = document.getElementById('mvweb_om_lng');
		var addressInput = document.getElementById('mvweb_om_address');

		ymaps3.ready.then(function () {
			var YMap = ymaps3.YMap;
			var YMapDefaultSchemeLayer = ymaps3.YMapDefaultSchemeLayer;
			var YMapDefaultFeaturesLayer = ymaps3.YMapDefaultFeaturesLayer;
			var YMapMarker = ymaps3.YMapMarker;
			var YMapListener = ymaps3.YMapListener;

			var startLat = parseFloat(el.getAttribute('data-lat'));
			var startLng = parseFloat(el.getAttribute('data-lng'));
			var hasStart = !isNaN(startLat) && !isNaN(startLng);
			var center = hasStart ? [startLng, startLat] : [37.617635, 55.755814];

			var map = new YMap(el, { location: { center: center, zoom: hasStart ? 15 : 9 } });
			map.addChild(new YMapDefaultSchemeLayer());
			map.addChild(new YMapDefaultFeaturesLayer());

			var markerEl = document.createElement('div');
			markerEl.className = 'mvweb-om-marker';

			var marker = new YMapMarker(
				{ coordinates: center, draggable: true, onDragEnd: function (coords) { writeCoords(coords); } },
				markerEl
			);
			map.addChild(marker);

			map.addChild(new YMapListener({
				layer: 'any',
				onClick: function (object, event) {
					if (event && event.coordinates) {
						marker.update({ coordinates: event.coordinates });
						writeCoords(event.coordinates);
					}
				}
			}));

			function writeCoords(coords) {
				if (!coords || coords.length < 2) {
					return;
				}
				lngInput.value = round(coords[0]);
				latInput.value = round(coords[1]);
			}

			function moveTo(coords) {
				marker.update({ coordinates: coords });
				map.update({ location: { center: coords, zoom: 16, duration: 300 } });
				writeCoords(coords);
			}

			var geocodeBtn = document.querySelector('.mvweb-om-geocode');
			if (geocodeBtn) {
				geocodeBtn.addEventListener('click', function () {
					var query = (addressInput.value || '').trim();
					if (!query) {
						return;
					}
					geocodeBtn.disabled = true;
					ymaps3.search({ text: query }).then(function (result) {
						geocodeBtn.disabled = false;
						if (result && result.length && result[0].geometry) {
							moveTo(result[0].geometry.coordinates);
						} else {
							window.alert(i18n.notFound || '');
						}
					}).catch(function () {
						geocodeBtn.disabled = false;
						window.alert(i18n.searchError || '');
					});
				});
			}

			syncFromInputs(marker, map, latInput, lngInput);
		});
	}

	/**
	 * Move the marker when lat/lng inputs are edited manually.
	 *
	 * @param {Object} marker   Map marker.
	 * @param {Object} map      Map instance.
	 * @param {HTMLElement} latInput Latitude input.
	 * @param {HTMLElement} lngInput Longitude input.
	 */
	function syncFromInputs(marker, map, latInput, lngInput) {
		function apply() {
			var lat = parseFloat(latInput.value);
			var lng = parseFloat(lngInput.value);
			if (isNaN(lat) || isNaN(lng)) {
				return;
			}
			var coords = [lng, lat];
			marker.update({ coordinates: coords });
			map.update({ location: { center: coords, zoom: 15, duration: 300 } });
		}
		latInput.addEventListener('change', apply);
		lngInput.addEventListener('change', apply);
	}

	/**
	 * Round a coordinate to 6 decimals.
	 *
	 * @param {number} n Coordinate.
	 * @return {string}
	 */
	function round(n) {
		return (Math.round(n * 1e6) / 1e6).toString();
	}

	/**
	 * Gallery picker backed by the WP media library.
	 */
	function initGallery() {
		var addBtn = document.querySelector('.mvweb-om-gallery-add');
		var wrap = document.getElementById('mvweb-om-gallery');
		var field = document.getElementById('mvweb_om_gallery');
		if (!addBtn || !wrap || !field) {
			return;
		}

		var frame = null;

		addBtn.addEventListener('click', function (e) {
			e.preventDefault();
			if (!frame) {
				frame = wp.media({
					title: i18n.selectImage || '',
					button: { text: i18n.useImage || '' },
					library: { type: 'image' },
					multiple: true
				});
				frame.on('select', function () {
					frame.state().get('selection').each(function (att) {
						addItem(att.toJSON());
					});
					syncField();
				});
			}
			frame.open();
		});

		wrap.addEventListener('click', function (e) {
			var btn = e.target.closest('.mvweb-om-gallery__remove');
			if (!btn) {
				return;
			}
			var item = btn.closest('.mvweb-om-gallery__item');
			if (item) {
				item.parentNode.removeChild(item);
				syncField();
			}
		});

		function addItem(att) {
			if (wrap.querySelector('[data-id="' + att.id + '"]')) {
				return;
			}
			var url = (att.sizes && att.sizes.thumbnail) ? att.sizes.thumbnail.url : att.url;
			if (!url) {
				return;
			}
			var item = document.createElement('span');
			item.className = 'mvweb-om-gallery__item';
			item.setAttribute('data-id', String(att.id));

			var img = document.createElement('img');
			img.src = url;
			img.alt = '';

			var remove = document.createElement('button');
			remove.type = 'button';
			remove.className = 'mvweb-om-gallery__remove';
			remove.textContent = '×';

			item.appendChild(img);
			item.appendChild(remove);
			wrap.appendChild(item);
		}

		function syncField() {
			var ids = [];
			wrap.querySelectorAll('.mvweb-om-gallery__item').forEach(function (item) {
				var id = parseInt(item.getAttribute('data-id'), 10);
				if (!isNaN(id)) {
					ids.push(id);
				}
			});
			field.value = JSON.stringify(ids);
		}
	}

	/**
	 * Custom marker image picker backed by the WP media library.
	 */
	function initIcon() {
		var selectBtn = document.querySelector('.mvweb-om-icon-select');
		var clearBtn = document.querySelector('.mvweb-om-icon-clear');
		var preview = document.getElementById('mvweb-om-icon-preview');
		var field = document.getElementById('mvweb_om_icon_image');
		if (!selectBtn || !preview || !field) {
			return;
		}

		var frame = null;

		selectBtn.addEventListener('click', function (e) {
			e.preventDefault();
			if (!frame) {
				frame = wp.media({
					title: i18n.selectImage || '',
					button: { text: i18n.useImage || '' },
					library: { type: 'image' },
					multiple: false
				});
				frame.on('select', function () {
					var att = frame.state().get('selection').first().toJSON();
					var url = (att.sizes && att.sizes.thumbnail) ? att.sizes.thumbnail.url : att.url;
					field.value = String(att.id);
					preview.textContent = '';
					var img = document.createElement('img');
					img.src = url;
					img.alt = '';
					preview.appendChild(img);
					if (clearBtn) {
						clearBtn.classList.remove('mvweb-om-hidden');
					}
				});
			}
			frame.open();
		});

		if (clearBtn) {
			clearBtn.addEventListener('click', function () {
				field.value = '0';
				preview.textContent = '';
				clearBtn.classList.add('mvweb-om-hidden');
			});
		}
	}

	/**
	 * Links repeater (label + url rows).
	 */
	function initLinks() {
		var wrap = document.getElementById('mvweb-om-links');
		var addBtn = document.querySelector('.mvweb-om-link-add');
		var template = document.getElementById('mvweb-om-link-template');
		if (!wrap || !addBtn || !template) {
			return;
		}

		addBtn.addEventListener('click', function () {
			var index = parseInt(wrap.getAttribute('data-next-index'), 10) || 0;
			var fragment = template.content.cloneNode(true);
			fragment.querySelectorAll('[name]').forEach(function (el) {
				el.setAttribute('name', el.getAttribute('name').split('__INDEX__').join(String(index)));
			});
			var row = fragment.querySelector('[data-index]');
			if (row) {
				row.setAttribute('data-index', String(index));
			}
			wrap.appendChild(fragment);
			wrap.setAttribute('data-next-index', String(index + 1));
		});

		wrap.addEventListener('click', function (e) {
			var btn = e.target.closest('.mvweb-om-link-remove');
			if (!btn) {
				return;
			}
			var row = btn.closest('.mvweb-om-link-row');
			if (row) {
				row.parentNode.removeChild(row);
			}
		});
	}
})();
