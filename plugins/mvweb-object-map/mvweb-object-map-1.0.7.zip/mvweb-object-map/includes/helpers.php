<?php
/**
 * Helper functions for MVweb Object Map.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sanitize a coordinate value within a range, kept as a string.
 *
 * A string preserves the exact entered precision (a float cast can drift).
 *
 * @since 1.0.0
 * @param mixed $value Raw coordinate.
 * @param float $min   Lower bound (inclusive).
 * @param float $max   Upper bound (inclusive).
 * @return string
 */
function mvweb_om_sanitize_coordinate( $value, $min, $max ) {
	$value = is_scalar( $value ) ? trim( (string) $value ) : '';
	if ( '' === $value || ! preg_match( '/^-?\d{1,3}(\.\d+)?$/', $value ) ) {
		return '';
	}
	$float = (float) $value;
	return ( $float >= $min && $float <= $max ) ? $value : '';
}

/**
 * Sanitize a latitude (-90..90).
 *
 * @since 1.0.0
 * @param mixed $value Raw latitude.
 * @return string
 */
function mvweb_om_sanitize_lat( $value ) {
	return mvweb_om_sanitize_coordinate( $value, -90.0, 90.0 );
}

/**
 * Sanitize a longitude (-180..180).
 *
 * @since 1.0.0
 * @param mixed $value Raw longitude.
 * @return string
 */
function mvweb_om_sanitize_lng( $value ) {
	return mvweb_om_sanitize_coordinate( $value, -180.0, 180.0 );
}

/**
 * Sanitize a URL for HTML output, allowing only http/https schemes.
 *
 * Unlike esc_url_raw(), this rejects javascript: and data: URIs so stored
 * values are safe to place into href attributes (still escape on output).
 *
 * @since 1.0.0
 * @param mixed $value Raw URL.
 * @return string
 */
function mvweb_om_sanitize_url( $value ) {
	$url = esc_url_raw( is_scalar( $value ) ? (string) $value : '' );
	if ( '' === $url ) {
		return '';
	}
	$scheme = wp_parse_url( $url, PHP_URL_SCHEME );
	if ( null !== $scheme && ! in_array( $scheme, array( 'http', 'https' ), true ) ) {
		return '';
	}
	return $url;
}

/**
 * Sanitize the gallery meta — a JSON array of attachment IDs.
 *
 * @since 1.0.0
 * @param mixed $value Raw JSON string or array.
 * @return string JSON-encoded array of positive integers.
 */
function mvweb_om_sanitize_gallery_json( $value ) {
	$items = mvweb_om_decode_array( $value );
	$ids   = array();
	foreach ( $items as $item ) {
		$id = absint( is_array( $item ) && isset( $item['id'] ) ? $item['id'] : $item );
		if ( $id > 0 ) {
			$ids[] = $id;
		}
	}
	$ids = array_values( array_unique( $ids ) );
	return wp_json_encode( $ids, JSON_UNESCAPED_UNICODE );
}

/**
 * Sanitize the links meta — a JSON array of { label, url } objects.
 *
 * @since 1.0.0
 * @param mixed $value Raw JSON string or array.
 * @return string JSON-encoded array.
 */
function mvweb_om_sanitize_links_json( $value ) {
	$items = mvweb_om_decode_array( $value );
	$out   = array();
	foreach ( $items as $item ) {
		if ( ! is_array( $item ) ) {
			continue;
		}
		$label = isset( $item['label'] ) ? sanitize_text_field( (string) $item['label'] ) : '';
		$url   = isset( $item['url'] ) ? mvweb_om_sanitize_url( (string) $item['url'] ) : '';
		if ( '' === $url ) {
			continue;
		}
		$out[] = array(
			'label' => $label,
			'url'   => $url,
		);
	}
	return wp_json_encode( $out, JSON_UNESCAPED_UNICODE );
}

/**
 * Sanitize the specs meta — a JSON object of { field_id: value }.
 *
 * Values are kept as plain text; the field schema (types/units) lives in the
 * plugin settings and is applied on output. Unknown field IDs are dropped when
 * a non-empty whitelist of allowed IDs is provided.
 *
 * @since 1.0.0
 * @param mixed $value   Raw JSON string or associative array.
 * @param array $allowed Optional whitelist of allowed field IDs.
 * @return string JSON-encoded object.
 */
function mvweb_om_sanitize_specs_json( $value, $allowed = array() ) {
	$items = mvweb_om_decode_array( $value );
	$out   = array();
	foreach ( $items as $field_id => $raw_value ) {
		$field_id = sanitize_key( (string) $field_id );
		if ( '' === $field_id ) {
			continue;
		}
		if ( ! empty( $allowed ) && ! in_array( $field_id, $allowed, true ) ) {
			continue;
		}
		$raw_value        = is_scalar( $raw_value ) ? (string) $raw_value : '';
		$out[ $field_id ] = sanitize_text_field( mb_substr( $raw_value, 0, 500 ) );
	}
	return wp_json_encode( $out, JSON_UNESCAPED_UNICODE );
}

/**
 * Decode a meta value into an array (accepts a JSON string or an array).
 *
 * @since 1.0.0
 * @param mixed $value Raw value.
 * @return array
 */
function mvweb_om_decode_array( $value ) {
	if ( is_array( $value ) ) {
		return $value;
	}
	if ( is_string( $value ) && '' !== $value ) {
		$decoded = json_decode( $value, true );
		if ( is_array( $decoded ) ) {
			return $decoded;
		}
	}
	return array();
}
