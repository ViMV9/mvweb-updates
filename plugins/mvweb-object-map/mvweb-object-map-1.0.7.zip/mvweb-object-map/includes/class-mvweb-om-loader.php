<?php
/**
 * Class loader for MVweb Object Map.
 *
 * Loads and initializes the plugin components (CPT, settings, admin, REST,
 * shortcode). Each component is wired only when its file exists so the plugin
 * stays bootable while features are added incrementally.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin component loader.
 *
 * @since 1.0.0
 */
final class MVweb_OM_Loader {

	/**
	 * Require and initialize plugin components.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function load() {
		$includes = MVWEB_OM_PATH . 'includes/';
		$admin    = MVWEB_OM_PATH . 'admin/';

		self::boot( $includes . 'class-mvweb-om-cpt.php', 'MVweb_OM_CPT' );
		self::boot( $includes . 'class-mvweb-om-settings.php', 'MVweb_OM_Settings' );
		self::boot( $includes . 'class-mvweb-om-rest.php', 'MVweb_OM_REST' );
		self::boot( $includes . 'class-mvweb-om-shortcode.php', 'MVweb_OM_Shortcode' );

		if ( is_admin() ) {
			self::boot( $admin . 'class-mvweb-om-admin.php', 'MVweb_OM_Admin' );
			self::boot( $admin . 'class-mvweb-om-metabox.php', 'MVweb_OM_Metabox' );
		}
	}

	/**
	 * Require a component file and call its static init() when present.
	 *
	 * @since 1.0.0
	 * @param string $file       Absolute path to the component class file.
	 * @param string $class_name Fully qualified class name expected in the file.
	 * @return void
	 */
	private static function boot( $file, $class_name ) {
		if ( ! file_exists( $file ) ) {
			return;
		}
		require_once $file;
		if ( class_exists( $class_name ) && method_exists( $class_name, 'init' ) ) {
			$class_name::init();
		}
	}
}
