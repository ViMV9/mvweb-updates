<?php
/**
 * Plugin settings: defaults, get, save and per-field sanitization.
 *
 * All settings live in a single wp_option named `mvweb_om_settings`. This class
 * is the single source of truth for the schema, including the user-defined
 * specs schema (the set of object characteristic fields).
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings store and sanitizer.
 *
 * @since 1.0.0
 */
final class MVweb_OM_Settings {

	/**
	 * Option name in wp_options.
	 */
	const OPTION_NAME = 'mvweb_om_settings';

	/**
	 * Settings group used by the Settings API.
	 */
	const OPTION_GROUP = 'mvweb_om_settings_group';

	/**
	 * Allowed card photo aspect ratios (CSS aspect-ratio values).
	 *
	 * @var array
	 */
	const ALLOWED_PHOTO_RATIOS = array( '1 / 1', '4 / 3', '3 / 2', '16 / 9', '3 / 4', '2 / 3', '9 / 16' );

	/**
	 * Allowed spec field types.
	 *
	 * @var array
	 */
	const ALLOWED_SPEC_TYPES = array( 'text', 'number', 'select', 'bool', 'url' );

	/**
	 * Wire the Settings API registration.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
	}

	/**
	 * Default values for every setting.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function defaults() {
		return array(
			'api_key'                  => '',
			'default_center'           => '',
			'default_zoom'             => 10,
			'cluster_enabled'          => true,
			'modal_enabled'            => false,
			'show_route'               => true,
			'accent_color'             => '#793ea4',
			'card_bg'                  => '#ffffff',
			'card_border'              => '#e2e8f0',
			'card_title_color'         => '',
			'card_text_color'          => '#64748b',
			'card_hover_border'        => '',
			'card_show_photo'          => true,
			'card_show_address'        => true,
			'card_show_excerpt'        => false,
			'card_radius'              => 8,
			'card_border_width'        => 1,
			'card_density'             => 'comfortable',
			'card_shadow'              => false,
			'card_photo_size'          => 64,
			'card_photo_pos'           => 'left',
			'card_photo_ratio'         => '1 / 1',
			'specs_schema'             => array(),
			'delete_data_on_uninstall' => false,
		);
	}

	/**
	 * Allowed card density modes.
	 *
	 * @var array
	 */
	const ALLOWED_DENSITY = array( 'comfortable', 'compact' );

	/**
	 * Allowed card photo positions.
	 *
	 * @var array
	 */
	const ALLOWED_PHOTO_POS = array( 'left', 'top' );

	/**
	 * Get all settings (or one key) merged with defaults.
	 *
	 * @since 1.0.0
	 * @param string|null $key Optional single key.
	 * @return mixed
	 */
	public static function get( $key = null ) {
		$saved  = get_option( self::OPTION_NAME, array() );
		$merged = array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );

		if ( null === $key ) {
			return $merged;
		}
		return isset( $merged[ $key ] ) ? $merged[ $key ] : null;
	}

	/**
	 * Save the full settings array.
	 *
	 * @since 1.0.0
	 * @param array $settings Settings array.
	 * @return bool
	 */
	public static function save( array $settings ) {
		return update_option( self::OPTION_NAME, $settings );
	}

	/**
	 * Register the option with the Settings API.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register() {
		register_setting(
			self::OPTION_GROUP,
			self::OPTION_NAME,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);
	}

	/**
	 * Sanitize callback for `register_setting`.
	 *
	 * @since 1.0.0
	 * @param mixed $input Raw input.
	 * @return array
	 */
	public static function sanitize( $input ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			add_settings_error(
				'mvweb_om_messages',
				'mvweb_om_forbidden',
				__( 'You do not have permission to change these settings.', 'mvweb-object-map' ),
				'error'
			);
			return self::get();
		}

		$input = is_array( $input ) ? $input : array();
		$out   = self::get();

		$out['api_key'] = isset( $input['api_key'] ) ? sanitize_text_field( (string) $input['api_key'] ) : '';

		$out['default_center'] = isset( $input['default_center'] ) ? self::sanitize_center( (string) $input['default_center'] ) : '';

		if ( isset( $input['default_zoom'] ) ) {
			$out['default_zoom'] = max( 0, min( 21, absint( $input['default_zoom'] ) ) );
		}

		$out['cluster_enabled'] = ! empty( $input['cluster_enabled'] );
		$out['modal_enabled']   = ! empty( $input['modal_enabled'] );
		$out['show_route']      = ! empty( $input['show_route'] );

		if ( isset( $input['accent_color'] ) ) {
			$defaults            = self::defaults();
			$color               = sanitize_hex_color( (string) $input['accent_color'] );
			$out['accent_color'] = $color ? $color : $defaults['accent_color'];
		}

		// List card appearance.
		$out['card_bg']           = self::sanitize_color( $input, 'card_bg', true );
		$out['card_border']       = self::sanitize_color( $input, 'card_border', true );
		$out['card_title_color']  = self::sanitize_color( $input, 'card_title_color', false );
		$out['card_text_color']   = self::sanitize_color( $input, 'card_text_color', true );
		$out['card_hover_border'] = self::sanitize_color( $input, 'card_hover_border', false );
		$out['card_show_photo']   = ! empty( $input['card_show_photo'] );
		$out['card_show_address'] = ! empty( $input['card_show_address'] );
		$out['card_show_excerpt'] = ! empty( $input['card_show_excerpt'] );

		if ( isset( $input['card_radius'] ) ) {
			$out['card_radius'] = max( 0, min( 40, absint( $input['card_radius'] ) ) );
		}
		if ( isset( $input['card_border_width'] ) ) {
			$out['card_border_width'] = max( 0, min( 8, absint( $input['card_border_width'] ) ) );
		}
		if ( isset( $input['card_photo_size'] ) ) {
			$out['card_photo_size'] = max( 32, min( 160, absint( $input['card_photo_size'] ) ) );
		}

		$out['card_density'] = ( isset( $input['card_density'] ) && in_array( $input['card_density'], self::ALLOWED_DENSITY, true ) )
			? $input['card_density']
			: 'comfortable';

		$out['card_photo_pos'] = ( isset( $input['card_photo_pos'] ) && in_array( $input['card_photo_pos'], self::ALLOWED_PHOTO_POS, true ) )
			? $input['card_photo_pos']
			: 'left';

		$out['card_photo_ratio'] = ( isset( $input['card_photo_ratio'] ) && in_array( $input['card_photo_ratio'], self::ALLOWED_PHOTO_RATIOS, true ) )
			? $input['card_photo_ratio']
			: '1 / 1';

		$out['card_shadow'] = ! empty( $input['card_shadow'] );

		$out['delete_data_on_uninstall'] = ! empty( $input['delete_data_on_uninstall'] );

		$out['specs_schema'] = self::sanitize_specs_schema( isset( $input['specs_schema'] ) ? $input['specs_schema'] : array() );

		return $out;
	}

	/**
	 * Sanitize a hex color field.
	 *
	 * @since 1.0.0
	 * @param array  $input     Raw input array.
	 * @param string $key       Field key.
	 * @param bool   $use_default Whether to fall back to the default (true) or
	 *                            to an empty string (false) when invalid/blank.
	 * @return string
	 */
	private static function sanitize_color( $input, $key, $use_default ) {
		$color = isset( $input[ $key ] ) ? sanitize_hex_color( (string) $input[ $key ] ) : '';
		if ( $color ) {
			return $color;
		}
		if ( $use_default ) {
			$defaults = self::defaults();
			return $defaults[ $key ];
		}
		return '';
	}

	/**
	 * Sanitize a "lat,lng" center string, or empty.
	 *
	 * @since 1.0.0
	 * @param string $value Raw center.
	 * @return string
	 */
	private static function sanitize_center( $value ) {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}
		$parts = array_map( 'trim', explode( ',', $value ) );
		if ( 2 !== count( $parts ) ) {
			return '';
		}
		$lat = mvweb_om_sanitize_lat( $parts[0] );
		$lng = mvweb_om_sanitize_lng( $parts[1] );
		if ( '' === $lat || '' === $lng ) {
			return '';
		}
		return $lat . ',' . $lng;
	}

	/**
	 * Sanitize the user-defined specs schema (repeater of field definitions).
	 *
	 * Each field: { id, label, type, unit, options[], show_in_balloon }.
	 *
	 * @since 1.0.0
	 * @param mixed $raw Raw schema (array of rows from the repeater).
	 * @return array
	 */
	private static function sanitize_specs_schema( $raw ) {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$out  = array();
		$used = array();

		foreach ( $raw as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$label = isset( $row['label'] ) ? sanitize_text_field( (string) $row['label'] ) : '';
			if ( '' === $label ) {
				continue;
			}

			$id = isset( $row['id'] ) ? sanitize_key( (string) $row['id'] ) : '';
			if ( '' === $id ) {
				$id = sanitize_key( sanitize_title( $label ) );
			}
			if ( '' === $id ) {
				continue;
			}

			$base    = $id;
			$counter = 2;
			while ( in_array( $id, $used, true ) ) {
				$id = $base . '_' . $counter;
				++$counter;
			}
			$used[] = $id;

			$type = isset( $row['type'] ) && in_array( $row['type'], self::ALLOWED_SPEC_TYPES, true )
				? $row['type']
				: 'text';

			$unit = isset( $row['unit'] ) ? sanitize_text_field( (string) $row['unit'] ) : '';

			$options = array();
			if ( 'select' === $type && isset( $row['options'] ) ) {
				$opts = is_array( $row['options'] ) ? $row['options'] : preg_split( '/\r\n|\r|\n/', (string) $row['options'] );
				foreach ( (array) $opts as $opt ) {
					$opt = sanitize_text_field( (string) $opt );
					if ( '' !== $opt ) {
						$options[] = $opt;
					}
				}
				$options = array_values( array_unique( $options ) );
			}

			$out[] = array(
				'id'              => $id,
				'label'           => $label,
				'type'            => $type,
				'unit'            => ( 'number' === $type ) ? $unit : '',
				'options'         => $options,
				'show_in_balloon' => ! empty( $row['show_in_balloon'] ),
			);
		}

		return $out;
	}
}
