<?php
/**
 * Custom Post Type, taxonomy and meta for MVweb Object Map.
 *
 * Registers the non-public `mvweb_object` post type (managed in admin only —
 * no front-end pages, archives or URLs), the `mvweb_object_category` taxonomy,
 * and all object meta fields with sanitize callbacks.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CPT / taxonomy / meta registration.
 *
 * @since 1.0.0
 */
final class MVweb_OM_CPT {

	/**
	 * Post type key.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	const POST_TYPE = 'mvweb_object';

	/**
	 * Taxonomy key.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	const TAXONOMY = 'mvweb_object_category';

	/**
	 * Term meta key for the category marker color.
	 *
	 * @since 1.0.5
	 * @var string
	 */
	const TERM_COLOR_META = 'mvweb_om_color';

	/**
	 * Wire WordPress hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'init', array( __CLASS__, 'register_taxonomy' ) );
		add_action( 'init', array( __CLASS__, 'register_meta' ) );

		add_action( self::TAXONOMY . '_add_form_fields', array( __CLASS__, 'add_color_field' ) );
		add_action( self::TAXONOMY . '_edit_form_fields', array( __CLASS__, 'edit_color_field' ) );
		add_action( 'created_' . self::TAXONOMY, array( __CLASS__, 'save_color_field' ) );
		add_action( 'edited_' . self::TAXONOMY, array( __CLASS__, 'save_color_field' ) );
		add_filter( 'manage_edit-' . self::TAXONOMY . '_columns', array( __CLASS__, 'add_color_column' ) );
		add_filter( 'manage_' . self::TAXONOMY . '_custom_column', array( __CLASS__, 'render_color_column' ), 10, 3 );
	}

	/**
	 * Register the non-public `mvweb_object` post type.
	 *
	 * Non-public by design: objects exist only in the admin as data for the
	 * map. No single pages, archives, URLs, search or sitemap presence.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_post_type() {
		$labels = array(
			'name'               => __( 'Map Objects', 'mvweb-object-map' ),
			'singular_name'      => __( 'Map Object', 'mvweb-object-map' ),
			'menu_name'          => _x( 'Map Objects', 'admin menu title', 'mvweb-object-map' ),
			'add_new'            => __( 'Add New', 'mvweb-object-map' ),
			'add_new_item'       => __( 'Add New Object', 'mvweb-object-map' ),
			'edit_item'          => __( 'Edit Object', 'mvweb-object-map' ),
			'new_item'           => __( 'New Object', 'mvweb-object-map' ),
			'view_item'          => __( 'View Object', 'mvweb-object-map' ),
			'search_items'       => __( 'Search Objects', 'mvweb-object-map' ),
			'not_found'          => __( 'No objects found.', 'mvweb-object-map' ),
			'not_found_in_trash' => __( 'No objects found in Trash.', 'mvweb-object-map' ),
			'all_items'          => __( 'All Objects', 'mvweb-object-map' ),
		);

		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_rest'        => false,
			'publicly_queryable'  => false,
			'exclude_from_search' => true,
			'has_archive'         => false,
			'rewrite'             => false,
			'query_var'           => false,
			'menu_position'       => 25,
			'menu_icon'           => 'dashicons-location-alt',
			'supports'            => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
			'capability_type'     => 'post',
			'map_meta_cap'        => true,
		);

		register_post_type( self::POST_TYPE, $args );
	}

	/**
	 * Register the hierarchical `mvweb_object_category` taxonomy.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_taxonomy() {
		$labels = array(
			'name'              => __( 'Object Categories', 'mvweb-object-map' ),
			'singular_name'     => __( 'Object Category', 'mvweb-object-map' ),
			'search_items'      => __( 'Search Categories', 'mvweb-object-map' ),
			'all_items'         => __( 'All Categories', 'mvweb-object-map' ),
			'parent_item'       => __( 'Parent Category', 'mvweb-object-map' ),
			'parent_item_colon' => __( 'Parent Category:', 'mvweb-object-map' ),
			'edit_item'         => __( 'Edit Category', 'mvweb-object-map' ),
			'update_item'       => __( 'Update Category', 'mvweb-object-map' ),
			'add_new_item'      => __( 'Add New Category', 'mvweb-object-map' ),
			'new_item_name'     => __( 'New Category Name', 'mvweb-object-map' ),
			'menu_name'         => __( 'Categories', 'mvweb-object-map' ),
		);

		$args = array(
			'labels'             => $labels,
			'public'             => false,
			'publicly_queryable' => false,
			'hierarchical'       => true,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'show_in_rest'       => false,
			'rewrite'            => false,
			'query_var'          => false,
		);

		register_taxonomy( self::TAXONOMY, self::POST_TYPE, $args );
	}

	/**
	 * Register object meta fields with sanitize callbacks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_meta() {

		$simple = array(
			'_mvweb_om_lat'         => 'mvweb_om_sanitize_lat',
			'_mvweb_om_lng'         => 'mvweb_om_sanitize_lng',
			'_mvweb_om_address'     => 'sanitize_text_field',
			'_mvweb_om_phone'       => 'sanitize_text_field',
			'_mvweb_om_hours'       => 'sanitize_text_field',
			'_mvweb_om_icon_preset' => 'sanitize_key',
		);
		foreach ( $simple as $key => $cb ) {
			register_post_meta(
				self::POST_TYPE,
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'sanitize_callback' => $cb,
					'show_in_rest'      => false,
					'auth_callback'     => array( __CLASS__, 'meta_auth' ),
				)
			);
		}

		register_post_meta(
			self::POST_TYPE,
			'_mvweb_om_icon_image',
			array(
				'type'              => 'integer',
				'single'            => true,
				'default'           => 0,
				'sanitize_callback' => 'absint',
				'show_in_rest'      => false,
				'auth_callback'     => array( __CLASS__, 'meta_auth' ),
			)
		);

		register_post_meta(
			self::POST_TYPE,
			'_mvweb_om_more_url',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'mvweb_om_sanitize_url',
				'show_in_rest'      => false,
				'auth_callback'     => array( __CLASS__, 'meta_auth' ),
			)
		);

		register_term_meta(
			self::TAXONOMY,
			self::TERM_COLOR_META,
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'sanitize_hex_color',
				'show_in_rest'      => false,
			)
		);

		$json = array(
			'_mvweb_om_gallery' => 'mvweb_om_sanitize_gallery_json',
			'_mvweb_om_links'   => 'mvweb_om_sanitize_links_json',
			// Wrapped: WP passes $meta_key as the 2nd argument, which would land in $allowed.
			'_mvweb_om_specs'   => static function ( $value ) {
				return mvweb_om_sanitize_specs_json( $value );
			},
		);
		foreach ( $json as $key => $cb ) {
			register_post_meta(
				self::POST_TYPE,
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '[]',
					'sanitize_callback' => $cb,
					'show_in_rest'      => false,
					'auth_callback'     => array( __CLASS__, 'meta_auth' ),
				)
			);
		}
	}

	/**
	 * Meta auth callback — only editors of the object may write meta.
	 *
	 * @since 1.0.0
	 * @param bool   $allowed  Whether the user can edit the meta key.
	 * @param string $meta_key Meta key (unused).
	 * @param int    $post_id  Object ID (0 for a new, unsaved object).
	 * @return bool
	 */
	public static function meta_auth( $allowed, $meta_key, $post_id ) {
		if ( $post_id > 0 ) {
			return current_user_can( 'edit_post', $post_id );
		}
		return current_user_can( 'edit_posts' );
	}

	/**
	 * Render the color field on the "Add Category" form.
	 *
	 * @since 1.0.5
	 * @return void
	 */
	public static function add_color_field() {
		wp_nonce_field( 'mvweb_om_term_color', 'mvweb_om_term_color_nonce' );
		?>
		<div class="form-field">
			<label for="mvweb_om_color"><?php esc_html_e( 'Marker color', 'mvweb-object-map' ); ?></label>
			<input type="color" name="mvweb_om_color" id="mvweb_om_color" value="#793ea4" />
			<p><?php esc_html_e( 'Color of this category’s markers on the map.', 'mvweb-object-map' ); ?></p>
		</div>
		<?php
	}

	/**
	 * Render the color field on the "Edit Category" form.
	 *
	 * @since 1.0.5
	 * @param WP_Term $term Term being edited.
	 * @return void
	 */
	public static function edit_color_field( $term ) {
		$color = sanitize_hex_color( (string) get_term_meta( $term->term_id, self::TERM_COLOR_META, true ) );
		wp_nonce_field( 'mvweb_om_term_color', 'mvweb_om_term_color_nonce' );
		?>
		<tr class="form-field">
			<th scope="row"><label for="mvweb_om_color"><?php esc_html_e( 'Marker color', 'mvweb-object-map' ); ?></label></th>
			<td>
				<input type="color" name="mvweb_om_color" id="mvweb_om_color" value="<?php echo esc_attr( $color ? $color : '#793ea4' ); ?>" />
				<p class="description"><?php esc_html_e( 'Color of this category’s markers on the map.', 'mvweb-object-map' ); ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * Save the category color term meta.
	 *
	 * @since 1.0.5
	 * @param int $term_id Term ID.
	 * @return void
	 */
	public static function save_color_field( $term_id ) {
		if ( ! isset( $_POST['mvweb_om_term_color_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['mvweb_om_term_color_nonce'] ), 'mvweb_om_term_color' ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_categories' ) ) {
			return;
		}
		if ( ! isset( $_POST['mvweb_om_color'] ) ) {
			return;
		}

		$color = sanitize_hex_color( wp_unslash( $_POST['mvweb_om_color'] ) );
		if ( $color ) {
			update_term_meta( $term_id, self::TERM_COLOR_META, $color );
		} else {
			delete_term_meta( $term_id, self::TERM_COLOR_META );
		}
	}

	/**
	 * Add the color swatch column to the categories table.
	 *
	 * @since 1.0.5
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public static function add_color_column( $columns ) {
		$columns['mvweb_om_color'] = __( 'Color', 'mvweb-object-map' );
		return $columns;
	}

	/**
	 * Render the color swatch cell.
	 *
	 * @since 1.0.5
	 * @param string $content     Column HTML.
	 * @param string $column_name Column key.
	 * @param int    $term_id     Term ID.
	 * @return string
	 */
	public static function render_color_column( $content, $column_name, $term_id ) {
		if ( 'mvweb_om_color' !== $column_name ) {
			return $content;
		}
		$color = sanitize_hex_color( (string) get_term_meta( $term_id, self::TERM_COLOR_META, true ) );
		if ( ! $color ) {
			return '&#8212;';
		}
		return '<span style="display:inline-block;width:18px;height:18px;border-radius:50%;border:1px solid #ccd0d4;background:' . esc_attr( $color ) . ';" title="' . esc_attr( $color ) . '"></span>';
	}
}
