/**
 * Frontend map for MVweb Object Map.
 *
 * Renders a Yandex map (JS API 3.0) per [mvweb_map] instance: markers,
 * clustering, category filter and balloons. All object text is inserted via
 * textContent and URLs via setAttribute — never innerHTML — because the REST
 * payload is plain text and must not be trusted as HTML.
 *
 * @package mvweb_om
 * @since   1.0.0
 */

(function () {
	'use strict';

	var data = window.mvwebOmData || {};
	var i18n = data.i18n || {};

	document.addEventListener('DOMContentLoaded', function () {
		var roots = document.querySelectorAll('.mvweb-om');
		roots.forEach(function (root) {
			new MapInstance(root).init();
		});
	});

	/**
	 * One map instance bound to a single shortcode container.
	 *
	 * @param {HTMLElement} root Container element.
	 */
	function MapInstance(root) {
		this.root = root;
		this.config = parseConfig(root.getAttribute('data-config'));
		this.canvas = root.querySelector('.mvweb-om__canvas');
		this.statusEl = root.querySelector('.mvweb-om__status');
		this.statusText = root.querySelector('.mvweb-om__status-text');
		this.filterEl = root.querySelector('.mvweb-om__filter');
		this.map = null;
		this.markersLayer = null;
		this.clusterer = null;
		this.markerObjects = [];
		this.objects = [];
		this.categories = [];
		this.activeCategory = '';
		this.applyAccent();
		this.applyCardStyle();
	}

	MapInstance.prototype.init = function () {
		if (!data.hasKey || typeof ymaps3 === 'undefined') {
			this.showStatus(i18n.noKey || '');
			return;
		}
		this.showStatus(i18n.loading || '');
		this.fetchObjects();
	};

	/**
	 * Apply the configured accent color as a CSS variable on the root.
	 */
	MapInstance.prototype.applyAccent = function () {
		if (data.accent) {
			this.root.style.setProperty('--mvweb-om-accent', data.accent);
		}
	};

	/**
	 * Apply the configured list-card appearance (CSS variables + modifiers).
	 */
	MapInstance.prototype.applyCardStyle = function () {
		var c = data.card;
		if (!c) {
			return;
		}
		var s = this.root.style;
		var setVar = function (name, value) {
			if (value) {
				s.setProperty(name, value);
			}
		};
		setVar('--mvweb-om-card-bg', c.bg);
		setVar('--mvweb-om-card-border', c.border);
		setVar('--mvweb-om-card-title', c.titleColor);
		setVar('--mvweb-om-card-text', c.textColor);
		setVar('--mvweb-om-card-hover', c.hoverBorder);
		if (c.radius || 0 === c.radius) {
			s.setProperty('--mvweb-om-card-radius', c.radius + 'px');
		}
		if (c.borderWidth || 0 === c.borderWidth) {
			s.setProperty('--mvweb-om-card-border-width', c.borderWidth + 'px');
		}
		if (c.photoSize) {
			s.setProperty('--mvweb-om-card-photo', c.photoSize + 'px');
		}
		if (c.photoRatio) {
			s.setProperty('--mvweb-om-card-ratio', c.photoRatio);
		}
		this.root.classList.toggle('mvweb-om--cards-compact', 'compact' === c.density);
		this.root.classList.toggle('mvweb-om--cards-shadow', !!c.shadow);
		this.root.classList.toggle('mvweb-om--cards-photo-top', 'top' === c.photoPos);
	};

	/**
	 * Show a status message (spinner area).
	 *
	 * @param {string} text Message.
	 */
	MapInstance.prototype.showStatus = function (text) {
		if (this.statusText) {
			this.statusText.textContent = text;
		}
		if (this.statusEl) {
			this.statusEl.hidden = false;
		}
	};

	/**
	 * Hide the status message.
	 */
	MapInstance.prototype.hideStatus = function () {
		if (this.statusEl) {
			this.statusEl.hidden = true;
		}
	};

	/**
	 * Fetch objects from the REST endpoint with the instance filter.
	 */
	MapInstance.prototype.fetchObjects = function () {
		var url = new URL(data.restUrl, window.location.origin);
		if (this.config.category) {
			url.searchParams.set('category', this.config.category);
		}
		if (this.config.ids) {
			url.searchParams.set('ids', this.config.ids);
		}

		var self = this;
		fetch(url.toString(), { credentials: 'omit' })
			.then(function (res) {
				if (!res.ok) {
					throw new Error('HTTP ' + res.status);
				}
				return res.json();
			})
			.then(function (payload) {
				self.objects = (payload && payload.objects) || [];
				self.categories = (payload && payload.categories) || [];
				if (!self.objects.length) {
					self.showStatus(i18n.empty || '');
					return;
				}
				self.buildCategoryColors();
				self.spreadOverlaps();
				self.renderMap();
			})
			.catch(function () {
				self.showStatus(i18n.error || '');
			});
	};

	/**
	 * Initialize the Yandex map and draw everything.
	 */
	MapInstance.prototype.renderMap = function () {
		var self = this;
		ymaps3.ready
			.then(function () {
				return self.loadClusterer();
			})
			.then(function (clustererModule) {
				self.clustererApi = clustererModule;

				var YMap = ymaps3.YMap;
				var YMapDefaultSchemeLayer = ymaps3.YMapDefaultSchemeLayer;
				var YMapDefaultFeaturesLayer = ymaps3.YMapDefaultFeaturesLayer;

				var center = self.resolveCenter();
				var zoom = self.config.zoom || data.defaultZoom || 10;

				self.map = new YMap(self.canvas, { location: { center: center, zoom: zoom } });
				self.map.addChild(new YMapDefaultSchemeLayer({ theme: 'light' }));
				self.markersLayer = new YMapDefaultFeaturesLayer();
				self.map.addChild(self.markersLayer);

				self.drawMarkers();
				self.fitToMarkers();
				self.buildFilter();
				self.buildList();
				self.initTabs();
				self.hideStatus();
			})
			.catch(function () {
				self.showStatus(i18n.error || '');
			});
	};

	/**
	 * Load the grid clusterer package when clustering is enabled.
	 *
	 * The ymaps3 import system needs a CDN loader registered before it can
	 * fetch optional packages. A failed load is non-fatal — the map falls
	 * back to plain (unclustered) markers instead of erroring out.
	 *
	 * @return {Promise} Resolves to the clusterer module or null.
	 */
	MapInstance.prototype.loadClusterer = function () {
		if (!this.clusterEnabled()) {
			return Promise.resolve(null);
		}
		if (ymaps3.import && ymaps3.import.registerCdn && !MapInstance.cdnRegistered) {
			ymaps3.import.registerCdn('https://cdn.jsdelivr.net/npm/{package}', '@yandex/ymaps3-clusterer@0.0.1');
			MapInstance.cdnRegistered = true;
		}
		return ymaps3.import('@yandex/ymaps3-clusterer@0.0.1').catch(function () {
			return null;
		});
	};

	/**
	 * Whether clustering is enabled (instance override or global default).
	 *
	 * @return {boolean}
	 */
	MapInstance.prototype.clusterEnabled = function () {
		var override = this.config.cluster;
		if (override === true || override === false) {
			return override;
		}
		return !!data.cluster;
	};

	/**
	 * Resolve the start center from config or the first object.
	 *
	 * @return {Array} [lng, lat]
	 */
	MapInstance.prototype.resolveCenter = function () {
		var center = parseLatLng(this.config.center) || parseLatLng(data.defaultCenter);
		if (center) {
			return center;
		}
		var first = this.objects[0];
		return first ? [first.lng, first.lat] : [37.617635, 55.755814];
	};

	/**
	 * Build a slug → color map from the category list.
	 */
	MapInstance.prototype.buildCategoryColors = function () {
		this.catColors = {};
		var self = this;
		this.categories.forEach(function (cat) {
			if (cat.color) {
				self.catColors[cat.slug] = cat.color;
			}
		});
	};

	/**
	 * Resolve an object's marker color from its first colored category.
	 *
	 * @param {Object} obj Object data.
	 * @return {string} Hex color or '' when none is set.
	 */
	MapInstance.prototype.categoryColor = function (obj) {
		var map = this.catColors || {};
		var cats = obj.categories || [];
		for (var i = 0; i < cats.length; i++) {
			if (map[cats[i]]) {
				return map[cats[i]];
			}
		}
		return '';
	};

	/**
	 * Nudge objects sharing the same coordinates onto a small ring so they
	 * cluster at low zoom but separate into side-by-side markers when zoomed
	 * in, instead of staying stacked under a single "N" bubble.
	 */
	MapInstance.prototype.spreadOverlaps = function () {
		var groups = {};
		this.objects.forEach(function (obj) {
			var key = obj.lat.toFixed(5) + ',' + obj.lng.toFixed(5);
			(groups[key] = groups[key] || []).push(obj);
		});

		var radius = 0.00025;
		Object.keys(groups).forEach(function (key) {
			var group = groups[key];
			if (group.length < 2) {
				return;
			}
			group.forEach(function (obj, i) {
				var angle = (2 * Math.PI * i) / group.length;
				var latRad = obj.lat * Math.PI / 180;
				obj.routeLat = obj.lat;
				obj.routeLng = obj.lng;
				obj.lat += radius * Math.cos(angle);
				obj.lng += radius * Math.sin(angle) / Math.cos(latRad);
			});
		});
	};

	/**
	 * Draw markers (clustered or plain) for the active category.
	 */
	MapInstance.prototype.drawMarkers = function () {
		var self = this;
		var list = this.visibleObjects();
		this.clearMarkers();

		if (this.clusterEnabled() && this.clustererApi) {
			this.drawClustered(list);
			return;
		}

		var YMapMarker = ymaps3.YMapMarker;
		list.forEach(function (obj) {
			var marker = new YMapMarker(
				{ coordinates: [obj.lng, obj.lat] },
				self.buildMarkerEl(obj)
			);
			self.markersLayer.addChild(marker);
			self.markerObjects.push(marker);
		});
	};

	/**
	 * Draw markers through the Yandex grid clusterer.
	 *
	 * @param {Array} list Visible objects.
	 */
	MapInstance.prototype.drawClustered = function (list) {
		var self = this;
		var YMapClusterer = this.clustererApi.YMapClusterer;
		var clusterByGrid = this.clustererApi.clusterByGrid;

		var features = list.map(function (obj, idx) {
			return {
				type: 'Feature',
				id: String(obj.id),
				geometry: { type: 'Point', coordinates: [obj.lng, obj.lat] },
				properties: { obj: obj, order: idx }
			};
		});

		var marker = function (feature) {
			return new ymaps3.YMapMarker(
				{ coordinates: feature.geometry.coordinates },
				self.buildMarkerEl(feature.properties.obj)
			);
		};

		var cluster = function (coordinates, features) {
			return new ymaps3.YMapMarker(
				{ coordinates: coordinates },
				self.buildClusterEl(features, coordinates)
			);
		};

		this.clusterer = new YMapClusterer({
			method: clusterByGrid({ gridSize: 64 }),
			features: features,
			marker: marker,
			cluster: cluster
		});
		this.map.addChild(this.clusterer);
	};

	/**
	 * Build a cluster bubble element that zooms in on click.
	 *
	 * @param {Array} features    Clustered features.
	 * @param {Array} coordinates Cluster center [lng, lat].
	 * @return {HTMLElement}
	 */
	MapInstance.prototype.buildClusterEl = function (features, coordinates) {
		var self = this;
		var el = document.createElement('div');
		el.className = 'mvweb-om__cluster';
		el.textContent = String(features.length);

		var newest = features[0];
		if (newest) {
			features.forEach(function (f) {
				if (f.properties.order < newest.properties.order) {
					newest = f;
				}
			});
			var color = this.categoryColor(newest.properties.obj);
			if (color) {
				el.style.background = color;
			}
		}

		el.addEventListener('click', function () {
			var zoom = (self.map.zoom || data.defaultZoom || 10) + 2;
			self.map.update({ location: { center: coordinates, zoom: zoom, duration: 300 } });
		});
		return el;
	};

	/**
	 * Objects filtered by the active category.
	 *
	 * @return {Array}
	 */
	MapInstance.prototype.visibleObjects = function () {
		if (!this.activeCategory) {
			return this.objects;
		}
		var cat = this.activeCategory;
		return this.objects.filter(function (obj) {
			return (obj.categories || []).indexOf(cat) !== -1;
		});
	};

	/**
	 * Build a marker DOM element for an object.
	 *
	 * @param {Object} obj Object data.
	 * @return {HTMLElement}
	 */
	MapInstance.prototype.buildMarkerEl = function (obj) {
		var self = this;
		var el = document.createElement('div');
		el.className = 'mvweb-om__marker';

		if (obj.icon && obj.icon.type === 'image' && isSafeUrl(obj.icon.url)) {
			var img = document.createElement('img');
			img.setAttribute('src', obj.icon.url);
			img.setAttribute('alt', '');
			el.appendChild(img);
		} else {
			if (obj.icon && /^[a-z0-9_-]+$/i.test(obj.icon.preset || '')) {
				el.classList.add('mvweb-om__marker--' + obj.icon.preset);
			}
			var color = this.categoryColor(obj);
			if (color) {
				el.style.background = color;
			}
		}

		el.addEventListener('click', function (e) {
			e.stopPropagation();
			self.openBalloon(obj);
		});
		return el;
	};

	/**
	 * Open a single balloon for an object (closing any previous one).
	 *
	 * The balloon is a fixed card pinned to the top-center of the map container
	 * (not a map marker), so it is always fully visible over the map regardless
	 * of where the marker sits — it never anchors into a corner or clips at the
	 * map edges. The map still recenters on the marker for context.
	 *
	 * @param {Object} obj Object data.
	 */
	MapInstance.prototype.openBalloon = function (obj) {
		this.closeBalloon();
		this.closeModal();

		var host = this.root.querySelector('.mvweb-om__map');
		if (!host) {
			return;
		}
		this.balloon = this.buildBalloonEl(obj);
		host.appendChild(this.balloon);
		this.map.update({ location: { center: [obj.lng, obj.lat], duration: 300 } });
	};

	/**
	 * Close the open balloon, if any.
	 */
	MapInstance.prototype.closeBalloon = function () {
		if (this.balloon) {
			if (this.balloon.parentNode) {
				this.balloon.parentNode.removeChild(this.balloon);
			}
			this.balloon = null;
		}
	};

	/**
	 * Build the balloon DOM for an object. Text via textContent, links via
	 * setAttribute — no innerHTML with object data.
	 *
	 * @param {Object} obj Object data.
	 * @return {HTMLElement}
	 */
	MapInstance.prototype.buildBalloonEl = function (obj) {
		var self = this;
		var box = document.createElement('div');
		box.className = 'mvweb-om__balloon';

		var close = document.createElement('button');
		close.type = 'button';
		close.className = 'mvweb-om__balloon-close';
		close.textContent = '×';
		close.setAttribute('aria-label', i18n.close || 'Close');
		close.addEventListener('click', function () { self.closeBalloon(); });
		box.appendChild(close);

		if (obj.thumb && isSafeUrl(obj.thumb)) {
			var photo = document.createElement('img');
			photo.className = 'mvweb-om__balloon-photo';
			photo.setAttribute('src', obj.thumb);
			photo.setAttribute('alt', '');
			box.appendChild(photo);
		}

		var title = document.createElement('div');
		title.className = 'mvweb-om__balloon-title';
		title.textContent = obj.title || '';
		box.appendChild(title);

		if (obj.address) {
			box.appendChild(textRow('mvweb-om__balloon-address', obj.address));
		}
		if (obj.excerpt) {
			box.appendChild(textRow('mvweb-om__balloon-excerpt', obj.excerpt));
		}
		if (obj.phone) {
			var phone = document.createElement('a');
			phone.className = 'mvweb-om__balloon-phone';
			var hasPlus = obj.phone.trim().charAt(0) === '+';
			var digits = obj.phone.replace(/[^0-9]/g, '');
			phone.setAttribute('href', 'tel:' + (hasPlus ? '+' : '') + digits);
			phone.textContent = obj.phone;
			box.appendChild(phone);
		}
		if (obj.hours) {
			box.appendChild(textRow('mvweb-om__balloon-hours', obj.hours));
		}

		var specs = (obj.specs || []).filter(function (s) { return s.inBalloon; });
		if (specs.length) {
			box.appendChild(buildSpecsDl(specs, 'mvweb-om__balloon-specs'));
		}

		if (obj.links && obj.links.length) {
			var links = buildLinks(obj.links, 'mvweb-om__balloon-links');
			if (links.childNodes.length) {
				box.appendChild(links);
			}
		}

		box.appendChild(buildActions(obj, 'mvweb-om__balloon-actions'));

		return box;
	};

	/**
	 * Build the category filter toggles.
	 */
	MapInstance.prototype.buildFilter = function () {
		if (!this.filterEl || !this.categories.length) {
			return;
		}
		var self = this;
		this.filterEl.textContent = '';

		var allBtn = filterButton(i18n.all || '', '');
		allBtn.classList.add('mvweb-om__filter-btn--active');
		this.filterEl.appendChild(allBtn);

		this.categories.forEach(function (cat) {
			self.filterEl.appendChild(filterButton(cat.name, cat.slug, cat.color));
		});

		this.filterEl.hidden = false;
		this.filterEl.addEventListener('click', function (e) {
			var btn = e.target.closest('.mvweb-om__filter-btn');
			if (!btn) {
				return;
			}
			self.activeCategory = btn.getAttribute('data-slug') || '';
			self.filterEl.querySelectorAll('.mvweb-om__filter-btn').forEach(function (b) {
				b.classList.remove('mvweb-om__filter-btn--active');
			});
			btn.classList.add('mvweb-om__filter-btn--active');
			self.closeBalloon();
			self.drawMarkers();
			self.fitToMarkers();
			self.buildList();
		});
	};

	/**
	 * Fit the map view to the visible markers.
	 */
	MapInstance.prototype.fitToMarkers = function () {
		var list = this.visibleObjects();
		if (this.config.center || this.config.zoom || data.defaultCenter || !list.length) {
			return;
		}
		var lngs = list.map(function (o) { return o.lng; });
		var lats = list.map(function (o) { return o.lat; });
		var bounds = [
			[Math.min.apply(null, lngs), Math.min.apply(null, lats)],
			[Math.max.apply(null, lngs), Math.max.apply(null, lats)]
		];
		try {
			this.map.update({ location: { bounds: bounds }, duration: 300 });
		} catch (err) {
			this.map.update({ location: { center: [lngs[0], lats[0]], zoom: 12 } });
		}
	};

	/**
	 * Remove all object markers from the layer.
	 */
	MapInstance.prototype.clearMarkers = function () {
		var self = this;
		if (this.markerObjects) {
			this.markerObjects.forEach(function (m) {
				self.markersLayer.removeChild(m);
			});
		}
		this.markerObjects = [];

		if (this.clusterer) {
			this.map.removeChild(this.clusterer);
			this.clusterer = null;
		}
	};

	/**
	 * Build the side catalog list with search and sort (when list is enabled).
	 */
	MapInstance.prototype.buildList = function () {
		if (!this.config.list) {
			return;
		}
		this.cardsEl = this.root.querySelector('.mvweb-om__cards');
		this.searchEl = this.root.querySelector('.mvweb-om__search');
		this.sortEl = this.root.querySelector('.mvweb-om__sort');
		if (!this.cardsEl) {
			return;
		}

		if (!this.listBound) {
			this.bindListControls();
			this.listBound = true;
		}

		this.renderCards();
	};

	/**
	 * Wire the search/sort controls once.
	 */
	MapInstance.prototype.bindListControls = function () {
		var self = this;

		if (this.searchEl) {
			this.searchEl.setAttribute('placeholder', i18n.search || '');
			this.searchEl.addEventListener('input', function () {
				self.renderCards();
			});
		}
		if (this.sortEl) {
			var optName = this.sortEl.querySelector('option[value="name"]');
			var optNew = this.sortEl.querySelector('option[value="new"]');
			if (optName) {
				optName.textContent = i18n.sortName || '';
			}
			if (optNew) {
				optNew.textContent = i18n.sortNew || '';
			}
			this.sortEl.addEventListener('change', function () {
				self.renderCards();
			});
		}
	};

	/**
	 * Render the cards for the current filter, search and sort.
	 */
	MapInstance.prototype.renderCards = function () {
		var self = this;
		var query = (this.searchEl ? this.searchEl.value : '').trim().toLowerCase().slice(0, 200);
		var sort = (this.sortEl && this.sortEl.value) || 'name';

		var list = this.visibleObjects().slice();
		if (query) {
			list = list.filter(function (obj) {
				return (obj.title || '').toLowerCase().indexOf(query) !== -1;
			});
		}
		if (sort === 'name') {
			list.sort(function (a, b) {
				return (a.title || '').localeCompare(b.title || '');
			});
		}

		this.cardsEl.textContent = '';
		list.forEach(function (obj) {
			self.cardsEl.appendChild(self.buildCardEl(obj));
		});
	};

	/**
	 * Build one catalog card. Click centers the map (and opens the modal when
	 * enabled). Text via textContent only.
	 *
	 * @param {Object} obj Object data.
	 * @return {HTMLElement}
	 */
	MapInstance.prototype.buildCardEl = function (obj) {
		var self = this;
		var card = document.createElement('button');
		card.type = 'button';
		card.className = 'mvweb-om__card';

		var cfg = data.card || {};

		if (false !== cfg.showPhoto && obj.thumb && isSafeUrl(obj.thumb)) {
			var img = document.createElement('img');
			img.className = 'mvweb-om__card-photo';
			img.setAttribute('src', obj.thumb);
			img.setAttribute('alt', '');
			card.appendChild(img);
		}

		var body = document.createElement('span');
		body.className = 'mvweb-om__card-body';

		var title = document.createElement('span');
		title.className = 'mvweb-om__card-title';
		title.textContent = obj.title || '';
		body.appendChild(title);

		if (false !== cfg.showAddress && obj.address) {
			var addr = document.createElement('span');
			addr.className = 'mvweb-om__card-address';
			addr.textContent = obj.address;
			body.appendChild(addr);
		}

		if (cfg.showExcerpt && obj.excerpt) {
			var ex = document.createElement('span');
			ex.className = 'mvweb-om__card-excerpt';
			ex.textContent = obj.excerpt;
			body.appendChild(ex);
		}
		card.appendChild(body);

		card.addEventListener('click', function () {
			self.map.update({ location: { center: [obj.lng, obj.lat], zoom: 16, duration: 300 } });
			if (data.modal) {
				self.openModal(obj);
			}
		});
		return card;
	};

	/**
	 * Wire the mobile Map/List tabs (when list is enabled).
	 */
	MapInstance.prototype.initTabs = function () {
		if (!this.config.list) {
			return;
		}
		var self = this;
		var tabs = this.root.querySelectorAll('.mvweb-om__tab');
		if (!tabs.length) {
			return;
		}

		var allowed = { map: true, list: true };
		this.root.classList.add('mvweb-om--view-map');
		tabs.forEach(function (tab) {
			tab.addEventListener('click', function () {
				var view = tab.getAttribute('data-view');
				if (!allowed[view]) {
					return;
				}
				self.root.classList.remove('mvweb-om--view-map', 'mvweb-om--view-list');
				self.root.classList.add('mvweb-om--view-' + view);
				tabs.forEach(function (t) {
					var on = t === tab;
					t.classList.toggle('mvweb-om__tab--active', on);
					t.setAttribute('aria-selected', on ? 'true' : 'false');
				});
				if (view === 'map' && self.map) {
					self.map.update({});
				}
			});
		});
	};

	/**
	 * Open the full-card modal for an object. Text via textContent only.
	 *
	 * @param {Object} obj Object data.
	 */
	MapInstance.prototype.openModal = function (obj) {
		this.closeModal();
		this.closeBalloon();
		var self = this;

		var dialog = document.createElement('dialog');
		dialog.className = 'mvweb-om__modal';
		if (data.accent) {
			dialog.style.setProperty('--mvweb-om-accent', data.accent);
		}
		if (data.card && data.card.photoRatio) {
			dialog.style.setProperty('--mvweb-om-card-ratio', data.card.photoRatio);
		}
		dialog.addEventListener('click', function (e) {
			if (e.target === dialog) {
				dialog.close();
			}
		});
		dialog.addEventListener('close', function () {
			if (dialog.parentNode) {
				dialog.parentNode.removeChild(dialog);
			}
			self.modal = null;
		});

		var box = document.createElement('div');
		box.className = 'mvweb-om__modal-box';

		var close = document.createElement('button');
		close.type = 'button';
		close.className = 'mvweb-om__modal-close';
		close.textContent = '×';
		close.setAttribute('aria-label', i18n.close || 'Close');
		close.addEventListener('click', function () { dialog.close(); });
		box.appendChild(close);

		if (obj.gallery && obj.gallery.length) {
			box.appendChild(buildGallery(obj.gallery));
		} else if (obj.thumb) {
			box.appendChild(buildGallery([obj.thumb]));
		}

		var title = document.createElement('h3');
		title.className = 'mvweb-om__modal-title';
		title.textContent = obj.title || '';
		box.appendChild(title);

		if (obj.address) {
			box.appendChild(textRow('mvweb-om__modal-address', obj.address));
		}
		if (obj.phone) {
			var mphone = document.createElement('a');
			mphone.className = 'mvweb-om__modal-phone';
			var mHasPlus = obj.phone.trim().charAt(0) === '+';
			var mDigits = obj.phone.replace(/[^0-9]/g, '');
			mphone.setAttribute('href', 'tel:' + (mHasPlus ? '+' : '') + mDigits);
			mphone.textContent = obj.phone;
			box.appendChild(mphone);
		}
		if (obj.hours) {
			box.appendChild(textRow('mvweb-om__modal-hours', obj.hours));
		}
		if (obj.excerpt) {
			box.appendChild(textRow('mvweb-om__modal-excerpt', obj.excerpt));
		}
		if (obj.specs && obj.specs.length) {
			box.appendChild(buildSpecsDl(obj.specs, 'mvweb-om__modal-specs'));
		}

		if (obj.links && obj.links.length) {
			var mlinks = buildLinks(obj.links, 'mvweb-om__modal-links');
			if (mlinks.childNodes.length) {
				box.appendChild(mlinks);
			}
		}

		box.appendChild(buildActions(obj, 'mvweb-om__modal-actions'));

		dialog.appendChild(box);
		document.body.appendChild(dialog);
		this.modal = dialog;

		if (typeof dialog.showModal === 'function') {
			dialog.showModal();
		} else {
			dialog.setAttribute('open', '');
		}
	};

	/**
	 * Close the modal, if any.
	 */
	MapInstance.prototype.closeModal = function () {
		if (this.modal) {
			if (typeof this.modal.close === 'function' && this.modal.open) {
				this.modal.close();
			} else if (this.modal.parentNode) {
				this.modal.parentNode.removeChild(this.modal);
			}
			this.modal = null;
		}
	};

	/**
	 * Parse the per-instance JSON config.
	 *
	 * @param {string} raw JSON string.
	 * @return {Object}
	 */
	function parseConfig(raw) {
		if (!raw) {
			return {};
		}
		try {
			return JSON.parse(raw) || {};
		} catch (err) {
			return {};
		}
	}

	/**
	 * Parse a "lat,lng" string into a [lng, lat] pair for ymaps, or null.
	 *
	 * @param {string} str Raw "lat,lng" string.
	 * @return {Array|null}
	 */
	function parseLatLng(str) {
		if (!str) {
			return null;
		}
		var parts = String(str).split(',');
		var lat = parseFloat(parts[0]);
		var lng = parseFloat(parts[1]);
		return (!isNaN(lat) && !isNaN(lng)) ? [lng, lat] : null;
	}

	/**
	 * Build a text row element.
	 *
	 * @param {string} cls  Class name.
	 * @param {string} text Text content.
	 * @return {HTMLElement}
	 */
	function textRow(cls, text) {
		var el = document.createElement('div');
		el.className = cls;
		el.textContent = text;
		return el;
	}

	/**
	 * Whether a URL is safe to place into src/href (http(s) or root-relative).
	 *
	 * Defence-in-depth on top of the server-side mvweb_om_sanitize_url().
	 *
	 * @param {string} url URL to test.
	 * @return {boolean}
	 */
	function isSafeUrl(url) {
		if (typeof url !== 'string') {
			return false;
		}
		var s = url.trim().toLowerCase();
		return s.indexOf('http://') === 0 || s.indexOf('https://') === 0 || s.indexOf('/') === 0;
	}

	/**
	 * Build the action buttons (details link + route) shared by the balloon
	 * and the modal. The route always links to Yandex Maps directions.
	 *
	 * @param {Object} obj Object payload.
	 * @param {string} cls Container class name.
	 * @return {HTMLElement}
	 */
	function buildActions(obj, cls) {
		var actions = document.createElement('div');
		actions.className = cls;
		if (obj.moreUrl && isSafeUrl(obj.moreUrl)) {
			var more = document.createElement('a');
			more.className = 'mvweb-om__btn';
			more.setAttribute('href', obj.moreUrl);
			more.setAttribute('target', '_blank');
			more.setAttribute('rel', 'noopener noreferrer');
			more.textContent = i18n.more || '';
			actions.appendChild(more);
		}
		if (data.showRoute) {
			var route = document.createElement('a');
			route.className = 'mvweb-om__btn mvweb-om__btn--ghost';
			var rLat = ('number' === typeof obj.routeLat) ? obj.routeLat : obj.lat;
			var rLng = ('number' === typeof obj.routeLng) ? obj.routeLng : obj.lng;
			route.setAttribute('href', 'https://yandex.ru/maps/?rtext=~' + encodeURIComponent(rLat) + ',' + encodeURIComponent(rLng));
			route.setAttribute('target', '_blank');
			route.setAttribute('rel', 'noopener noreferrer');
			route.textContent = i18n.route || '';
			actions.appendChild(route);
		}
		return actions;
	}

	/**
	 * Build the object links list (label + external URL). Returns an element
	 * that may be empty when no links are safe — the caller checks childNodes.
	 * Text via textContent, URLs via setAttribute.
	 *
	 * @param {Array}  links Link rows ({ label, url }).
	 * @param {string} cls   Container class name.
	 * @return {HTMLElement}
	 */
	function buildLinks(links, cls) {
		var wrap = document.createElement('div');
		wrap.className = cls;
		(links || []).forEach(function (link) {
			if (!link || !isSafeUrl(link.url)) {
				return;
			}
			var a = document.createElement('a');
			a.className = 'mvweb-om__link';
			a.setAttribute('href', link.url);
			a.setAttribute('target', '_blank');
			a.setAttribute('rel', 'noopener noreferrer');
			a.textContent = link.label || link.url;
			wrap.appendChild(a);
		});
		return wrap;
	}

	/**
	 * Build a definition list of spec label/value rows (text via textContent).
	 *
	 * @param {Array}  specs Spec rows ({ label, value }).
	 * @param {string} cls   Class name for the <dl>.
	 * @return {HTMLElement}
	 */
	function buildSpecsDl(specs, cls) {
		var dl = document.createElement('dl');
		dl.className = cls;
		specs.forEach(function (s) {
			var dt = document.createElement('dt');
			dt.textContent = s.label;
			var dd = document.createElement('dd');
			dd.textContent = s.value;
			dl.appendChild(dt);
			dl.appendChild(dd);
		});
		return dl;
	}

	/**
	 * Build a simple photo slider (prev/next) from a list of image URLs.
	 *
	 * @param {Array} urls Image URLs.
	 * @return {HTMLElement}
	 */
	function buildGallery(urls) {
		urls = urls.filter(isSafeUrl);
		var wrap = document.createElement('div');
		wrap.className = 'mvweb-om__slider';

		if (!urls.length) {
			return wrap;
		}

		var img = document.createElement('img');
		img.className = 'mvweb-om__slider-img';
		img.setAttribute('src', urls[0]);
		img.setAttribute('alt', '');
		wrap.appendChild(img);

		if (urls.length < 2) {
			return wrap;
		}

		var index = 0;
		var prev = sliderBtn('mvweb-om__slider-prev', '‹', i18n.prev || 'Previous');
		var next = sliderBtn('mvweb-om__slider-next', '›', i18n.next || 'Next');

		prev.addEventListener('click', function () {
			index = (index - 1 + urls.length) % urls.length;
			img.setAttribute('src', urls[index]);
		});
		next.addEventListener('click', function () {
			index = (index + 1) % urls.length;
			img.setAttribute('src', urls[index]);
		});

		wrap.appendChild(prev);
		wrap.appendChild(next);
		return wrap;
	}

	/**
	 * Build a slider navigation button.
	 *
	 * @param {string} cls   Class name.
	 * @param {string} glyph Visible glyph.
	 * @param {string} label Accessible label.
	 * @return {HTMLElement}
	 */
	function sliderBtn(cls, glyph, label) {
		var btn = document.createElement('button');
		btn.type = 'button';
		btn.className = 'mvweb-om__slider-btn ' + cls;
		btn.textContent = glyph;
		btn.setAttribute('aria-label', label);
		return btn;
	}

	/**
	 * Build a filter toggle button.
	 *
	 * @param {string} label Visible label.
	 * @param {string} slug  Category slug ('' for all).
	 * @param {string} color Category color for the legend dot (optional).
	 * @return {HTMLElement}
	 */
	function filterButton(label, slug, color) {
		var btn = document.createElement('button');
		btn.type = 'button';
		btn.className = 'mvweb-om__filter-btn';
		btn.setAttribute('data-slug', slug);
		if (color) {
			var dot = document.createElement('span');
			dot.className = 'mvweb-om__filter-dot';
			dot.style.background = color;
			btn.appendChild(dot);
		}
		var text = document.createElement('span');
		text.textContent = label;
		btn.appendChild(text);
		return btn;
	}
})();
