<?php
/**
 * Plugin Name:       MVweb Object Map
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-object-map
 * Description:       Show catalog objects on an interactive Yandex map — a non-public custom post type with coordinates, photos, contacts and custom specs, output via the [mvweb_map] shortcode.
 * Version:           1.0.2
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-object-map
 * Domain Path:       /languages
 *
 * @package mvweb_om
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_OM_VERSION' ) ) {
	return;
}

define( 'MVWEB_OM_VERSION', '1.0.2' );
define( 'MVWEB_OM_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_OM_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_OM_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_OM_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_OM_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_OM_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_OM_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_OM_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-object-map' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter(
	'mvweb_registered_plugins',
	function ( $plugins ) {
		$plugins['mvweb-object-map'] = array(
			'name'         => 'MVweb Object Map',
			'description'  => __( 'Show catalog objects on an interactive Yandex map — a non-public custom post type with coordinates, photos, contacts and custom specs, output via the [mvweb_map] shortcode.', 'mvweb-object-map' ),
			'url'          => 'https://mvweb.ru/plugins/mvweb-object-map',
			'settings_url' => 'admin.php?page=mvweb-object-map',
			'textdomain'   => 'mvweb-object-map',
		);
		return $plugins;
	}
);

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_om_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-object-map',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_om_load_textdomain' );

require_once MVWEB_OM_PATH . 'includes/helpers.php';
require_once MVWEB_OM_PATH . 'includes/class-mvweb-om-loader.php';

if ( class_exists( 'MVweb_OM_Loader' ) ) {
	MVweb_OM_Loader::load();
}

/**
 * Activation: register the CPT and taxonomy so they exist immediately.
 *
 * The CPT is non-public (no rewrite rules), so no rewrite flush is needed.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_om_activate() {
	if ( class_exists( 'MVweb_OM_CPT' ) ) {
		MVweb_OM_CPT::register_post_type();
		MVweb_OM_CPT::register_taxonomy();
	}
}
register_activation_hook( __FILE__, 'mvweb_om_activate' );
