<?php
/**
 * REST endpoint and object cache for MVweb Object Map.
 *
 * Exposes a read-only public endpoint that returns the published map objects
 * as JSON for the frontend map. Results are cached in a transient and the
 * cache is invalidated whenever an object or the settings change.
 *
 * Endpoint:
 *   GET /wp-json/mvweb-om/v1/objects  (args: category, ids)
 *
 * @package mvweb_om
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST controller and cache.
 *
 * @since 1.0.0
 */
final class MVweb_OM_REST {

	/**
	 * REST namespace.
	 */
	const NAMESPACE_V1 = 'mvweb-om/v1';

	/**
	 * Transient key prefix for cached payloads.
	 */
	const CACHE_PREFIX = 'mvweb_om_objects_';

	/**
	 * Cache lifetime.
	 */
	const CACHE_TTL = DAY_IN_SECONDS;

	/**
	 * Option storing the list of cache keys for full invalidation.
	 */
	const CACHE_INDEX = 'mvweb_om_cache_keys';

	/**
	 * Maximum number of cache keys tracked for invalidation. Oldest keys are
	 * dropped past this limit (their transients still expire on their own).
	 */
	const CACHE_INDEX_MAX = 200;

	/**
	 * Wire WordPress hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'save_post_' . MVweb_OM_CPT::POST_TYPE, array( __CLASS__, 'flush_cache' ) );
		add_action( 'deleted_post', array( __CLASS__, 'flush_on_delete' ), 10, 2 );
		add_action( 'update_option_' . MVweb_OM_Settings::OPTION_NAME, array( __CLASS__, 'flush_cache' ) );
		add_action( 'created_' . MVweb_OM_CPT::TAXONOMY, array( __CLASS__, 'flush_cache' ) );
		add_action( 'edited_' . MVweb_OM_CPT::TAXONOMY, array( __CLASS__, 'flush_cache' ) );
		add_action( 'delete_' . MVweb_OM_CPT::TAXONOMY, array( __CLASS__, 'flush_cache' ) );
	}

	/**
	 * Register the objects route.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_routes() {
		register_rest_route(
			self::NAMESPACE_V1,
			'/objects',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_objects' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'category' => array(
						'description'       => __( 'Category slugs, comma-separated.', 'mvweb-object-map' ),
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'ids'      => array(
						'description'       => __( 'Object IDs, comma-separated.', 'mvweb-object-map' ),
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);
	}

	/**
	 * Return the published objects matching the request, cached.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function get_objects( $request ) {
		$categories = self::parse_slugs( (string) $request->get_param( 'category' ) );
		$ids        = self::parse_ids( (string) $request->get_param( 'ids' ) );

		$cache_key = self::CACHE_PREFIX . md5( wp_json_encode( array( $categories, $ids ) ) );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}

		$payload = self::build_payload( $categories, $ids );

		set_transient( $cache_key, $payload, self::CACHE_TTL );
		self::remember_key( $cache_key );

		return rest_ensure_response( $payload );
	}

	/**
	 * Build the objects payload from the database.
	 *
	 * @since 1.0.0
	 * @param array $categories Category slugs.
	 * @param array $ids        Object IDs.
	 * @return array
	 */
	private static function build_payload( $categories, $ids ) {
		$args = array(
			'post_type'              => MVweb_OM_CPT::POST_TYPE,
			'post_status'            => 'publish',
			'posts_per_page'         => 2000,
			'no_found_rows'          => true,
			'update_post_meta_cache' => true,
			'update_post_term_cache' => true,
			'orderby'                => 'date',
			'order'                  => 'DESC',
		);

		if ( ! empty( $ids ) ) {
			$args['post__in']       = $ids;
			$args['orderby']        = 'post__in';
			$args['posts_per_page'] = count( $ids );
		}

		if ( ! empty( $categories ) ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => MVweb_OM_CPT::TAXONOMY,
					'field'    => 'slug',
					'terms'    => $categories,
				),
			);
		}

		$query   = new WP_Query( $args );
		$schema  = (array) MVweb_OM_Settings::get( 'specs_schema' );
		$objects = array();

		self::prime_attachment_cache( $query->posts );

		foreach ( $query->posts as $post ) {
			$item = self::format_object( $post, $schema );
			if ( null !== $item ) {
				$objects[] = $item;
			}
		}

		return array(
			'objects'    => $objects,
			'categories' => self::format_categories(),
		);
	}

	/**
	 * Prime the post/meta cache for all referenced attachments in one pass.
	 *
	 * Avoids per-attachment queries from wp_get_attachment_image_url() inside
	 * the formatting loop (matters on a cache miss with many galleries).
	 *
	 * @since 1.0.0
	 * @param WP_Post[] $posts Object posts.
	 * @return void
	 */
	private static function prime_attachment_cache( $posts ) {
		$att_ids = array();

		foreach ( $posts as $post ) {
			$thumb = (int) get_post_thumbnail_id( $post->ID );
			if ( $thumb > 0 ) {
				$att_ids[] = $thumb;
			}

			$icon = (int) get_post_meta( $post->ID, '_mvweb_om_icon_image', true );
			if ( $icon > 0 ) {
				$att_ids[] = $icon;
			}

			foreach ( array_map( 'absint', mvweb_om_decode_array( get_post_meta( $post->ID, '_mvweb_om_gallery', true ) ) ) as $gid ) {
				if ( $gid > 0 ) {
					$att_ids[] = $gid;
				}
			}
		}

		$att_ids = array_values( array_unique( $att_ids ) );
		if ( ! empty( $att_ids ) && function_exists( '_prime_post_caches' ) ) {
			_prime_post_caches( $att_ids, false, true );
		}
	}

	/**
	 * Format a single object for the frontend.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post   Object post.
	 * @param array   $schema Specs schema.
	 * @return array|null Null when the object has no coordinates.
	 */
	private static function format_object( $post, $schema ) {
		$lat = (string) get_post_meta( $post->ID, '_mvweb_om_lat', true );
		$lng = (string) get_post_meta( $post->ID, '_mvweb_om_lng', true );

		if ( '' === $lat || '' === $lng ) {
			return null;
		}

		$gallery_ids = array_map( 'absint', mvweb_om_decode_array( get_post_meta( $post->ID, '_mvweb_om_gallery', true ) ) );
		$thumb_id    = (int) get_post_thumbnail_id( $post->ID );

		$gallery = array();
		foreach ( $gallery_ids as $att_id ) {
			$url = wp_get_attachment_image_url( $att_id, 'large' );
			if ( $url ) {
				$gallery[] = $url;
			}
		}

		$more_url = mvweb_om_sanitize_url( (string) get_post_meta( $post->ID, '_mvweb_om_more_url', true ) );
		$specs    = self::format_specs( $post->ID, $schema );

		return array(
			'id'         => $post->ID,
			'title'      => html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' ),
			'lat'        => (float) $lat,
			'lng'        => (float) $lng,
			'address'    => wp_strip_all_tags( (string) get_post_meta( $post->ID, '_mvweb_om_address', true ) ),
			'excerpt'    => wp_strip_all_tags( (string) $post->post_excerpt ),
			'thumb'      => $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'medium' ) : '',
			'gallery'    => $gallery,
			'phone'      => wp_strip_all_tags( (string) get_post_meta( $post->ID, '_mvweb_om_phone', true ) ),
			'hours'      => wp_strip_all_tags( (string) get_post_meta( $post->ID, '_mvweb_om_hours', true ) ),
			'links'      => self::format_links( $post->ID ),
			'moreUrl'    => $more_url,
			'icon'       => self::format_icon( $post->ID ),
			'categories' => wp_get_post_terms( $post->ID, MVweb_OM_CPT::TAXONOMY, array( 'fields' => 'slugs' ) ),
			'specs'      => $specs,
		);
	}

	/**
	 * Format object specs into label/value/balloon rows following the schema.
	 *
	 * @since 1.0.0
	 * @param int   $post_id Object ID.
	 * @param array $schema  Specs schema.
	 * @return array
	 */
	private static function format_specs( $post_id, $schema ) {
		$values = mvweb_om_decode_array( get_post_meta( $post_id, '_mvweb_om_specs', true ) );
		$out    = array();

		foreach ( $schema as $field ) {
			if ( empty( $field['id'] ) || ! isset( $values[ $field['id'] ] ) ) {
				continue;
			}
			$value = (string) $values[ $field['id'] ];
			if ( '' === $value ) {
				continue;
			}
			if ( 'bool' === $field['type'] ) {
				$value = ( '1' === $value )
					? _x( 'Yes', 'object spec boolean value', 'mvweb-object-map' )
					: _x( 'No', 'object spec boolean value', 'mvweb-object-map' );
			} elseif ( 'number' === $field['type'] && ! empty( $field['unit'] ) ) {
				$value = $value . ' ' . $field['unit'];
			}

			$out[] = array(
				'label'     => wp_strip_all_tags( (string) $field['label'] ),
				'value'     => wp_strip_all_tags( $value ),
				'type'      => $field['type'],
				'inBalloon' => ! empty( $field['show_in_balloon'] ),
			);
		}

		return $out;
	}

	/**
	 * Format object links.
	 *
	 * @since 1.0.0
	 * @param int $post_id Object ID.
	 * @return array
	 */
	private static function format_links( $post_id ) {
		$links = mvweb_om_decode_array( get_post_meta( $post_id, '_mvweb_om_links', true ) );
		$out   = array();
		foreach ( $links as $link ) {
			if ( ! is_array( $link ) || empty( $link['url'] ) ) {
				continue;
			}
			$out[] = array(
				'label' => wp_strip_all_tags( isset( $link['label'] ) ? (string) $link['label'] : '' ),
				'url'   => mvweb_om_sanitize_url( (string) $link['url'] ),
			);
		}
		return $out;
	}

	/**
	 * Format the marker icon (custom image URL or preset key).
	 *
	 * @since 1.0.0
	 * @param int $post_id Object ID.
	 * @return array
	 */
	private static function format_icon( $post_id ) {
		$image_id = (int) get_post_meta( $post_id, '_mvweb_om_icon_image', true );
		if ( $image_id > 0 ) {
			$url = wp_get_attachment_image_url( $image_id, 'thumbnail' );
			if ( $url ) {
				return array(
					'type' => 'image',
					'url'  => $url,
				);
			}
		}

		return array(
			'type'   => 'preset',
			'preset' => sanitize_key( (string) get_post_meta( $post_id, '_mvweb_om_icon_preset', true ) ),
		);
	}

	/**
	 * Format the category list (slug + name) for the frontend filter.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private static function format_categories() {
		$terms = get_terms(
			array(
				'taxonomy'   => MVweb_OM_CPT::TAXONOMY,
				'hide_empty' => true,
			)
		);

		$out = array();
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$out[] = array(
					'slug' => $term->slug,
					'name' => wp_strip_all_tags( $term->name ),
				);
			}
		}
		return $out;
	}

	/**
	 * Parse a comma-separated list of taxonomy slugs.
	 *
	 * @since 1.0.0
	 * @param string $raw Raw value.
	 * @return array
	 */
	private static function parse_slugs( $raw ) {
		if ( '' === $raw ) {
			return array();
		}
		$slugs = array_map( 'sanitize_title', array_map( 'trim', explode( ',', $raw ) ) );
		$slugs = array_values( array_filter( array_unique( $slugs ) ) );
		$slugs = array_slice( $slugs, 0, 20 );

		$existing = get_terms(
			array(
				'taxonomy'   => MVweb_OM_CPT::TAXONOMY,
				'fields'     => 'slugs',
				'hide_empty' => false,
			)
		);
		$slugs    = is_wp_error( $existing ) ? array() : array_values( array_intersect( $slugs, $existing ) );
		sort( $slugs );

		return $slugs;
	}

	/**
	 * Parse a comma-separated list of post IDs.
	 *
	 * @since 1.0.0
	 * @param string $raw Raw value.
	 * @return array
	 */
	private static function parse_ids( $raw ) {
		if ( '' === $raw ) {
			return array();
		}
		$ids = array_map( 'absint', array_map( 'trim', explode( ',', $raw ) ) );
		$ids = array_values( array_filter( array_unique( $ids ) ) );
		$ids = array_slice( $ids, 0, 100 );
		sort( $ids );
		return $ids;
	}

	/**
	 * Remember a cache key so it can be purged on invalidation.
	 *
	 * @since 1.0.0
	 * @param string $key Transient key.
	 * @return void
	 */
	private static function remember_key( $key ) {
		$keys = get_option( self::CACHE_INDEX, array() );
		if ( ! is_array( $keys ) ) {
			$keys = array();
		}
		if ( in_array( $key, $keys, true ) ) {
			return;
		}
		if ( count( $keys ) >= self::CACHE_INDEX_MAX ) {
			array_shift( $keys );
		}
		$keys[] = $key;
		update_option( self::CACHE_INDEX, $keys, false );
	}

	/**
	 * Flush the cache only when a map object is deleted.
	 *
	 * @since 1.0.0
	 * @param int     $post_id Deleted post ID.
	 * @param WP_Post $post    Deleted post object.
	 * @return void
	 */
	public static function flush_on_delete( $post_id, $post = null ) {
		if ( $post instanceof WP_Post && MVweb_OM_CPT::POST_TYPE === $post->post_type ) {
			self::flush_cache();
		}
	}

	/**
	 * Flush all cached object payloads.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function flush_cache() {
		$keys = get_option( self::CACHE_INDEX, array() );
		if ( is_array( $keys ) ) {
			foreach ( $keys as $key ) {
				delete_transient( $key );
			}
		}
		delete_option( self::CACHE_INDEX );
	}
}
